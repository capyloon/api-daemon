var gulp = require('gulp');
var concat = require('gulp-concat');
var uglify = require('gulp-uglify');

var vendorPaths = 'node_modules/phaser-ce/build/phaser.js';
var gamePaths = ['js/locale/en-us.js',
  'js/plugin/locale.js',
  'js/plugin/softkey.js',
  'js/constants.js',
  'js/view/score.js',
  'js/view/options.js',
  'js/view/about.js',
  'js/view/game-start.js',
  'js/view/menu.js',
  'js/view/splash.js',
  'js/game.js',
  'js/view/component/confirm.js',
  'js/view/component/pause.js',
  'js/view/component/score.js',
  'js/view/component/gameOver.js'];

gulp.task('uglify', function () {
  gulp.src(vendorPaths)
    .pipe(concat('vendor.js'))
    .pipe(uglify())
    .pipe(gulp.dest('./dist'))

  gulp.src(gamePaths)
    .pipe(concat('game.js'))
    .pipe(uglify().on('error', function(e){
      console.log(e);
    }))
    .pipe(gulp.dest('./dist'))
});

gulp.task('watch', function () {
  gulp.watch(vendorPaths, ['uglify'])
  gulp.watch(gamePaths, ['uglify'])
});

gulp.task('default', ['uglify'], function(){});
