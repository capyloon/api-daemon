var locale = {
  lang: null,
  getLocale: function() {
    return navigator.mozL10n.get;
  }
};
