var game = new Phaser.Game(
  240,
  320,
  Phaser.AUTO,
  'phaser-game'
);

var Render = {};//Need to use renderFiles

game.customConfig = Object.freeze({
  debug: false,
  fontStyle: Object.freeze({
    "font": "AvenirHeavy",
    "fontFamily": "Avenir",
    "fontSize": "16px",
    "fill": "#FFFFFF"
  })
});

var maxScore = localStorage.getItem(maxScoreStorage);
if (!maxScore)
  localStorage.setItem(maxScoreStorage, 0);

var sound = localStorage.getItem(soundStorage);
if (!soundStorage)
  localStorage.setItem(soundStorage, 'true');

var vibration = localStorage.getItem(vibrationStorage);
if (!vibrationStorage)
  localStorage.setItem(vibrationStorage, 'true');

game.state.add('splash', splash);
game.state.add('menu', menu);
game.state.add('game', game_start);
game.state.add('about', about);
game.state.add('options', options);
game.state.add('score', score);

game.state.start('splash');
