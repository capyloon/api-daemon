var fieldSize = 5;
var orbColors = 5;
var swapSpeed = 200;
var fallSpeed = 200;
var destroySpeed = 300;
var fastFall = true;
var skGroup;
var gameArray = [];
var removeMap = [];

var orbGroup;
var cloneGroup;

var selectedOrb;
var canPick = true;
var gameHeader = null;
var boardMarginTop = 60;
var boardMarginLeft = 10;
var selectorMarginTop = boardMarginTop + 5;
var selectorMarginLeft = boardMarginLeft;
var playTime = 60;
var bonusTimePrimaryMove = 4;
var bonusTimeSecondaryMove = 2;
var actualBonusTime = bonusTimePrimaryMove;

var timeLabel;
var scoreLabel;
var timer;
var scoreValue = 0;
var pointPerOrb = 1;
var bonusPointConstant = 1;
var accumulatedBonusPoints = 0;
var maxScore = 0;
var canPlay = true;

var plus1, plus3;

var shouldVibrate = false;
var previousState = null;
var game_start = {
  selectorPosition: [0, 0],
  selectorPositionPrevious: [0, 0],
  sofkey: null,
  selector: null,
  currentState: null,
  gameState: {
    INGAME: "INGAME",
    GAMEOVER: "GAMEOVER",
    OPTIONS: "OPTIONS",
    BACKSPACE: "BACKSPACE",
    ENDCALL: "ENDCALL"
  },
  moves : [],
  clusters: [],
  locale: null,
  create: function () {
    this.locale = locale.getLocale();
    this.switchState(this.gameState.INGAME);
    playTime = 60;
    this.selectorPosition = [0, 0];
    scoreValue = 0;
    selectedOrb = null;
    canPlay = true;


    this.toggleSound();
    this.toggleVibration();

    game.add.tileSprite(0, 0, 240, 320, 'bg');
    this.drawField(true);
    this.drawHeader();

    maxScore = localStorage.getItem(maxScoreStorage);
    canPick = true;
    this.formatTimer();
    this.bind();
    timer = game.time.create(false);
    timer.loop(Phaser.Timer.SECOND, this.updateCounter, this);
    timer.start();
  },
  toggleSound: function () {
    var shouldPlay = this.loadData(soundStorage);
    if (shouldPlay) {
      setTimeout(function () {
        if (!game.bgSound.isPlaying) {
          game.bgSound.loopFull();
          game.bgSound.play();
        }
      }, 400);
    } else {
      game.bgSound.stop();
    }
  },
  loadData: function (key) {
    var value = localStorage.getItem(key);

    if (null === value || undefined === value) {
      this.saveData(key, 'true');
      return true;
    } else {
      return JSON.parse(value);
    }
  },
  saveData: function (key, value) {
    localStorage.setItem(key, value);
  },
  // save the score and the MaxScore if is score is high
  saveGame: function(){
    localStorage.setItem(actualScore, scoreValue);
    this.maxScore = parseInt(localStorage.getItem(maxScoreStorage));

    if (scoreValue > this.maxScore) {
      localStorage.setItem(maxScoreStorage, scoreValue);
    }
  },
  toggleVibration: function () {
    shouldVibrate = ('true' === localStorage.getItem(vibrationStorage));
  },
  vibrate: function () {
    if (shouldVibrate) {
      navigator.vibrate(100);
    }
  },
  updateCounter: function () {
    playTime--;
    playTime = Math.abs(playTime);
    this.formatTimer();
    if (playTime == 0) {
      canPlay = false;
      timer.stop();
      this.switchState(this.gameState.GAMEOVER);
      Render.GameOver.show(this);
    }
  },
  formatTimer: function () {
    var minutes = Math.floor(playTime / 60);
    var seconds = playTime - (minutes * 60);
    if (seconds < 10) seconds = '0' + seconds;
    if (minutes < 10) minutes = '0' + minutes;

    timeLabel.setText(minutes + ':' + seconds);
  },
  switchState: function (nextState) {
    this.currentState = nextState;
  },
  bind: function () {
    var self = this;


    // arrow keys
    game.input.keyboard.addKey(Phaser.Keyboard.DOWN).onDown.add(this.moveSelectorDown, this);
    game.input.keyboard.addKey(Phaser.Keyboard.LEFT).onDown.add(this.moveSelectorLeft, this);
    game.input.keyboard.addKey(Phaser.Keyboard.RIGHT).onDown.add(this.moveSelectorRight, this);
    game.input.keyboard.addKey(Phaser.Keyboard.UP).onDown.add(this.moveSelectorUp, this);

    this.softkey = this.game.plugins.add(Phaser.Plugin.Softkey);

    skGroup = this.softkey.config({
      font: "AvenirMedium",
      fontSize: '16px',
      fontColor: '#fff',
      lsk: this.locale('restart'),
      rsk: this.locale('options'),
      csk: this.locale('select')
    });
    // should pause
    document.addEventListener('visibilitychange', function (e) {
      if (document.hidden) {
        if ('INGAME' === self.currentState) {
          self.showOptions();
        }
      }
    });

    skGroup.children.forEach(function (item) {
      item.setShadow(3, 3, 'rgba(0,0,0,0.3)', 5);
    });

    this.softkey.listener({
      debugMode: true,
      softLeft: function () {
        if (self.currentState === self.gameState.GAMEOVER) {
          game.bgSound.stop();
          game.state.start("menu");
        }
        if (self.currentState === self.gameState.INGAME) {
          game.state.start(game.state.current);
        }
        if (self.currentState === self.gameState.OPTIONS) {
          game.paused = false;
          game.bgSound.stop();
          game.state.start("menu");
        }
        if (self.currentState === self.gameState.BACKSPACE ||
          self.currentState === self.gameState.ENDCALL) {
          if (previousState != null) {
            self.switchState(previousState);
            previousState = null;
          } else {
            self.switchState(self.gameState.INGAME);
            game.paused = false;
          }
          skGroup.visible = true;
          Render.Confirm.hide();
        }
      },
      softRight: function () {
        if (self.currentState === self.gameState.INGAME) {
          self.showOptions();
        } else if (self.currentState === self.gameState.OPTIONS) {
          self.canMove = true;
          self.switchState(self.gameState.INGAME);
          game.paused = false;
          Render.Options.hide(self);
          skGroup.visible = true;
        } else if (self.currentState === self.gameState.GAMEOVER) {
          self.switchState(self.gameState.INGAME);
          game.state.start(game.state.current);
          Render.GameOver.hide(self);
        }

        if (self.currentState === self.gameState.BACKSPACE) {
          game.bgSound.stop();
          window.close();
        }
        if (self.currentState === self.gameState.ENDCALL) {
          game.paused = false;
          game.bgSound.stop();
          window.close();
        }
      },
      enter: function () {
        if (self.currentState === self.gameState.INGAME) {
          self.toggleSelect();
        } else if (self.currentState === self.gameState.OPTIONS) {
          Render.Options.select();
        }
      },
      backspace: function () {
        if (self.currentState == self.gameState.ENDCALL ||
          self.currentState == self.gameState.BACKSPACE) {
          return;
        }
        if (self.currentState == self.gameState.OPTIONS ||
          self.currentState == self.gameState.GAMEOVER) {
          previousState = self.currentState;
        }

        skGroup.visible = false;
        if (self.currentState == self.gameState.INGAME) {
          game.paused = true;
        }
        self.switchState(self.gameState.BACKSPACE);
        Render.Confirm.show(self.locale('confirmText'), self);
      },
      endCall: function () {
        if (self.currentState == self.gameState.ENDCALL ||
          self.currentState == self.gameState.BACKSPACE) {
          return;
        }
        if (self.currentState == self.gameState.OPTIONS) {
          previousState = self.currentState;
        }
        skGroup.visible = false;
        self.switchState(self.gameState.ENDCALL);
        Render.Confirm.show(self.locale('confirmText'), self);
      }
    });
  },
  showOptions: function () {
    this.canMove = false;
    this.switchState(this.gameState.OPTIONS);
    game.paused = true;
    Render.Options.show(this);
    skGroup.visible = false;
  },
  setSelectorPosition: function () {
    var x = (this.selectorPosition[0] * orbSize) + selectorMarginLeft;
    var y = (this.selectorPosition[1] * orbSize) + selectorMarginTop;

    var selectorTween = game.add.tween(this.selector).to({ x: x, y: y }, 200);
    selectorTween.onComplete.add(function () {
    });
    selectorTween.start();
  },
  moveSelectorToDiagonalLeftUp: function () {
    this.orbSelect();
    this.moveSelectorUp();
    this.moveSelectorLeft();
  },
  moveSelectorToDiagonalRightUp: function () {
    this.orbSelect();
    this.moveSelectorUp();
    this.moveSelectorRight();
  },

  moveSelectorToDiagonalRightDown: function () {
    this.orbSelect();
    this.moveSelectorDown();
    this.moveSelectorRight();
  },
  moveSelectorToDiagonalLeftDown: function () {
    this.orbSelect();
    this.moveSelectorDown();
    this.moveSelectorLeft();
  },
  moveSelectorDown: function (e) {
    if(this.currentState==this.gameState.OPTIONS)return;
    if (canPlay) {
      this.selectorPositionPrevious = Object.assign([],this.selectorPosition);
      if (this.selectorPosition[1] < fieldSize - 1) {
        this.selectorPosition[1]++;
      }
      this.setSelectorPosition();
      if (selectedOrb != null) {
        this.orbSelect();
      }
    }

  },
  moveSelectorUp: function (e) {
    if(this.currentState==this.gameState.OPTIONS)return;
    if (canPlay) {
      this.selectorPositionPrevious = Object.assign([],this.selectorPosition);
      if (this.selectorPosition[1] > 0) {
        this.selectorPosition[1]--;
      }
      this.setSelectorPosition();

      if (selectedOrb != null) {
        this.orbSelect();
      }
    }
  },
  moveSelectorLeft: function (e) {
    if(this.currentState==this.gameState.OPTIONS)return;
    this.selectorPositionPrevious = Object.assign([],this.selectorPosition);
    if (canPlay) {
      if (this.selectorPosition[0] > 0) {
        this.selectorPosition[0]--;
      }
      this.setSelectorPosition();
      if (selectedOrb != null) {
        this.orbSelect();
      }
    }
  },
  moveSelectorRight: function (e) {
    if(this.currentState==this.gameState.OPTIONS)return;
    this.selectorPositionPrevious = Object.assign([],this.selectorPosition);
    if (canPlay) {
      if (this.selectorPosition[0] < fieldSize - 1) {
        this.selectorPosition[0]++;
      }
      this.setSelectorPosition();
      if (selectedOrb != null) {
        this.orbSelect();
      }
    }
  },
  update: function () {},
  drawHeader: function () {
    gameHeader = game.add.group();

    var bgSprite = game.add.sprite(0, 0, 'header_bg');
    gameHeader.add(bgSprite);

    var timeTitle = game.add.text(10, 10,
      this.locale('time'), { font: '14px Avenir', fill: '#ffffff' });
    timeLabel = game.add.text(10, 25,
      '00:00', { font: '18px Avenir', fill: '#ffffff' });

    var scoreTitle = game.add.text(game.width - 47, 10,
      this.locale('score'), { font: '14px Avenir', fill: '#ffffff' });
    scoreLabel = game.add.text(game.width - 50, 25,
      '0000', { font: '18px Avenir', fill: '#ffffff' });

    gameHeader.add(timeTitle);
    gameHeader.add(scoreTitle);
    gameHeader.add(timeLabel);
    gameHeader.add(scoreLabel);

    plus1 = game.add.tileSprite(game.world.centerX, 30, 40, 40, 'plus1');
    plus1.anchor.set(0.5);
    plus1.alpha = 0;
    plus3 = game.add.tileSprite(game.world.centerX, 30, 40, 40, 'plus3');
    plus3.alpha = 0;
    plus3.anchor.set(0.5);
  },
  drawField: function (shouldCreateGroup) {
    if (shouldCreateGroup) {
      game.add.tileSprite(0, boardMarginTop - 1, 240, 240, 'board_bg');
      orbGroup = game.add.group();
      cloneGroup = game.add.group();
      this.selector = game.add.sprite(selectorMarginLeft, selectorMarginTop, 'selector');
    }

    for (var i = 0; i < fieldSize; i++) {
      gameArray[i] = [];
      for (var j = 0; j < fieldSize; j++) {
        var orb = game.add.sprite(
          orbSize * j + orbSize / 2,
          orbSize * i + orbSize / 2, "orbs");
        orb.anchor.set(0.5);
        orbGroup.add(orb);
        do {
          var randomColor = game.rnd.between(0, orbColors - 1);
          orb.frame = randomColor;
          gameArray[i][j] = {
            orbColor: randomColor,
            orbSprite: orb
          }
        } while (this.isMatch(i, j));
      }
    }

    if (selectedOrb)
      this.orbSelect();
    orbGroup.y = boardMarginTop + 5;
    orbGroup.x = boardMarginLeft;
    cloneGroup.y = boardMarginTop + 5;
    cloneGroup.x = boardMarginLeft;

    this.findMoves();
  },

  toggleSelect: function () {
    if (canPlay) {
      if (canPick) {
        this.orbSelect();
      } else {
        this.orbDeselect();
      }
      this.toggleCenterSoftKey();
    }
  },
  toggleCenterSoftKey: function () {
    if (null !== selectedOrb) {
      this.softkey.config({
        fontSize: '16px',
        fontColor: '#fff',
        lsk: this.locale('restart'),
        rsk: this.locale('options'),
        csk: this.locale('deselect')
      });
    } else {
      this.softkey.config({
        fontSize: '16px',
        fontColor: '#FFF',
        lsk: this.locale('restart'),
        rsk: this.locale('options'),
        csk: this.locale('select')
      });
    }
  },
  orbSelect: function () {
    var row, col;
    accumulatedBonusPoints = 0;
    actualBonusTime = bonusTimePrimaryMove;

    if (canPick) {
      row = this.selectorPosition[1];
      col = this.selectorPosition[0];
      var pickedOrb = this.gemAt(row, col);
      if (pickedOrb != -1) {
        if (selectedOrb == null) {
          pickedOrb.orbSprite.scale.setTo(1.2);
          pickedOrb.orbSprite.bringToTop();
          selectedOrb = pickedOrb;
          game.input.addMoveCallback(this.orbMove, this);
        }
        else {
          if (this.areTheSame(pickedOrb, selectedOrb)) {
            selectedOrb.orbSprite.scale.setTo(1);
            selectedOrb = null;
          }
          else {
            if (this.areNext(pickedOrb, selectedOrb)) {
              selectedOrb.orbSprite.scale.setTo(1);
              this.swapOrbs(selectedOrb, pickedOrb, true, this);
            }
            else {
              selectedOrb.orbSprite.scale.setTo(1);
              pickedOrb.orbSprite.scale.setTo(1.2);
              selectedOrb = pickedOrb;
              game.input.addMoveCallback(this.orbMove, this);
            }
          }
        }
      }
    }
  },

  orbDeselect: function (e) {
    game.input.deleteMoveCallback(this.orbMove, this);
  },

  orbMove: function (event, pX, pY) {
    if (event.id == 0 && selectedOrb != null) {
      var distX = pX - selectedOrb.orbSprite.x;
      var distY = pY - selectedOrb.orbSprite.y;
      var deltaRow = 0;
      var deltaCol = 0;

      if (Math.abs(distX) > orbSize / 2) {
        if (distX > 0) {
          deltaCol = 1;
        }
        else {
          deltaCol = -1;
        }
      } else {
        if (Math.abs(distY) > orbSize / 2) {
          if (distY > 0) {
            deltaRow = 1;
          }
          else {
            deltaRow = -1;
          }
        }
      }
      if (deltaRow + deltaCol != 0) {
        var pickedOrb = this.gemAt(this.getOrbRow(selectedOrb) + deltaRow, this.getOrbCol(selectedOrb) + deltaCol);
        if (pickedOrb != -1) {
          selectedOrb.orbSprite.scale.setTo(1);
          this.swapOrbs(selectedOrb, pickedOrb, true);
          game.input.deleteMoveCallback(this.orbMove, this);
        }
      }
    }
  },

  swapOrbs: function (orb1, orb2, swapBack) {
    canPick = false;
    var fromColor = orb1.orbColor;
    var fromSprite = orb1.orbSprite;
    var toColor = orb2.orbColor;
    var toSprite = orb2.orbSprite;
    gameArray[this.getOrbRow(orb1)][this.getOrbCol(orb1)].orbColor = toColor;
    gameArray[this.getOrbRow(orb1)][this.getOrbCol(orb1)].orbSprite = toSprite;
    gameArray[this.getOrbRow(orb2)][this.getOrbCol(orb2)].orbColor = fromColor;
    gameArray[this.getOrbRow(orb2)][this.getOrbCol(orb2)].orbSprite = fromSprite;
    var orb1Tween = game.add.tween(gameArray[this.getOrbRow(orb1)][this.getOrbCol(orb1)].orbSprite).to({
      x: this.getOrbCol(orb1) * orbSize + orbSize / 2,
      y: this.getOrbRow(orb1) * orbSize + orbSize / 2
    }, swapSpeed, Phaser.Easing.Linear.None, true);
    var orb2Tween = game.add.tween(gameArray[this.getOrbRow(orb2)][this.getOrbCol(orb2)].orbSprite).to({
      x: this.getOrbCol(orb2) * orbSize + orbSize / 2,
      y: this.getOrbRow(orb2) * orbSize + orbSize / 2
    }, swapSpeed, Phaser.Easing.Linear.None, true);
    orb2Tween.onComplete.add(function () {
      if (!this.matchInBoard() && swapBack) {
        this.swapOrbs(orb1, orb2, false);
        this.selectorPosition = Object.assign([], this.selectorPositionPrevious);
        this.setSelectorPosition();
      }
      else {
        if (this.matchInBoard()) {
          this.handleMatches();
        }
        else {
          canPick = true;
          selectedOrb = null;
          this.toggleCenterSoftKey();
        }
      }
    }.bind(this));
  },
  areNext: function (orb1, orb2) {
    return Math.abs(this.getOrbRow(orb1) - this.getOrbRow(orb2)) + Math.abs(this.getOrbCol(orb1) - this.getOrbCol(orb2)) == 1;
  },

  areTheSame: function (orb1, orb2) {
    return this.getOrbRow(orb1) == this.getOrbRow(orb2) && this.getOrbCol(orb1) == this.getOrbCol(orb2);
  },

  gemAt: function (row, col) {
    if (row < 0 || row >= fieldSize || col < 0 || col >= fieldSize) {
      return -1;
    }
    return gameArray[row][col];
  },

  getOrbRow: function (orb) {
    return Math.floor(orb.orbSprite.y / orbSize);
  },

  getOrbCol: function (orb) {
    return Math.floor(orb.orbSprite.x / orbSize);
  },

  isHorizontalMatch: function (row, col) {
    return this.gemAt(row, col).orbColor == this.gemAt(row, col - 1).orbColor && this.gemAt(row, col).orbColor == this.gemAt(row, col - 2).orbColor;
  },

  isVerticalMatch: function (row, col) {
    return this.gemAt(row, col).orbColor == this.gemAt(row - 1, col).orbColor && this.gemAt(row, col).orbColor == this.gemAt(row - 2, col).orbColor;
  },

  isMatch: function (row, col) {
    return this.isHorizontalMatch(row, col) || this.isVerticalMatch(row, col);
  },

  matchInBoard: function () {
    for (var i = 0; i < fieldSize; i++) {
      for (var j = 0; j < fieldSize; j++) {
        if (this.isMatch(i, j)) {
          return true;
        }
      }
    }
    return false;
  },

  handleMatches: function () {
    removeMap = [];
    for (var i = 0; i < fieldSize; i++) {
      removeMap[i] = [];
      for (var j = 0; j < fieldSize; j++) {
        removeMap[i].push(0);
      }
    }
    this.handleHorizontalMatches();
    this.handleVerticalMatches();
    this.destroyOrbs();
  },

  handleVerticalMatches: function () {
    for (var i = 0; i < fieldSize; i++) {
      var colorStreak = 1;
      var currentColor = -1;
      var startStreak = 0;
      for (var j = 0; j < fieldSize; j++) {
        if (this.gemAt(j, i).orbColor == currentColor) {
          colorStreak++;
        }
        if (this.gemAt(j, i).orbColor != currentColor || j == fieldSize - 1) {
          if (colorStreak >= 3) {
            for (var k = 0; k < colorStreak; k++) {
              removeMap[startStreak + k][i]++;
            }
          }
          startStreak = j;
          colorStreak = 1;
          currentColor = this.gemAt(j, i).orbColor;
        }
      }
    }
  },
  handleHorizontalMatches: function () {
    for (var i = 0; i < fieldSize; i++) {
      var colorStreak = 1;
      var currentColor = -1;
      var startStreak = 0;
      for (var j = 0; j < fieldSize; j++) {
        if (this.gemAt(i, j).orbColor == currentColor) {
          colorStreak++;
        }
        if (this.gemAt(i, j).orbColor != currentColor || j == fieldSize - 1) {
          if (colorStreak >= 3) {
            for (var k = 0; k < colorStreak; k++) {
              removeMap[i][startStreak + k]++;
            }
          }
          startStreak = j;
          colorStreak = 1;
          currentColor = this.gemAt(i, j).orbColor;
        }
      }
    }
  },
  updateScore: function (orbsDestroyed) {
    var scoreL = scoreValue = (orbsDestroyed + scoreValue);

    scoreL += '';
    switch (scoreL.length) {
      case 1:
        scoreL = '0' + scoreL;
      case 2:
        scoreL = '0' + scoreL;
      case 3:
        scoreL = '0' + scoreL;
    }
    scoreLabel.setText(scoreL);
  },

  updateTime: function (bonusTime) {
    playTime += bonusTime;
    this.animateBonusTime(bonusTime);
  },
  animateBonusTime: function (bonusTime) {
    var plus = bonusTime === bonusTimePrimaryMove ? plus3 : plus1;

    var sizeFadeIn = game.add.tween(plus.scale).to({ x: 1.2, y: 1.2 }, 500);
    var sizeFadeOut = game.add.tween(plus.scale).to({ x: 1, y: 1 }, 200);
    var tweenFadeIn = game.add.tween(plus).to({
      alpha: 1,
      scaleX: 2,
      scaleY: 2
    }, 500);
    var tweenFadeOut = game.add.tween(plus).to({
      alpha: 0,
      scaleX: 1,
      scaleY: 1
    }, 500);
    tweenFadeIn.chain(tweenFadeOut);
    tweenFadeIn.start();
    sizeFadeIn.chain(sizeFadeOut);
    sizeFadeIn.start();
  },
  destroyOrbs: function () {
    var destroyed = 0;
    for (var i = 0; i < fieldSize; i++) {
      for (var j = 0; j < fieldSize; j++) {
        if (removeMap[i][j] > 0) {
          var destroyTween = game.add.tween(gameArray[i][j].orbSprite).to({
            alpha: 0
          }, destroySpeed, Phaser.Easing.Linear.None, true);
          destroyed++;

          destroyTween.onComplete.add(function (orb) {
            orb.destroy();
            destroyed--;
            if (destroyed == 0) {
              this.vibrate();
              this.makeOrbsFall();
              if (fastFall) {
                this.replenishField();
              }
            }
          }.bind(this));
          gameArray[i][j] = null;
        }
      }
    }
    this.updateTime(actualBonusTime);
    actualBonusTime = bonusTimeSecondaryMove;
    this.updateScore(destroyed + (accumulatedBonusPoints * destroyed));
    accumulatedBonusPoints += bonusPointConstant;
  },
  makeOrbsFall: function () {
    var fallen = 0;
    var restart = false;
    for (var i = fieldSize - 2; i >= 0; i--) {
      for (var j = 0; j < fieldSize; j++) {
        if (gameArray[i][j] != null) {
          var fallTiles = this.holesBelow(i, j);
          if (fallTiles > 0) {
            if (!fastFall && fallTiles > 1) {
              fallTiles = 1;
              restart = true;
            }
            var orb2Tween = game.add.tween(gameArray[i][j].orbSprite).to({
              y: gameArray[i][j].orbSprite.y + fallTiles * orbSize
            }, fallSpeed, Phaser.Easing.Linear.None, true);
            fallen++;
            orb2Tween.onComplete.add(function () {
              fallen--;
              if (fallen == 0) {
                if (restart) {
                  this.makeOrbsFall();
                }
                else {
                  if (!fastFall) {
                    this.replenishField();
                  }
                }
              }
            }.bind(this));
            gameArray[i + fallTiles][j] = {
              orbSprite: gameArray[i][j].orbSprite,
              orbColor: gameArray[i][j].orbColor
            };
            gameArray[i][j] = null;
          }
        }
      }
    }
    if (fallen == 0) {
      this.replenishField();
    }
  },
  replenishField: function () {
    var replenished = 0;
    var restart = false;
    for (var j = 0; j < fieldSize; j++) {
      var emptySpots = this.holesInCol(j);
      if (emptySpots > 0) {
        if (!fastFall && emptySpots > 1) {
          emptySpots = 1;
          restart = true;
        }
        for (var i = 0; i < emptySpots; i++) {
          var orb = game.add.sprite(orbSize * j + orbSize / 2, -(orbSize * (emptySpots - 1 - i) + orbSize / 2), "orbs");
          orb.anchor.set(0.5);
          orbGroup.add(orb);
          var randomColor = game.rnd.between(0, orbColors - 1);
          orb.frame = randomColor;
          gameArray[i][j] = {
            orbColor: randomColor,
            orbSprite: orb
          };
          var orb2Tween = game.add.tween(gameArray[i][j].orbSprite).to({
            y: orbSize * i + orbSize / 2
          }, fallSpeed, Phaser.Easing.Linear.None, true);
          replenished++;
          orb2Tween.onComplete.add(function () {
            replenished--;
            if (replenished == 0) {
              if (restart) {
                this.makeOrbsFall();
              }
              else {
                if (this.matchInBoard()) {
                  game.time.events.add(250, this.handleMatches, this);
                }
                else {
                  canPick = true;
                  selectedOrb = null;
                  this.toggleCenterSoftKey();
                }

              }
            }
          }.bind(this))
        }
      }
    }
    this.findMoves();
  },
  showNoPlay: function () {
    var self = this;
    if (canPlay) {
      this.toggleCenterSoftKey();

      setTimeout(function () {
        if (canPick) {
          canPlay = false;
          timer.pause();
          canPick = false;
          var confirmBack = game.add.graphics();
          confirmBack.beginFill(0xe9e9e9, 0.9);
          confirmBack.drawRect(0, 59, 240, 230);

          var noPlayText = game.add.text(game.world.centerX, game.world.centerY,
            self.locale('possibleMoves'), {
              font: '20px Heavitas',
              fill: '#000',
              align: 'center'
            });

          noPlayText.wordWrap = true;
          noPlayText.wordWrapWidth = 160;
          noPlayText.setShadow(3, 3, 'rgba(0,0,0,0.5)', 5);
          noPlayText.anchor.set(0.5);
          noPlayText.setTextBounds(0, 0, 150, 100);
          var noPlayTextAnim = game.add.tween(noPlayText).to({ alpha: 1 }, 200, 'Linear', true).start();
          noPlayTextAnim.onComplete.add(function () {
            setTimeout(function () {
              noPlayText.destroy();
              confirmBack.destroy();
              self.recreateField();
              canPlay = true;
              if (selectedOrb) {
                self.orbSelect();
              }
            }, 2500);
          });
        }
      }, 600);
    }
  },
  holesBelow: function (row, col) {
    var result = 0;
    for (var i = row + 1; i < fieldSize; i++) {
      if (gameArray[i][col] == null) {
        result++;
      }
    }
    return result;
  },
  holesInCol: function (col) {
    var result = 0;
    for (var i = 0; i < fieldSize; i++) {
      if (gameArray[i][col] == null) {
        result++;
      }
    }
    return result;
  },
  swap: function(x1, y1, x2, y2) {
      var typeswap = gameArray[x1][y1].orbColor;
      gameArray[x1][y1].orbColor = gameArray[x2][y2].orbColor;
      gameArray[x2][y2].orbColor = typeswap;
  },
  findMoves: function() {
      this.moves = []
      for (var j=0; j<fieldSize; j++) {
          for (var i=0; i<fieldSize-1; i++) {
              this.swap(i, j, i+1, j);
              this.findClusters();
              this.swap(i, j, i+1, j);
              if (this.clusters.length > 0) {
                  this.moves.push({column1: i, row1: j, column2: i+1, row2: j});
              }
          }
      }
      for (var i=0; i<fieldSize; i++) {
          for (var j=0; j<fieldSize-1; j++) {
              this.swap(i, j, i, j+1);
              this.findClusters();
              this.swap(i, j, i, j+1);
              if (this.clusters.length > 0) {
                  this.moves.push({column1: i, row1: j, column2: i, row2: j+1});
              }
          }
      }
      if (this.moves.length === 0) {
        this.showNoPlay();
      }
      this.clusters = [];
  },
  findClusters: function () {
      this.clusters = [];
      for (var j=0; j<fieldSize; j++) {
          var matchlength = 1;
          for (var i=0; i<fieldSize; i++) {
              var checkcluster = false;
              if (i == fieldSize-1) {
                  checkcluster = true;
              } else {
                  if (gameArray[i][j].orbColor == gameArray[i+1][j].orbColor &&
                      gameArray[i][j].orbColor != -1) {
                      matchlength += 1;
                  } else {
                      checkcluster = true;
                  }
              }
              if (checkcluster) {
                  if (matchlength >= 3) {
                      this.clusters.push({ column: i+1-matchlength, row:j,
                                      length: matchlength, horizontal: true });
                  }
                  matchlength = 1;
              }
          }
      }
      for (var i=0; i<fieldSize; i++) {
          var matchlength = 1;
          for (var j=0; j<fieldSize; j++) {
              var checkcluster = false;
              if (j == fieldSize-1) {
                  checkcluster = true;
              } else {
                  if (gameArray[i][j].orbColor == gameArray[i][j+1].orbColor &&
                      gameArray[i][j].orbColor != -1) {
                      matchlength += 1;
                  } else {
                      checkcluster = true;
                  }
              }
              if (checkcluster) {
                  if (matchlength >= 3) {
                      this.clusters.push({ column: i, row:j+1-matchlength,
                                      length: matchlength, horizontal: false });
                  }
                  matchlength = 1;
              }
          }
      }
  },
  recreateField: function () {
    canPlay = false;
    var x = this.getRandomInt(0, fieldSize - 1);
    var y = this.getRandomInt(0, fieldSize - 1);

    var orb = this.gemAt(x, y).orbSprite;
    cloneGroup.add(orb);
    var transitionTween = game.add.tween(orb.scale).to({
      x: 42,
      y: 42
    }, 500);
    var self = this;
    game.add.tween(this.selector).to({ alpha: 0 }, 200).start();

    transitionTween.onComplete.add(function () {
      var reshufflingText = game.add.text(game.world.centerX, 167,
        self.locale('reshufflig'), { font: '20px Heavitas', fill: '#fff' });
      reshufflingText.anchor.set(0.5);
      reshufflingText.alpha = 0.1;

      var reshufflingTextAnim = game.add.tween(reshufflingText).to({ alpha: 1 }, 200, "Linear", true).start();
      var transitionTween2 = game.add.tween(orb.scale).to({
        x: 0,
        y: 0
      }, 400);
      setTimeout(function () {
        orbGroup.removeAll(true);
        self.drawField(false);
        transitionTween2.start();
        var reshufflingTextAnim2 = game.add.tween(reshufflingText).to({ alpha: 0 }, 300, "Linear", true).start();
        transitionTween2.onComplete.add(function () {
          reshufflingTextAnim2.onComplete.add(function () {
            reshufflingText.destroy();
          });

          cloneGroup.removeAll(true);
          game.add.tween(self.selector).to({ alpha: 1 }, 200).start();
          canPlay = true;
          canPick = true;
          timer.resume();
        });

      }, 1000);

    });

    transitionTween.start();
  },
  getRandomInt: function (min, max) {
    return Math.floor(Math.random() * (max - min + 1)) + min;
  }
};
