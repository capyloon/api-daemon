var menu = {
  gameState: {
    MENU: "MENU",
    BACKSPACE: "BACKSPACE",
    ENDCALL: "ENDCALL"
  },
  softkey: null,
  locale: null,
  currentState: null,
  switchState: function (nextState) {
    this.currentState = nextState;
  },
  create: function () {
    this.locale = locale.getLocale();
    this.switchState(this.gameState.MENU);
    game.add.tileSprite(0, 0, 240, 320, 'bg_menu');
    game.add.tileSprite(18, 35, 202, 103, 'logo');
    game.add.tileSprite(48, 190, 140, 42, 'btn_play');

    this.renderText();
    this.bind();
  },
  bind: function () {
    var self = this;
    this.softkey = this.game.plugins.add(Phaser.Plugin.Softkey);
    this.softkey.config({
      font: "AvenirHeavy",
      fontSize: "16px",
      fontColor: "#fff",
      lsk: this.locale('score'),
      rsk: this.locale('options')
    });
    this.softkey.listener({
      debugMode: true,
      softLeft: function () {
        if (self.currentState === self.gameState.BACKSPACE ||
          self.currentState === self.gameState.ENDCALL) {
          self.switchState(this.gameState.MENU);
          self.softkey.visible = true;
          Render.Confirm.hide();
          return;
        }
        game.state.start('score');
      },
      enter: function () {
        if (self.currentState !== self.gameState.BACKSPACE ||
          self.currentState !== self.gameState.ENDCALL) {
          game.state.start('game');
        }
      },
      softRight: function () {
        if (self.currentState === self.gameState.BACKSPACE ||
          self.currentState === self.gameState.ENDCALL) {
          game.paused = false;
          window.close();
          return;
        }
        game.state.start('options');
      }
    });
  },
  renderText: function () {
    //label play
    var label = this.game.add.text(this.game.world.centerX, game.height * 0.67, this.locale('play').toUpperCase(), { font: '14px AvenirHeavy', fill: '#ffffff' });
    label.anchor.setTo(0.5);
    label.fontWeight = 'bold';
  }
};
