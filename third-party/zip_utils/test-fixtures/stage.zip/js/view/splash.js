var orbSize = 44;

var splash = {
  locale: null,
  preload: function () {
    game.load.image('splash_logo', 'assets/kaios-logo.png');
    var arr = document.querySelectorAll('.fontPreload');
    for (var i = 0; i < arr.length; i++) {
      arr[i].remove();
    }
  },
  create: function () {
    this.locale = locale.getLocale();
    var logo = game.add.sprite(game.world.centerX, 140, 'splash_logo');
    logo.anchor.set(0.5);
    this.loadData(soundStorage);
    this.loadData(vibrationStorage);
    var start = game.add.text(game.world.centerX, game.world.centerY + 40, this.locale('presents'), {
      font: '20px Bebas Neue',
      fill: '#fff'
    });
    start.anchor.set(0.5);

    document.addEventListener('visibilitychange', function (e) {
      if (document.hidden) {
        game.sound.mute = true;
      } else {
        game.sound.mute = false;
      }
    });

    game.load.onLoadComplete.add(function () {
      game.bgSound = game.add.audio('bg_sound');
      game.bgSound.volume = 0.4;

      game.state.start('menu');
    }, this);
    this.start();
  },
  start: function () {
    game.load.image('bg_menu', 'assets/home-background.png');
    game.load.image('btn_play', "assets/btn-play.png");
    game.load.image('logo', "assets/logo-color.png");

    //dialog confirm
    game.load.image('bg-dialog', 'assets/dialog.png');

    // Game assets
    game.load.spritesheet("orbs", "assets/sprites/tile-colorful.png", orbSize, orbSize);
    game.load.spritesheet('selector', "assets/sprites/focus-select.png", orbSize, orbSize);
    game.load.image('board_bg', "assets/game-board.png");
    game.load.image('header_bg', "assets/header_footer_bg.png");
    game.load.image('no_play_bg', "assets/bg_50.png");
    game.load.spritesheet('plus1', "assets/sprites/bonus-time_1.png", 40, 40);
    game.load.spritesheet('plus3', "assets/sprites/bonus-time_3.png", 40, 40);

    //Options
    game.load.image('focus', 'assets/focus-options.png');
    game.load.image('on', 'assets/selector-on.png');
    game.load.image('off', 'assets/selector-off.png');

    // Game Over
    game.load.image('gameover_title', "assets/label-game_over.png");
    game.load.image('new_max_record', "assets/new-record.png");

    // Score
    game.load.image('score_title', "assets/label-dots.png");

    // About
    game.load.image('kaios_logo', "assets/logo-kaios.png");

    // BG Sound
    game.load.audio('bg_sound', ['assets/sounds/zazie.mp3']);

    game.load.start();
  },
  loadData: function (key) {
    var value = localStorage.getItem(key);
    if (null === value || undefined === value) {
      this.saveData(key, 'true');
      return 'true';
    }
    return value;
  },
  saveData: function (key, value) {
    localStorage.setItem(key, value);
  }
};
