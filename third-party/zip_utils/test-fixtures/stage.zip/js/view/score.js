var delay = 10;

var score = {
  score: 0,
  softkey: null,
  locale: null,
  gameState: {
    SCORE: "SCORE",
    BACKSPACE: "BACKSPACE",
    ENDCALL: "ENDCALL"
  },
  currentState: null,
  switchState: function (nextState) {
    this.currentState = nextState;
  },
  create: function () {
    this.locale = locale.getLocale();
    this.switchState(this.gameState.SCORE);
    this.softkey = this.game.plugins.add(Phaser.Plugin.Softkey);
    var background = game.add.graphics();
    background.beginFill(0xe9e9e9, 1);
    background.drawRect(0, 0, 240, 320);

    this.scoreTitle();
    this.renderText();
    this.bind();
  },
  scoreTitle: function () {

    var scoreTitleDots = game.add.sprite(game.width / 2, -20, 'score_title');
    scoreTitleDots.anchor.setTo(0, 0.5);
    game.add.tween(scoreTitleDots).to({x: game.width / 2, y: 70}, 600).start();

    var scoreTitle = game.add.text(game.width / 2, -20, this.locale('score').toUpperCase(), {
      font: '23px AvenirHeavy',
      fill: '#3f3f3f'
    });
    scoreTitle.anchor.setTo(1, 0.5);
    scoreTitle.fontWeight = 'bold';

    game.add.tween(scoreTitle, scoreTitleDots).to({x: game.width / 2, y: 70}, 600).start();
  },
  bind: function () {
    var self = this;
    this.softkey = this.game.plugins.add(Phaser.Plugin.Softkey);
    this.softkey.config({
      font: "AvenirHeavy",
      fontSize: "16px",
      fontColor: "#000",
      lsk: this.locale('home')
    });
    this.softkey.listener({
      debugMode: true,
      softLeft: function () {
        if (self.currentState === self.gameState.BACKSPACE ||
          self.currentState === self.gameState.ENDCALL) {
          self.switchState(self.gameState.MENU);
          self.softkey.visible = true;
          Render.Confirm.hide();
          return;
        }
        game.state.start('menu');
      },
      softRight: function () {
        if (self.currentState === self.gameState.BACKSPACE ||
          self.currentState === self.gameState.ENDCALL) {
          game.paused = false;
          window.close();
        }
      },
      backspace: function () {
        game.state.start('menu');
      }
    });
  },
  renderText: function () {
    var self = this;
    var scoreLabel = game.add.text(game.width / 2, 140, '0000',
      {font: '35px Avenir Black', fill: '#3f3f3f'});
    scoreLabel.fontWeight = 'bold';
    scoreLabel.anchor.setTo(0.5);

    var score = localStorage.getItem(maxScoreStorage);
    this.animationScore(score, scoreLabel, self);

  },
  animationScore: function(score, scoreLabel, self) {
    var initial = 1;
    var sumValue = 1;

    if (score > 0) {
      var interval = setInterval(function () {
        if ((score - initial) < 100) {
          sumValue = 1;
        } else {
          sumValue = 100;
        }
        initial += sumValue;
        scoreLabel.setText(self.formatScore(initial, 4));
        if (initial >= score) {
          clearInterval(interval);
        }
      }, delay);
    }
  },
  formatScore: function (num, size) {
    var s = num + "";
    while (s.length < size) {
      s = "0" + s;
    }
    return s;
  }
};
