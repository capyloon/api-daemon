var options = {
  listenerUp: null,
  listenerDown: null,
  focus: null,
  focus2: null,
  soundOn: null,
  soundOff: null,
  vibrationOn: null,
  vibrationOff: null,
  index: 0,
  softkey: null,
  vibrationText: null,
  soundText: null,
  locale: null,
  gameState: {
    OPTIONS: "OPTIONS",
    BACKSPACE: "BACKSPACE",
    ENDCALL: "ENDCALL"
  },
  currentState: null,
  switchState: function (nextState) {
    this.currentState = nextState;
  },
  create: function () {
    this.locale = locale.getLocale();
    this.switchState(this.gameState.OPTIONS);
    var background = game.add.graphics();
    background.beginFill(0xe9e9e9, 1);
    background.drawRect(0, 0, 240, 320);
    this.index = 0;
    this.createTitleOption();
    this.focus = game.add.tileSprite(25, 138, 190, 40, 'focus');
    this.focus.visible = true;
    this.focus2 = game.add.tileSprite(25, 178, 190, 40, 'focus');
    this.focus2.visible = false;

    this.soundOn = game.add.tileSprite(178, 151, 28, 15, 'on');
    this.soundOn.visible = false;
    this.soundOff = game.add.tileSprite(178, 151, 28, 15, 'off');
    this.soundOff.visible = false;

    this.vibrationOn = game.add.tileSprite(178, 191, 28, 15, 'on');
    this.vibrationOn.visible = false;
    this.vibrationOff = game.add.tileSprite(178, 191, 28, 15, 'off');
    this.vibrationOff.visible = false;

    this.renderText();
    this.bind();
    this.loadSound();
    this.loadVibration();
  },
  createTitleOption: function(){
    var optionsTitleDots = game.add.sprite(game.width / 2, -20, 'score_title');
    optionsTitleDots.anchor.setTo(0, 0.5);
    game.add.tween(optionsTitleDots).to({x: game.width / 2, y: 70}, 600).start();

    var optionsTitle = game.add.text(game.width / 2, -20, this.locale('options').toUpperCase(), {
      font: '23px AvenirHeavy',
      fill: '#3f3f3f'
    });
    optionsTitle.anchor.setTo(1, 0.5);
    optionsTitle.fontWeight = 'bold';

    game.add.tween(optionsTitle, optionsTitleDots).to({x: game.width / 2, y: 70}, 600).start();
  },
  bind: function () {
    var self = this;
    this.softkey = this.game.plugins.add(Phaser.Plugin.Softkey);
    this.softkey.config({
      fontSize: "16px",
      fontColor: "#000",
      lsk: this.locale('home'),
      rsk: this.locale('about'),
    });
    this.softkey.listener({
      debugMode: true,
      softLeft: function () {
        if (self.currentState === self.gameState.BACKSPACE ||
          self.currentState === self.gameState.ENDCALL) {
          self.switchState(self.gameState.MENU);
          self.softkey.visible = true;
          Render.Confirm.hide();
          return;
        }
        game.state.start('menu');
      },
      enter: function () {
        if (self.currentState !== self.gameState.BACKSPACE ||
          self.currentState !== self.gameState.ENDCALL) {
          self.select();
        }
      },
      softRight: function () {
        if (self.currentState === self.gameState.BACKSPACE ||
          self.currentState === self.gameState.ENDCALL) {
          game.paused = false;
          window.close();
          return;
        }
        game.state.start('about');
      },
      backspace: function () {
        game.state.start('menu');
      }
    });

    this.listenerUp = game.input.keyboard.addKey(Phaser.Keyboard.UP);
    this.listenerUp.onDown.add(this.up, this);

    this.listenerDown = game.input.keyboard.addKey(Phaser.Keyboard.DOWN);
    this.listenerDown.onDown.add(this.down, this);
  },
  renderText: function () {
    var style = game.customConfig.fontStyle;
    this.soundText = game.add.text(40, 148, this.locale('sound'), game.customConfig.fontStyle);
    this.vibrationText = game.add.text(40, 188, this.locale('vibration'), game.customConfig.fontStyle);
    this.soundText.addColor('#fff', 0);
    this.vibrationText.addColor('#000', 0);

  },
  select: function () {
    switch (this.index) {
      case 0:
        this.saveData(soundStorage, (!this.soundOn.visible).toString());
        this.loadSound();
        break;
      case 1:
        this.saveData(vibrationStorage, (!this.vibrationOn.visible).toString());
        this.loadVibration();
        break;
    }
  },
  up: function () {
    if (this.index === 1) {
      --this.index;
      this.focus.visible = true;
      this.focus2.visible = false;
      this.soundText.addColor('#fff', 0);
      this.vibrationText.addColor('#000', 0);
    }
  },
  down: function () {
    if (this.index < 1) {
      ++this.index;
      this.focus.visible = false;
      this.focus2.visible = true;
      this.vibrationText.addColor('#fff', 0);
      this.soundText.addColor('#000', 0);
    }
  },
  saveData: function (key, value) {
    localStorage.setItem(key, value);
  },
  loadData: function (key) {
    var value = localStorage.getItem(key);

    if (null === value || undefined === value) {
      this.saveData(key, 'true');
      return 'true';
    }
    if (value) {
      return value;
    }
  },
  loadSound: function () {
    var sound = this.loadData(soundStorage);
    this.soundOn.visible = ('true' === sound);
    this.soundOff.visible = ('false' === sound);
  },
  loadVibration: function () {
    var vibration = this.loadData(vibrationStorage);
    this.vibrationOn.visible = ('true' === vibration);
    this.vibrationOff.visible = ('false' === vibration);
  }
};
