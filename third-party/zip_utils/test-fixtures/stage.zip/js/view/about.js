var about = {
  softkey: null,
  locale: null,
  gameState: {
    ABOUT: "ABOUT",
    BACKSPACE: "BACKSPACE",
    ENDCALL: "ENDCALL"
  },
  currentState: null,
  switchState: function (nextState) {
    this.currentState = nextState;
  },
  create: function () {
    this.locale = locale.getLocale();
    this.switchState(this.gameState.ABOUT);
    var background = game.add.graphics();
    background.beginFill(0xe9e9e9, 1);
    background.drawRect(0, 0, 240, 320);
    this.createTitleAbout();
    this.renderText();
    this.bind();
  },
  createTitleAbout: function () {
    var aboutTitleDots = game.add.sprite(game.width / 2, -20, 'score_title');
    aboutTitleDots.anchor.setTo(0, 0.5);
    game.add.tween(aboutTitleDots).to({x: game.width / 2, y: 55}, 600).start();

    var aboutTitle = game.add.text(game.width / 2, -20, this.locale('about').toUpperCase(), {
      font: '23px AvenirHeavy',
      fill: '#3f3f3f'
    });
    aboutTitle.anchor.setTo(1, 0.5);
    aboutTitle.fontWeight = 'bold';

    game.add.tween(aboutTitle, aboutTitleDots).to({x: game.width / 2, y: 55}, 600).start();

    game.add.sprite(game.width / 2, 250, 'kaios_logo').anchor.setTo(1, 0.5);
  }
  ,

  bind: function () {
    var self = this;
    this.softkey = this.game.plugins.add(Phaser.Plugin.Softkey);
    this.softkey.config({
      fontSize: "16px",
      fontColor: "#000",
      lsk: this.locale('home')
    });
    this.softkey.listener({
      debugMode: true,
      softLeft: function () {
        if (self.currentState === self.gameState.BACKSPACE ||
          self.currentState === self.gameState.ENDCALL) {
          self.switchState(self.gameState.MENU);
          self.softkey.visible = true;
          Render.Confirm.hide();
          return;
        }
        game.state.start('menu');
      },
      softRight: function () {
        if (self.currentState === self.gameState.BACKSPACE ||
          self.currentState === self.gameState.ENDCALL) {
          game.paused = false;
          window.close();
        }
      },
      backspace: function () {
        game.state.start('options');
      }
    });
  },
  renderText: function () {
    var wordWrapWidth = 180;
    var texto = game.add.text(20, 100,
      this.locale('aboutText'),
      {font: '16px AvenirHeavy', fill: '#3f3f3f', align: "left"});
    texto.wordWrap = true;
    texto.wordWrapWidth = wordWrapWidth;

    var credits = game.add.text(20, 155, this.locale('zazieMusic')
      + this.locale('licensedCC'),
      {
        font: '11px AvenirHeavy',
        fill: '#3f3f3f',
        align: "left"
      });
    credits.wordWrap = true;
    credits.wordWrapWidth = wordWrapWidth;

  }
};
