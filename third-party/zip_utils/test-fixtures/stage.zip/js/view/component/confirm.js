
Render.Confirm = {
    show: function (text, self) {
        this.confirmGroup = game.add.group();
        var confirmBack = game.add.graphics();
        confirmBack.beginFill(0x1a0129, 0.9);
        confirmBack.drawRect(0, 0, 240, 320);

        var skConfirm = self.game.plugins.add(Phaser.Plugin.Softkey).config({
            fontSize: "16px",
            fontColor: "#ffffff",
            lsk: self.locale('cancel'),
            rsk: self.locale('quit')
        });

        var logo = game.add.image(game.world.centerX, game.world.centerY - 50, 'logo');
        logo.anchor.setTo(0.5);

        var dialog = game.add.image(game.world.centerX, game.height - 80, 'bg-dialog');
        dialog.anchor.setTo(0.5);

        var txt = game.add.text(dialog.x, dialog.y, text, { fontSize: 16, align: "center", fill: "#0a0a0a" });
        txt.anchor.setTo(0.5);
        txt.wordWrap = true;
        txt.wordWrapWidth = 200;

        this.confirmGroup.addMultiple([confirmBack, skConfirm, logo, dialog, txt]);
    },
    hide: function () {
        this.confirmGroup.removeAll();
    }
};
