Render.Score = function (self) {
  var style1 = Object.assign({}, game.customConfig.fontStyle);
  var stylehScorePoints = Object.assign({}, game.customConfig.fontStyle);
  var style2 = Object.assign({}, game.customConfig.fontStyle);
  style1.fontSize = 14;
  stylehScorePoints.fontSize = 18;
  style1.align = "center";
  self.hscoreTxt = game.add.text(game.world.centerX, 17, self.locale('bestScore'), style1);
  self.hscoreTxt.anchor.setTo(0.5);
  self.hscoreTxt.lineSpacing = -6;
  self.hscorePoints = game.add.text(0, 16, self.highScore, stylehScorePoints);
  self.hscorePoints.anchor.setTo(0.5);
  self.hscoreTxt.addChild(self.hscorePoints);

  style2.fontSize = 22;
  self.scoreText = game.add.text(game.world.centerX, game.height - 20, '', style2);
  self.scoreText.anchor.setTo(0.5);
  self.scoreText.lineSpacing = -10;
};
