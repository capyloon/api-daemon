var _self;
Render.Options = {
  show: function (self) {
    _self = self;
    self.switchState(self.gameState.OPTIONS);
    this.optionsGroup = game.add.group();

    var background = game.add.graphics();
    background.beginFill(0xffd800, 0.9);
    background.drawRect(0, 0, 240, 320);

    var skOptions = self.game.plugins.add(Phaser.Plugin.Softkey).config({
      fontSize: "16px",
      fontColor: "#000000",
      lsk: _self.locale('home'),
      rsk: _self.locale('resume')
    });

    this.focus = game.add.sprite(game.world.centerX, 190, 'focus');
    this.focus.anchor.setTo(0.5);
    this.focus.visible = true;
    this.focus2 = game.add.sprite(game.world.centerX, 228, 'focus');
    this.focus2.anchor.setTo(0.5);
    this.focus2.visible = false;

    this.soundOn = game.add.tileSprite(180, 183, 28, 15, 'on');
    this.soundOn.visible = false;
    this.soundOff = game.add.tileSprite(180, 183, 28, 15, 'off');
    this.soundOff.visible = false;

    this.vibrationOn = game.add.tileSprite(180, 223, 28, 15, 'on');
    this.vibrationOn.visible = false;
    this.vibrationOff = game.add.tileSprite(180, 223, 28, 15, 'off');
    this.vibrationOff.visible = false;

    this.index = 0;
    self.listenerUp = game.input.keyboard.addKey(Phaser.Keyboard.UP).onDown.add(function () {

      if (this.index === 1) {
        --this.index;
        this.focus.visible = true;
        this.focus2.visible = false;
      }
    }, this);

    self.listenerDown = game.input.keyboard.addKey(Phaser.Keyboard.DOWN).onDown.add(function () {
      if (this.index < 1) {
        ++this.index;
        this.focus.visible = false;
        this.focus2.visible = true;
      }
    }, this);
    this.loadSound();
    this.loadVibration();

    var style = Object.assign({}, game.customConfig.fontStyle);
    style.fontSize = "24px";
    var sound = game.add.text(43, 180, _self.locale('sound'), game.customConfig.fontStyle);
    sound.setShadow(3, 3, 'rgba(0,0,0,0.3)', 5);
    var vibration = game.add.text(43, 220, _self.locale('vibration'), game.customConfig.fontStyle);
    vibration.setShadow(3, 3, 'rgba(0,0,0,0.3)', 5);

    var optionsTitleDots = game.add.sprite(game.width / 2, 100, 'score_title');
    optionsTitleDots.anchor.setTo(0, 0.5);

    var optionsTitle = game.add.text(game.width / 2, 100, _self.locale('options').toUpperCase(), {
      font: '23px AvenirHeavy',
      fill: '#3f3f3f'
    });
    optionsTitle.anchor.setTo(1, 0.5);
    optionsTitle.fontWeight = 'bold';

    this.optionsGroup.addMultiple([background, this.focus, optionsTitle,optionsTitleDots ,this.focus2, sound, vibration,
      this.vibrationOn, this.vibrationOff, this.soundOff, this.soundOn, skOptions]);
  },
  hide: function () {
    this.optionsGroup.removeAll();
  },
  select: function () {
    switch (this.index) {
      case 0:
        this.saveData(soundStorage, (!this.soundOn.visible).toString());
        this.loadSound();
        break;
      case 1:
        this.saveData(vibrationStorage, (!this.vibrationOn.visible).toString());
        this.loadVibration();
        break;
    }
  },
  saveData: function (key, value) {
    localStorage.setItem(key, value);
  },
  loadData: function (key) {
    var value = localStorage.getItem(key);
    if (null === value || undefined === value) {
      this.saveData(key, 'true');
      return 'true';
    }
    return value;
  },
  loadSound: function () {
    var sound = this.loadData(soundStorage);
    _self.toggleSound();
    this.soundOn.visible = ('true' === sound);
    this.soundOff.visible = ('false' === sound);
  },
  loadVibration: function () {
    var vibration = this.loadData(vibrationStorage);
    _self.toggleVibration();
    this.vibrationOn.visible = ('true' === vibration);
    this.vibrationOff.visible = ('false' === vibration);
  }
};
