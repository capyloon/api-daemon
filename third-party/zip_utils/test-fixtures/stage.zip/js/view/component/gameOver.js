Render.GameOver = {
  show: function (self) {
    self.gameOverGroup = game.add.group();
    self.switchState(self.gameState.GAMEOVER);

    var background = game.add.graphics();
    background.beginFill(0xfa1919, 0.9);
    background.drawRect(0, 0, 240, 320);

    var skGameOver = self.game.plugins.add(Phaser.Plugin.Softkey).config({
      font: "Avenir",
      fontSize: "14px",
      fontColor: "#ffffff",
      lsk: self.locale('home'),
      rsk: self.locale('restart')
    });
    var scoreTitleImage = game.add.text(5, -20, self.locale('gameOver'), {font: '43px Heavitas', fill: '#fff', align: 'center'});
    scoreTitleImage.wordWrap = true;
    scoreTitleImage.anchor.setTo(0, 0.5);
    scoreTitleImage.wordWrapWidth = self.game.width / 2;

    var newMaxScore = game.add.sprite(31, 143, 'new_max_record');
    newMaxScore.scale.x = 0;
    newMaxScore.scale.y = 0;
    newMaxScore.alpha = 0;

    var newRecord = game.add.text(scoreTitleImage.x + 15 + (scoreTitleImage.width / 2), 160 ,self.locale('newRecord').toUpperCase(), {font: '14px Avenir', fill: '#ff0000'});
    newRecord.anchor.setTo(0.5);
    newRecord.alpha = 0;
    newRecord.scale.x = 0;
    newRecord.scale.y = 0;
    newRecord.fontWeight = 'bold';


    game.add.tween(scoreTitleImage).to({x: 0, y: 70}, 600).start();

    this.actualScore = scoreValue;
    this.maxScore = parseInt(localStorage.getItem(maxScoreStorage));

    if (this.actualScore > this.maxScore) {
      localStorage.setItem(maxScoreStorage, scoreValue);
      game.add.tween(newMaxScore).to({alpha: 1}).start();
      game.add.tween(newMaxScore.scale).to({x: 1, y: 1}).start();
      game.add.tween(newRecord).to({alpha: 1}).start();
      game.add.tween(newRecord.scale).to({ x: 1, y: 1}).start();
    }
    var scoreTitle = game.add.text(30, 180, self.locale('score'),
      {font: '16px Avenir Heavy', fill: '#ffffff', align: "right"});
    var scoreLabel = game.add.text(30, 207, '0000',
      {font: '40px Avenir Heavy', fill: '#ffffff', align: "right"});
    scoreLabel.fontWeight = 'bold';
    var score = this.actualScore;
    var initial = 0;
    var delay = 50;
    var compareVal = parseInt(score * 0.9);
    var sumValue = 1;
    if (score > 0) {
      if (score > 100) {
        delay = 10;
        compareVal = parseInt(score * 0.95);
        sumValue = 3;
      }
      var interval = setInterval(function () {
        initial += sumValue;
        scoreLabel.setText(this.formatScore(initial, 4));
        if (initial >= compareVal) {
          delay = 130;
          clearInterval(interval);
          interval = setInterval(function () {
            scoreLabel.setText(this.formatScore(initial++, 4));
            if (initial > score) {
              clearInterval(interval);
            }
          }.bind(this), delay);
        }
      }.bind(this), delay);
    }
  },
  hide: function () {

  },
  formatScore: function (num, size) {
    var s = num + "";
    while (s.length < size) {
      s = "0" + s;
    }
    return s;
  }
};
