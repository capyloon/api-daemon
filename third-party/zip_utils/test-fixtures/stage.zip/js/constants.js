var maxScoreStorage = 'color-crumbs-max-score';
var actualScore = 'color-crumbs-actual-score';
var soundStorage = 'color-crumbs-sound';
var vibrationStorage = 'color-crumbs-vibration';