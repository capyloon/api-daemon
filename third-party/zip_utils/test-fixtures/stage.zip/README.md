If you have python, just execute:

python -m SimpleHTTPServer 8080

COMMANDS
--------
  - "Enter" is the CSK
  - "1" is the LSK
  - "2" is the RSK
  
HOW TO PLAY
-----------
  - In the game, press "Enter" to toggle select or deselect state;
  - Use the arrow keys to navigate in the board;
  - If one orb is selected, using arrow keys will make the orbs swap 
  places;
  - If the board does not have any possible combination, the game will
  reshuffle the board;
  - You start with 1 minute to make your combinations;
  - Every time you make a combination, you'll receive 3 seconds to play 
  and 1 point for each orb you have destroyed.
  - The subsequent wave of combinations (if there are combinations but 
  you didn't move the orbs), you'll receive 1 extra second and 2 points 
  per orb. 
  - Every subsequent combination (again, if you didn't move the orbs) 
  will add 1 point per wave of combinations, but the bonus time will 
  remain 1 second per wave; 