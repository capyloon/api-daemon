'use strict';
if (typeof window.debug !== 'function') {
  window.DEBUG_LEVEL = 0;
  window.log = function () {
    if (window.DEBUG_LEVEL > 0) {
      console.log.apply(console,
        arguments);
    }
  };
  window.debug = function () {
    if (window.DEBUG_LEVEL > 1) {
      console.log.apply(console,
        arguments);
    }
  };
}

if (typeof window.$ !== 'function') {
  window.$ = function (id) {
    return typeof id === 'string'
      ? document.getElementById(id)
      : id;
  };
}

if (typeof window.lget !== 'function') {
  window.lget = function (l10nId) {
    return navigator.mozL10n.get(l10nId);
  };
}

if (typeof String.prototype.startsWith !== 'function') {
  String.prototype.startsWith = function (prefix) {
    return prefix === this.slice(0,
      prefix.length);
  };
}

if (typeof String.prototype.contains !== 'function') {
  String.prototype.contains = function (substr) {
    return -1 !== this.indexOf(substr);
  };
}

if (typeof Array.prototype.contains !== 'function') {
  Array.prototype.contains = function (item) {
    return -1 !== this.indexOf(item);
  };
}

if (typeof Array.prototype.bsearch !== 'function') {
  Array.prototype.bsearch = function (key, cmp) {
    let low = 0;
    let high = this.length - 1;
    while (low <= high) {
      const mid = low + high >> 1;
      const result = cmp(key,
        this[mid]);
      if (result < 0) {
        high = mid - 1;
      } else if (result > 0) {
        low = mid + 1;
      } else {
        return mid;
      }
    }
    return -1;
  };
}

const Utilities = {
  bindClick(prefix, postfix, func, idParams, bindObj) {
    if (undefined === bindObj) {
      bindObj = null;
    }
    for (let idParam of idParams) { // eslint-disable-line
      $(prefix + idParam[0] + postfix).onclick = func.bind(bindObj,
        idParam[1]);
    }
  },

  getLoopNum(min, max, num, increase, delta) {
    let newNum;
    if (undefined === delta) {
      delta = 1;
    }
    if (increase) {
      if (num >= max) {
        newNum = min;
      } else {
        num += delta;
        newNum = num > max ? max : num;
      }
    } else if (num <= min) {
      newNum = max;
    } else {
      num -= delta;
      newNum = num < min ? min : num;
    }
    return newNum;
  }
};

/*
 * /////////////////
 * / Set the variable of your localization string to 'var' when using the Message.show().
 * / eg: "{{var}}" selected
 * /////////////////
 */
const Message = {
  show(l10nId, args) {
    this.showEx(l10nId,
      args);
  },

  showEx(l10nId, args) {
    const options = {
      messageL10nId: l10nId,
      messageL10nArgs: args,
      latency: 2000,
      useTransition: false
    };
    Toaster.showToast(options);
  }
};
