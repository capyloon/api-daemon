'use strict';
(function (exports) {
  const InAlbum = {
    thumbnailList: null,
    container: null,
    isSystem: false,
    albumId: null,
    albumItem: null,
    newAlbumName: null,
    firstLoadImages: 35,
    firstLoadImageNames: [],
    systemEmpty: {
      src: null,
      titletext: 'No Photos',
      description: null,
      emptyBtn: null
    },
    notSystemEmpty: {
      src: null,
      titletext: 'No Photos',
      description: null,
      emptyBtn: {
        class: 'add-photos',
        text: 'ADD PHOTOS',
        clickCallback: null
      }
    },

    enterAnAlbum(albumItem) {
      this.isSystem = albumItem.data.isSystem;
      this.albumId = albumItem.data.id;
      this.albumItem = albumItem;
      this.setHeaderTitle(albumItem.data);
      this.setMenuOption(albumItem.data);
      View.switchView(View.views.inAlbumView);
      this.initContainer();
      if (albumItem.data.photos.length === 0) {
        this.notSystemEmpty.emptyBtn.clickCallback = this.addPhotos.bind(this);
        Overlay.inAlbumView = albumItem.data.isSystem
          ? this.systemEmpty : this.notSystemEmpty;
        Overlay.showEmptyPage(View.views.inAlbumView);
      } else {
        this.createInAlbumThumbnails();
      }
    },

    initContainer() {
      if (this.container) {
        return;
      }
      this.container = document.querySelector('#inalbum');
      this.thumbnailList =
        new ThumbnailList(ThumbnailDateGroup,
          this.container);
      this.lazyLoadImage = new LazyLoadImage();
      this.lazyLoadImage.init(this.container);
    },

    setHeaderTitle(albumFile) {
      let title = albumFile.name;
      if (albumFile.isSystem) {
        title = navigator.mozL10n.get(albumFile.name);
      }
      View.headers.inAlbumView.title = title;
    },

    setMenuOption(albumFile) {
      let options = null;
      if (!albumFile.isSystem) {
        options = [
          Options.items.addPhotos,
          Options.items.renameAlbum,
          Options.items.deleteAlbum
        ];
        Options.items.renameAlbum.callback = this.renameAlbum.bind(this);
        Options.items.deleteAlbum.callback = this.deleteAlbum.bind(this);
        Options.items.addPhotos.callback = this.addPhotos.bind(this);
      }
      View.headers.inAlbumView.menuoptions = options;
    },

    exitAnAlbum() {
      this.thumbnailList.reset();
      this.albumId = null;
      if (Overlay.current === 'emptygallery') {
        Overlay.hideEmptyPage();
      }
      View.switchView(View.views.albumsView);
    },

    createInAlbumThumbnails() {
      const allThumbnails = Photos.thumbnailList.getAllThumbnails();
      if (this.albumItem.data.photos.length >= this.firstLoadImages) {
        this.create(allThumbnails,
          true);
        this.lazyLoadImage.render();
        clearTimeout(this.timeOut);
        this.timeOut = setTimeout(() => {
          this.create(allThumbnails,
            false);
          this.lazyLoadImage.render();
        }, 300);
      } else {
        this.create(allThumbnails,
          true);
        this.lazyLoadImage.render();
      }
      this.container.scrollTop = 0;
    },

    create(thumbnails, isFirstLoad) {
      for (let item of thumbnails) { // eslint-disable-line
        if (item.data.metadata.albums &&
          item.data.metadata.albums.contains(this.albumId)) {
          if (isFirstLoad) {
            this.thumbnailList.addItem(item.data,
              false);
            this.firstLoadImageNames.push(item.data.name);
            if (this.firstLoadImages === this.thumbnailList.getCount()) {
              break;
            }
          } else if (!this.firstLoadImageNames.contains(item.data.name)) {
            this.thumbnailList.addItem(item.data,
              false);
            if (this.albumItem.data.photos.length ===
                this.thumbnailList.getCount()) {
              break;
            }
          }
        }
      }
    },

    deletePhoto(fileInfo) {
      this.thumbnailList.removeItem(fileInfo.data,
        false);
    },

    deletePhotos(deleteFiles, callback, deleteDone) {
      Photos.deletePhotos(deleteFiles,
        callback,
        deleteDone);
    },

    addPhotos() {
      PickMore.enterPickmoreView();
    },

    deleteAlbum() {
      const message = navigator.mozL10n.get('dialog-delete-n-albums',
        { n: 1 });
      Dialog.delete.message = message;
      Dialog.showDialog(Dialog.delete,
        null,
        this.deleteAlbumFile.bind(this));
    },

    deleteAlbumFile() {
      Dialog.hideDialog();
      const files = [];
      files.push(this.albumItem);
      Album.deleteAlbums(files);
      this.exitAnAlbum();
    },

    renameAlbum() {
      this.renameInput = Album.createNameInput(this.albumItem.data.name,
        this.renameInputNameChanged.bind(this));
      Dialog.showDialog(Dialog.renameAlbum,
        this.renameInput,
        this.rename.bind(this));
      Dialog.dialog.primarybtndisabled = true;
    },

    renameInputNameChanged(e) {
      this.newAlbumName = e.detail.value;
      this.renameInput.errorstate = false;
      if (this.newAlbumName === '' ||
        this.newAlbumName === this.albumItem.data.name) {
        Dialog.dialog.primarybtndisabled = true;
      } else {
        Dialog.dialog.primarybtndisabled = false;
      }
    },

    rename() {
      const validity = Album.checkNameValidity(this.newAlbumName,
        this.renameInput);
      if (!validity) {
        return;
      }
      const albumFile = Album.albumsFiles[this.albumId];
      albumFile.name = this.newAlbumName;
      Album.updateAlbumStorage();
      View.header.setAttribute('title',
        this.newAlbumName);
      this.albumItem.albumName.innerHTML = this.newAlbumName;
      Dialog.hideDialog();
    }
  };
  exports.InAlbum = InAlbum;
}(window));
