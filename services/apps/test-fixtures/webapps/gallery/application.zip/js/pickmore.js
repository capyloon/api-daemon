'use strict';
(function (exports) {
  const PickMore = {
    thumbnailList: null,
    container: null,
    firstLoadImages: 35,
    pickThumbnailCount: 0,
    firstLoadImageNames: [],
    pickItems: [],
    addBtn: null,

    enterPickmoreView() {
      View.switchView(View.views.pickMoreView);
      this.initContainer();
      const count = Photos.thumbnailList.getCount();
      const largeSizeCount =
        Photos.container.querySelectorAll('.largeSize').length;
      this.pickThumbnailCount = count - largeSizeCount;
      if (count === largeSizeCount) {
        Overlay.showEmptyPage(View.views.pickMoreView);
      } else {
        Overlay.hideEmptyPage();
        this.createPickThumbnails();
      }
    },

    exitPickmoreView() {
      this.pickItems = [];
      this.firstLoadImageNames = [];
      this.addBtn.disabled = true;
      this.thumbnailList.reset();
      if (Overlay.current === 'emptygallery') {
        Overlay.hideEmptyPage();
      }
      View.switchView(View.views.inAlbumView);
      if (!InAlbum.albumItem.data.photos.length) {
        Overlay.showEmptyPage(View.views.inAlbumView);
      }
    },

    initContainer() {
      if (this.container) {
        return;
      }
      this.addBtn = document.querySelector('.add-photo');
      this.addBtn.addEventListener('click',
        this.addBtnClickCallback.bind(this));
      this.container = document.querySelector('#pickphotos');
      this.thumbnailList =
        new ThumbnailList(ThumbnailDateGroup,
          this.container);
      this.lazyLoadImage = new LazyLoadImage();
      this.lazyLoadImage.init(this.container);
    },

    createPickThumbnails() {
      const allThumbnails = Photos.thumbnailList.getAllThumbnails();
      if (this.pickThumbnailCount >= this.firstLoadImages) {
        this.create(allThumbnails,
          true);
        this.lazyLoadImage.render();
        clearTimeout(this.timeOut);
        this.timeOut = setTimeout(() => {
          this.create(allThumbnails,
            false);
          this.lazyLoadImage.render();
        }, 300);
      } else {
        this.create(allThumbnails,
          true);
        this.lazyLoadImage.render();
      }
      this.container.scrollTop = 0;
    },

    create(thumbnails, isFirstLoad) {
      for (let item of thumbnails) { // eslint-disable-line
        if (isFirstLoad && !item.data.metadata.largeSize) {
          const newItem = this.thumbnailList.addItem(item.data,
            true);
          this.disableAlreadyInAlbumPhoto(newItem);
          this.firstLoadImageNames.push(item.data.name);
          if (this.firstLoadImages === this.thumbnailList.getCount()) {
            break;
          }
        } else if (!this.firstLoadImageNames.contains(item.data.name) &&
            !item.data.metadata.largeSize) {
          const newItem = this.thumbnailList.addItem(item.data,
            true);
          this.disableAlreadyInAlbumPhoto(newItem);
        }
      }
    },

    disableAlreadyInAlbumPhoto(item) {
      const alreadyInAlbumPhotos = InAlbum.albumItem.data.photos;
      if (!alreadyInAlbumPhotos.contains(item.data.name)) {
        return;
      }
      item.htmlNode.classList.add('disabled');
      item.selector.setAttribute('data-icon',
        'tick');
    },

    updatePick(item) {
      if (item.htmlNode.classList.contains('disabled')) {
        return;
      }
      item.htmlNode.classList.toggle('selected');
      const picked = item.htmlNode.classList.contains('selected');
      if (picked) {
        item.selector.setAttribute('data-icon',
          'tick');
        this.pickItems.push(item);
      } else {
        item.selector.removeAttribute('data-icon');
        const fileName = item.data.name;
        for (let i = 0; i < this.pickItems.length; i++) {
          if (fileName === this.pickItems[i].data.name) {
            this.pickItems.splice(i,
              1);
            break;
          }
        }
      }
      const pickedCount = this.pickItems.length;
      View.header.setAttribute('title',
        `${pickedCount} Selected`);
      if (!pickedCount) {
        this.addBtn.disabled = true;
      } else {
        this.addBtn.disabled = false;
      }
    },

    addBtnClickCallback() {
      Array.forEach(this.pickItems,
        (item) => {
          Album.addPhoto(InAlbum.albumId,
            item);
          InAlbum.thumbnailList.addItem(item.data,
            false);
          InAlbum.lazyLoadImage.render();
        });
      Message.show('toast-add-n-photos',
        {
          n: this.pickItems.length,
          name: Album.albumsFiles[InAlbum.albumId].name
        });
      this.exitPickmoreView();
    }
  };
  exports.PickMore = PickMore;
}(window));
