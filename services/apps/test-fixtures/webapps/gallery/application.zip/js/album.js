'use strict';
/* global AlbumItem, Overlay, View, MediaUtils, Photos,
PhotoDB, Message, Dialog, Selector, Preview, InAlbum*/
(function (exports) { // eslint-disable-line
  const Album = {
    MAX_USER_CREATE_ALBUMS_COUNT: 100,
    columnCount: 2,
    systemColumn: 3,
    defaultCoverPhoto: '/style/images/gallery_error.png',
    userCreatedAlbums: [],
    systemAlbums: [],
    userCreatedContainer: null,
    systemContainer: null,
    systemAlbumIds: ['screenshots', 'selfies', 'webshots'],
    albumsFiles: {
      selfies: {
        id: 'selfies',
        name: 'system-selfies',
        date: new Date().getTime(),
        isSystem: true,
        coverPhoto: null,
        photos: []
      },
      screenshots: {
        id: 'screenshots',
        name: 'system-screenshots',
        date: new Date().getTime(),
        isSystem: true,
        coverPhoto: null,
        photos: []
      },
      webshots: {
        id: 'webshots',
        name: 'system-webshots',
        date: new Date().getTime(),
        isSystem: true,
        coverPhoto: null,
        photos: []
      }
    },
    albumNameCount: 0,
    defaultName: null,
    albumName: null,

    enterAlbums() {
      if (Overlay.current === 'emptygallery') {
        Overlay.hideEmptyPage();
      }
      View.switchView(View.views.albumsView);
      if (this.userCreatedAlbums.length === 0) {
        View.selectBtn.classList.add('hidden');
      }
    },

    getPosition(album) {
      const { date } = album.data;
      if (this.userCreatedAlbums.length === 0 ||
        date > this.userCreatedAlbums[0].data.date) {
        return 0;
      } else if (date <
        this.userCreatedAlbums[this.userCreatedAlbums.length - 1].data.date) {
        return this.userCreatedAlbums.length;
      }
      return MediaUtils.binarySearch(this.userCreatedAlbums,
        album,
        (a, b) => b.data.date - a.data.date);

    },

    getDisplayPosition(albumId, albumItems) {
      for (let i = 0; i < albumItems.length; i++) {
        if (Number(albumId) === albumItems[i].data.id) {
          return i;
        }
      }
      return -1;
    },

    addItem(item) {
      if (!this.userCreatedContainer) {
        this.userCreatedContainer =
          document.querySelector('.user-created-albums');
      }
      if (!this.systemContainer) {
        this.systemContainer = document.querySelector('.system-albums');
      }
      const album = new AlbumItem(item);
      album.htmlNode.addEventListener('click',
        () => {
          this.albumClickHandle(album);
        });
      if (item.isSystem) {
        this.systemAlbums.push(album);
        album.htmlNode.classList.add(item.name);
        this.systemContainer.appendChild(album.htmlNode);
      } else {
        const container = this.userCreatedContainer;
        const index = this.getPosition(album);
        container.insertBefore(album.htmlNode,
          container.children[index + 1]);
        this.userCreatedAlbums.splice(index,
          0,
          album);
      }
    },

    deleteUserCreatedAlbumItem(albumId) {
      const index = this.getDisplayPosition(albumId,
        this.userCreatedAlbums);
      if (-1 === index) {
        return;
      }
      const albumItem = this.userCreatedAlbums[index];
      const { photos } = albumItem.data;
      for (let i = 0; i < photos.length; i++) {
        const item = Photos.thumbnailList.getThumbnail(photos[i]);
        const { albums } = item.data.metadata;
        if (albums && albums.contains(albumId)) {
          const order = albums.indexOf(albumId);
          albums.splice(order,
            1);
          PhotoDB.photodb.updateMetadata(photos[i],
            { albums });
        }
      }
      this.userCreatedContainer.removeChild(albumItem.htmlNode);
      delete this.albumsFiles[albumItem.data.id];
      this.userCreatedAlbums.splice(index,
        1);
    },

    deleteAlbums(files) {
      for (let i = 0; i < files.length; i++) {
        this.deleteUserCreatedAlbumItem(files[i].data.id);
      }
      if (this.userCreatedAlbums.length === 0) {
        View.selectBtn.classList.add('hidden');
      }
      this.updateAlbumStorage();
      Message.show('toast-delete-n-albums',
        { n: files.length });
    },

    checkNameValidity(name, input) {
      for (let id in this.albumsFiles) { // eslint-disable-line
        const albumFile = this.albumsFiles[id];
        if (!albumFile.isSystem && albumFile.name === name) {
          input.errorstate = true;
          return false;
        }
      }
      return true;
    },

    addUserCreatedAlbum() {
      if (this.userCreatedAlbums.length === this.MAX_USER_CREATE_ALBUMS_COUNT) {
        Dialog.hideDialog();
        Dialog.showDialog(Dialog.reachMaxAlbums);
        return;
      }
      if (!this.albumName) {
        this.albumName = this.defaultName;
      }
      const validity = this.checkNameValidity(this.albumName,
        this.newnameInput);
      if (!validity) {
        return;
      }
      const albumDate = new Date().getTime();
      const album = {
        id: albumDate,
        name: this.albumName,
        date: albumDate,
        isSystem: false,
        coverPhoto: null,
        photos: []
      };
      this.albumsFiles[albumDate] = album;
      this.addItem(album);
      this.updateAlbumStorage();
      Dialog.hideDialog();
      View.selectBtn.classList.remove('hidden');
      if (View.currentView === View.views.selectView) {
        Selector.addSelectedFilesToAlbum(albumDate);
      }
      if (View.currentView === View.views.previewView) {
        Preview.addPreviewToAlbum(albumDate);
      }
    },

    albumClickHandle(item) {
      if (View.views.selectView === View.currentView) {
        Selector.updateSelection(item);
      } else if (View.views.albumsView === View.currentView) {
        InAlbum.enterAnAlbum(item);
      }
    },

    systemAlbumsAddPhoto(imageInfo) {
      let albumId = null;
      const imageName = imageInfo.data.name;
      const imageSrc = imageName.substring(0,
        imageName.lastIndexOf('/'));
      if (imageSrc === 'screenshots') {
        albumId = 'screenshots';
      } else if (imageSrc === 'DCIM') {
        albumId = 'selfies';
      }
      if (!albumId) {
        return;
      }
      this.addPhoto(albumId,
        imageInfo);
    },

    addPhoto(albumId, imageInfo) {
      const albumFile = this.albumsFiles[albumId];
      if (albumFile.photos.contains(imageInfo.data.name)) {
        return false;
      }
      albumFile.photos.push(imageInfo.data.name);
      if (imageInfo.data.metadata.albums) {
        imageInfo.data.metadata.albums.push(albumId);
      } else {
        imageInfo.data.metadata.albums = [];
        imageInfo.data.metadata.albums.push(albumId);
      }
      PhotoDB.photodb.updateMetadata(imageInfo.data.name,
        { albums: imageInfo.data.metadata.albums });
      if (albumFile.photos.length === 1) {
        let albumItem = null;
        if (this.systemAlbumIds.contains(albumId)) {
          const index = this.getDisplayPosition(albumId,
            this.systemAlbums);
          albumItem = this.systemAlbums[index];
        } else {
          const index = this.getDisplayPosition(albumId,
            this.userCreatedAlbums);
          albumItem = this.userCreatedAlbums[index];
        }
        const { htmlNode } = albumItem;
        const { noCoverPhoto } = albumItem;
        const url = imageInfo.htmlNode.getAttribute('data-src');
        htmlNode.style.backgroundImage = `url(${url})`;
        htmlNode.removeChild(noCoverPhoto);
        albumFile.coverPhoto = imageInfo.data.name;
      }
      this.updateAlbumStorage();
      return true;
    },

    removePhoto(photo, albumId) {
      const albumFile = this.albumsFiles[albumId];
      const { name } = photo;
      if (!albumFile.photos.contains(name)) {
        return;
      }
      const index = albumFile.photos.indexOf(name);
      albumFile.photos.splice(index,
        1);
      const item = Photos.thumbnailList.getThumbnail(name);
      if (!item) {
        return;
      }
      const { albums } = item.data.metadata;
      if (albums && albums.contains(albumId)) {
        const order = albums.indexOf(albumId);
        albums.splice(order,
          1);
        PhotoDB.photodb.updateMetadata(name,
          { albums });
      }
    },

    anAlbumRemovePhotos(photos, albumId) {
      const albumFile = this.albumsFiles[albumId];
      const { coverPhoto } = albumFile;
      let containsCoverPhoto = false;
      for (let i = 0; i < photos.length; i++) {
        if (coverPhoto === photos[i].data.name) {
          containsCoverPhoto = true;
        }
        this.removePhoto(photos[i].data,
          albumId);
      }
      if (containsCoverPhoto) {
        let albumItem = null;
        if (this.systemAlbumIds.contains(albumId)) {
          const order = this.getDisplayPosition(albumId,
            this.systemAlbums);
          albumItem = this.systemAlbums[order];
        } else {
          const order = this.getDisplayPosition(albumId,
            this.userCreatedAlbums);
          albumItem = this.userCreatedAlbums[order];
        }
        const { htmlNode } = albumItem;
        const { noCoverPhoto } = albumItem;
        if (albumFile.photos.length === 0) {
          htmlNode.style.backgroundImage = '';
          htmlNode.appendChild(noCoverPhoto);
          albumFile.coverPhoto = null;
        } else {
          PhotoDB.photodb.getFileInfo(albumFile.photos[0],
            (file) => {
              if (!file) {
                return;
              }
              const { thumbnail } = file.metadata;
              const url = URL.createObjectURL(thumbnail);
              htmlNode.style.backgroundImage = `url(${url})`;
            });
          [albumFile.coverPhoto] = albumFile.photos;
        }
      }
      this.updateAlbumStorage();
    },

    someAlbumsRemovePhotos(photos) {
      for (let id in this.albumsFiles) { // eslint-disable-line
        if (this.albumsFiles[id].photos.length !== 0) {
          this.anAlbumRemovePhotos(photos,
            id);
        }
      }
    },

    updateAlbumStorage() {
      try {
        localStorage.setItem('albums',
          JSON.stringify(this.albumsFiles));
      } catch (e) {
        console.error('update Album Storage error:',
          e);
      }
    },

    createNameInput(value, callBack) {
      const nameInput = document.createElement('kai-textfield');
      nameInput.setAttribute('slot',
        'custom-view');
      nameInput.classList.add('name-input');
      nameInput.label = 'Album name';
      nameInput.value = value;
      nameInput.errormessage = 'Album name already in use';
      nameInput.errorstate = false;
      nameInput.addEventListener('change', (e) => {
        callBack(e);
      });
      return nameInput;
    },

    createNewAlbum() {
      this.albumName = null;
      this.defaultName = `Album ${this.albumNameCount + 1}`;
      this.newnameInput = this.createNameInput(this.defaultName,
        this.newNameInputNameChanged.bind(this));
      Dialog.showDialog(Dialog.createAlbum,
        this.newnameInput,
        this.addUserCreatedAlbum.bind(this));
    },

    newNameInputNameChanged(e) {
      this.albumName = e.detail.value;
      this.newnameInput.errorstate = false;
      if (this.albumName === '') {
        Dialog.dialog.primarybtndisabled = true;
      } else {
        Dialog.dialog.primarybtndisabled = false;
      }
    },

    newAlbumAddEvent() {
      const createAlbum = document.querySelector('.create-album-item');
      createAlbum.addEventListener('click',
        () => {
          if (View.currentView === View.views.selectView &&
          View.lastView === View.views.albumsView) {
            return;
          }
          this.createNewAlbum();
        });
    },

    initAlbums() {
      const albums = localStorage.getItem('albums');
      if (albums) {
        this.albumsFiles = JSON.parse(albums);
      }
      const files = this.albumsFiles;
      for (let id in files) { // eslint-disable-line
        this.addItem(files[id]);
      }
      this.newAlbumAddEvent();
    }
  };
  exports.Album = Album;
}(window));
