function ThumbnailItem(fileData) {
  if (!fileData) {
    throw new Error('fileData should not be null or undefined.');
  }
  this.data = fileData;

  this.htmlNode = document.createElement('div');
  this.htmlNode.classList.add('thumbnail');
  this.htmlNode.dataset.columncount = Startup.thumbnailColumn;
  if (fileData.metadata.largeSize) {
    this.htmlNode.classList.add('largeSize');
  }
  if (fileData.metadata.favorite) {
    this.htmlNode.classList.add('favorite');
  }
  const url = fileData.metadata.largeSize
    ? PhotoDB.galleryErrorLargeSrc
    : URL.createObjectURL(fileData.metadata.thumbnail);
  this.htmlNode.setAttribute("data-src",
    url);
  this.htmlNode.setAttribute("load-image",
    'false');
  this.htmlNode.setAttribute('animationMode',
    'dontanim');
  const imgNodeOverlay = document.createElement('div');
  imgNodeOverlay.classList.add('thumbnail-list-img-overlay');
  this.selector = document.createElement('span');
  this.selector.classList.add('thumbnail-list-img-selector');
  const imgSelectorOverlay = document.createElement('div');
  imgSelectorOverlay.classList.add('thumbnail-list-img-selector-overlay');
  this.imgFavorite = document.createElement('i');
  this.imgFavorite.setAttribute('data-icon',
    'favorite-on');
  this.imgFavorite.classList.add('thumbnail-list-img-favorite');
  this.htmlNode.appendChild(imgNodeOverlay);
  this.htmlNode.appendChild(this.selector);
  this.htmlNode.appendChild(this.imgFavorite);
  this.htmlNode.appendChild(imgSelectorOverlay);
}

ThumbnailItem.prototype.localize = function () {
  const date = new Date(this.data.date);
  const description = navigator.mozL10n.get('imageDescriptionShort');
  const label = ThumbnailItem.formatter.localeFormat(date,
    description);
  this.htmlNode.setAttribute('aria-label',
    label);
};
