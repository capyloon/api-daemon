'use strict';
/* global View, ImageCropRotate, ImageFilter, ImageCorrector,
  ImageDrawer, Preview, ImageProcessor, PhotoDB, Startup, cropResizeRotate,
  ImageEditor
*/
(function (exports) { // eslint-disable-line
  const ImageEditView = {
    currentEditView: null,
    lastEditView: null,
    editViews: null,
    lazyLoadFile: null,
    imageEditor: null,
    editSettings: null,
    editedPhotoURL: null,
    lazyLoadFiles: false,

    enterEditView() {
      this.editViews = {
        cropRotateView: 'cropRotateView',
        filterView: 'filterView',
        correctorView: 'correctorView',
        evView: 'evView',
        drawerView: 'drawerView'
      };
      document.body.classList.remove(View.views.previewView);
      document.body.classList.add(View.views.editView);
      View.currentView = View.views.editView;
      this.addEventListeners();
      this.getEditFile();
    },

    exitEditView() {
      document.body.classList.add(View.views.previewView);
      document.body.classList.remove(View.views.editView);
      View.currentView = View.views.previewView;
      this.toolsContainer.classList.remove(this.currentEditView);
      this.toolsContainer.classList.add(this.editViews.cropRotateView);
      this.toolsContainer = null;
      const tools = this.editTools.querySelectorAll('.image-editor-tool');
      [].forEach.call(tools, (el) => {
        if (el.id === 'image-crop-rotate') {
          el.classList.add('focus');
        } else {
          el.classList.remove('focus');
        }
      });
      this.changeSaveBtnState(false);
      this.removeEventListeners();
      this.exitEditMode();
      this.currentEditView = null;
      this.lastEditView = null;
      this.editViews = null;
    },

    exitLastEditView(view) {
      if (!view) {
        return;
      }
      if (view === this.editViews.cropRotateView) {
        ImageCropRotate.exitCropRotate();
      }
    },

    addEventListeners() {
      this.toolsContainer =
        document.querySelector('#image-editor-tools-container');
      this.editToolsClickCallback = this.showCurrentView.bind(this);
      this.editTools = document.querySelector('#image-editor-tools');
      this.editTools.addEventListener('click',
        this.editToolsClickCallback);

      this.saveBtn = document.querySelector('#image-editor-save');
    },

    removeEventListeners() {
      this.editTools.removeEventListener('click',
        this.editToolsClickCallback);
      this.editTools = null;
      this.editToolsClickCallback = null;
    },

    setEditView(view) {
      if (this.currentEditView === view) {
        return;
      }
      this.lastEditView = this.currentEditView;
      this.exitLastEditView(this.lastEditView);
      this.currentEditView = view;
      this.enterCurrentEditView(this.currentEditView);
      this.changeSaveBtnState(this.imageEditor.isEdited());
      this.toolsContainer.classList.remove(this.lastEditView);
      this.toolsContainer.classList.add(view);
    },

    enterCurrentEditView(view) {
      switch (view) {
        case this.editViews.cropRotateView:
          ImageCropRotate.enterCropRotateView();
          break;
        case this.editViews.filterView:
          ImageFilter.enterFilterView();
          break;
        case this.editViews.correctorView:
          ImageCorrector.enterCorrectionView();
          break;
        case this.editViews.evView:
          ImageEv.enterEvView()
          break;
        case this.editViews.drawerView:
          ImageDrawer.enterDrawerView();
          break;
        default:
          break;
      }
    },

    showCurrentView(e) {
      const { target } = e;
      if (!target.dataset.tool || target.classList.contains('focus')) {
        return;
      }
      const tools = this.editTools.querySelectorAll('.image-editor-tool');
      [].forEach.call(tools, (el) => {
        el.classList.remove('focus');
      });
      target.classList.add('focus');
      const view = target.dataset.tool;
      this.setEditView(view);
    },

    getEditFile() {
      const { name } = Preview.previewFile.data;
      const { metadata } = Preview.previewFile.data;
      this.editSettings = {
        crop: {
          x: 0, y: 0, w: metadata.width, h: metadata.height,
          cropModeId: 'edit-crop-aspect-free'
        },
        exposure: {
          sliderThumbPos: 0,
          gamma: 1,
          value: 0
        },
        rotate: {
          matIdx: 0,
          set: false
        },
        effect: {
          effectId: 'edit-filters-none',
          matrix: ImageProcessor.IDENTITY_MATRIX
        },
        enhance: {
          rgbMinMaxValues: ImageProcessor.default_enhancement
        }
      };
      PhotoDB.photodb.getFile(name,
        (file) => {
          const imageSize = metadata.width * metadata.height;
          let imagesizelimit = Startup.CONFIG_MAX_IMAGE_PIXEL_SIZE;
          if (metadata.type !== 'jpeg' && Startup.lowMemory) {
            imagesizelimit = Startup.LOW_MAX_IMAGE_PIXEL_SIZE_NO_JPEG;
          }
          if (metadata.rotation || metadata.mirrored ||
            imageSize > imagesizelimit) {
            cropResizeRotate(file,
              null,
              imagesizelimit,
              null,
              metadata,
              (error, rotatedBlob) => {
                if (error) {
                  console.error('Error while rotating image:',
                    error);
                  rotatedBlob = file;
                }
                this.showEditImage(rotatedBlob);
              });
          } else {
            this.showEditImage(file);
          }
        });
    },

    showEditImage(blob) {
      const container = document.querySelector('#image-editor-image-container');
      const ready = this.setEditView.bind(this,
        this.editViews.cropRotateView);
      this.imageEditor = new ImageEditor(blob,
        container,
        'edit-preview-canvas',
        this.editSettings,
        ready);
    },

    exitEditMode() {
      ImageCropRotate.exitEditMode();
      ImageFilter.exitEditMode();
      ImageDrawer.exitEditMode();
      ImageCorrector.exitEditMode();
      ImageEv.exitEditMode();
      URL.revokeObjectURL(this.editedPhotoURL);
      this.editedPhotoURL = null;
      if (this.imageEditor) {
        this.imageEditor.destroy();
        this.imageEditor = null;
      }
      this.editSettings = null;
      /*
       * Window.removeEventListener('resize', resizeHandler);
       * window.removeEventListener('localized', localizeHandler);
       */
    },

    clone(obj) {
      return JSON.parse(JSON.stringify(obj));
    },

    changeSaveBtnState(isShow) {
      if (isShow) {
        this.saveBtn.classList.remove('hidden');
        if (ImageCropRotate.reset) {
          ImageCropRotate.reset.classList.remove('disabled');
        }
      } else {
        this.saveBtn.classList.add('hidden');
        if (ImageCropRotate.reset) {
          ImageCropRotate.reset.classList.add('disabled');
        }
      }
    }
  };
  exports.ImageEditView = ImageEditView;
}(window));
