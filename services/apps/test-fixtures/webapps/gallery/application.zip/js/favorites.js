'use strict';
(function (exports) {
  const Favorite = {
    container: null,
    firstLoadImages: 35,
    firstLoadImageNames: [],
    favoriteCount: 0,
    unfavoriteFileNames: [],

    enterFavorites() {
      this.initContainer();
      View.switchView(View.views.favoriteView);
      const count = this.getFavoritesCount();
      if (!count) {
        Overlay.showEmptyPage(View.views.favoriteView);
      } else {
        Overlay.hideEmptyPage();
        this.createThumbnails();
      }
    },

    exitFavorite() {
      this.thumbnailList.reset();
      this.firstLoadImageNames = [];
    },

    getFavoritesCount() {
      const favorites = Photos.container.querySelectorAll('.favorite');
      if (favorites) {
        return favorites.length;
      }
      return 0;

    },

    initContainer() {
      if (this.container) {
        return;
      }
      this.container = document.querySelector('#favorites');
      this.thumbnailList =
        new ThumbnailList(ThumbnailDateGroup,
          this.container);
      this.lazyLoadImage = new LazyLoadImage();
      this.lazyLoadImage.init(this.container);
    },

    createThumbnails() {
      const allThumbnails = Photos.thumbnailList.getAllThumbnails();
      this.favoriteCount = this.getFavoritesCount();
      if (this.favoriteCount >= this.firstLoadImages) {
        this.create(allThumbnails,
          true);
        this.lazyLoadImage.render();
        clearTimeout(this.timeOut);
        this.timeOut = setTimeout(() => {
          this.create(allThumbnails,
            false);
          this.lazyLoadImage.render();
        }, 300);
      } else {
        this.create(allThumbnails,
          true);
        this.lazyLoadImage.render();
      }
      this.container.scrollTop = 0;
    },

    create(thumbnails, isFirstLoad) {
      for (let item of thumbnails) { // eslint-disable-line
        if (item.data.metadata.favorite) {
          if (isFirstLoad) {
            this.thumbnailList.addItem(item.data,
              false);
            this.firstLoadImageNames.push(item.data.name);
            if (this.firstLoadImages === this.thumbnailList.getCount()) {
              break;
            }
          } else if (!this.firstLoadImageNames.contains(item.data.name)) {
            this.thumbnailList.addItem(item.data,
              false);
            if (this.favoriteCount === this.thumbnailList.getCount()) {
              break;
            }
          }
        }
      }
    },

    deletePhoto(fileInfo) {
      this.thumbnailList.removeItem(fileInfo.data,
        false);
    },

    deletePhotos(deleteFiles, callback, deleteDone) {
      Photos.deletePhotos(deleteFiles,
        callback,
        deleteDone);
    }
  };
  exports.Favorite = Favorite;
}(window));
