'use strict';
/* global GestureDetector, ImageProcessor, ROT_MAT_IDX, ImageEditView,
  Utilities
*/
// eslint-disable-next-line
function ImageEditor(imageBlob, container, ID, edits, ready, croponly) { 
  this.imageBlob = imageBlob;
  this.imageURL = URL.createObjectURL(imageBlob);
  this.container = container;
  this.edits = edits || {};
  this.croponly = !!croponly;
  this.isChange = false;
  this.source = {};
  this.dest = {};
  this.cropRegion = {};
  this.previewCanvas = document.createElement('canvas');
  this.previewCanvas.id = ID;
  this.previewCanvas.setAttribute('data-l10n-id',
    'image-editor-imagepreview');
  this.previewCanvas.setAttribute('role',
    'img');
  this.container.appendChild(this.previewCanvas);
  const dpr = window.devicePixelRatio;
  this.previewCanvas.width = Math.ceil(this.previewCanvas.clientWidth * dpr);
  this.previewCanvas.height = Math.ceil(this.previewCanvas.clientHeight * dpr);
  this.gestureDetector = new GestureDetector(container,
    { panThreshold: 3 });
  this.gestureDetector.startDetecting();
  this.scale = 1.0;
  this.needsUpload = true;
  if (this.croponly) {
    this.original = null;
    this.preview = new Image();
    this.preview.src = this.imageURL;
    this.preview.onload = () => {
      this.resetCropSource();
      this.displayCropOnlyPreview();
      if (ready) {
        ready();
      }
    };
  } else {
    this.original = new Image();
    this.original.src = this.imageURL;
    this.preview = new Image();
    this.preview.src = null;
    this.processor = new ImageProcessor(this.previewCanvas,
      null,
      () => {
        this.needsUpload = true;
        this.edit();
      });
    this.original.onload = () => {
      this.resetCropRegion();
      this.resetPreview();
      this.edit(() => {
        if (ready) {
          ready();
        }
      });
    };
  }
}

ImageEditor.prototype.isEdited = function isEdited() {
  return 1 !== this.edits.exposure.gamma ||
    ROT_MAT_IDX.r0 !== this.edits.rotate.matIdx ||
    this.hasBeenCropped() ||
    !arrayEqual(this.edits.effect.matrix,
      ImageProcessor.IDENTITY_MATRIX) ||
    !arrayEqual(this.edits.enhance.rgbMinMaxValues,
      ImageProcessor.default_enhancement);
  function arrayEqual(a1, a2) {
    if (!a1 || !a2) {
      return true;
    }
    if (a1.length !== a2.length) {
      return false;
    }
    for (let i = 0; i < a1.length; i++) {
      if (a1[i] !== a2[i]) {
        return false;
      }
    }
    return true;
  }
};

ImageEditor.prototype.displayCropOnlyPreview =
  function displayCropOnlyPreview() {
    const previewContext = this.previewCanvas.getContext('2d');
    this.resetDest(this.preview);
    previewContext.drawImage(this.preview,
      this.dest.x,
      this.dest.y,
      this.dest.width,
      this.dest.height);
  };

ImageEditor.prototype.resetDest = function resetDest(dest) {
  const { width } = dest;
  const { height } = dest;
  const scalex = this.previewCanvas.width / width;
  const scaley = this.previewCanvas.height / height;
  this.scale = Math.min(Math.min(scalex,
    scaley),
  1);
  this.dest.width = Math.floor(width * this.scale);
  this.dest.height = Math.floor(height * this.scale);
  this.dest.x = Math.floor((this.previewCanvas.width - this.dest.width) / 2);
  this.dest.y = Math.floor((this.previewCanvas.height - this.dest.height) / 2);
};

ImageEditor.prototype.resetCropSource = function resetCropSource() {
  this.source.x = 0;
  this.source.y = 0;
  this.source.width = this.preview.width;
  this.source.height = this.preview.height;
};

ImageEditor.prototype.generateNewPreview = function generateNewPreview(done) {
  const scalex = this.previewCanvas.width / this.source.width;
  const scaley = this.previewCanvas.height / this.source.height;
  this.scale = Math.min(Math.min(scalex,
    scaley),
  1);
  const previewWidth = Math.floor(this.source.width * this.scale);
  const previewHeight = Math.floor(this.source.height * this.scale);
  this.edits.crop.x = this.source.x;
  this.edits.crop.y = this.source.y;
  this.edits.crop.w = this.source.width;
  this.edits.crop.h = this.source.height;
  this.dest.x = Math.floor((this.previewCanvas.width - previewWidth) / 2);
  this.dest.y = Math.floor((this.previewCanvas.height - previewHeight) / 2);
  this.dest.width = previewWidth;
  this.dest.height = previewHeight;
  const canvas = document.createElement('canvas');
  canvas.width = previewWidth;
  canvas.height = previewHeight;
  this.previewContext = canvas.getContext('2d',
    { willReadFrequently: true });
  this.previewContext.drawImage(
    this.original,
    this.source.x,
    this.source.y,
    this.source.width,
    this.source.height,
    0,
    0,
    previewWidth,
    previewHeight
  );
  const imageData = this.previewContext.getImageData(0,
    0,
    previewWidth,
    previewHeight);
  this.prepareAutoEnhancement(imageData.data);
  canvas.toBlob((thumbnail) => {
    this.preview.src = URL.createObjectURL(thumbnail);
    this.preview.onload = () => {
      this.needsUpload = true;
      done();
    };
  }, 'image/jpeg');
};

ImageEditor.prototype.resetPreview = function resetPreview() {
  if (this.preview.src) {
    URL.revokeObjectURL(this.preview.src);
    this.preview.removeAttribute('src');
  }
};

ImageEditor.prototype.resize = function resize() {
  const canvas = this.previewCanvas;
  const dpr = window.devicePixelRatio;
  canvas.width = Math.ceil(canvas.clientWidth * dpr);
  canvas.height = Math.ceil(canvas.clientHeight * dpr);
  const savedCropRegion = {};
  const hadCropOverlay = this.isCropOverlayShown();
  if (hadCropOverlay) {
    savedCropRegion.left = this.cropRegion.left / this.scale;
    savedCropRegion.top = this.cropRegion.top / this.scale;
    savedCropRegion.right = this.cropRegion.right / this.scale;
    savedCropRegion.bottom = this.cropRegion.bottom / this.scale;
    this.hideCropOverlay();
  }
  if (this.croponly) {
    this.displayCropOnlyPreview();
    if (hadCropOverlay) {
      const newRegion = {};
      newRegion.left = Math.floor(savedCropRegion.left * this.scale);
      newRegion.top = Math.floor(savedCropRegion.top * this.scale);
      newRegion.right = Math.floor(savedCropRegion.right * this.scale);
      newRegion.bottom = Math.floor(savedCropRegion.bottom * this.scale);
      this.showCropOverlay(newRegion);
    }
  } else {
    this.resetPreview();
    this.edit();
  }
};

ImageEditor.prototype.destroy = function destroy() {
  if (this.processor) {
    this.processor.destroy();
    this.processor = null;
  }
  if (this.original) {
    this.original.src = '';
    this.original = null;
  }
  if (this.preview) {
    if (this.preview.src !== this.imageURL) {
      URL.revokeObjectURL(this.preview.src);
    }
    this.preview.src = '';
    this.preview = null;
  }
  URL.revokeObjectURL(this.imageURL);
  if (this.previewCanvas) {
    this.container.removeChild(this.previewCanvas);
    this.previewCanvas = null;
  }
  this.hideCropOverlay();
  this.gestureDetector.stopDetecting();
  this.gestureDetector = null;
};

/*
 * Preview the image with the specified edits applied. If edit is omitted,
 * displays the original image. Clients should call this function when the
 * desired edits change or when the size of the container changes (on
 * orientation change events, for example)
 */
ImageEditor.prototype.edit = function edit(callback) {
  if (this.preview.src) {
    this.finishEdit(callback);
  } else {
    this.generateNewPreview(() => {
      this.finishEdit(callback);
    });
  }
};

ImageEditor.prototype.finishEdit = function finishEdit(finishEditCallback) {
  this.processor.draw(this.preview,
    this.needsUpload,
    0,
    0,
    this.preview.width,
    this.preview.height,
    this.dest.x,
    this.dest.y,
    this.dest.width,
    this.dest.height,
    this.edits);
  this.needsUpload = false;
  if (finishEditCallback) {
    finishEditCallback();
  }
};

/* eslint-disable */
ImageEditor.prototype.getFullSizeBlob = function getFullSizeBlob(type,
  done, progress) {
  const TILE_SIZE = 512;
  let self = this;
  let canvas = document.createElement('canvas');
  let context = canvas.getContext('2d', { willReadFrequently: true });
  let startX = 0,startY = 0;
  let matIdx = this.edits.rotate.matIdx;
  if (this.widthHeightWasSwapped()) {
    canvas.width = this.source.height;
    canvas.height = this.source.width;
  } else {
    canvas.width = this.source.width;
    canvas.height = this.source.height;
  }
  if(matIdx > 0) {
    context.rotate(matIdx * Math.PI / 2);
    switch(matIdx) {
    case 1:
      startY = -this.source.height;
      break;
    case 2:
      startX = -this.source.width;
      startY = -this.source.height;
      break;
    case 3:
      startX = -this.source.width;
      break;
    }
  }
  this.edits.rotate.matIdx = ROT_MAT_IDX.r0;
  context.drawImage(this.original,
    this.source.x, this.source.y,
    this.source.width, this.source.height,
    startX, startY, this.source.width, this.source.height);
  if (matIdx > 0) {
    context.rotate((matIdx * (-1)) * Math.PI / 2);
  }
  this.edits.rotate.matIdx = 0;
  switch(matIdx) {
    case 1:
    case 3:
      var width_temp = this.source.width;
      this.source.width = this.source.height;
      this.source.height = width_temp;
      break;
  }
  matIdx =0;
  this.original.src = '';
  let totalPixels = canvas.width * canvas.height;
  let processedPixels = 0;
  function makeTileList(imageWidth, imageHeight, tileWidth, tileHeight) {
    let tiles = [];
    let x = 0, y = 0;
    while (y < imageHeight) {
      x = 0;
      while (x < imageWidth) {
        let tile = {
          x: x,
          y: y,
          w: tileWidth,
          h: tileHeight
        };
        if (x + tileWidth > imageWidth) {
          tile.w = imageWidth - x;
        }
        if (y + tileHeight > imageHeight) {
          tile.h = imageHeight - y;
        }
        tiles.push(tile);
        x += tileWidth;
      }
      y += tileHeight;
    }
    return tiles;
  }
  // Create a smaller tile canvas.
  let tile = document.createElement('canvas');
  tile.width = tile.height = TILE_SIZE;
  // Create an ImageProcessor object that renders into the tile.
  let processor = new ImageProcessor(tile);
  // Divide the image into a set of tiled rectangles
  let rectangles = makeTileList(this.source.width, this.source.height,
    tile.width, tile.height);
  processNextTile();
  // Process one tile of the original image, copy the processed tile
  // to the full-size canvas, and then return to the event queue.
  function processNextTile() {
    let rect = rectangles.shift();
    // Get the input pixels for this tile
    let pixels = context.getImageData(rect.x, rect.y, rect.w, rect.h);
    let centerX = Math.floor((tile.width - rect.w) / 2);
    let centerY = Math.floor((tile.height - rect.h) / 2);
    // Edit the pixels and draw them to the tile
    processor.draw(pixels, true, 0, 0, rect.w, rect.h,
      centerX, centerY, rect.w, rect.h, self.edits);
    // Copy the edited pixels from the tile back to the canvas
    context.drawImage(tile, centerX, centerY, rect.w, rect.h,
      rect.x, rect.y, rect.w, rect.h);
    if (processor.isContextLost()) {
      processor.destroy();
      processor = null;
      context = null;
      canvas.width = canvas.height = 0;
      canvas = null;
      self.edits.rotate.matIdx = matIdx;
      if (progress) {
        // Reload the original image.
        self.original.src = self.imageURL;
        self.original.onload = function() {
          // Send the error to reset processing state.
          progress(0, true);
        };
      }
      return;
    }
    processedPixels += rect.w * rect.h;
    if (progress) {
      progress(processedPixels / totalPixels);
    }
    if (rectangles.length) {
      setTimeout(processNextTile);
    } else {
      processor.destroy();
      processor = null;
      canvas.toBlob((blobData) => {
        context = null;
        canvas.width = canvas.height = 0;
        canvas = null;
        self.edits.rotate.matIdx = matIdx;
        done(blobData);
      }, type);
    }
  }
};
/* eslint-enable */

ImageEditor.prototype.isCropOverlayShown = function isCropOverlayShown() {
  return this.cropCanvas;
};

ImageEditor.prototype.getDest = function getDest() {
  const dest = {};
  const swapped = this.widthHeightWasSwapped();
  dest.x = swapped
    ? Math.floor(this.dest.y / window.devicePixelRatio)
    : Math.floor(this.dest.x / window.devicePixelRatio);
  dest.y = swapped
    ? Math.floor(this.dest.x / window.devicePixelRatio)
    : Math.floor(this.dest.y / window.devicePixelRatio);
  dest.width = swapped
    ? Math.floor(this.dest.height / window.devicePixelRatio)
    : Math.floor(this.dest.width / window.devicePixelRatio);
  dest.height = swapped
    ? Math.floor(this.dest.width / window.devicePixelRatio)
    : Math.floor(this.dest.height / window.devicePixelRatio);
  return dest;
};

ImageEditor.prototype.hasBeenCropped = function hasBeenCropped() {
  const dest = this.getDest();
  const dpr = window.devicePixelRatio;
  return Object.keys(this.cropRegion).length > 0 && (
    this.cropRegion.left !== 0 ||
    this.cropRegion.top !== 0 ||
    Math.ceil(this.cropRegion.right) < Math.floor(dest.width / dpr) ||
    Math.ceil(this.cropRegion.bottom) < Math.floor(dest.height / dpr)
  );
};

ImageEditor.prototype.showCropOverlay = function showCropOverlay(newRegion) {
  const canvas = document.createElement('canvas');
  this.cropCanvas = canvas;
  canvas.id = 'edit-crop-canvas';
  this.container.appendChild(canvas);
  canvas.width = canvas.clientWidth;
  canvas.height = canvas.clientHeight;
  const context = canvas.getContext('2d');
  this.cropContext = context;
  context.lineCap = 'round';
  context.strokeStyle = 'rgba(255,255,255,.75)';
  const region = this.cropRegion;
  if (newRegion) {
    region.left = newRegion.left;
    region.top = newRegion.top;
    region.right = newRegion.right;
    region.bottom = newRegion.bottom;
  } else {
    const dpr = window.devicePixelRatio;
    region.left = 0;
    region.top = 0;
    region.right = Math.floor(this.dest.width / dpr);
    region.bottom = Math.floor(this.dest.height / dpr);
  }
  if (this.widthHeightWasSwapped() && !newRegion) {
    const paTMP = region.bottom;
    region.bottom = region.right;
    region.right = paTMP;
  }
  this.drawCropControls();

  let isCropping = false;
  this.cropCanvas.addEventListener('pan',
    (ev) => {
      if (!isCropping) {
        this.cropStart(ev);
        isCropping = true;
      }
    });
  this.cropCanvas.addEventListener('swipe',
    () => {
      isCropping = false;
    });
};

// Replace value of two params base on the condition
ImageEditor.prototype.paramReplace = function paramReplace(param1,
  param2, condition) {
  if (condition) {
    let paramReplaceTmp = null;
    paramReplaceTmp = param1;
    param1 = param2;
    param2 = paramReplaceTmp;
    console.error(param2);
  }
};

ImageEditor.prototype.widthHeightWasSwapped = function widthHeightWasSwapped() {
  if (this.edits.rotate) {
    const rotateArr = [ROT_MAT_IDX.r90, ROT_MAT_IDX.r270];
    return rotateArr.contains(this.edits.rotate.matIdx);
  }
  return false;
};

ImageEditor.prototype.hideCropOverlay = function hideCropOverlay() {
  if (this.isCropOverlayShown()) {
    this.container.removeChild(this.cropCanvas);
    this.cropCanvas.width = 0;
    this.cropCanvas = null;
    this.cropContext = null;
  }
};

// Force set image to crop sizes in edit settings
ImageEditor.prototype.forceSetCropRegion = function forceSetCropRegion() {
  this.source.x = this.edits.crop.x;
  this.source.y = this.edits.crop.y;
  this.source.width = this.edits.crop.w;
  this.source.height = this.edits.crop.h;

};

// Reset image to full original size
ImageEditor.prototype.resetCropRegion = function resetCropRegion() {
  this.source.x = 0;
  this.source.y = 0;
  this.source.width = this.original.width;
  this.source.height = this.original.height;

};

ImageEditor.prototype.drawCropControls = function drawCropControls() {
  const region = this.cropRegion;
  const dest = this.getDest();
  const canvas = this.cropCanvas;
  const context = this.cropContext;
  const left = region.left + dest.x;
  const top = region.top + dest.y;
  const right = region.right + dest.x;
  const bottom = region.bottom + dest.y;
  const oneThirdX = (region.right - region.left) / 3;
  const oneThirdY = (region.bottom - region.top) / 3;
  const width = right - left;
  const height = bottom - top;
  const cropIndicatorLen = 15;
  context.clearRect(0,
    0,
    canvas.width,
    canvas.height);
  context.fillStyle = 'rgba(0, 0, 0, .5)';
  context.strokeStyle = 'rgba(255, 255, 255, 1)';
  context.fillRect(dest.x,
    dest.y,
    dest.width,
    dest.height);
  context.clearRect(left,
    top,
    width,
    height);
  context.lineWidth = 1;
  context.strokeRect(left,
    top,
    width,
    height);
  context.lineWidth = 3;
  context.beginPath();
  // NE
  context.moveTo(right - cropIndicatorLen,
    top);
  context.lineTo(right,
    top);
  context.lineTo(right,
    top + cropIndicatorLen);
  // SE
  context.moveTo(right,
    bottom - cropIndicatorLen);
  context.lineTo(right,
    bottom);
  context.lineTo(right - cropIndicatorLen,
    bottom);
  // SW
  context.moveTo(left + cropIndicatorLen,
    bottom);
  context.lineTo(left,
    bottom);
  context.lineTo(left,
    bottom - cropIndicatorLen);
  // NW
  context.moveTo(left,
    top + cropIndicatorLen);
  context.lineTo(left,
    top);
  context.lineTo(left + cropIndicatorLen,
    top);
  context.stroke();
  // Grid
  context.lineWidth = 1;
  context.beginPath();
  context.moveTo(oneThirdX + left,
    top);
  context.lineTo(oneThirdX + left,
    bottom);
  context.moveTo(oneThirdX * 2 + left,
    top);
  context.lineTo(oneThirdX * 2 + left,
    bottom);
  context.moveTo(left,
    oneThirdY + top);
  context.lineTo(right,
    oneThirdY + top);
  context.moveTo(left,
    oneThirdY * 2 + top);
  context.lineTo(right,
    oneThirdY * 2 + top);
  context.stroke();
  if (this.isEdited()) {
    ImageEditView.changeSaveBtnState(true);
  } else {
    ImageEditView.changeSaveBtnState(false);
  }
};

// Called when the first pan event comes in on the crop canvas
ImageEditor.prototype.cropStart = function cropStart(ev) {
  const that = this;
  const region = this.cropRegion;
  const dest = this.getDest();
  const rect = this.previewCanvas.getBoundingClientRect();
  const x0 = ev.detail.position.screenX - rect.left - dest.x;
  const y0 = ev.detail.position.screenY - rect.top - dest.y;
  const { left } = region;
  const { top } = region;
  const { right } = region;
  const { bottom } = region;
  const aspectRatio = this.cropAspectWidth
    ? this.cropAspectWidth / this.cropAspectHeight
    : 0;
  const centerX = (region.left + region.right) / 2;
  const centerY = (region.top + region.bottom) / 2;
  function getDirection() {
    if (x0 > left - 25 && x0 < left + 25 &&
      y0 > top - 25 && y0 < top + 25) {
      return 'nw';
    }
    if (x0 > right - 25 && x0 < right + 25 &&
      y0 > top - 25 && y0 < top + 25) {
      return 'ne';
    }
    if (x0 > right - 25 && x0 < right + 25 &&
      y0 > bottom - 25 && y0 < bottom + 25) {
      return 'se';
    }
    if (x0 > left - 25 && x0 < left + 25 &&
      y0 > bottom - 25 && y0 < bottom + 25) {
      return 'sw';
    }
    if (x0 > left && x0 < right && y0 > top - 25 && y0 < top + 25) {
      return 'n';
    }
    if (x0 > right - 25 && x0 < right + 25 && y0 > top && y0 < bottom) {
      return 'e';
    }
    if (x0 > left && x0 < right && y0 > bottom - 25 && y0 < bottom + 25) {
      return 's';
    }
    if (x0 > left - 25 && x0 < left + 25 && y0 > top && y0 < bottom) {
      return 'w';
    }
    if (x0 > left - 25 && x0 < right + 25 &&
      y0 > top - 25 && y0 < bottom + 25) {
      return 'move';
    }
    return null;
  }
  const direction = getDirection();
  if (direction) {
    drag(direction);
  } else {
    drag();
  }

  function drag(handle) {
    window.addEventListener('pan',
      move,
      true);
    window.addEventListener('swipe',
      up,
      true);
    function move(e) {
      const { dx } = e.detail.absolute;
      const { dy } = e.detail.absolute;
      let newleft = region.left;
      let newright = region.right;
      let newtop = region.top;
      let newbottom = region.bottom;

      if (!handle) {
        return;
      }
      if ('move' === handle) {
        pan(dx,
          dy);
        return;
      }
      switch (handle) {
        case 'n':
          newtop = top + dy;
          if (aspectRatio) {
            const height = newbottom - newtop;
            const width = height * aspectRatio;
            newleft = Math.floor(centerX - Math.floor(width / 2));
            newright = Math.ceil(centerX + Math.ceil(width / 2));
          }
          break;
        case 'ne':
          newright = right + dx;
          if (aspectRatio) {
            const width = newright - newleft;
            const height = width / aspectRatio;
            newtop = Math.floor(centerY - Math.floor(height / 2));
            newbottom = Math.ceil(centerY + Math.ceil(height / 2));
          } else {
            newtop = top + dy;
          }
          break;
        case 'e':
          newright = right + dx;
          if (aspectRatio) {
            const width = newright - newleft;
            const height = width / aspectRatio;
            newtop = Math.floor(centerY - Math.floor(height / 2));
            newbottom = Math.ceil(centerY + Math.ceil(height / 2));
          }
          break;
        case 'se':
          newbottom = bottom + dy;
          if (aspectRatio) {
            const height = newbottom - newtop;
            const width = height * aspectRatio;
            newleft = Math.floor(centerX - Math.floor(width / 2));
            newright = Math.ceil(centerX + Math.ceil(width / 2));
          } else {
            newright = right + dx;
          }
          break;
        case 's':
          newbottom = bottom + dy;
          if (aspectRatio) {
            const height = newbottom - newtop;
            const width = height * aspectRatio;
            newleft = Math.floor(centerX - Math.floor(width / 2));
            newright = Math.ceil(centerX + Math.ceil(width / 2));
          }
          break;
        case 'sw':
          newbottom = bottom + dy;
          if (aspectRatio) {
            const height = newbottom - newtop;
            const width = height * aspectRatio;
            newleft = Math.floor(centerX - Math.floor(width / 2));
            newright = Math.ceil(centerX + Math.ceil(width / 2));
          } else {
            newleft = left + dx;
          }
          break;
        case 'w':
          newleft = left + dx;
          if (aspectRatio) {
            const width = newright - newleft;
            const height = width / aspectRatio;
            newtop = Math.floor(centerY - Math.floor(height / 2));
            newbottom = Math.ceil(centerY + Math.ceil(height / 2));
          }
          break;
        case 'nw':
          newleft = left + dx;
          if (aspectRatio) {
            const width = newright - newleft;
            const height = width / aspectRatio;
            newtop = Math.floor(centerY - Math.floor(height / 2));
            newbottom = Math.ceil(centerY + Math.ceil(height / 2));
          } else {
            newtop = top + dy;
          }
          break;
        default:
          break;
      }

      /*
       * Now if the new region is out of bounds then bail out without
       * changing the region at all and ignore this move event
       */
      if (newtop < 0 || newleft < 0 ||
        newright > dest.width || newbottom > dest.height) {
        return;
      }

      /*
       * Don't let the crop region become smaller than 100x100. If it does
       * then the sensitive regions of the crop handles start to intersect.
       * If there is a cropping aspect ratio, then the minimum size in
       * one dimension will be 100 and will be larger in the other.
       */
      let minHeight = 100,
        minWidth = 100;
      if (aspectRatio) {
        if (aspectRatio > 1) {
          minWidth = Math.round(minWidth * aspectRatio);
        } else if (aspectRatio < 1) {
          minHeight = Math.round(minHeight / aspectRatio);
        }
      }

      /*
       * If the width is less than the minimum allowed (due to orientation
       * change), only allow the crop region to get bigger
       */
      const newWidth = newright - newleft;
      if (newWidth < region.right - region.left && newWidth < minWidth) {
        return;
      }
      const newHeight = newbottom - newtop;
      if (newHeight < region.bottom - region.top && newHeight < minHeight) {
        return;
      }
      region.left = newleft;
      region.right = newright;
      region.top = newtop;
      region.bottom = newbottom;
      that.drawCropControls();
    }

    function pan(dx, dy) {
      if (dx > 0) {
        dx = Math.min(dx,
          dest.width - right);
      }
      if (dx < 0) {
        dx = Math.max(dx,
          -left);
      }
      if (dy > 0) {
        dy = Math.min(dy,
          dest.height - bottom);
      }
      if (dy < 0) {
        dy = Math.max(dy,
          -top);
      }
      region.left = left + dx;
      region.right = right + dx;
      region.top = top + dy;
      region.bottom = bottom + dy;
      that.drawCropControls();
    }

    function up(e) {
      window.removeEventListener('pan',
        move,
        true);
      window.removeEventListener('swipe',
        up,
        true);
      that.drawCropControls(); // Erase drag handle highlight
      e.preventDefault();
    }
  }
};

/*
 * If the crop overlay is displayed, use the current position of the
 * overlaid crop region to actually set the crop region of the original image
 */
ImageEditor.prototype.cropImage = function cropImage(cropImageCallback) {
  if (!this.isCropOverlayShown()) {
    if (cropImageCallback) {
      cropImageCallback();
    }
    return;
  }

  const region = this.cropRegion;
  const dest = this.getDest();
  // Convert the preview crop region to fractions
  let left = Math.min(region.left / dest.width,
    1.0);
  let right = Math.min(region.right / dest.width,
    1.0);
  let top = Math.min(region.top / dest.height,
    1.0);
  let bottom = Math.min(region.bottom / dest.height,
    1.0);
  let srcHeight = null;
  let srcWidth = null;
  const swapped = this.widthHeightWasSwapped();
  if (swapped) {
    [srcWidth, srcHeight] = [this.source.height, this.source.width];
  } else {
    [srcWidth, srcHeight] = [this.source.width, this.source.height];
  }

  /*
   * Now convert those fractions to pixels in the original image
   * Note that the original image may have already been cropped, so we
   * multiply by the size of the crop region, not the full size
   */
  left = Math.floor(left * srcWidth);
  right = Math.ceil(right * srcWidth);
  top = Math.floor(top * srcHeight);
  bottom = Math.ceil(bottom * srcHeight);

  /*
   * XXX: tweak these to make sure we still have the right aspect ratio
   * after rounding to pixels
   *console.error('Maintain aspect ratio precisely!!!');
   */

  // And update the real crop region
  this.source.width = swapped ? bottom - top : right - left;
  this.source.height = swapped ? right - left : bottom - top;
  switch (this.edits.rotate.matIdx) {
    case ROT_MAT_IDX.r90:
      this.source.x += top;
      this.source.y += srcWidth - right;
      break;
    case ROT_MAT_IDX.r180:
      this.source.x += srcWidth - right;
      this.source.y += srcHeight - bottom;
      break;
    case ROT_MAT_IDX.r270:
      this.source.x += srcHeight - bottom;
      this.source.y += left;
      break;
    default:
      this.source.x += left;
      this.source.y += top;
  }

  this.resetPreview();
  this.edit(() => {
    this.hideCropOverlay();
    this.showCropOverlay();
    if (cropImageCallback) {
      cropImageCallback();
    }
  });
};

// Restore the image to its full original size
ImageEditor.prototype.undoCrop = function undoCrop() {
  this.resetCropRegion();
  this.resetPreview();
  this.edit(() => {
    this.hideCropOverlay();
    this.showCropOverlay();
  });
};

// Cw: clockwise, ccw: counter clockwise
ImageEditor.prototype.rotate = function rotate(isClockwise) {
  const cropProportions = this.getNewCropRegion();
  const canvas = this.previewCanvas;
  const pre = this.preview;
  const { dest } = this;
  const STMP = canvas.width;
  canvas.width = canvas.height;
  canvas.height = STMP;
  this.edits.rotate.matIdx = Utilities.getLoopNum(
    ROT_MAT_IDX.r0,
    ROT_MAT_IDX.r270,
    this.edits.rotate.matIdx,
    isClockwise);
  const scalex = this.previewCanvas.width / this.source.width;
  const scaley = this.previewCanvas.height / this.source.height;
  this.scale = Math.min(Math.min(scalex,
    scaley),
  1);
  pre.width = Math.floor(this.source.width * this.scale);
  pre.height = Math.floor(this.source.height * this.scale);
  dest.x = Math.floor((this.previewCanvas.width - pre.width) / 2);
  dest.y = Math.floor((this.previewCanvas.height - pre.height) / 2);
  dest.width = pre.width;
  dest.height = pre.height;
  this.edits.rotate.set = false;
  this.processor.draw(pre,
    this.needsUpload,
    0,
    0,
    pre.width,
    pre.height,
    dest.x,
    dest.y,
    dest.width,
    dest.height,
    this.edits);
  this.rotateCropOverlay(cropProportions);
};

ImageEditor.prototype.unRotate = function unRotate() {
  if (!this.edits.rotate.set) {
    const dpr = window.devicePixelRatio;
    const canvas = this.previewCanvas;
    const pre = this.preview;
    const { dest } = this;
    canvas.width = Math.ceil(canvas.clientWidth * dpr);
    canvas.height = Math.ceil(canvas.clientHeight * dpr);
    this.edits.rotate.matIdx = 0;
    const scalex = this.previewCanvas.width / this.source.width;
    const scaley = this.previewCanvas.height / this.source.height;
    this.scale = Math.min(Math.min(scalex,
      scaley),
    1);
    pre.width = Math.floor(this.source.width * this.scale);
    pre.height = Math.floor(this.source.height * this.scale);
    dest.x = Math.floor((this.previewCanvas.width - pre.width) / 2);
    dest.y = Math.floor((this.previewCanvas.height - pre.height) / 2);
    dest.width = pre.width;
    dest.height = pre.height;
    this.processor.draw(pre,
      this.needsUpload,
      0,
      0,
      pre.width,
      pre.height,
      dest.x,
      dest.y,
      dest.width,
      dest.height,
      this.edits);
  }
};

ImageEditor.prototype.resetCrop = function resetCrop() {
  this.setCropAspectRatio();
  this.edits.crop.cropModeId = 'edit-crop-aspect-free';
};

ImageEditor.prototype.getNewCropRegion = function getNewCropRegion() {
  const region = this.cropRegion;
  const dest = this.getDest();
  const regionWidth = region.right - region.left;
  const regionHeight = region.bottom - region.top;
  const newTop = dest.width - region.right;
  const newLeft = region.top;
  const newRight = newLeft + regionHeight;
  const newBottom = newTop + regionWidth;
  const topProportion = Math.min(newTop / dest.width,
    1.0);
  const leftProportion = Math.min(newLeft / dest.height,
    1.0);
  const rightProportion = Math.min(newRight / dest.height,
    1.0);
  const bottomProportion = Math.min(newBottom / dest.width,
    1.0);
  return [topProportion, rightProportion, bottomProportion, leftProportion];
};

ImageEditor.prototype.rotateCropOverlay =
  function rotateCropOverlay(proportions) {
    const dest = this.getDest();
    const newRegion = {
      top: dest.height * proportions[0],
      right: dest.width * proportions[1],
      bottom: dest.height * proportions[2],
      left: dest.width * proportions[3]
    };
    const storageCache = this.cropAspectWidth;
    this.cropAspectWidth = this.cropAspectHeight;
    this.cropAspectHeight = storageCache;
    this.hideCropOverlay();
    this.showCropOverlay(newRegion);
    this.changeCropModeId();
  };

ImageEditor.prototype.changeCropModeId = function changeCropModeId() {
  const cropModeID = this.edits.crop.cropModeId;
  const needChangeCropModeIDs = [
    'edit-crop-aspect-3x2',
    'edit-crop-aspect-2x3',
    'edit-crop-aspect-4x3',
    'edit-crop-aspect-3x4',
    'edit-crop-aspect-16x9',
    'edit-crop-aspect-9x16'
  ];
  if (needChangeCropModeIDs.contains(cropModeID)) {
    const arr = cropModeID.split('-');
    const sizeArr = arr[3].split('x');
    this.edits.crop.cropModeId =
      `edit-crop-aspect-${sizeArr[1]}x${sizeArr[0]}`;
  }
};

/*
 * Pass no arguments for freeform 1,1 for square,
 * 2,3 for portrait, 3,2 for landscape.
 */
ImageEditor.prototype.setCropAspectRatio = function setCropAspectRatio(
  ratioWidth, ratioHeight) {
  const region = this.cropRegion;
  const dest = this.getDest();
  this.cropAspectWidth = ratioWidth || 0;
  this.cropAspectHeight = ratioHeight || 0;

  if (ratioWidth && ratioHeight) {
    // Constrained cropping, centered on image
    const centerX = dest.width / 2;
    const centerY = dest.height / 2;

    const scaleX = dest.width / ratioWidth;
    const scaleY = dest.height / ratioHeight;
    const scale = Math.min(scaleX,
      scaleY);

    const width = Math.floor(scale * ratioWidth);
    const height = Math.floor(scale * ratioHeight);

    region.left = centerX - width / 2;
    region.right = centerX + width / 2;
    region.top = centerY - height / 2;
    region.bottom = centerY + height / 2;
  } else {
    // Freeform cropping
    region.left = 0;
    region.top = 0;
    region.right = dest.width;
    region.bottom = dest.height;
  }
  this.drawCropControls();
};

ImageEditor.prototype.updateCrop = function updateCrop(delta) {
  const region = this.cropRegion;
  const dest = this.getDest();

  [region.left, region.right] = inc(delta.x,
    region.left,
    region.right,
    dest.width);
  [region.top, region.bottom] = inc(delta.y,
    region.top,
    region.bottom,
    dest.height);

  this.drawCropControls();

  function inc(value, oldmin, oldmax, max) { // eslint-disable-line
    if (0 === value) {
      return [oldmin, oldmax];
    }
    const len = oldmax - oldmin;
    let valmax = null;
    let valmin = null;
    [valmin, valmax] = [oldmin + value, oldmax + value];
    if (valmax > max) {
      [valmin, valmax] = [max - len, max];
    } else if (valmin < 0) {
      [valmin, valmax] = [0, len];
    }
    return [valmin, valmax];
  }
};

/*
 * Return the crop region as an object with left, top, width and height
 * properties. The values of these properties are numbers between 0 and 1
 * representing fractions of the full image width and height.
 */
ImageEditor.prototype.getCropRegion = function getCropRegion() {
  const region = this.cropRegion;
  const previewRect = this.dest;
  const dpr = window.devicePixelRatio;
  this.paramReplace(previewRect.width,
    previewRect.height,
    this.widthHeightWasSwapped());
  // Convert the preview crop region to fractions
  const left = dpr * region.left / previewRect.width;
  const right = dpr * region.right / previewRect.width;
  const top = dpr * region.top / previewRect.height;
  const bottom = dpr * region.bottom / previewRect.height;

  return {
    left,
    top,
    width: Math.min(right - left,
      1.0),
    height: Math.min(bottom - top,
      1.0)
  };
};

ImageEditor.prototype.prepareAutoEnhancement =
  function prepareAutoEnhancement(pixel) {
    const worker = new Worker('js/auto_enhancement_worker.js');
    worker.addEventListener('message',
      (message) => {
        this.autoEnhanceValues = message.data;
      });
    worker.postMessage(pixel);
  };
