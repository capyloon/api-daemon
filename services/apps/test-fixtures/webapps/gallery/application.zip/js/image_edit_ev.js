'use strict';
/* global ImageEditView, GestureDetector */
(function (exports) { // eslint-disable-line
  const ImageEv = {
    enterEvView() {
      this.dragSlider();
    },

    exitEditMode() {
      if (!this.slider) {
        return;
      }
      this.slider.removeEventListener('touchend', this.touchendCallback);
      this.slider.value = 3;
      this.slider = null;
      this.touchendCallback = null;
      this.gestureDetector.stopDetecting();
      this.gestureDetector = null;
    },

    dragSlider() {
      if (this.slider) {
        return;
      }
      this.slider = document.querySelector('#image-ev-slider-thumb');
      this.gestureDetector = new GestureDetector(this.slider);
      this.gestureDetector.startDetecting();
      this.touchendCallback = this.setExposure.bind(this);
      this.slider.addEventListener('touchend', this.touchendCallback);
    },

    setExposure() {
      const sliderValue = this.slider.value;
      const exposure = sliderValue - 3;
      const factor = -1;
      const gamma = Math.pow(2, exposure * factor);
      ImageEditView.editSettings.exposure.gamma = gamma;
      ImageEditView.editSettings.exposure.sliderThumbPos = exposure;
      ImageEditView.imageEditor.edit();
      ImageEditView.changeSaveBtnState(ImageEditView.imageEditor.isEdited());
    }
  };
  exports.ImageEv = ImageEv;
}(window));
