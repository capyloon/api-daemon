/**
 * ThumbnailList is the class reponsible for rendering all gallery content in to
 * list. It uses GroupClass to group and sort file data as ThumbnailItem.
 *
 * Constructor:
 *    groupClass: the grouping class.
 *    container: the HTML DOM object for containing everything.
 *
 * API:
 *    addItem: add a file data and render it.
 *        item: the file data to add.
 *    removeItem: remove a ThumbnailItem.
 *        filename: the filename of file data.
 *    reset: clears all the internal data structure.
 *
 * Properties:
 *    thumbnailMap: a mapping of filename to ThumbnailItem.
 *    groupMap: a mapping of filename to thumbnail group.
 *    itemGroups: an sorted array of thumbnail group.
 *    count: the total ThumbnailItem in this list.
 *    groupClass: the grouping class this list used.
 *    container: the HTML DOM element containing this list.
 */
function ThumbnailList(groupClass, container) {
  if (!groupClass || !container) {
    throw new Error('group class or container cannot be null or undefined');
  }
  // The group list
  this.itemGroups = [];
  this.groupClass = groupClass;
  this.container = container;
}

ThumbnailList.prototype.findGroup = function (fileInfo, needGroup) {
  const group = {
    groupID: ThumbnailDateGroup.getGroupID(fileInfo,
      needGroup)
  };
  const index = this.itemGroups.bsearch(group,
    (a, b) => ThumbnailDateGroup.compareGroupID(b.groupID,
      a.groupID));
  return index !== -1 ? this.itemGroups[index] : null;
};

ThumbnailList.prototype.addItem = function (item, needGroup) {
  if (!item) {
    return null;
  }
  const self = this;
  function createItemGroup(item, before, needGroup) {
    const group = new self.groupClass(item,
      needGroup);

    self.container.insertBefore(group.htmlNode,
      before ? before.htmlNode : null);
    return group;
  }

  function getItemGroup(item, needGroup) {
    const groupID = self.groupClass.getGroupID(item,
      needGroup);
    let i;
    for (i = 0; i < self.itemGroups.length; i++) {
      if (self.itemGroups[i].groupID === groupID) {
        return self.itemGroups[i];
      } else if (self.groupClass.compareGroupID(self.itemGroups[i].groupID,
        groupID) < 0) {
        // Existing ID is less than current groupID, stop searching/
        break;
      }
    }
    const createdGroup = createItemGroup(item,
      self.itemGroups[i],
      needGroup);
    self.itemGroups.splice(i,
      0,
      createdGroup);
    return createdGroup;
  }

  const group = getItemGroup(item,
    needGroup);
  const thumbnail = group.addItem(item);
  thumbnail.htmlNode.addEventListener('click',
    () => {
      PhotoDB.thumbnailClickHandler(thumbnail);
    });
  return thumbnail;
};

ThumbnailList.prototype.removeItem = function (fileInfo, needGroup) {
  const group = this.findGroup(fileInfo,
    needGroup);
  if (group) {
    group.removeItem(fileInfo);
    if (!group.getCount()) {
      this.container.removeChild(group.htmlNode);
      this.itemGroups.splice(this.itemGroups.indexOf(group),
        1);
    }
  }
};

ThumbnailList.prototype.reset = function () {
  this.container.innerHTML = '';
  this.itemGroups = [];
};

ThumbnailList.prototype.resetThumbnail = function (needGroup) {
  const allPhotos = this.getAllThumbnails();
  this.reset();
  for (let i = 0; i < allPhotos.length; i++) {
    this.addItem(allPhotos[i].data,
      needGroup);
  }
};

ThumbnailList.prototype.getAllThumbnails = function () {
  let allThumbnails = [];
  const groups = this.itemGroups;
  for (let i = 0; i < groups.length; i++) {
    const { thumbnails } = groups[i];
    allThumbnails = allThumbnails.concat(thumbnails);
  }
  return allThumbnails;
};

ThumbnailList.prototype.getCount = function () {
  let count = 0;
  const groups = this.itemGroups;
  if (!groups) {
    return count;
  }
  for (let i = 0; i < groups.length; i++) {
    count += groups[i].thumbnails.length;
  }
  return count;
};

ThumbnailList.prototype.getThumbnailIndex = function (name) {
  let index = -1;
  const allPhotos = this.getAllThumbnails(name);
  for (let i = 0; i < allPhotos.length; i++) {
    if (name === allPhotos[i].data.name) {
      index = i;
      break;
    }
  }
  return index;
};

ThumbnailList.prototype.getThumbnail = function (name) {
  let fileInfo = null;
  const allPhotos = this.getAllThumbnails(name);
  for (let i = 0; i < allPhotos.length; i++) {
    if (name === allPhotos[i].data.name) {
      fileInfo = allPhotos[i];
      break;
    }
  }
  return fileInfo;
};

