'use strict';
function pendingInit() {
  window.removeEventListener('load',
    pendingInit);
  window.setTimeout(() => {
    const lazyFiles = [
      'shared/style/toaster.css',
      'style/view_dialog.css',
      'style/inalbum.css',

      'shared/js/toaster.js',
      'js/view_dialog.js',
      'js/view_valueselect.js',
      'js/fileinfo.js',
      'js/inalbum.js',
      'js/pickmore.js',
      'app://shared.gaiamobile.org/elements/kai-dialog.js',
      'app://shared.gaiamobile.org/elements/kai-textfield.js'
    ];
    LazyLoader.load(lazyFiles);
  }, 500);
}
window.addEventListener('load',
  pendingInit);
