class Calculator {
  constructor() {
    this.SIGNIFICANT_DIGITS = 10;
    this.EX_SIGNIFICANT_DIGITS = 6;
    this.MAX_SCREEN_DISPALY_LENGTH = 11;
  }

  calculate(firstOperand, secondOperand, operator) {
    let result = 0;
    let operandOne = parseFloat(firstOperand);
    let operandTwo = parseFloat(secondOperand);
    switch (operator) {
      case '+':
        result = operandOne + operandTwo;
        break;
      case '−':
        result = operandOne - operandTwo;
        break;
      case '×':
        result = operandOne * operandTwo;
        break;
      case '÷':
        if (operandTwo === 0 || operandTwo === -0) {
          result = navigator.mozL10n.get('error');
        } else {
          result = operandOne / operandTwo;
        }
        break;
    }
    return this.toPrecision(result);
  }

  toPrecision(value) {
    if (isNaN(value)) {
      return value;
    }
    let result = parseFloat(value.toPrecision(this.SIGNIFICANT_DIGITS));
    let maxDisplayableValue = '1e' + this.SIGNIFICANT_DIGITS - 1;
    if (value > maxDisplayableValue || value < -maxDisplayableValue) {
      let originResult = result;
      result = originResult.toExponential(this.EX_SIGNIFICANT_DIGITS);
      if (result.indexOf('e') >= 0 && result.indexOf('.') >= 0) {
        let splitResult = result.split('e')[0].split('.')[1];
        splitResult = splitResult.replace(/0+$/gi, '');
        let aResult = result.split('.')[0];
        if (splitResult) {
          aResult = aResult + '.';
        }
        result = aResult + splitResult + 'e' + result.split('e')[1];
      }
    } else {
      let valueStr = result.toString();
      if (valueStr.length > this.MAX_SCREEN_DISPALY_LENGTH && -1 !== valueStr.indexOf('.')) {
        result = parseFloat(result.toExponential(this.SIGNIFICANT_DIGITS - 1));
        result = parseFloat(result.toFixed(this.SIGNIFICANT_DIGITS - 1));
      }
    }
    return result + '';
  }

  exceedLimit(operand) {
    if (operand.indexOf('e') !== -1) {
      return true;
    }
    let len = operand.length;
    if (operand.indexOf('.') !== -1) {
      len--;
    }
    if (operand.indexOf('-') !== -1) {
      len--;
    }
    return (len >= this.SIGNIFICANT_DIGITS);
  }
}