const STATUS = {
  'INIT': 0,
  'FIRST_OPERAND': 1,
  'OPERATOR': 2,
  'SECOND_OPERAND': 3,
  'RESULT': 4
};
class Panel {
  constructor() {
    this.showResult = false;
    this.secondOperandValue = '0';
    this.operatorValue = '';
    this.firstOperandValue = '';
  }

  get showResult() {
    return this._showResult;
  }

  set showResult(flag) {
    this._showResult = flag;
  }

  get firstOperand() {
    return document.getElementById('first_operand');
  }

  get firstOperandValue() {
    return this._firstOperand;
  }

  set firstOperandValue(value) {
    this._firstOperand = value;
    this.firstOperand.innerHTML = this.formatNumber(value);
  }

  get secondOperand() {
    return document.getElementById('second_operand');
  }

  get secondOperandValue() {
    return this._secondOperand;
  }

  set secondOperandValue(value) {
    this._secondOperand = value;
    if (value.length > 8) {
      this.secondRow.setAttribute('class', 'row-two smallFont');
    } else {
      this.secondRow.setAttribute('class', 'row-two');
    }
    this.secondOperand.innerHTML = this.formatNumber(value);
  }

  get secondRow() {
    return document.getElementsByClassName('row-two')[0];
  }

  get operator() {
    return document.getElementById('operator');
  }

  get operatorValue() {
    return this.operator.innerHTML;
  }

  set operatorValue(value) {
    this.operator.innerHTML = value;
  }

  get backBtn(){
    return document.getElementById('backBtn');
  }

  getStatus() {
    if (this.showResult) {
      return STATUS.RESULT;
    } else {
      return (
        ('' === this.firstOperandValue ? 0 : 1) +
        ('' === this.operatorValue ? 0 : 1) +
        ('' === this.secondOperandValue ? 0 : 1)
      );
    }
  }

  liftResult() {
    return new Calculator().calculate(this.firstOperandValue, this.secondOperandValue, this.operatorValue);
  }

  updatePanel({ firstOperand, secondOperand, operator }) {
    if (firstOperand !== null) {
      this.firstOperandValue = firstOperand;
    }
    if (secondOperand !== null) {
      this.secondOperandValue = secondOperand;
    }
    if (operator !== null) {
      this.operatorValue = operator;
    }
  }

  addStorage(value) {
    localStorage.setItem('calculator_app', JSON.stringify(value));
  }

  getStorage() {
    let localStorageValue = JSON.parse(localStorage.getItem('calculator_app'));
    if (localStorageValue) {
      this.updatePanel(localStorageValue);
      this.showResult = localStorageValue.showResult;
    }
  }

  formatNumber(numStr, setDot) {
    if ('' === numStr || '-0' === numStr || !this.lang ||
      isNaN(numStr) || numStr.indexOf('e') > -1) {
      return numStr;
    }
    let pointIndex = numStr.indexOf('.');
    let tempStr;
    let needSplit = pointIndex > 0 && !setDot;
    if (needSplit) {
      tempStr = numStr.substring(0, pointIndex);
    } else {
      tempStr = numStr;
    }
    tempStr = ('-0' === tempStr ? '-' : '') + Number(tempStr).toLocaleString(this.lang);
    if (setDot && !this.dot) {
      this.dot = tempStr[1];
    }
    if (needSplit) {
      numStr = tempStr + this.dot + numStr.substr(pointIndex + 1);
    } else {
      numStr = tempStr;
    }
    return numStr;
  }
}