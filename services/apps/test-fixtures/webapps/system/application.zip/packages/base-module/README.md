# BaseModule es6 version #
BaseModule is a helper class for any ui-less controller/store module to extends.
# Usage #
## Service registration ##
```js
import BaseModule from 'base-module';

export default class MyModuleA extends BaseModule {
  EVENT_PREFIX = 'a-';

  name = 'MyModuleA';

  SERVICES = ['show', 'open'];

  constructor() {
    super();
  }

  open(evt) {
    // service request
  }
};
```
## CustomEvent handling ##
```js
import BaseModule from 'base-module';

export default class MyModuleA extends BaseModule {
  EVENT_PREFIX = 'a-';

  name = 'MyModuleA';

  EVENTS = ['iac-my'];

  constructor() {
    super();
  }

  '_handle_iac-my'(evt) {
    // handle evt...
  }
};
```
## Settings Observation ##
```js
import BaseModule from 'base-module';

export default class MyModuleA extends BaseModule {
  EVENT_PREFIX = 'a-';

  name = 'MyModuleA';

  SETTINGS = ['xxx.enabled'];

  constructor() {
    super();
  }

  '_observe_xxx.enabled'(value) {
    // Can use this._settings to access, too
  }
};
```
## Event Emitter ##
```js
import BaseModule from 'base-module';

export default class MyModuleA extends BaseModule {
  EVENT_PREFIX = 'a-';

  name = 'MyModuleA';

  changed(value) {
    this.emit('changed');
  }
};
```