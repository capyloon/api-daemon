## Usage ##
```js
  classA extends BaseEmitter {
    start() {
      this.emit('started');
    }
  }
  var a = new classA();
  a.on('started', () => {
    // do something
  });
```