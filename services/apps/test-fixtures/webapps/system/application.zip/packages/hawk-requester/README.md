# hawk-requester

## Usage ##
```js
import Requester from 'hawk-requester';

var requester = new Requester(TIMEOUT);
requester.setHawkCredentials(kid, macKey);
requester.send({
  url: url,
  method: 'POST',
  params: params
});
```