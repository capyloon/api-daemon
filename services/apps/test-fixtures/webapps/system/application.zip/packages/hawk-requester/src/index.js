import hawk from './lib/hawk';

const XHR_TIMEOUT_MS = 60000;

class Requester {
  constructor(timeout = XHR_TIMEOUT_MS) {
    this._timeout = timeout;
    this._hawkCredentials = null;
    this._deviceInfo = null;
    this.hawk = hawk;
  }

  setDeviceInfo(deviceInfo) {
    //ct=(wifi|3g|4g|5g)
    //dev_utc=1541197041  Device time in UTC
    //dev_utc_off="-8" 
    //dev_build_id
    //dev_build_number

    this._deviceInfo = {
      'ct': deviceInfo.ct,
      'dev_utc': deviceInfo.utc,
      'dev_utc_off': deviceInfo.utcOff,
      'dev_build_id': deviceInfo.buildID,
      'dev_build_number':
        (deviceInfo.buildNumber)? deviceInfo.buildNumber : null
    };
  }

  setHawkCredentials(kid, macKey) {
    this._hawkCredentials = {
      id: kid,
      key: convertKey(macKey),
      algorithm: 'sha256'
    };
  }

  send(options) {
    return new Promise((resolve, reject) => {
      const params = JSON.stringify(options.params);
      const url = options.url;
      const method = options.method;
      const authorization = options.authorization;

      const xhr = new XMLHttpRequest({ mozSystem: true });
      xhr.open(method, url, true);
      xhr.timeout = this._timeout;
      xhr.setRequestHeader('Content-Type', 'application/json');
      xhr.withCredentials = true;
      xhr.responseType = '';

      if (authorization) {
        xhr.setRequestHeader('Authorization', authorization);
      } else if (this._hawkCredentials) {
        let credentials = {
          credentials: this._hawkCredentials
        };
        if (params) {
          credentials.payload = params;
          credentials.contentType = 'application/json';
        }
        let hawkHeader = hawk.client.header(url, method, credentials);
        xhr.setRequestHeader('Authorization', hawkHeader.field);
      }

      if (this._deviceInfo) {
        const deviceInfo = this._deviceInfo;
        Object.keys(deviceInfo).forEach(function(key) {
          let val = deviceInfo[key];
          xhr.setRequestHeader(key, val);
        });
      }

      xhr.onload = function fmdr_xhr_onload() {
        if (xhr.status >= 200 && xhr.status < 300) {
          resolve(xhr.response);
        } else {
          reject({
            status: xhr.status,
            statusText: xhr.statusText,
            responseText: xhr.responseText
          });
        }
      };

      xhr.onerror = function fmd_xhr_onerror() {
        reject({
          status: xhr.status,
          statusText: xhr.statusText,
          responseText: xhr.responseText
        });
      };

      xhr.ontimeout = function fmd_xhr_ontimeout() {
        xhr.onerror();
      };

      if (params) {
        xhr.send(params);
      } else {
        xhr.send(null);
      }
    });
  }
}

function convertKey(key) {
  var key_bin = atob(key);
  var key_array = new ArrayBuffer(key_bin.length);
  var key_uint8 = new Uint8Array(key_array);
  for (var i = 0; i < key_uint8.length; i++) {
    key_uint8[i] = key_bin.charCodeAt(i);
  }
  return toHexString(key_uint8);
}

function toHexString(uint8arr) {
  if (!uint8arr) {
    return '';
  }
  var hexStr = '';
  for (var i = 0; i < uint8arr.length; i++) {
    var hex = (uint8arr[i] & 0xff).toString(16);
    hex = (hex.length === 1) ? '0' + hex : hex;
    hexStr += hex;
  }
  return hexStr.toUpperCase();
}

function atob(str) {
  return new Buffer(str, 'base64').toString('binary');
}

export default Requester;