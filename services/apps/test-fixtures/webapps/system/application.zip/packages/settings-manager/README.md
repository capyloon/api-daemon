## Usage ##
```js
import SettingsManager from 'settings-manager';
var MyModule = {
  start() {
    SettingsManager.observe('my-settings.enabled', this);
  }
  observe(name, value) {
    console.log(name, value);
  }
}
```
