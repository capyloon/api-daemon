## Usage ##
```js
// my_history.js
import SimpleNavigationHelper from 'simple-navigation-helper';
let navigator = new SimpleNavigationHelper('.focusable', element);
```
