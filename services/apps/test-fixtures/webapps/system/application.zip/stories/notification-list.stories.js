import { storiesOf } from '@storybook/html';
import { store } from '../src/redux';
import '../src/custom_elements/kai-notification';
import '../src/custom_elements/notification-list.js';

storiesOf('notification-list', module)
  .add('basic', () => {
    randomItems(99).forEach((item) => {
      store.dispatch({
        type: 'ADD_NOTIFICATION',
        id: item.id,
        item,
      });
    });
    return '<notification-list></notification-list>';
  });

function randomItems(count) {
  const appNames =[
    'System',
    'Call',
    'Messages',
  ];

  const groups = [
    'Email',
    'Calendar',
    'Facebook',
  ];

  const titles = [
    '',
    'Cras non mauris vitae mi venenatis.',
    'Maecenas sagittis odio sit amet arcu congue, at viverra eros volutpat id nisi venenatis, mattis tellus.',
  ];

  const texts = [
    '',
    'Morbi nec enim sed arcu lacinia bibendum.',
    'Integer ut sapien orci. Aenean semper bibendum tellus eget blandit. Ut placerat ipsum eu tincidunt consequat. Integer vestibulum lectus quis lectus tincidunt aliquet et a libero.',
  ];

  const randomFrom = (candidates) => candidates[parseInt(Math.random() * candidates.length)];
  const randomTime = () => {
    // averagely choose from just now to one year ago
    const hr = randomFrom([0.5, 5, 24, 24 * 30, 24 * 30 * 12]);
    return Date.now() - 3600 * hr * 1000 * Math.random();
  };

  const items = [];
  appNames.forEach((appName, i) => {
    items.push({
      id: `id${i}`,
      appIcon: '',
      appName,
      title: randomFrom(titles),
      text: randomFrom(texts),
      timestamp: randomTime(),
    });
  });

  Array(count - appNames.length).fill(true).forEach((v, i) => {
    items.push({
      id: `id${i + appNames.length}`,
      appIcon: '',
      appName: randomFrom(groups),
      title: randomFrom(titles),
      text: randomFrom(texts),
      timestamp: randomTime(),
    });
  });
  items.sort((a, b) => a.timestamp - b.timestamp);
  return items;
}
