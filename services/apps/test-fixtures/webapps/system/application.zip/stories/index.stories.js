import { storiesOf } from '@storybook/html';
import { store } from '../src/redux';
import '../src/custom_elements/air-deck.js';
import '../src/custom_elements/app-root.js';
import '../src/custom_elements/infogation-bar.js';
import '../src/custom_elements/instant-panel.js';
import '../src/custom_elements/keyboard-app.js';

storiesOf('Basic', module)
  .add('air-deck', () => {
    store.dispatch({
      type: 'UPDATE_AIR_DECK',
      isShown: true,
    });
    return '<air-deck></air-deck>';
  })
  .add('app-root', () => '<app-root></app-root>')
  .add('keyboard-app', () => '<keyboard-app></keyboard-app>');

storiesOf('instant-panel', module)
  .add('switch off', () => {
    if (!store.getState().isInstantPanelShown) {
      store.dispatch({ type: 'TOGGLE_INSTANT_PANEL' });
    }
    store.dispatch({ type: 'UPDATE_SETTING', item: 'mobileData', value: false });
    return '<instant-panel></instant-panel>';
  })
  .add('switch on', () => {
    if (!store.getState().isInstantPanelShown) {
      store.dispatch({ type: 'TOGGLE_INSTANT_PANEL' });
    }
    store.dispatch({ type: 'UPDATE_SETTING', item: 'mobileData', value: true });
    return '<instant-panel></instant-panel>';
  });

storiesOf('infogation-bar', module)
  .add('battery low', () => {
    if (store.getState().isInstantPanelShown) {
      store.dispatch({ type: 'TOGGLE_INSTANT_PANEL' });
    }
    store.dispatch({
      type: 'UPDATE_BATTERY',
      newState: {
        charging: true,
        level: 0.15,
        plugged: false,
      },
    });

    return '<infogation-bar></infogation-bar>';
  })
  .add('battery full', () => {
    if (store.getState().isInstantPanelShown) {
      store.dispatch({ type: 'TOGGLE_INSTANT_PANEL' });
    }
    store.dispatch({
      type: 'UPDATE_BATTERY',
      newState: {
        level: 1,
        plugged: true,
      },
    });

    return '<infogation-bar></infogation-bar>';
  })
  .add('when instant-panel shown', () => {
    if (!store.getState().isInstantPanelShown) {
      store.dispatch({ type: 'TOGGLE_INSTANT_PANEL' });
    }
    return '<infogation-bar></infogation-bar>';
  });
