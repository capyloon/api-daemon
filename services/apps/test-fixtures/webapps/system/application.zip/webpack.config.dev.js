const path = require('path');
const fs = require('fs');
const MiniCssExtractPlugin = require('mini-css-extract-plugin');
const BundleAnalyzerPlugin = require('webpack-bundle-analyzer').BundleAnalyzerPlugin;

module.exports = {
  mode: 'development',
  resolve: {
    modules: [
      'node_modules',
    ],
  },
  entry: {
    app: './src/app.js',
    app_umd: './src/app_umd.js',
    app_umd_defer: './src/app_umd_defer.js'
  },
  output: {
    path: path.resolve(__dirname, 'dist'),
    filename: '[name].bundle.js',
    publicPath: 'dist/'
  },
  devtool: '#source-map',
  stats: {
    children: false
  },
  module: {
    rules: [
      {
        test: /\.js$/,
        include: [
          path.resolve(__dirname, 'src'),
          path.resolve(__dirname, 'js'),
          path.resolve(__dirname, 'packages'),
          /(node_modules)\/(lit-element)/,
          /(node_modules)\/(lit-html)/
        ],
        use: {
          loader: 'babel-loader',
          options: {
            // Read file `.babelrc` directly because somehow the option `babelrc: true` doesn't work.
            // See: https://github.com/babel/babel-loader/issues/552#issuecomment-394788570
            // Not using `babel.config.js` because we want apply the same babel config for storybook
            // but it [only supports `.babelrc`](https://storybook.js.org/docs/configurations/custom-babel-config/).
            ...JSON.parse(fs.readFileSync(path.resolve(__dirname, './.babelrc')))
          }
        }
      },
      {
        test: /\.(scss|css)$/,
        use: [
          'style-loader',
          {
            loader: MiniCssExtractPlugin.loader,
            options: {
              publicPath: './'
            }
          },
          'css-loader',
          'sass-loader',
        ]
      },
      {
        test: /\.(ttf|eot|png|svg|woff(2)?)(\?[a-z0-9]+)?$/,
        use: 'file-loader?name=[name]-[hash:6].[ext]'
      }
    ]
  },
  optimization: {
    splitChunks: {
      chunks(chunk) {
        // Exclude `app_umd.js` and `app_umd_defer.js` for now.
        // This is because we defer the vendors.bundle.js(executed far after `app_umd*` are loaded)
        // Once all the `<script>` tags are cleared, we may improve the chunks strategy
        return !chunk.name.startsWith('app_umd');
      },
      name: 'vendors'
    }
  },
  plugins: [
    new MiniCssExtractPlugin({
      filename: '[name].css',
      chunkFilename: '[id].css',
    }),
    // generate stats.json without server
    // use yarn run analyze to serve and browse the stats
    new BundleAnalyzerPlugin({
      analyzerMode: 'disabled',
      openAnalyzer: false,
      generateStatesFile: true
    })
  ]
};
