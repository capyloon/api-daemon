# System app

## Prerequisites

* GNU Make
* [Node.js][Node.js] v8.x
* [yarn][yarn] v1.x

[Node.js]: https://nodejs.org/docs/latest-v8.x/api/fs.html
[yarn]: https://yarnpkg.com/en/docs/install

## Usage

### yarn scripts
- quick start for development with watch
```sh
yarn install
yarn start
```

- watch for bundling
```sh
# development mode
yarn watch:dev
# production mode
# yarn watch:prod
```

- build bundles(no watch)
```sh
# development mode
yarn build:dev
# production mode
# yarn build:prod
```

- to analyze bundles(use `webpack-bundle-analyzer`)
```sh
# development mode
yarn profile:dev
# production mode
# yarn profile:prod
yarn analyze
```

## Make Options

* `make`
* `make clean`
* `make distclean`
* `make watch`
* `make build`
* `make test`

## Development

See [development.md](development.md).

## How to change theme
##### Pre-requirement
- Link theme.css in `index.html`
  - `<link rel="stylesheet" type="text/css" href="app://theme.gaiamobile.org/theme.css">`
- Ensure `lighttheme` and `darktheme` included in gaia profile
  - `gaia/build/config/phone/apps-engineering.list` should have `apps/lighttheme` and `apps/darktheme`
- Set default value of `theme.selected`
  - `gaia/build/config/common-settings.json`
  - e.g. `"theme.selected": "app://darktheme.gaiamobile.org/manifest.webapp"`

##### Change theme from WebIDE
Set `lighttheme`:
```js
navigator.mozSettings.createLock().set({'theme.selected': 'app://lighttheme.gaiamobile.org/manifest.webapp'}).then(e=> console.log(e))
```

Set `darktheme`:
```js
navigator.mozSettings.createLock().set({'theme.selected': 'app://darktheme.gaiamobile.org/manifest.webapp'}).then(e=> console.log(e))
```

## Logging
- Make sure `debug.gaia.enabled` true

  Execute in webIDE's console:
  ```js
  navigator.mozSettings.createLock().get('debug.gaia.enabled').then(e=> console.log(e));
  ```

  To set:
  ```js
  navigator.mozSettings.createLock().set({'debug.gaia.enabled': true}).then(e=> console.log(e));
  ```

- Use `adb`
  ```sh
  adb logcat *:S GeckoDump:V
  ```
