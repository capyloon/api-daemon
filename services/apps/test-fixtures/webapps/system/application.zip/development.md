# Development guide

This file provides some high level knowledge that is useful (hopefully) when developing System app.

#### Table of Contents
* [Key files & folders](#key-files--folders)
* [Architecture](#architecture)
* [How to migrate files under the folder `js`](#how-to-migrate-files-under-the-folder-js)
* [Steps to enable a new feature](#steps-to-enable-a-new-feature)
    * [with UI](#with-ui)
    * [without UI](#without-ui)
* [Customized theme](#customized-theme)
* [index.html](#indexhtml)
    - [app-root](#app-root)
* [How to use storybook](#how-to-use-storybook)
* [Bundling strategy (webpack v4)](#bundling-strategy-webpack-v4)
    - [three entry points](#three-entry-points)
    - [to examine the bundle](#to-examine-the-bundle)
* [Others](#others)

## Key files & folders

```sh
.
├── js  # legacy codes, should be migrated and deprecated
│   ├── ...
│   ├── app_window.js       # base class to hold app iframes
│   ├── base_module.js      # root class of inheritance
│   ├── bootstrap.js        # register global vars, handle ftu, lazy load some modules
│   ├── core.js             # declare core modules inheriting from base_module
│   ├── hardware_buttons.js # handle hardware events by state machine
│   └── ...
├── deprecated  # deprecated codes, keep for reference only
│   └── ...
├── packages    # local copy of legacy shared modules
│   └── ...
├── src
│   ├── app_umd
│   │   ├── defer                 # files will be bundled and loaded by <script defer>
│   │   │   ├── browser_frame.js  # manipulate app iframe element
│   │   │   └── ...
│   │   ├── lazy                  # put lazy loading files here to bundle them independantly
│   │   │   └── ...
│   │   ├── theme.js              # helper for creating local theme <link> elements
│   │   └── ...
│   ├── custom_elements           # brand new components for touch phones
│   │   └── ...
│   ├── redux                     # monolithic store with some customized APIs
│   │   └── ...
│   └── webapi                    # brand new modules (stateless) for accessing gecko web APIs
│       └── ...
├── styles
│   ├── lighttheme.css  # customized light theme
│   ├── darktheme.css   # customized dark theme
│   └── ...
├── stories                       # storybook files for rapid UI development and debugging
│   └── ...
└── index.html

```

## Architecture

![architecture](architecture.png)

## How to migrate files under the folder `js`
Reference commits by this command:

`git log --oneline --grep migrate --since 2019-01-01`

## Steps to enable a new feature

##### with UI
- Define the custom element, tag name.
- Figure out the internal props and public props (props from global redux store).
- Implement `mapStateToProp` and `mapDispatchToProp` for public props.
- Import the element in `src/app.js`.
- (optional) Create your own [`hasChanged`](https://lit-element.polymer-project.org/guide/properties#haschanged) callback if suspect having performance issues.

Example `src/custom_elements/tag-name.js`:
```js
import { LitElement, html, css } from 'lit-element';
import { connect } from '../redux';

// change `TagName` and `tag-name`
class TagName extends LitElement {
  static get properties() {
    return {
      myProp: { type: Object },
    };
  }

  static get styles() {
    return css`
    `;
  }

  constructor() {
    super();
  }

  firstUpdated() {
  }

  render(){
    return html`
    `;
  }
}

const mapStateToProps = (state) => {
  return {
    myProp: state,
  };
};

const mapDispatchToProps = {
  doSomething: () => ({ type: 'SOME_ACTION' }),
};

customElements.define('tag-name', connect(mapStateToProps, mapDispatchToProps)(TagName));
```

Or without redux:
```js
import { LitElement, html, css } from 'lit-element';

// change `TagName` and `tag-name`
class TagName extends LitElement {
  static get properties() {
    return {
    };
  }

  static get styles() {
    return css`
    `;
  }

  constructor() {
    super();
  }

  firstUpdated() {
  }

  render(){
    return html`
    `;
  }
}

customElements.define('tag-name', TagName);
```

##### without UI
- Create related web api manager class under `src/webapi`.
- Figure out the data you want to save in redux store.
- Dispatch the state change by listening events from gecko.
- (optional) Create public api for using in element's `mapDispatchToProps`.
- Create the manager instance in `src/redux/index.js` (and inject the redux store).

Example `src/webapi/api_manager.js`:
```js
class ApiManager {
  constructor(store) {
    this._store = store;

    // e.g. navigator.someWebApi.addEventListener('ondatachange', this._onDataChange);
  }

  changeData = () => {
    // access web APIs directly
  }

  _onDataChange = () => {
    this._store.dispatch({
      // define related action and reducer in redux store
    })
  }
}

export default ApiManager;
```

## Customized theme
There exists `style/lighttheme.css` and `style/darktheme.css` for customized theme definition.

See `src/app_umd/theme.js`, where a `link` element will be inserted to load the customized theme(one of `style/lighttheme.css` and `style/darktheme.css`).

## index.html
The simple principle is to implement everything having UI using custom elements.

Current page layout looks like:
```html
<body>
  <div id='os-logo'></div>
  <div id='app-screen'>
    <app-root>
      <div id='screen'>
        <div id='windows'>
          <!-- app iframes -->
        </div>
      </div>
    </app-root>
    <instant-panel></instant-panel>
    <keyboard-app></keyboard-app>
  </div>
  <!-- custom elements of other system UI -->
  <air-deck></air-deck>
  <infogation-bar></infogation-bar>
</body>
```

And we would like to refactor it to:
```html
<body>
  <app-root>
    <!-- custom elements of app iframes -->
  </app-root>
  <!-- custom elements of other system UI -->
  <instant-panel></instant-panel>
  <keyboard-app></keyboard-app>
  <air-deck></air-deck>
  <infogation-bar></infogation-bar>
</body>
```

#### app-root
As a container for app iframes. For now, it provides edge swipe detection to invoke `air-deck`.

## How to use storybook
- Create folder (symbolic link or hard copy) named `theme` from [darktheme](https://git.kaiostech.com/touch-apps/darktheme) or [lighttheme](https://git.kaiostech.com/touch-apps/lighttheme) and `touch-shared` from [shared](https://git.kaiostech.com/touch-apps/shared).
  - if current directory is `gaia/apps/system`, you can do:

    ```sh
    ln -s ../darktheme theme
    # or
    # ln -s ../lighttheme theme
    ln -s ../shared touch-shared
    ```
- Execute `yarn storybook`
- Use browser(Firefox) to navigate `http://localhost:6006`

## Bundling strategy (webpack v4)

#### three entry points
This is a temporary solution. Once all files under `js/` are migrated, re-think about this.
```js
// webpack.config.dev.js
entry: {
  app: './src/app.js',
  app_umd: './src/app_umd.js',
  app_umd_defer: './src/app_umd_defer.js'
},
```

#### to examine the bundle
```sh
yarn profile:dev
# or
# yarn profile:prod
yarn analyze
```

## Others

- Good article about js state management
  - https://blog.nrwl.io/managing-state-in-angular-applications-22b75ef5625f
