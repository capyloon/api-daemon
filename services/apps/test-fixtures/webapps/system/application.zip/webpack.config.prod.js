const devConfig = require('./webpack.config.dev');
const webpack = require('webpack');
const TerserPlugin = require('terser-webpack-plugin');

const defineOptions = {
  'process.env.NODE_ENV': JSON.stringify('production')
};

const uglifyOptions = {
  ie8: false,
  ecma: 8,
  sourceMap: true,
  beautify: false,
  comments: false,
  warnings: false,
  compress: {
    collapse_vars: true,
    drop_console: true,
  },
  mangle: {
    reserved: ['$super', '$', 'exports', 'require']
  },
  output: {
    beautify: false,
    comments: false
  }
};

const config = Object.assign({}, devConfig, {
  mode: 'production',
  optimization: Object.assign({}, devConfig.optimization, {
    minimizer: [new TerserPlugin({
      terserOptions: uglifyOptions
    })],
  }),
  plugins: devConfig.plugins.concat([
    new webpack.DefinePlugin(defineOptions)
  ])
});

module.exports = config;
