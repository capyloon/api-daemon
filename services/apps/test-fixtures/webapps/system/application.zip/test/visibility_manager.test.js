import test from 'tape';

import MockService from './mocks/mock_service.js';
global.Service = MockService;

require('../js/visibility_manager');

test('VisibilityManager', (assert) => {
  const visibilityManager = new window.VisibilityManager();
  visibilityManager.start();

  test('Normal audio channel is on.', (assert) => {
    visibilityManager.handleEvent({
      type: 'visibleaudiochannelchanged',
      detail: {
        channel: 'normal'
      }
    });
    assert.true(visibilityManager._normalAudioChannelActive);
    assert.end();
  });

  test('Normal audio channel is off.', (assert) => {
    visibilityManager.handleEvent({
      type: 'visibleaudiochannelchanged',
      detail: {
        channel: 'none'
      }
    });
    assert.false(visibilityManager._normalAudioChannelActive);
    assert.end();
  });
  assert.end();
});
