const MockService = {
  query: function(name) {
    return this.mQueries ? this.mQueries[name] : undefined;
  },

  request: function() {
    return Promise.resolve();
  }
};

export default MockService;
