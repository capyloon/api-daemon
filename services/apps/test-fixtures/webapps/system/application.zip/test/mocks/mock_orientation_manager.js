const MockOrientationManager = {
  isDefaultPortrait: () => true
};

export default MockOrientationManager;
