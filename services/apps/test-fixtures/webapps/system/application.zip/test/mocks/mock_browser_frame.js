class BrowserFrame {
  constructor() {
    this._id = 0;
    this.element = document.createElement('iframe');
  }
}

export default BrowserFrame;
