const MockSettingsListener = {
  observe: () => {}
};

export default MockSettingsListener;
