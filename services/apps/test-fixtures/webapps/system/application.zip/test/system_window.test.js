import test from 'tape';
import Service from '../src/app_umd/defer/service.js';
import MockAudioChannelController from './mocks/mock_audio_channel_controller';

require('../js/base_module');
window.BaseModule.prototype.service = Service;
global.BaseModule = window.BaseModule;

require('../js/system_window');

test('SystemWindow', (assert) => {
  global.AudioChannelController = MockAudioChannelController;
  navigator.mozAudioChannelManager = {
    allowedAudioChannels: [
      { name: 'normal' },
      { name: 'notification' },
      { name: 'telephony' }
    ]
  };
  const BaseModule = window.BaseModule;
  const subject = BaseModule.instantiate('SystemWindow');
  subject.start();

  test('The fake app window ID', (assert) => {
    assert.equal(subject.instanceID, 'systemAppID');
    assert.end();
  });

  test('Get audio channels', (assert) => {
    const audioChannels = Service.query('getAudioChannels');
    assert.equal(audioChannels.size, 3);
    const names = audioChannels.keys();
    assert.equal(names.next().value, 'normal');
    assert.equal(names.next().value, 'notification');
    assert.equal(names.next().value, 'telephony');
    assert.end();
  });
  assert.end();
});
