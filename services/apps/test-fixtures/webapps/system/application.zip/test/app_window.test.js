import test from 'tape';
import sinon from 'sinon';

import MockSettingsListener from './mocks/mock_settings_listener';
import MockOrientationManager from './mocks/mock_orientation_manager';
import MockManifestHelper from './mocks/mock_manifest_helper';
import MockAudioChannelController from './mocks/mock_audio_channel_controller';
import MockBrowser from './mocks/mock_browser';
import MockBrowserFrame from './mocks/mock_browser_frame';

global.SettingsListener = MockSettingsListener;
global.OrientationManager = MockOrientationManager;
global.ManifestHelper = MockManifestHelper;
global.AudioChannelController = MockAudioChannelController;
global.BrowserFrame = MockBrowserFrame;

require('../js/app_window');

test('AppWindow', (assert) => {
  const AppWindow = window.AppWindow;
  AppWindow.prototype.render = () => {};
  AppWindow.prototype.browser = MockBrowser;
  AppWindow.prototype.element = document.createElement('div');
  AppWindow.prototype.browserContainer = document.createElement('div');
  AppWindow.prototype.browserNavigationWidgets = {
    destroy: () => {}
  }

  test('navigate app -> browser', (assert) => {
    const fakeSearchAppConfig = {
      url: 'app://search.gaiamobile.org/newtab.html',
      manifest: {
        role: 'search'
      },
      manifestURL: 'app://search.gaiamobile.org/ManifestURL',
      origin: 'app://search.gaiamobile.org'
    };
    const app1 = new AppWindow(fakeSearchAppConfig);
    const url = 'http://changed.url';

    sinon.stub(app1, 'reConfig');
    sinon.stub(app1, '_unregisterAudioChannels');
    sinon.stub(app1, '_registerAudioChannels');
    sinon.stub(AppWindow.prototype.browserContainer, 'removeChild');
    app1.navigate(url);

    assert.ok(app1.reConfig.calledOnce);
    assert.ok(app1._unregisterAudioChannels.calledOnce);
    assert.ok(app1._registerAudioChannels.calledOnce);
    assert.ok(app1.element.classList.contains('browser'));
    assert.end();
  });

  test('Sub component', (assert) => {
    let app;

    test('installSubComponents', (assert) => {
      const CustomEvent = window.CustomEvent;
      const fakeAppConfig = {
        url: 'app://www.fake/index.html',
        manifest: {},
        manifestURL: 'app://wwww.fake/ManifestURL',
        origin: 'app://www.fake'
      };

      app = new AppWindow(fakeAppConfig);
      const element = app.browser.element;
      element.allowedAudioChannels = [
        { name: 'normal' },
        { name: 'content' }
      ];
      app.installSubComponents();
      element.dispatchEvent(new CustomEvent('mozbrowserloadstart'));

      assert.equal(app.audioChannels.size, 2);
      assert.equal(app.audioChannels.get('normal').name, 'normal');
      assert.equal(app.audioChannels.get('content').name, 'content');
      assert.end();
    });

    test('uninstallSubComponents', (assert) => {
      const normalChannel = app.audioChannels.get('normal');
      const contentChannel = app.audioChannels.get('content');
      sinon.spy(normalChannel, 'destroy');
      sinon.spy(contentChannel, 'destroy');
      app.uninstallSubComponents();
      assert.ok(normalChannel.destroy.calledOnce);
      assert.ok(contentChannel.destroy.calledOnce);
      assert.deepEqual(app.audioChannels, null);
      assert.end();
    });
    assert.end();
  });
  assert.end();
});
