/* global Service */
'use strict';

(function(exports) {
  var _id = 0;

  /**
   * The https authentication dialog of the AppWindow.
   *
   * @class AppAuthenticationDialog
   * @param {AppWindow} app The app window instance
   *                        where this dialog should popup.
   * @extends BaseUI
   */
  function AppAuthenticationDialog(app) {
    this.app = app;
    this._event = null;
    this.containerElement = app.element;
    this.instanceID = _id++;
    this._injected = false;
    this.app.element.addEventListener('mozbrowserusernameandpasswordrequired',
      this);
  }

  AppAuthenticationDialog.prototype = Object.create(window.BaseUI.prototype);

  AppAuthenticationDialog.prototype.CLASS_NAME = 'AuthenticationDialog';

  AppAuthenticationDialog.prototype.EVENT_PREFIX = 'authdialog';

  /**
   * Used for element id access.
   * e.g., 'authentication-dialog-alert-ok'
   * @type {String}
   * @memberof AppAuthenticationDialog.prototype
   */
  AppAuthenticationDialog.prototype.ELEMENT_PREFIX = 'authentication-dialog-';

  /**
   * Maps to DOM elements.
   * @type {Object}
   * @memberof AppAuthenticationDialog.prototype
   */
  AppAuthenticationDialog.prototype.elements = null;

  /**
   * The current authentication event.
   * Note: Only one event one time.
   * @type {Event}
   * @memberof AppAuthenticationDialog.prototype
   */
  AppAuthenticationDialog.prototype._event = null;

  /**
   * Get all elements when inited.
   * @memberof AppAuthenticationDialog.prototype
   */
  AppAuthenticationDialog.prototype._fetchElements =
    function aad__fetchElements() {
      this.element = document.getElementById(this.CLASS_NAME + this.instanceID);
      this.elements = {};

      var toCamelCase = function toCamelCase(str) {
        return str.replace(/\-(.)/g, function replacer(str, p1) {
          return p1.toUpperCase();
        });
      };

      this.elementClasses = [
        'http-authentication-message', 'http-username-input',
        'http-password-input', 'http-show-password-checkbox'
      ];

      this.elementClasses.forEach(function createElementRef(name) {
        this.elements[toCamelCase(name)] =
        this.element.querySelector('.' + this.ELEMENT_PREFIX + name);
      }, this);

      this.focusable =
      Array.prototype.slice.call(this.element.querySelectorAll(
        '.authentication-dialog input'));
    };

  /**
   * Generates markup for the dialog.
   * @memberof AppAuthenticationDialog.prototype
   */
  AppAuthenticationDialog.prototype.view = function aad_view() {
    var id = this.CLASS_NAME + this.instanceID;

    return `<section class="authentication-dialog skin-organic" id="${id}"
      role="region">
      <h1 class="authentication-dialog-http-authentication-header"
          data-l10n-id="signIn"></h1>
      <p class="authentication-dialog-http-authentication-message">
      </p>
      <label>
        <span data-l10n-id="username" class="p-sec"></span>
        <input type="text"
               class="authentication-dialog-http-username-input p-sec" />
      </label>
      <label>
        <span data-l10n-id="password" class="p-sec"></span>
        <input type="password"
               class="authentication-dialog-http-password-input p-sec" />
      </label>
      <label class="checkbox">
        <span data-l10n-id="show-password" class="p-pri"></span>
        <input type="checkbox"
               class="authentication-dialog-http-show-password-checkbox checkbox"/>
        <span data-icon="check-off" ></span>
        <span data-icon="check-on" ></span>
      </label>
    </section>`;
  };

  /**
   * General event handler interface.
   * @memberof AppAuthenticationDialog.prototype
   */
  AppAuthenticationDialog.prototype.handleEvent = function(evt) {
    this.debug(' AAD>> got event: ' + evt.type);
    evt.preventDefault();
    evt.stopPropagation();
    this._event = evt;
    if (!this._injected) {
      this.render();
      this.registerSoftKey();
    }
    this.show();
    this._injected = true;
  };

  /**
   * Handle key event.
   * @memberof AppAuthenticationDialog.prototype
   */
  AppAuthenticationDialog.prototype.handleKey = function(evt) {
    if (!this.isVisible() || !this._event) {
      return;
    }

    this.debug(' AAD>> handleKey: ' + evt.key);
    switch (evt.key) {
      case 'ArrowUp':
      case 'ArrowDown':
        this.move(evt.key);
        break;
      case 'Enter':
        this.toggleCheckbox();
        break;
      case 'SoftLeft':
        evt.preventDefault();
        evt.stopPropagation();
        this.cancelHandler();
        break;
      case 'SoftRight':
        evt.preventDefault();
        evt.stopPropagation();
        this.confirmHandler();
        break;
    }
  };

  /**
   * Handle soft key event.
   * @memberof AppAuthenticationDialog.prototype
   */
  AppAuthenticationDialog.prototype.softkeyHandler = function(key) {
    if (!this.isVisible() || !this._event) {
      return;
    }

    this.debug(' AAD>> softkeyHandler: ' + key.type);
  };

  /**
   * Handle focus event.
   * @memberof AppAuthenticationDialog.prototype
   */
  AppAuthenticationDialog.prototype.onfocus = function(evt) {
    this.debug(' AAD>> onfocus: ');
    evt.target.parentElement.classList.add('focused');
  };

  /**
   * Handle blur event.
   * @memberof AppAuthenticationDialog.prototype
   */
  AppAuthenticationDialog.prototype.onblur = function(evt) {
    this.debug(' AAD>> onblur: ');
    evt.target.parentElement.classList.remove('focused');
  };

  AppAuthenticationDialog.prototype.isVisible = function() {
    // We don't have `this.element` until we receive
    // `mozbrowserusernameandpasswordrequired` event.
    return this.element && this.element.classList.contains('visible');
  };

  /**
   * Registers click events.
   * @memberof AppAuthenticationDialog.prototype
   */
  AppAuthenticationDialog.prototype._registerEvents =
    function aad__registerEvents() {
      this.element.addEventListener('keydown', this.handleKey.bind(this));
      this.focusable.forEach((inputElement) => {
        inputElement.addEventListener('focus', this.onfocus.bind(this));
        inputElement.addEventListener('blur', this.onblur.bind(this));
      });
    };

  /**
   * Unregisters authentication events from the app element.
   * @memberof AppAuthenticationDialog.prototype
   */
  AppAuthenticationDialog.prototype._unregisterEvents =
    function aad__unregisterEvents() {
      this.app.element.removeEventListener(
        'mozbrowserusernameandpasswordrequired',
        this);
    };

  /**
   * Registers soft key for authentication dialog.
   * @memberof AppAuthenticationDialog.prototype
   */
  AppAuthenticationDialog.prototype.registerSoftKey = function() {
    Service.request('SoftKeyStore:register',
      {left: 'cancel', right: 'signIn'},
      this.element);
  };

  /**
   * Focus the authentication dialog.
   * @memberof AppAuthenticationDialog.prototype
   */
  AppAuthenticationDialog.prototype.focus = function () {
    this.debug(' AAD>> focus');
    var bottomWindow = this.app.getBottomMostWindow();
    var topmostui = Service.query('getTopMostUI');
    var shouldFocus = (Service.query('getTopMostWindow') === this.app &&
            topmostui && topmostui.name === bottomWindow.HIERARCHY_MANAGER);
    if (shouldFocus && this.focusElement) {
      this.focusElement.focus();
    }
  };

  /**
   * Shows the authentication dialog.
   * @memberof AppAuthenticationDialog.prototype
   */
  AppAuthenticationDialog.prototype.show = function aad_show() {
    var evt = this._event;
    var elements = this.elements;
    this.app.setVisibleForScreenReader(false);
    this.element.classList.add('visible');
    this.debug(' AAD>> showing');
    navigator.mozL10n.setAttributes(
      elements.httpAuthenticationMessage,
      'http-authentication-message2',
      {host: evt.detail.host}
    );
    elements.httpUsernameInput.value = '';
    elements.httpPasswordInput.value = '';
    // Focus on user name.
    this.focusElement = this.focusable[0];
    this.debug(this.focusElement);
    Service.request('focus');
  };

  /**
   * Hides the authentication dialog.
   * @memberof AppAuthenticationDialog.prototype
   */
  AppAuthenticationDialog.prototype.hide = function aad_hide() {
    this.elements.httpUsernameInput.blur();
    this.elements.httpPasswordInput.blur();
    this.elements.httpShowPasswordCheckbox.blur();
    this.app.setVisibleForScreenReader(true);
    this.element.classList.remove('visible');
    if (this.app) {
      Service.request('focus');
    }
    this.debug(' AAD>> hided');
  };

  AppAuthenticationDialog.prototype.move = function add_mode(key) {
    var index = this.focusable.indexOf(document.activeElement);
    if (index === -1) {
      return;
    }

    if (key === 'ArrowDown') {
      this.focusElement = this.focusable[(index + 1) % this.focusable.length];
    } else if (key === 'ArrowUp') {
      this.focusElement =
        this.focusable[(index - 1 + this.focusable.length) %
        this.focusable.length];
    }
    this.debug(this.focusElement);
    Service.request('focus');
  };

  /**
   * Called when the user confirms the authentication dialog.
   * @memberof AppAuthenticationDialog.prototype
   */
  AppAuthenticationDialog.prototype.confirmHandler =
    function aad_confirmHandler() {
      var elements = this.elements;
      var evt = this._event;
      this.hide();
      evt.detail.authenticate(elements.httpUsernameInput.value,
        elements.httpPasswordInput.value);
      this._event = null;
    };

  /**
   * Called when the user cancels the authentication dialog.
   * @memberof AppAuthenticationDialog.prototype
   */
  AppAuthenticationDialog.prototype.cancelHandler =
    function aad_cancelHandler() {
      var evt = this._event;
      this.hide();
      evt.detail.cancel();
      this._event = null;
    };

  /**
   * Called when the user cancels the authentication dialog.
   * @memberof AppAuthenticationDialog.prototype
   */
  AppAuthenticationDialog.prototype.toggleCheckbox = function() {
    if (document.activeElement === this.elements.httpShowPasswordCheckbox) {
      this.elements.httpShowPasswordCheckbox.checked =
        !this.elements.httpShowPasswordCheckbox.checked;
      var passwordFieldType =
        this.elements.httpShowPasswordCheckbox.checked ? 'text' : 'password';
      var dataIcon =
        this.elements.httpShowPasswordCheckbox.checked ?
          'check-on' : 'check-off';
      this.elements.httpPasswordInput.setAttribute('type', passwordFieldType);
      this.elements.httpPasswordInput.setAttribute('data-icon', dataIcon);
    }
  };

  exports.AppAuthenticationDialog = AppAuthenticationDialog;

}(window));
