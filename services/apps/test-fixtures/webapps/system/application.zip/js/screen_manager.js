'use strict';

/* globals SettingsListener, Bluetooth, Service,
           ScreenBrightnessTransition, ScreenWakeLockManager */

var ScreenManager = {
  name: 'ScreenManager',
  DEBUG: true,
  brightLevel2Value: {
    '0': 0,
    '0.1': 0.04,
    '0.2': 0.115,
    '0.3': 0.225,
    '0.4': 0.336,
    '0.5': 0.447,
    '0.6': 0.557,
    '0.7': 0.668,
    '0.8': 0.779,
    '0.9': 0.889,
    '1': 1
  },
  /*
   * return the current screen status
   * Must not mutate directly - use toggleScreen/turnScreenOff/turnScreenOn.
   * Listen to 'screenchange' event to properly handle status changes
   * This value can be "out of sync" with real mozPower value,
   * we do this to give screen some time to flash before actual turn off.
   */
  screenEnabled: navigator.mozPower.screenEnabled,

  /**
   * If user is unlocking, postpone the timeout counter.
   */
  _unlocking: false,

  /*
   * before idle-screen-off, invoke a nice dimming to the brightness
   * to notify the user that the screen is about to be turn off.
   * The user can cancel the idle-screen-off by touching the screen
   * and by pressing a button (trigger onactive callback on Idle API)
   *
   */
  _inTransition: false,

  /*
   * Whether the device light is enabled or not
   * sync with setting 'screen.automatic-brightness'
   */
  _deviceLightEnabled: true,

  /*
   * Preferred brightness without considering device light nor dimming
   * sync with setting 'screen.brightness'
  */
  _userBrightness: 1,
  _brightnessLoaded: false,
  _backLightEnabled: true,

  /*
   * The auto-brightness algorithm will never set the screen brightness
   * to a value smaller than this. 0.1 seems like a good screen brightness
   * in a completely dark room on a Unagi.
   */
  AUTO_BRIGHTNESS_MINIMUM: 0.1,

  /*
   * This constant is used in the auto brightness algorithm. We take
   * the base 10 logarithm of the incoming lux value from the light
   * sensor and multiplied it by this constant. That value is used to
   * compute a weighted average with the current brightness and
   * finally that average brightess is and then clamped to the range
   * [AUTO_BRIGHTNESS_MINIMUM, 1.0].
   *
   * Making this value larger will increase the brightness for a given
   * ambient light level. At a value of about .25, the screen will be
   * at full brightness in sunlight or in a well-lighted work area.
   * At a value of about .3, the screen will typically be at maximum
   * brightness in outdoor daylight conditions, even when overcast.
   */
  AUTO_BRIGHTNESS_CONSTANT: 0.27,

  /*
   * We won't set a new brightness value if the difference between the old and
   * new ambient light sensor values is lower than this constant.
   */
  AUTO_BRIGHTNESS_MIN_DELTA: 10,

  /*
   * This variable contains the latest ambient light sensor value that was used
   * to set a brightness.
   */
  _previousLux: undefined,

  /*
   * This property will host a ScreenBrightnessTransition instance
   * and control the brightness transition for us.
   * Eventually we want to move all brightness controls
   * (including auto-brightness toggle and calculation) out of this module.
   */
  _screenBrightnessTransition: null,

  /**
   * Timeout to black the screen when locking.
   * (in `LOCKED` mode)
   */
  LOCKING_SHORT_TIMEOUT: 5,

  /**
   * Timeout to black the screen when locking.
   * (in any mode but `LOCKED`)
   */
  LOCKING_TIMEOUT: 10,

  /**
   * Timeout to dismiss the notice dialog in pocketmode/lockscreen.
   */
  NOTICE_DIALOG_TIMEOUT: 60,

  /*
   * Wait for _dimNotice milliseconds during idle-screen-off
   */
  _dimNotice: 10 * 1000,

  /*
   * We track the value of the idle timeout pref in this variable.
   */
  _idleTimeout: 0,
  _idleTimerId: 0,

  /*
   * To track the reason caused screen off?
   */
  _screenOffBy: null,
  _screenOffTimeout: 0,

  init: function scm_init() {
    window.addEventListener('attentionopening', this);
    window.addEventListener('attentionopened', this);
    window.addEventListener('notice-dialog-activated', this);
    window.addEventListener('notice-dialog-deactivated', this);
    window.addEventListener('dialog--activated', this);
    window.addEventListener('sleep', this);
    window.addEventListener('wake', this);
    window.addEventListener('nfc-tech-discovered', this);
    window.addEventListener('nfc-tech-lost', this);

    // User is unlocking by sliding or other methods.
    window.addEventListener('unlocking-start', this);
    window.addEventListener('unlocking-stop', this);

    // When secure app is on, do not turn the screen off.
    // And when it's down, reset the timeout.
    window.addEventListener('secure-appopened', this);
    window.addEventListener('secure-appterminated', this);

    window.addEventListener('lockscreen-appclosed', this);
    window.addEventListener('lockmode-change', this);

    // User is actively using the screen reader.
    window.addEventListener('accessibility-action', this);

    this.screen = document.getElementById('screen');

    this._screenBrightnessTransition = new ScreenBrightnessTransition();

    var self = this;
    var power = navigator.mozPower;
    // Tell gecko to enable keyLight and it will just sync with screen on/off.
    power.keyLightEnabled = true;

    // Start the screen wake lock manager so it will monitor screen wake lock
    // for us. We will need to re-config the screen timeout when the lock state
    // is changed.
    //
    // Noted that getting a lock while the screen is off will not
    // turn on the screen, since no frame is considered visible by Gecko when
    // the screen is off. See discussion in bug 818840.
    this._wakeLockManager = new ScreenWakeLockManager();
    this._wakeLockManager.onwakelockchange =
      this._reconfigScreenTimeout.bind(this);
    this._wakeLockManager.start();

    this._firstOn = false;
    this._screenLock = navigator.requestWakeLock('screen');
    window.addEventListener('logohidden', this);

    SettingsListener.observe('screen.timeout', 60,
      function screenTimeoutChanged(value) {
        if (typeof value !== 'number') {
          value = parseInt(value);
        }
        self._idleTimeout = value;
        self._setIdleTimeout(self._idleTimeout);

        if (!self._firstOn) {
          self._firstOn = true;

          // During boot up, the brightness was set by bootloader as 0.5,
          // Let's set the API value to that so setScreenBrightness() can
          // dim nicely to value set by user.
          self.setScreenBrightness(0.5, true);
          // Turn screen on with dim.
          self.turnScreenOn(false);
        }
      });

    SettingsListener.observe('screen.automatic-brightness', true,
      function deviceLightSettingChanged(value) {
        self.setDeviceLightEnabled(value);
      });

    SettingsListener.observe('screen.brightness', 1,
      function brightnessSettingChanged(value) {
        if (self._brightnessLoaded && !self._backLightEnabled &&
          value !== self._userBrightness) {
          navigator.mozSettings.createLock().set({
            'accessibility.backlight' : true
          });
        }
        self._brightnessLoaded = true;
        let cur = self._userBrightness;
        self._userBrightness = value;
        if (!self._backLightEnabled) {
          return;
        }
        if (cur - value > 0.5) {
          // if it took more than 50 steps and the transition is downward, ignore the transitioning.
          self.setScreenBrightness(value, true);
        } else {
          self.setScreenBrightness(value, false);
        }
      }
    );

    SettingsListener.observe('accessibility.backlight', self._backLightEnabled,
      function SettingBrightnessChange(enable) {
        self._backLightEnabled = enable;
        if (enable === true) {
          self.setScreenBrightness(self._userBrightness, false);
        } else {
          self.setScreenBrightness(self.AUTO_BRIGHTNESS_MINIMUM, false);
        }
      }
    );

    Service.registerState('screenEnabled', this);
    Service.register('turnScreenOn', this);
    Service.register('turnScreenOff', this);
  },

  //
  // Automatically adjust the screen brightness based on the ambient
  // light (in lux) measured by the device light sensor
  //
  autoAdjustBrightness: function scm_adjustBrightness(lux) {
    if (lux < 1) { // Can't take the log of 0 or negative numbers
      lux = 1;
    }

    if (this._previousLux !== undefined) {
      var brightnessDelta = Math.abs(this._previousLux - lux);
      if (brightnessDelta <= this.AUTO_BRIGHTNESS_MIN_DELTA) {
        return;
      }
    }
    this._previousLux = lux;

    var computedBrightness =
      Math.log10(lux) * this.AUTO_BRIGHTNESS_CONSTANT;

    var clampedBrightness = Math.max(this.AUTO_BRIGHTNESS_MINIMUM,
      Math.min(1.0, computedBrightness));

    this.setScreenBrightness(clampedBrightness, false);
  },

  handleEvent: function scm_handleEvent(evt) {
    switch (evt.type) {
      case 'notice-dialog-activated':
        this.turnScreenOn();
        this._setIdleTimeout(this.NOTICE_DIALOG_TIMEOUT, true);
        break;

      case 'notice-dialog-deactivated':
        this._reconfigScreenTimeout();
        break;

      case 'attentionopening':
      case 'attentionopened':
      case 'dialog--activated':
        if (!this.enabled) {
          this.turnScreenOn();
        } else {
          this._reconfigScreenTimeout();
        }
        break;

      case 'devicelight':
        if (!this._deviceLightEnabled || !this.screenEnabled ||
            this._inTransition) {
          return;
        }
        this.autoAdjustBrightness(evt.value);
        break;

      case 'sleep':
        if (!Service.query('DialerAgent.isAlerting')) {
          this.turnScreenOff(true, 'powerkey');
        }
        break;

      case 'wake':
        this.turnScreenOn();
        if (FxAccountsUI.dialog && !FxAccountsUI.dialog.Hidden())
        {FxAccountsUI.dialog.focus();}
        break;

      case 'accessibility-action':
        this._reconfigScreenTimeout();
        break;

      case 'nfc-tech-discovered':
      case 'nfc-tech-lost':
        if (this._inTransition) {
          this.turnScreenOn();
        } else {
          this._reconfigScreenTimeout();
        }
        break;

      case 'unlocking-start':
        this._setUnlocking();
        break;

      // When secure app is on, do not turn the screen off.
      // And when it's down, reset the timeout.
      case 'secure-appopened':
      case 'secure-appterminated':
        this._reconfigScreenTimeout();
        break;
      case 'unlocking-stop':
        this._resetUnlocking();
        break;
      case 'lockscreen-appclosed':
      case 'lockscreen-appclosing' :
      case 'lockpanelchange' :
        window.removeEventListener('lockscreen-appclosing', this);
        window.removeEventListener('lockpanelchange', this);
        this._setIdleTimeout(this._idleTimeout, false);
        break;

      case 'lockmode-change' :
        if (evt.detail.mode !== 'none') {
          this._reconfigScreenTimeout();
        }
        break;

      case 'logohidden':
        window.removeEventListener('logohidden', this);
        this._screenLock.unlock();
        this._screenLock = null;
        break;
    }
  },

  toggleScreen: function scm_toggleScreen() {
    if (this.screenEnabled) {
      // Currently there is no one used toggleScreen, so just set reason as
      // toggle. If it is used by someone in the future, we can rename it.
      this.turnScreenOff(true, 'toggle');
    } else {
      this.turnScreenOn();
    }
  },

  turnScreenOff: function scm_turnScreenOff(instant, reason) {
    if (!this.screenEnabled) {
      return false;
    }

    var self = this;
    if (reason) {
      this._screenOffBy = reason;
    }

    var screenOff = function scm_screenOff() {
      self._setIdleTimeout(0);

      if (self._deviceLightEnabled) {
        window.removeEventListener('devicelight', self);
      }

      window.removeEventListener('lockscreen-appclosing', self);
      window.removeEventListener('lockpanelchange', self);
      window.removeEventListener('lockmode-change', self);
      self.screenEnabled = false;
      self._inTransition = false;

      // do before adding 'screenoff' class to have a chance to do DOM change
      self.fireBeforeScreenOffEvent();

      self.screen.classList.add('screenoff');
      clearTimeout(self._screenOffTimeout);
      self._screenOffTimeout = setTimeout(function realScreenOff() {
        self.setScreenBrightness(0, true);
        // Sometimes the ScreenManager.screenEnabled and mozPower.screenEnabled
        // values are out of sync. Since the rest of the world relies only on
        // the value of ScreenManager.screenEnabled it can be some situations
        // where the screen is off but ScreenManager think it is on... (see
        // bug 822463). Ideally a callback should have been used, like
        // ScreenManager.getScreenState(function(value) { ...} ); but there
        // are too many places to change that for now.
        self.screenEnabled = false;
        navigator.mozPower.screenEnabled = false;
      }, 50);

      self.fireScreenChangeEvent();
    };

    if (instant) {
      screenOff();
      return true;
    }

    this.setScreenBrightness(0.1, false);
    this._inTransition = true;
    setTimeout(function noticeTimeout() {
      if (!self._inTransition) {
        return;
      }

      screenOff();
    }, self._dimNotice);

    return true;
  },

  turnScreenOn: function scm_turnScreenOn(instant, reason) {
    if (reason && reason === 'proximity' && this._screenOffBy !== reason) {
      return;
    }
    clearTimeout(this._screenOffTimeout);
    let restoreBrightness = this._backLightEnabled ?
      this._userBrightness : this.AUTO_BRIGHTNESS_MINIMUM;
    if (this.screenEnabled) {
      if (this._inTransition) {
        // Cancel the dim out
        this._inTransition = false;
        this.setScreenBrightness(restoreBrightness, true);
        this._reconfigScreenTimeout();
      }
      return false;
    }

    // Actually turn the screen on.
    var power = navigator.mozPower;
    if (power) {
      power.screenEnabled = true;
    }
    this.screenEnabled = true;

    // Set the brightness before the screen is on.
    this.setScreenBrightness(restoreBrightness, instant);

    this.screen.classList.remove('screenoff');

    // Attaching the event listener effectively turn on the hardware
    // device light sensor, which _must be_ done after power.screenEnabled.
    if (this._deviceLightEnabled) {
      window.addEventListener('devicelight', this);
    }

    this._reconfigScreenTimeout();
    this.fireScreenChangeEvent();

    return true;
  },

  _reconfigScreenTimeout: function scm_reconfigScreenTimeout() {
    // Remove idle timer if screen wake lock is acquired or
    // if no app has been displayed yet.
    if (this._wakeLockManager.isHeld) {
      this._setIdleTimeout(0);
    // The screen should be turn off with shorter timeout if
    // it was never unlocked.
    } else if (!this._unlocking) {
      if (window.Service.query('locked') && !window.secureWindowManager.isActive()) {
        this.debug('_reconfigScreenTimeout: currently locked');
        let timeout;

        if (window.Service.query('LockscreenView.mode') === 'locked') {
          timeout = this.LOCKING_SHORT_TIMEOUT;
        } else {
          timeout = this.LOCKING_TIMEOUT;
        }

        this._setIdleTimeout(timeout, true);
        window.addEventListener('lockscreen-appclosing', this);
        window.addEventListener('lockpanelchange', this);
        window.addEventListener('lockmode-change', this);
      } else {
        this._setIdleTimeout(this._idleTimeout, false);
      }
    }
  },

  /**
   * If user is unlocking, postpone the timeout counter.
   *
   * @this {ScreenManager}
   */
  _setUnlocking: function scm_setUnlocking() {
    this._unlocking = true;

    // Need to cancel it: the last set timeout would still be triggered.
    window.clearIdleTimeout(this._idleTimerId);
  },

  /**
   * Reset the state of user unlocking.
   *
   * @this {ScreenManager}
   */
  _resetUnlocking: function scm_resetUnlocking() {
    this._unlocking = false;
    this._reconfigScreenTimeout();
  },

  setScreenBrightness: function scm_setScreenBrightness(brightness, instant) {
    var value = this.brightLevel2Value[brightness];
    if (value === undefined) {
      brightness = brightness.toFixed(1);
      value = this.brightLevel2Value[brightness];
    }
    this._targetBrightness = value;
    this._curBrightLevel = brightness;
    var power = navigator.mozPower;
    if (!power) {
      return;
    }

    // Stop the current transition
    if (this._screenBrightnessTransition.isRunning) {
      this._screenBrightnessTransition.abort();
    }

    if (typeof instant !== 'boolean') {
      instant = true;
    }

    if (instant) {
      power.screenBrightness = value;
      return;
    }

    this._screenBrightnessTransition.transitionTo(this._targetBrightness);
  },

  setDeviceLightEnabled: function scm_setDeviceLightEnabled(enabled) {
    if (!enabled && this._deviceLightEnabled) {
      // Disabled -- set the brightness back to preferred brightness
      this.setScreenBrightness(this._userBrightness, false);
    }
    this._deviceLightEnabled = enabled;
    this._previousLux = undefined;

    if (!this.screenEnabled) {
      return;
    }

    // Disable/enable device light sensor accordingly.
    // This will also toggle the actual hardware, which
    // must be done while the screen is on.
    if (enabled) {
      window.addEventListener('devicelight', this);
    } else {
      window.removeEventListener('devicelight', this);
    }
  },

  _setIdleTimeout: function scm_setIdleTimeout(time, instant) {
    this.debug('_setIdleTimeout called: (time, instant):', time, instant);
    window.clearIdleTimeout(this._idleTimerId);

    // Reset the idled state back to false.
    this._idled = false;

    // 0 is the value used to disable idle timer by user and by us.
    if (time === 0) {
      return;
    }

    var self = this;
    var idleCallback = function idle_proxy() {
      self.turnScreenOff(instant, 'idle_timeout');
    };
    var activeCallback = function active_proxy() {
      self.turnScreenOn(true);
    };

    var finalTimeout = instant ? time * 1000 : (time * 1000) - this._dimNotice;
    this.debug('finalTimeout set:', finalTimeout);
    this._idleTimerId = window.setIdleTimeout(idleCallback,
      activeCallback, finalTimeout);
  },

  fireBeforeScreenOffEvent: function scm_fireBeforeScreenOffEvent() {
    const detail = { screenOffBy: this._screenOffBy };
    const eventDetail = { bubbles: true, cancelable: false, detail: detail };
    const evt = new CustomEvent('beforescreenoff', eventDetail);
    window.dispatchEvent(evt);
  },
  fireScreenChangeEvent: function scm_fireScreenChangeEvent() {
    var detail = { screenEnabled: this.screenEnabled };

    // Tell others the cause of screen-off.
    detail.screenOffBy = this._screenOffBy;
    detail.wakeUpExtScreen = this.wakeUpExtScreen;

    var evt = new CustomEvent('screenchange',
      { bubbles: true, cancelable: false,
        detail: detail });
    window.dispatchEvent(evt);

    this.wakeUpExtScreen = false;
  },

  debug: function scm_debug() {
    if (this.DEBUG) {
      console.log(`[${this.name}][${window.Service.currentTime()}] ${Array.slice(arguments).concat()}`);
    }
  }
};

ScreenManager.init();
