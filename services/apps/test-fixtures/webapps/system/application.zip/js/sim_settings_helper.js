/* exported SimSettingsHelper */
/* global SIMSlotManager, SettingsListener */
'use strict';

(function(exports) {
  // we have to make sure we are in DSDS
  if (!SIMSlotManager.isMultiSIM()) {
    return;
  }

  var SimSettingsHelper = {
    AUTOREBOOT_TIME_INTERVAL: 3000,
    ALWAYS_ASK_OPTION_VALUE: -1,
    initFromDB: false,
    iccIds: [null, null],
    lastcardsState: ['', ''],
    notification: null,
    timer: null,
    hotPlugHandler: null,
    skipIccCmd: true,
    pendingForceSet: false,

    start: function ssh_init() {
      if (SIMSlotManager.ready) {
        this.initSimSettings();
      } else {
        window.addEventListener('simslotready', this.initSimSettings.bind(this));
        if (SIMSlotManager.noSIMCardOnDevice()) {
          this.skipIccCmd = false;
        }
      }
      this.observerSimCardHotPlug();
      this.observeUserSimSettings();
      Service.register('updateDefaultServiceSettings', this);
    },

    updateDefaultServiceSettings:
      function ssh_updateDefaultServiceSettings(forceSet) {
        let cardsState = [null, null];

        SIMSlotManager.getSlots().forEach((slot, index) => {
          if (!slot.simCard) {
            cardsState[index] = null;
          } else {
            let cardState = slot.getCardState();
            cardsState[index] = cardState === 'ready' ? 'ready' : 'locked';
          }
        });

        if (cardsState[0] === this.lastcardsState[0] &&
        cardsState[1] === this.lastcardsState[1]) {
          return;
        }

        if (forceSet || this.pendingForceSet ||
        (cardsState[0] !== 'locked' && cardsState[1] !== 'locked')) {
          if (!this.initFromDB) {
            this.pendingForceSet = true;
            return;
          }

          this.pendingForceSet = false;
          this.lastcardsState = cardsState;
          this.simslotUpdatedHandler();
        }
      },

    initSimSettings: function ssh_recordCurrentIccIds(evt) {
      var conns = window.navigator.mozMobileConnections;
      for (var i = 0; i < conns.length; i++) {
        this.iccIds[i] = conns[i].iccId;
      }
      this.updateDefaultServiceSettings();
      this.skipIccCmd = false;
    },

    _hotPlugHandler: function(evt) {
      if (!Service.query('supportSimHotswap')) {
        return;
      }
      if (!this.skipIccCmd) {
        let contentId = 'sim-hot-plug';
        if (evt.type === 'iccundetected' && SIMSlotManager.noSIMCardOnDevice()) {
          contentId = 'sim-hot-plug-empty';
        }
        this.skipIccCmd = true;
        const id = 'sim-hot-plug-dialog';
        const _ = navigator.mozL10n.get;
        const config = {
          id,
          title: _('sim-confirmation-title'),
          message: _(contentId),
          primarybtntext: _('ok'),
          onDialogPrimaryBtnClick: () => {
            clearTimeout(this.timer);
            Service.request('restart');
            Service.request('DialogService:hide', id);
          }
        };
        Service.request('DialogService:show', config);
        this.timer = window.setTimeout(() => {
          Service.request('restart');
        }, this.AUTOREBOOT_TIME_INTERVAL);
      }
    },

    observerSimCardHotPlug: function() {
      let iccManager = navigator.mozIccManager;
      this.hotPlugHandler = this._hotPlugHandler.bind(this);
      iccManager.addEventListener('iccdetected', this.hotPlugHandler);
      iccManager.addEventListener('iccundetected', this.hotPlugHandler);
    },

    overrideUserSimSettings: function() {
      this.setServiceOnCard('outgoingCall');
      this.setServiceOnCard('outgoingMessages');
      this.setServiceOnCard('outgoingData');
    },

    simslotUpdatedHandler: function() {
      this.overrideUserSimSettings();
      if (!this['ril.notFirst.sim.settings']) {
        SettingsListener.getSettingsLock().set({
          'ril.notFirst.sim.settings': true
        });
      }
    },

    showSimCardConfirmation: function(cardIndex) {
      if (this.notification) {
        this.notification.close();
        this.notification = null;
      }
      if (SIMSlotManager.noSIMCardOnDevice() ||
        !this['ril.notFirst.sim.settings']) {
        return null;
      }
      var _ = navigator.mozL10n.get;
      var title = _('sim-confirmation-notice-title') || '';
      var body = _('sim-confirmation-notice') || '';

      var notification = new window.Notification(title, {
        body: body,
        tag: 'simCard',
        data: {
          icon: 'sim-card'
        },
        mozbehavior: {
          showOnlyOnce: true
        }
      });

      notification.onclick = function(cardIndex) {
        var _ = navigator.mozL10n.get;
        var header = _('sim-confirmation-title');
        var content = _('sim-confirmation-content', {
          'n': cardIndex + 1
        });
        if (this.notification) {
          this.notification.close();
          this.notification = null;
        }
        const id = 'sim-confirmation-dialog';
        const config = {
          id,
          title: header,
          message: content,
          primarybtntext: _('ok'),
          onDialogPrimaryBtnClick: () => {
            Service.request('DialogService:hide', id);
          },
        };
        Service.request('DialogService:show', config);
      }.bind(this, cardIndex);
      return notification;
    },

    observeUserSimSettings: function ssh_observeUserSimSettings() {
      var mozKeys = [];
      var Settings = navigator.mozSettings;
      var servicePromises = [];
      mozKeys.push('ril.telephony.defaultServiceId');
      mozKeys.push('ril.voicemail.defaultServiceId');
      mozKeys.push('ril.telephony.defaultServiceId.iccId');
      mozKeys.push('ril.voicemail.defaultServiceId.iccId');

      mozKeys.push('ril.sms.defaultServiceId');
      mozKeys.push('ril.sms.defaultServiceId.iccId');

      mozKeys.push('ril.mms.defaultServiceId');
      mozKeys.push('ril.data.defaultServiceId');
      mozKeys.push('ril.mms.defaultServiceId.iccId');
      mozKeys.push('ril.data.defaultServiceId.iccId');
      mozKeys.push('ril.notFirst.sim.settings');
      mozKeys.push('ril.sim.iccIds');

      mozKeys.forEach((eachKey) => {
        var promise = new Promise((resolve) => {
          var lock = navigator.mozSettings.createLock();
          var request = lock.get(eachKey);
          request.onsuccess = () => {
            this[eachKey] = request.result[eachKey];
            resolve();
          };
          request.onerror = () => {
            resolve();
          };
          Settings.addObserver(eachKey, function onChange(event) {
            var value = event.settingValue;
            // 1. 'newPrefCard' --> set data to other card
            // 2. 'oldCard' --> reboot device and card not change
            // 3. 'recordPrefCard' -->  insert new card and the card is the last
            //                          card that user set mobile data
            // 4. 'noSimCard' --> no sim card in device
            // 5. 'noMobileData' --> the card not set mobile data.
            console.log('SimSettingsHelper ' + eachKey + ' : ' + value);
            if (eachKey === 'ril.data.defaultServiceId' &&
              Service.query('supportSwitchPrimarysim')) {
              var cardsState = [{
                state: 'newPrefCard'
              }, {
                state: 'newPrefCard'
              }];
              var anotherCardIndex = value^1;
              if (this['ril.sim.iccIds'][anotherCardIndex] ===
                this.iccIds[anotherCardIndex] && this[eachKey] === value) {
                cardsState[anotherCardIndex].state = 'oldCard';
              } else {
                cardsState[anotherCardIndex].state = 'noMobileData';
              }
              // No simCard in device
              if (!this.iccIds[value]) {
                cardsState[value].state = 'noSimCard';
              } else if (this.iccIds[value] ===
                this['ril.data.defaultServiceId.iccId']) {
                cardsState[value].state = 'recordPrefCard';
              } else if (this['ril.sim.iccIds'][value] === this.iccIds[value] &&
                this[eachKey] === value) {
                cardsState[value].state = 'oldCard';
              }
              Service.request('setPreferredNetworkType', cardsState);
            }

            this[eachKey] = value;
            // For support SIM1* SIM2* mode, record
            // ril.data.defaultServiceId.iccID in settings app
            if (eachKey === 'ril.data.defaultServiceId.iccId') {
              if (this.notification) {
                this.notification.close();
                this.notification = null;
              }
            } else if (eachKey.indexOf('iccId') < 0 && value >= 0 &&
              (eachKey !== 'ril.data.defaultServiceId' ||
              !this['ril.notFirst.sim.settings']) &&
              this.lastcardsState[0] !== 'locked' &&
              this.lastcardsState[1] !== 'locked') {
              var setObj = {};
              setObj[eachKey + '.iccId'] = this.iccIds[value];
              SettingsListener.getSettingsLock().set(setObj);
            }
          }.bind(this));
        });
        servicePromises.push(promise);
      });
      Promise.all(servicePromises).then(() => {
        this.initFromDB = true;
        if (SIMSlotManager.ready || SIMSlotManager.noSIMCardOnDevice()) {
          this.updateDefaultServiceSettings();
        }
      });
    },

    setServiceOnCard: function ssh_setServiceOnCard(serviceName) {
      var mozKeys = [];
      var notFirstSet = this['ril.notFirst.sim.settings'];
      var cardIndex = this.ALWAYS_ASK_OPTION_VALUE;
      switch (serviceName) {
        case 'outgoingCall':
          mozKeys.push('ril.telephony.defaultServiceId');
          mozKeys.push('ril.voicemail.defaultServiceId');
          break;

        case 'outgoingMessages':
          mozKeys.push('ril.sms.defaultServiceId');
          mozKeys.push('ril.mms.defaultServiceId');
          break;

        case 'outgoingData':
          mozKeys.push('ril.data.defaultServiceId');
          break;
      }
      // First time run and first set.
      if (!notFirstSet) {
        if (SIMSlotManager.noSIMCardOnDevice()) {
          cardIndex = this.ALWAYS_ASK_OPTION_VALUE;
        } else {
          cardIndex = SIMSlotManager.isSIMCardAbsent(0) ? 1 : 0;
        }
      }

      if (this.lastcardsState[0] === 'locked' &&
        this.lastcardsState[1] === 'ready') {
        cardIndex = 1;
      } else if (this.lastcardsState[1] === 'locked' &&
        this.lastcardsState[0] === 'ready') {
        cardIndex = 0;
      }

      mozKeys.forEach((eachKey) => {
        if (cardIndex === this.ALWAYS_ASK_OPTION_VALUE && notFirstSet) {
          // Not first set, need compare remembered iccid
          // if not matched, then set to -1. (always ask)
          var iccId = this[eachKey + '.iccId'];
          if (iccId) {
            if (iccId === this.iccIds[0] &&
              this.lastcardsState[0] === 'ready') {
              cardIndex = 0;
            } else if (iccId === this.iccIds[1] &&
              this.lastcardsState[1] === 'ready') {
              cardIndex = 1;
            }
          }
        }
        if (eachKey === 'ril.data.defaultServiceId') {
          if (cardIndex === this.ALWAYS_ASK_OPTION_VALUE) {
            // 1. No simcard
            // 2. slot1 empty & slot2 new simcard
            // 3. slot1 new simcard & slot2 empty
            // 4. slot1 & slot2 both new simcards (slot1 is ready)
            // 5. slot1 & slot2 both new simcards (slot1  locked, slot2 ready)
            // 1, 3, 4 cardIndex set to 0, 2 & 5 set to 1
            var slots = SIMSlotManager.getSlots();
            if (slots[0].isAbsent() && !slots[1].isAbsent()) {
              cardIndex = 1;
            } else {
              cardIndex = 0;
            }
          }

          if (this.lastcardsState[0] !== 'locked' &&
            this.lastcardsState[1] !== 'locked' &&
            (!this['ril.sim.iccIds'] ||
            this['ril.sim.iccIds'][cardIndex] !== this.iccIds[cardIndex] ||
            this['ril.data.defaultServiceId'] !== cardIndex)) {
            this.notification = this.showSimCardConfirmation(cardIndex);
          }
          var iccIdsSetObj = {};
          iccIdsSetObj['ril.sim.iccIds'] = this.iccIds;
          SettingsListener.getSettingsLock().set(iccIdsSetObj);
        }
        var setObj = {};
        setObj[eachKey] = cardIndex;
        SettingsListener.getSettingsLock().set(setObj);
      });
    }
  };
  exports.SimSettingsHelper = SimSettingsHelper;
})(window);
