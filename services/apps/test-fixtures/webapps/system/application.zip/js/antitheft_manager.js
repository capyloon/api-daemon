'use strict';

var AntitheftManager = {
  timeSpan: 60 * 24 * 60 * 1000,
  lastRefreshTime: 0,
  alarmId: null,
  init: function () {
    var _self = this;
    SettingsHelper('antitheft.pushServerUrl').get(function (value) {
      if (value) {
        navigator.mozId.watch({
          wantIssuer: 'kaios-accounts',
          audience: value,
          onlogin: function (assertion) {
            _self.appendAlarms();
          },
          onerror: function (error) {

          },
          onlogout: function () {
            _self.removeAlarms();
          },
          onready: function () {

          }
        });
      }
    }.bind(this));
  },
  appendAlarms: function () {
    var _self = this;
    this.createAlarms();
    AlarmMessageHandler.addCallback(function(message) {
      if (message.data && message.data.type === 'refreshMozId') {
        _self.createAlarms();
        navigator.mozId.request();
      }
    });

    window.addEventListener('online', function() {
      _self.refreshMozId();
    });

    window.addEventListener('moztimechange', function() {
      if (Date.now() < this.lastRefreshTime) {
        _self.lastRefreshTime = Date.now();
        _self.createAlarms();
      }
    });
  },
  refreshMozId: function () {
    if (Date.now() - this.lastRefreshTime > this.timeSpan) {
      navigator.mozId.request();
      this.lastRefreshTime = Date.now();
    }
  },
  createAlarms: function () {
    var _self = this;
    this.removeAlarms();
    var request = navigator.mozAlarms.add(
      new Date(Date.now() + _self.timeSpan), 'ignoreTimezone', { type: 'refreshMozId' }
    );

    request.onsuccess = function (data) {
      _self.alarmId = data.target.result;
    };

    request.onerror = function (err) {

    };
  },
  removeAlarms: function () {
    if (this.alarmId) {
      navigator.mozAlarms.remove(this.alarmId);
      this.alarmId = null;
    }
  }
};
AntitheftManager.init();
