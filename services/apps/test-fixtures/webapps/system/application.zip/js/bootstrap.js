/* -*- Mode: js; tab-width: 2; indent-tabs-mode: nil; c-basic-offset: 2 -*- /
/* vim: set shiftwidth=2 tabstop=2 autoindent cindent expandtab: */

/*global ActivityWindowManager, Browser, SecureWindowFactory,
         SecureWindowManager, HomescreenLauncher, HomescreenWindowManager,
         FtuLauncher, ScreenManager, Places, Activities,
         DeveloperHUD, DialerAgent, RemoteDebugger,
         VisibilityManager, UsbStorage, TTLView, AppWindowFactory, SystemDialogManager,
         applications, Rocketbar, LayoutManager,
         Accessibility, NfcUtils, SleepMenu,
         NfcManager,
         ExternalStorageMonitor,
         BrowserSettings,
         CpuManager,
         BatteryOverlay, BaseModule, AppWindowManager,
         LazyLoader*/
'use strict';

/* === Shortcuts === */
/* For hardware key handling that doesn't belong to anywhere */
var Shortcuts = {
  init: function rm_init() {
    window.addEventListener('keyup', this);
  },

  handleEvent: function rm_handleEvent(evt) {
    if (!ScreenManager.screenEnabled || evt.keyCode !== evt.DOM_VK_F6) {
      return;
    }

    document.location.reload();
  }
};

window.addEventListener('load', function startup() {
  if (!window.homescreenLauncher) {
    // If application.ready is true, we already create homescreenLauncher in
    // safelyLaunchFTU(). We should use it. If it is false, we should create it
    // here.
    window.homescreenLauncher = new HomescreenLauncher();
  }
  window.wallpaperManager = new window.WallpaperManager();
  window.wallpaperManager.start();

  /**
   * Register global instances and constructors here.
   */
  function registerGlobalEntries() {
    /** @global */
    window.performance.mark('start registerGlobalEntries');

    window.nfcManager = new NfcManager();
    window.nfcManager.start();

    /** @global */
    window.appWindowManager = new AppWindowManager();

    /** @global */
    window.activityWindowManager = new ActivityWindowManager();
    window.activityWindowManager.start();

    /** @global */
    window.secureWindowManager = window.secureWindowManager ||
      new SecureWindowManager();
    /** @global */
    window.secureWindowFactory = new SecureWindowFactory();

    /** @global */
    window.systemDialogManager = window.systemDialogManager ||
      new SystemDialogManager();

    window.appWindowManager.start();

    window.performance.mark('done registerGlobalEntries');
  }

  function safelyLaunchFTU() {
    FtuLauncher.retrieve();
    /** @global */
    if (!window.homescreenLauncher) {
      // We may have application.ready = true while reloading at firefox nightly
      // browser. In this case, the window.homescreenLauncher haven't been
      // created. We should create it and start it in this case.
      window.homescreenLauncher = new HomescreenLauncher();
    }
    window.homescreenLauncher.start();
  }

  if (applications.ready) {
    registerGlobalEntries();
    safelyLaunchFTU();
  } else {
    window.addEventListener('applicationready', function appListReady(event) {
      window.removeEventListener('applicationready', appListReady);
      registerGlobalEntries();
      safelyLaunchFTU();
    });
  }

  /**
   * Enable checkForUpdate after FTU is either done or skipped.
   */
  function doneWithFTU() {
    window.performance.mark('done-with-ftu');
    window.removeEventListener('ftudone', doneWithFTU);
    window.removeEventListener('ftuskip', doneWithFTU);
    var lock = window.navigator.mozSettings.createLock();
    lock.set({
      'gaia.system.checkForUpdates': true
    });
  }

  window.addEventListener('ftudone', doneWithFTU);
  // Enable checkForUpdate as well if booted without FTU
  window.addEventListener('ftuskip', doneWithFTU);

  ScreenManager.turnScreenOn();

  // To make sure homescreen window manager can intercept webapps-launch event,
  // we need to move the code here.
  window.homescreenWindowManager = new HomescreenWindowManager();
  window.homescreenWindowManager.start();

  // Please sort it alphabetically

  window.appWindowFactory = new AppWindowFactory();
  window.appWindowFactory.start();

  /** @global */
  window.attentionWindowManager = new window.AttentionWindowManager();
  window.attentionWindowManager.start();
  window.dialerAgent = new DialerAgent();
  window.dialerAgent.start();
  window.layoutManager = new LayoutManager();
  window.layoutManager.start();

  window.visibilityManager = new VisibilityManager();
  window.visibilityManager.start();


  // We need to be sure to get the focus in order to wake up the screen
  // if the phone goes to sleep before any user interaction.
  // Apparently it works because no other window has the focus at this point.
  window.focus();

  window.performance.mark('loadEnd');

  window.core = BaseModule.instantiate('Core');
  window.core && window.core.start();
});

// Define the default background to use for all homescreens
window.addEventListener('wallpaperchange', function(evt) {
  // evt.detail.url will be same with window.wallpaperManager.getBlobURL()
  document.documentElement.style.setProperty('--wallpaper-url', `url('${evt.detail.url}')`);
});

function delayed_launch() {
  window.performance.mark('delayed-launch');

  function lazyLoad(file, winProp, objName) {
    LazyLoader.load(file, () => {
      window[winProp] = new objName();
      window[winProp].start();
    });
  }

  Shortcuts.init();

  LazyLoader.load('js/accessibility.js', () => {
    window.accessibility = new Accessibility();
    window.accessibility.start();
  });

  LazyLoader.load('js/battery_overlay.js', () => {
    window.batteryOverlay = new BatteryOverlay();
    window.batteryOverlay.start();
  });

  LazyLoader.load('js/cpu_manager.js', () => {
    window.cpuManager = new CpuManager();
    window.cpuManager.start();
  });

  LazyLoader.load('js/devtools/developer_hud.js', () => {
    window.developerHUD = new DeveloperHUD();
    window.developerHUD.start();
  });

  LazyLoader.load('js/remote_debugger.js', () => {
    window.remoteDebugger = new RemoteDebugger();
  });

  LazyLoader.load('js/places.js', () => {
    window.places = new Places();
    window.places.start();
  });

  LazyLoader.load('js/ttlview.js', () => {
    window.ttlView = new TTLView();
  });

  LazyLoader.load('js/external_storage_monitor.js', () => {
    window.externalStorageMonitor = new ExternalStorageMonitor();
    window.externalStorageMonitor.start();
  });

  LazyLoader.load('js/usb_storage.js', () => {
    window.usbStorage = new UsbStorage();
  });

  // Account Authenticator for third party account,
  // it will setup the content event listener to communicate with gecko
  LazyLoader.load(
    [
      'shared/js/oauth2_config.js',
      'js/account_authenticator/account_authenticator.js',
      'js/account_authenticator/account_authenticator_config.js'
    ],
    () => {
      // With all important event handlers in place, we can now notify
      // Gecko that we're ready for certain system services to send us
      // messages (e.g. the radio).
      // Note that shell.js starts listen for the mozContentEvent event at
      // mozbrowserloadstart, which sometimes does not happen till window.onload.
      var evt = new CustomEvent('mozContentEvent',
        {
          bubbles: true, cancelable: false,
          detail: { type: 'system-message-listener-ready' }
        });
      window.dispatchEvent(evt);
    }
  );

  window.browserSitesDataStore = new BrowserSitesDataStore();
  window.nfcUtils = new NfcUtils();
  window.rocketbar = new Rocketbar();
}

window.addEventListener('homescreenloaded', function homeloaded(evt) {
  window.removeEventListener('homescreenloaded', homeloaded);
  delayed_launch();
  window.performance.mark('fullyLoaded');
});

window.browser = new Browser();
window.browser.start();
window.browserSettings = new BrowserSettings();
window.browserSettings.start();
