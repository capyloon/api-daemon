/* -*- Mode: js; js-indent-level: 2; indent-tabs-mode: nil -*- */
/* vim: set shiftwidth=2 tabstop=2 autoindent cindent expandtab: */
/* global LazyLoader, DUMP, NotificationHelper, STKHelper, icc_worker */
'use strict';

var icc = {
  name: 'Icc',
  _displayTextTimeout: 40000,
  _defaultURL: null,
  _inputTimeout: 40000,
  _toneDefaultTimeout: 5000,
  _screen: null,
  _currentMessage: null,
  _idleModeTextMessage: null,
  state: {
    mode: ''
  },

  checkPlatformCompatibility: function icc_checkPlatformCompat() {
    // The STK_RESULT_ACTION_CONTRADICTION_TIMER_STATE constant will be added
    // in the next versions of the platform. This code avoid errors if running
    // in old versions. See bug #1026556
    // Remove this workaround as soon as Gecko has the constant defined.
    // Followup bug #1059166
    if (!('STK_RESULT_ACTION_CONTRADICTION_TIMER_STATE' in this._iccManager)) {
      this._iccManager.STK_RESULT_ACTION_CONTRADICTION_TIMER_STATE = 0x24;
    }
  },

  init: function icc_init() {
    this._iccManager = window.navigator.mozIccManager;
    if (!this._iccManager) {
      return;
    }
    this.checkPlatformCompatibility();
    var self = this;
    this.clearMenuCache(function() {
      window.navigator.mozSetMessageHandler('icc-stkcommand',
        function callHandleSTKCommand(message) {
          if (self._iccManager && self._iccManager.getIccById) {
            self.handleSTKCommand(message);
          }
        });
    });
    this.getIccInfo();

    // Update displayTextTimeout with settings parameter
    Service.request('SettingsCore:addObserver', 'icc.displayTextTimeout', (value) => {
      this._displayTextTimeout = value;
    });

    // Update inputTimeout with settings parameter
    Service.request('SettingsCore:addObserver', 'icc.inputTextTimeout', (value) => {
      this._inputTimeout = value;
    });

    // Update toneDefaultTimeout with settings parameter
    Service.request('SettingsCore:addObserver', 'icc.toneDefaultTimeout', (value) => {
      this._toneDefaultTimeout = value;
    });

    window.addEventListener('iac-settingsstk', (evt) => {
      var message = evt.detail;
      DUMP('STK_System IAC!!!!');
      if (message === 'StkMenuHidden') {
        this.hideViews();
      }
    });

    Service.register('terminateResponse', this);
    Service.register('helpResponse', this);
    Service.register('backResponse', this);

    // Wait desktop-notification-resend event
    // for loading all notifications before last power off.
    window.addEventListener('desktop-notification-resend',
      self.clearIdleTextNotification);
  },

  clearIdleTextNotification: function icc_clearIdleTextNotification() {
    Notification.get().then(function(notifications) {
      for (var i = 0; i < notifications.length; i++) {
        if (notifications[i].tag.indexOf('stkNotification_') === 0) {
          notifications[i].close();
        }
      }
    });
  },

  getIccInfo: function icc_getIccInfo() {
    var self = this;
    var url = './resources/icc.json';
    LazyLoader.getJSON(url).then(function(json) {
      self._defaultURL = json.defaultURL;
      DUMP('ICC default URL: ', self._defaultURL);
    }, function(error) {
      DUMP('Failed to fetch file: ' + url + ',' + error);
    });
  },

  getIcc: function icc_getIcc(iccId) {
    DUMP('ICC Getting ICC for ' + iccId);
    return this._iccManager.getIccById(iccId);
  },

  getConnection: function icc_getConnection(iccId) {
    DUMP('ICC Getting Connection for ' + iccId);
    for (var i = 0; i < window.navigator.mozMobileConnections.length; i++) {
      if (window.navigator.mozMobileConnections[i].iccId === iccId) {
        DUMP('ICC Connection ' + i + ' found for ' + iccId);
        return window.navigator.mozMobileConnections[i];
      }
    }
    return null;
  },

  getSIMNumber: function icc_getSIMNumber(iccId) {
    DUMP('ICC Getting SIM Number for ' + iccId);
    for (var i = 0; i < window.navigator.mozMobileConnections.length; i++) {
      if (window.navigator.mozMobileConnections[i].iccId === iccId) {
        return i + 1;
      }
    }
    return '';
  },

  clearMenuCache: function icc_clearMenuCache(callback) {
    if (typeof callback != 'function') {
      callback = function() {};
    }
    // Remove previous menu
    var resetApplications = window.navigator.mozSettings.createLock().set({
      'icc.applications': '{}'
    });
    resetApplications.onsuccess = function icc_resetApplications() {
      DUMP('STK Cache Reseted');
      callback();
    };
  },

  handleSTKCommand: function icc_handleSTKCommand(message) {
    // Protection to bad formed messages
    if (!message || !message.iccId || !message.command ||
        !message.command.typeOfCommand || !message.command.options) {
      return DUMP('STK Proactive Command bad formed: ', message);
    }

    DUMP('STK Proactive Command for SIM ' + message.iccId + ': ',
      message.command);
    if (FtuLauncher.isFtuRunning()) {
      // Delay the stk command until FTU is done
      var self = this;
      window.addEventListener('ftudone', function ftudone() {
        DUMP('FTU is done!... processing STK message:', message);
        self.handleSTKCommand(message);
      });
      return DUMP('FTU is running, delaying STK...');
    }

    /* TODO: cleanup branching after bug 819831 landed */
    var cmdId;
    if (typeof message.command.typeOfCommand === 'string') {
      cmdId = message.command.typeOfCommand;
    } else {
      cmdId = '0x' + message.command.typeOfCommand.toString(16);
    }
    if (icc_worker[cmdId]) {
      this.resize();
      return icc_worker[cmdId](message);
    }

    DUMP('STK Command not recognized ! - ', message);
  },

  handleEvent: function icc_handleEvent(evt) {
  },

  /**
   * Response ICC Command
   */
  responseSTKCommand: function icc_responseSTKCommand(message, response) {
    DUMP('sendStkResponse to message: ', message);
    DUMP('STK sendStkResponse -- # response = ', response);
    var _icc = icc.getIcc(message.iccId);
    _icc && _icc.sendStkResponse(message.command, response);
    message.response = true;
  },

  /**
   * Common responses
   */
  terminateResponse: function(message) {
    DUMP('STK Sending STK_RESULT_UICC_SESSION_TERM_BY_USER to card ' +
      message.iccId);
    this.responseSTKCommand(message, {
      resultCode: this._iccManager.STK_RESULT_UICC_SESSION_TERM_BY_USER
    });
  },

  helpResponse: function(message) {
    DUMP('STK Sending STK_RESULT_HELP_INFO_REQUIRED to card ' +
      message.iccId);
    this.responseSTKCommand(message, {
      resultCode: this._iccManager.STK_RESULT_HELP_INFO_REQUIRED
    });
  },

  backResponse: function(message) {
    DUMP('STK Sending STK_RESULT_BACKWARD_MOVE_BY_USER to card ' +
      message.iccId);
    this.responseSTKCommand(message, {
      resultCode: this._iccManager.STK_RESULT_BACKWARD_MOVE_BY_USER
    });
  },

  /******************************************
   * ICC Helper methods
   ******************************************/

  calculateDurationInMS: function icc_calculateDurationInMS(timeUnit,
    timeInterval) {
    var timeout = timeInterval;
    switch (timeUnit) {
      case this._iccManager.STK_TIME_UNIT_MINUTE:
        timeout *= 60000;
        break;
      case this._iccManager.STK_TIME_UNIT_SECOND:
        timeout *= 1000;
        break;
      case this._iccManager.STK_TIME_UNIT_TENTH_SECOND:
        timeout *= 100;
        break;
    }
    return timeout;
  },

  hideViews: function icc_hideViews(reason) {
    Service.request('StkDialog:hide', reason);
    this._currentMessage = null;
  },

  setupView: function icc_setupView(viewId) {
  },

  resize: function() {
  },

  alert: function icc_alert(stkMessage, message, icons) {
    Service.request('StkDialog:show', {
      mode: 'alert',
      stkMessage: stkMessage,
      message: message,
      icons: icons
    });
  },

  /**
   * callback responds with "userCleared"
   */
  confirm: function(stkMessage, message, icons, timeout, callback) {
    Service.request('StkDialog:show',  {
      mode: 'confirm',
      stkMessage: stkMessage,
      message: message,
      icons: icons,
      timeout: timeout,
      callback: callback
    });
  },

  asyncConfirm: function(stkMessage, message, icons, callback) {
    Service.request('StkDialog:show',  {
      mode: 'aconfirm',
      stkMessage: stkMessage,
      message: message,
      icons: icons,
      callback: callback
    });
  },

  /**
   * Open URL
   */
  showURL: function(stkMessage, url, icons, confirmMessage) {
    function openURL(url) {
      // Sanitise url just in case it doesn't start with http or https
      // the web activity won't work, so add by default the http protocol
      if (url.search('^https?://') == -1) {
        // Our url doesn't contains the protocol
        url = 'http://' + url;
      }
      new MozActivity({
        name: 'view',
        data: { type: 'url', url: url }
      });
    }
    if (url == null || url.length == 0) {
      url = this._defaultURL;
    }
    DUMP('Final URL to open: ' + url);
    if (url != null || url.length != 0) {
      if (icons || confirmMessage) {
        this.asyncConfirm(stkMessage, confirmMessage, icons, function(res) {
          if (res) {
            openURL(url);
          }
        });
      } else {
        openURL(url);
      }
    }
  },

  input: function(stkMessage, message, icons, timeout, options, callback) {
    Service.request('StkDialog:show', {
      mode: 'input',
      stkMessage: stkMessage,
      message: message,
      icons: icons,
      timeout: timeout,
      options: options,
      callback: callback
    });
  },

  discardCurrentMessageIfNeeded: function(new_message) {
    var _currentMessage = this._currentMessage;
    if (_currentMessage && _currentMessage !== new_message) {
      Service.request('StkDialog:hide');
      if (!_currentMessage.response &&
        _currentMessage.command.typeOfCommand !== 19) {
        DUMP('New message received, discarding previous message...');
        this.responseSTKCommand(_currentMessage, {
          resultCode:
            icc._iccManager.STK_RESULT_TERMINAL_CRNTLY_UNABLE_TO_PROCESS
        });
      }
    }

    this._currentMessage = new_message;
  },

  setIdleModeTextMsg: function(message) {
    this._idleModeTextMessage = message;
  },

  showIdleModeTextNotification: function () {
    let message = this._idleModeTextMessage;
    if (!message) {
      return;
    }
    console.log('show idle mode txt');
    let options = message.command.options;

    return NotificationHelper.send({
      id: 'icc-notification-title',
      args: { id: icc.getSIMNumber(message.iccId) }
    }, {
      body: options.text,
      icon: 'style/icons/system_84.png',
      tag: 'stkNotification_' + message.iccId,
      mozbehavior: { showOnlyOnce: true }
    }).then((notification) => {
      icc_worker.idleTextNotifications[message.iccId] = notification;
      notification.onclick = function onClickSTKNotification() {
        icc.discardCurrentMessageIfNeeded(message);
        let text = STKHelper.getMessageText(options);
        icc.alert(message, text, options.icons);
      };
    });
  }
};

// Initialize icc management
icc.init();
