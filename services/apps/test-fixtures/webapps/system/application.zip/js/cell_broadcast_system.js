'use strict';
/* global CarrierInfoNotifier */
/* global MobileOperator */
/* global BaseModule */
/* global SIMSlotManager */

const GSM_CMAS_LOWER_BOUND = 4370;  //0x1112
const GSM_CMAS_UPPER_BOUND = 4400;  //0x1130
const CDMA_CMAS_LOWER_BOUND = 4096; //0x1000
const CDMA_CMAS_UPPER_BOUND = 4351; //0x10FF

const ETWS_WARNINGTYPE_EARTHQUAKE = 4352;             //0x1100 Earthquake warning!
const ETWS_WARNINGTYPE_TSUNAMI = 4353;                //0x1101 Tsunami waring!
const ETWS_WARNINGTYPE_EARTHQUAKE_TSUNAMI = 4354;     //0x1102 Earthquake-tsunami warning!
const ETWS_WARNINGTYPE_TEST = 4355;                   //0x1103 Test emergency warning!
const ETWS_WARNINGTYPE_OTHER = 4356;                  //0x1104 Other emergency warning!
const ETWS_WARNINGTYPE_EXTENSION_LOWER_BOUND = 4357;  //0x1105 Future extension warning
const ETWS_WARNINGTYPE_EXTENSION_UPPER_BOUND = 4359;  //0x1107 Future extension warning

(function(exports) {
  /**
   * CellBroadcastSystem
   * @class CellBroadcastSystem
   * @requires CarrierInfoNotifier
   * @requires MobileOperator
   */
  let CellBroadcastSystem = function() {};

  CellBroadcastSystem.SETTINGS = [
    'ril.normal-cellbroadcast.enabled',
    'ril.cellbroadcast.disabled'
  ];

  BaseModule.create(CellBroadcastSystem, {
    name: 'CellBroadcastSystem',

    TAG_PREFIX: 'cell-broadcast-',

    EVENT_PREFIX: 'cellbroadcast',

    DEBUG: true,

    '_observe_ril.cellbroadcast.disabled': function(value) {
      if ('undefined' === typeof(this._settings['ril.normal-cellbroadcast.enabled'])) {
        return;
      }
      this.toggleCellbroadcast();
    },

    '_observe_ril.normal-cellbroadcast.enabled': function(value) {
      if ('undefined' === typeof(this._settings['ril.cellbroadcast.disabled'])) {
        return;
      }
      this.toggleCellbroadcast();
    },

    onNotification: function(message) {
      this.debug('onNotification -> ' + JSON.stringify(message));
      if ((Object.prototype.hasOwnProperty.call(message, 'click') &&
        !message.clicked) || (Object.prototype.hasOwnProperty.call(message,
          'tag') && (!message.tag.startsWith(this.TAG_PREFIX)))) {
        return;
      }

      CarrierInfoNotifier.show(message.body,
        navigator.mozL10n.get('cb-channel', { channel: message.messageId }));
      this.clearNotifications(message);
    },

    clearNotifications: function(message) {
      if ((Object.prototype.hasOwnProperty.call(message, 'tag') &&
          (!message.tag.startsWith(this.TAG_PREFIX)))) {
        return;
      }

      return Notification.get({ tag: message.tag }).then((notifications) => {
        notifications.forEach((notification) => {
          let tag = notification && notification.tag;
          if (!tag || !tag.startsWith(this.TAG_PREFIX)) {
            return;
          }
          notification.close();
        });
      });
    },

    toggleCellbroadcast: function() {
      if (this._hasNormalCBSDisabled()) {
        this.debug('disabled!');
        navigator.mozCellBroadcast.onreceived = null;
      } else {
        this.debug('enabled!');
        navigator.mozCellBroadcast.onreceived = this.show.bind(this);
      }
      this.publish('msgchanged');
    },

    isEmergencyAlert: function (message) {
      return this.isWEAMsg(message) || this.isETWSAlert(message);
    },

    isWEAMsg: function(message) { // WEA
      if (message.cdmaServiceCategory) {
        return (message.cdmaServiceCategory >= CDMA_CMAS_LOWER_BOUND &&
          message.cdmaServiceCategory <= CDMA_CMAS_UPPER_BOUND);
      } else {
        return (message.messageId >= GSM_CMAS_LOWER_BOUND &&
          message.messageId < GSM_CMAS_UPPER_BOUND);
      }
    },

    isETWSAlert: function(message) { // ETWS
      if (message.etws) {
        return (message.messageId === ETWS_WARNINGTYPE_EARTHQUAKE ||
          message.messageId === ETWS_WARNINGTYPE_TSUNAMI ||
          message.messageId === ETWS_WARNINGTYPE_EARTHQUAKE_TSUNAMI ||
          message.messageId === ETWS_WARNINGTYPE_TEST ||
          message.messageId === ETWS_WARNINGTYPE_OTHER ||
          (message.messageId >= ETWS_WARNINGTYPE_EXTENSION_LOWER_BOUND &&
          message.messageId <= ETWS_WARNINGTYPE_EXTENSION_UPPER_BOUND));
      } else {
        return false;
      }
    },

    /**
     * Shows the cell broadcast notification.
     * @memberof CellBroadcastSystem.prototype
     */
    show: function cbs_show(event) {
      this.debug('will show cb if it is not emergency');
      let msg = event.message;
      let serviceId = msg.serviceId || 0;
      let conn = window.navigator.mozMobileConnections[serviceId];
      let id = msg.messageId;

      // Early return CMAS messsage and let network alert app handle it. Please
      // ref http://www.etsi.org/deliver/etsi_ts/123000_123099/123041/
      // 11.06.00_60/ts_123041v110600p.pdf, chapter 9.4.1.2.2 GSM　Message
      // identifier Message id from range 4370 to 4399(1112 hex to 112f hex),
      // and CDMA　Message identifier Message id from range 4096 to 4351(0x1000
      // hex ro 0x10ff hex) should be CMAS message and network alert will
      // display detail information.
      if (this.isEmergencyAlert(msg)) {
        return;
      }

      if (conn &&
          conn.voice.network.mcc === MobileOperator.BRAZIL_MCC &&
          id === MobileOperator.BRAZIL_CELLBROADCAST_CHANNEL) {
        let evt = new CustomEvent('cellbroadcastmsgchanged',
          { detail: msg.body });
        window.dispatchEvent(evt);
        return;
      }

      if (this._hasNormalCBSDisabled()) {
        return;
      }
      this.sendNotification(msg);
    },

    sendNotification: function(message) {
      return new Promise((resolve, reject) => {
        let _ = window.navigator.mozL10n.get;
        let iconName = '';
        if (SIMSlotManager.isMultiSIM()) {
          iconName = 'cell-broadcast-sim' + (message.serviceId + 1);
        } else {
          iconName = 'cell-broadcast';
        }

        let iconURL = '/resources/images/cellbroadcast/' + iconName + '.svg';
        this.debug('iconURL -> ' + iconURL);
        let title = _('cell-broadcast-subtitle') + ' - ' + message.messageId;
        let notification = new Notification(title, {
          icon: iconName,
          data: message,
          body: message.body,
          tag: this.TAG_PREFIX + message.timestamp,
        });

        notification.onerror = () => {
          reject(new Error('notification API error'));
        };
        notification.onshow = resolve;

        notification.onclick = (evt) => {
          let msg = evt.target.data;
          this.onNotification(msg);
        };
      }, this);
    },

    /**
     * To make sure there is any CBS pref is disabled
     * @memberof CellBroadcastSystem.prototype
     */
    _hasNormalCBSDisabled: function() {
      if (!this._settings) {
        return true;
      }
      let cbsDisabled = this._settings['ril.cellbroadcast.disabled'];
      let normalEnabled = this._settings['ril.normal-cellbroadcast.enabled'];
      let enabled = Array.prototype.some.call((cbsDisabled), (disabled) => {
        return disabled === false;
      });
      return !normalEnabled && enabled;
    }
  });
}(window));
