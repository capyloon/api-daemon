/* -*- Mode: Java; tab-width: 2; indent-tabs-mode: nil; c-basic-offset: 2 -*- /
/* vim: set shiftwidth=2 tabstop=2 autoindent cindent expandtab: */

/**
 * Firefox Accounts is a database of users who have opted in to services in
 * the Mozilla cloud. Firefox Accounts holds Mozilla specific information
 * (which of your devices are attached right now?), as well as one (and
 * eventually multiple) verified identities for a user.
 *
 * Firefox Accounts is a web scale service with a REST API, that allows a user
 * agent to authenticate to the service (by verifying the user's identity),
 * and in exchange to get credentials that allow the user agent to assert the
 * identity of the user to other services.
 *
 * FxAccountsManager is mostly a proxy between certified apps that wants to
 * manage Firefox Accounts (FTU and Settings so far) and the platform.
 * It handles the communication via IAC and redirects the requests coming from
 * these apps to the platform in the form of mozContentEvents. It also handles
 * sign-in requests done via the mozId API from RPs and triggers FxAccountsUI
 * to show the appropriate UI in each case.
 *
 *
 * =FTU=                          =Settings=                     =RP=
 *   |                           /                                |
 *   |-IAC                  IAC-/                                 |
 *    \                        /                                  |
 * ========================System=======================          |
 *       \                  /                                     |
 *        \                /       FxAccountsUI                   |
 *       FxAccountsManager ______/       |                        |-mozId API
 *            |                  \       |                        |
 *            |                       FxAccountsClient            |
 *            |                        |                          |
 *            |                        |                          |
 * =============================Gecko======================================
 *            |                        |                          |
 *            |                        |-moz(Chrome/Content)Event |
 *            |                        |                          |
 *       FxAccountsUIGlue    FxAccountsMgmtService                |
 *                 |               ^                              |
 *                 |               |                              |
 *                 |               |                              |
 *                 |__________FxAccountsManager                   |
 *                                 |                              |
 *                                 |                              |
 *                          DOM Identity API impl. _______________|
 */

/* global IACHandler, LazyLoader, FxAccountsClient, FxAccountsUI */

'use strict';

var FxAccountsManager = {
  DEBUG: false,
  _isConfigToPhoneMethod: false, // The default method is email.

  _debug: function(msg) {
    if (this.DEBUG) {
      console.log(msg);
    }
  },

  _activateAccountsLoginUI: function fxa_mgmt_activateAccountsUI(message) {
    FxAccountsUI.login(
      function(result) {
        // Enable antitheft if sign-in successfully
        if (result && result.success) {
          navigator.mozSettings.createLock().set({
            'antitheft.enabled': true
          });
        }

        this._sendContentEvent({
          id: message.id,
          result: result
        });
      }.bind(this),
      function(error) {
        this._sendContentEvent({
          id: message.id,
          error: error
        });
      }.bind(this)
    );
  },

  init: function fxa_mgmt_init() {
    // Set up the listener for IAC API connection requests.
    window.addEventListener('iac-fxa-mgmt', this.onPortMessage);
    // Listen for unsolicited chrome events coming from the implementation o
    // RP DOM API or the Fx Accounts UI glue.
    window.addEventListener('mozFxAccountsUnsolChromeEvent', this);
    // Listen for platform OTP received event.
    window.addEventListener('otpReceived', this.onOTPReceived.bind(this));
    // Get the 'account.verification.phone.enabled' settings key.
    this.initDefaultVerificationMethod();
    // When time changed, we need to fresh check password check time
    this.initRefreshCheckPassWordTime();
  },

  initRefreshCheckPassWordTime: function() {
    // Per spec SFP_IxD_Spec_Account & Anti-theft_v2.5
    var _retryInterval = {
      6: 1 * 60 * 1000,
      7: 5 * 60 * 1000,
      8: 15 * 60 * 1000,
      9: 60 * 60 * 1000,
      10: 4 * 60 * 60 * 1000
    };
    var setCheckPwdTime = function() {
      window.asyncStorage.getItem('checkpassword.retrycount', count => {
        this._debug('checkpassword.retrycount is ' + count);
        if (count >= 6) {
          if (count >= 10) {
            count = 10;
          }
          var interval = _retryInterval[count];
          var enableTime = new Date().getTime() + interval;
          this._debug('Next password retry should be later than ' + enableTime);
          window.asyncStorage.setItem('checkpassword.enabletime', enableTime);
        }
      });
    };

    this._debug('initRefreshChkPwd when moztimechange');
    window.addEventListener('moztimechange', setCheckPwdTime.bind(this));
  },

  initDefaultVerificationMethod: function() {
    var key = 'account.verification.phone.enabled';
    var getRequest = navigator.mozSettings.createLock().get(key);
    getRequest.onsuccess = () => {
      this._debug(
        '--> onsuccess(): getRequest.result[key] = ' + getRequest.result[key]
      );
      if (getRequest.result[key] === true) {
        this._isConfigToPhoneMethod = true;
      }
    };

    getRequest.onerror = () => {
      this._debug('--> onerror(): get config failed');
    };
  },

  sendPortMessage: function fxa_mgmt_sendPortMessage(message) {
    var port = IACHandler.getPort('fxa-mgmt');
    if (port) {
      port.postMessage(message);
    }
  },

  onOTPReceived: function(event) {
    this._debug('--> onOTPReceived(): event = ' + event);
    FxAccountsUI.fillInOTP(event.detail);
  },

  onPortMessage: function fxa_mgmt_onPortMessage(event) {
    if (!event || !event.detail) {
      console.error('Wrong event');
      return;
    }

    var self = FxAccountsManager;
    self._debug(
      '--> onPortMessage(): event.detail.name = ' + event.detail.name
    );

    var methodName = event.detail.name;

    self._debug('--> methodName = ' + methodName);

    switch (methodName) {
      case 'getAccounts':
      case 'logout':
        (function(methodName) {
          LazyLoader.load('js/fxa_client.js', function() {
            FxAccountsClient[methodName](
              function(data) {
                self.sendPortMessage({ methodName: methodName, data: data });
              },
              function(error) {
                self.sendPortMessage({ methodName: methodName, error: error });
              }
            );
          });
        })(methodName);
        break;
      case 'requestEmailVerification':
        (function(methodName) {
          var email = event.detail.email;
          var altEmail = event.detail.altEmail;
          if (!email) {
            self.sendPortMessage({
              methodName: methodName,
              error: 'NO_VALID_EMAIL'
            });
            return;
          }
          LazyLoader.load('js/fxa_client.js', function() {
            FxAccountsClient[methodName](
              email,
              altEmail,
              function(data) {
                self.sendPortMessage({ methodName: methodName, data: data });
              },
              function(error) {
                self.sendPortMessage({ methodName: methodName, error: error });
              }
            );
          });
        })(methodName);
        break;
      case 'signIn':
        (function(methodName) {
          var email = event.detail.email;
          var password = event.detail.password;
          if (!email) {
            self.sendPortMessage({
              methodName: methodName,
              error: 'NO_VALID_EMAIL'
            });
            return;
          }
          LazyLoader.load('js/fxa_client.js', function() {
            FxAccountsClient[methodName](
              email,
              password,
              function(data) {
                self.sendPortMessage({ methodName: methodName, data: data });
              },
              function(error) {
                self.sendPortMessage({ methodName: methodName, error: error });
              }
            );
          });
        })(methodName);
        break;
      case 'openFlow':
        (function(methodName) {
          FxAccountsUI.login(
            function(data) {
              self.sendPortMessage({ methodName: methodName, data: data });
            },
            function(error) {
              self.sendPortMessage({ methodName: methodName, error: error });
            }
          );
        })(methodName);
        break;
      case 'openInfoPage':
        (function(methodName) {
          FxAccountsUI.openAccount(
            function(data) {
              self.sendPortMessage({ methodName: methodName, data: data });
            },
            function(error) {
              self.sendPortMessage({ methodName: methodName, error: error });
            }
          );
        })(methodName);
        break;
      case 'signOut':
        (function(methodName) {
          var email = event.detail.email;
          FxAccountsUI.signOut(
            email,
            function(data) {
              self.sendPortMessage({ methodName: methodName, data: data });
            },
            function(error) {
              self.sendPortMessage({ methodName: methodName, error: error });
            }
          );
        })(methodName);
        break;
      case 'checkPassword':
        (function(methodName) {
          var accountInfo = event.detail.accountInfo;
          var type = event.detail.type;
          FxAccountsUI.checkPassword(
            accountInfo,
            type,
            function(data) {
              self.sendPortMessage({ methodName: methodName, data: data });
            },
            function(error) {
              self.sendPortMessage({ methodName: methodName, error: error });
            }
          );
        })(methodName);
        break;
      case 'changePassword':
        (function(methodName) {
          var email = event.detail.email;
          FxAccountsUI.changePassword(
            email,
            function(data) {
              self.sendPortMessage({ methodName: methodName, data: data });
            },
            function(error) {
              self.sendPortMessage({ methodName: methodName, error: error });
            }
          );
        })(methodName);
        break;
      case 'createAccount':
        (function(methodName) {
          FxAccountsUI.createAccount(
            function(data) {
              self.sendPortMessage({ methodName: methodName, data: data });
            },
            function(error) {
              self.sendPortMessage({ methodName: methodName, error: error });
            }
          );
        })(methodName);
        break;
      case 'refreshAuthentication':
        (function(methodName) {
          var email = event.detail.email;
          if (!email) {
            self.sendPortMessage({
              methodName: methodName,
              error: 'NO_VALID_EMAIL'
            });
            return;
          }

          FxAccountsUI.refreshAuthentication(
            email,
            function(data) {
              self.sendPortMessage({ methodName: methodName, data: data });
            },
            function(error) {
              self.sendPortMessage({ methodName: methodName, error: error });
            }
          );
        })(methodName);
        break;
      case 'phoneNumberLogin':
        (function(methodName) {
          FxAccountsUI.phoneNumberLogin(
            function(data) {
              self._debug('--> phoneNumberLogin: data = ' + data);
              self.sendPortMessage({ methodName: methodName, data: data });
            },
            function(error) {
              self.sendPortMessage({ methodName: methodName, error: error });
            }
          );
        })(methodName);
        break;
      case 'verifyAltPhone':
        (function(methodName) {
          var altPhone = event.detail.altPhone;
          var accountId = event.detail.phone || event.detail.email;
          FxAccountsUI.verifyAltPhone(
            accountId,
            altPhone,
            function(data) {
              self._debug('--> verifyAltPhone: data = ' + data);
              self.sendPortMessage({ methodName: methodName, data: data });
            },
            function(error) {
              self.sendPortMessage({ methodName: methodName, error: error });
            }
          );
        })(methodName);
        break;
      case 'disableAntiTheft':
        (function(methodName) {
          FxAccountsUI.disableAntiTheft(
            function(data) {
              self.sendPortMessage({ methodName: methodName, data: data });
            },
            function(error) {
              self.sendPortMessage({ methodName: methodName, error: error });
            }
          );
        })(methodName);
        break;
    }
  },

  _sendContentEvent: function fxa_mgmt_sendContentEvent(msg) {
    var event = new CustomEvent('mozFxAccountsRPContentEvent', { detail: msg });
    window.dispatchEvent(event);
  },

  handleEvent: function fxa_mgmt_handleEvent(event) {
    if (!event || !event.detail) {
      console.error('Wrong event');
      return;
    }

    var message = event.detail;
    var email;
    this._debug(
      '--> mozFxAccountsUnsolChromeEvent handleEvent(): ' +
        'event.detail.eventName = ' +
        event.detail.eventName
    );

    switch (message.eventName) {
      case 'openFlow':
        this._activateAccountsLoginUI(message);
        break;
      case 'openInfoPage':
        FxAccountsUI.openAccount(
          function(result) {
            this._sendContentEvent({
              id: message.id,
              result: result
            });
          }.bind(this),
          function(error) {
            this._sendContentEvent({
              id: message.id,
              error: error
            });
          }.bind(this)
        );
        break;
      case 'phoneNumberLogin':
        FxAccountsUI.phoneNumberLogin(
          function(result) {
            this._sendContentEvent({
              id: message.id,
              result: result
            });
          }.bind(this),
          function(error) {
            this._sendContentEvent({
              id: message.id,
              error: error
            });
          }.bind(this)
        );
        break;
      case 'signOut':
        email = message.email;
        FxAccountsUI.signOut(
          email,
          function(result) {
            this._sendContentEvent({
              id: message.id,
              result: result
            });
          }.bind(this),
          function(error) {
            this._sendContentEvent({
              id: message.id,
              error: error
            });
          }.bind(this)
        );
        break;
      case 'checkPassword':
        var data = message.data;
        var type = event.detail.type;
        FxAccountsUI.checkPassword(
          data,
          type,
          function(result) {
            this._sendContentEvent({
              id: message.id,
              result: result
            });
          }.bind(this),
          function(error) {
            this._sendContentEvent({
              id: message.id,
              error: error
            });
          }.bind(this)
        );
        break;
      case 'changePassword':
        email = message.email;
        FxAccountsUI.changePassword(
          email,
          function(result) {
            this._sendContentEvent({
              id: message.id,
              result: result
            });
          }.bind(this),
          function(error) {
            this._sendContentEvent({
              id: message.id,
              error: error
            });
          }.bind(this)
        );
        break;
      case 'createAccount':
        FxAccountsUI.createAccount(
          function(result) {
            this._sendContentEvent({
              id: message.id,
              result: result
            });
          }.bind(this),
          function(error) {
            this._sendContentEvent({
              id: message.id,
              error: error
            });
          }.bind(this)
        );
        break;
      case 'refreshAuthentication':
        var getL10n = navigator.mozL10n.get;
        var refreshAuthNotify = new window.Notification(
          getL10n('account-refreshAuthentication-notice-title'),
          {
            body: getL10n('account-refreshAuthentication-notice-text'),
            tag: 'refreshAuthentication',
            mozbehavior: {
              showOnlyOnce: true
            },
          }
        );

        refreshAuthNotify.onclick = function() {
          refreshAuthNotify.close();
          this._activateAccountsLoginUI(message);
        }.bind(this);
        break;
      case 'disableAntiTheft':
        FxAccountsUI.disableAntiTheft(
          function(result) {
            this._sendContentEvent({
              id: message.id,
              result: result
            });
          }.bind(this),
          function(error) {
            this._sendContentEvent({
              id: message.id,
              error: error
            });
          }.bind(this)
        );
        break;
      case 'onlogin':
      case 'onverified':
      case 'onlogout':
        FxAccountsManager.sendPortMessage({ eventName: message.eventName });
        break;
    }
  }
};

FxAccountsManager.init();
