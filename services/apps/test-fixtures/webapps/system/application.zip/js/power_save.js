'use strict';
/* global batteryOverlay, MozActivity, NotificationHelper,
   SettingsListener */

(function(exports) {

  function PowerSave() {}

  PowerSave.prototype = {
    _powerSaveResume: {},

    _powerSaveEnabled: false,

    POWERSAVE_BACKUP_KEY: 'powersave.backup',

    _states: {
      'wifi.enabled': false,
      'ril.data.enabled': false,
      'bluetooth.enabled': false,
      'geolocation.enabled': false,
      'nfc.enabled': false
    },

    _powerSaveEnabledLock: false,

    start: function() {
      this.initPowerSaveState();
      let Settings = navigator.mozSettings;
      Settings.addObserver('powersave.enabled', event => {
        let enabled = event.settingValue;
        if (enabled) {
          this.enablePowerSave();
        } else {
          this.disablePowerSave();
        }
        this._powerSaveEnabled = enabled;
      });

      SettingsListener.observe('powersave.threshold', -1, value => {
        this.doCheckThreshold(value);
      });

      function getState(state, value) {
        /* jshint validthis: true */
        this._states[state] = value;
      }

      // Monitor the states of various modules
      for (var j in this._states) {
        SettingsListener.observe(j, true, getState.bind(this, j));
      }
    },

    // XXX Break down obj keys in a for each loop because mozSettings
    // does not currently supports multiple keys in one set()
    // https://bugzilla.mozilla.org/show_bug.cgi?id=779381
    setMozSettings: function(keypairs) {
      var setlock = SettingsListener.getSettingsLock();
      for (var key in keypairs) {
        // not set bluetooth key because we'll handle it separately
        // for API compatibility
        if ('bluetooth.enabled' !== key) {
          var obj = {};
          obj[key] = keypairs[key];
          setlock.set(obj);
        }
      }
    },

    backupResumeValue: function() {
      let setlock = SettingsListener.getSettingsLock();
      let obj = {};
      obj[this.POWERSAVE_BACKUP_KEY] = this._powerSaveResume;
      setlock.set(obj);
    },

    restoreResumeValue: function() {
      let Settings = navigator.mozSettings;
      let lock = Settings.createLock();
      let req =  lock.get(this.POWERSAVE_BACKUP_KEY);
      req.onsuccess = () => {
        this._powerSaveResume = req.result[this.POWERSAVE_BACKUP_KEY] || {};
      };
      if (lock.forceClose) {
        lock.forceClose();
      }
    },

    initPowerSaveState: function() {
      this.restoreResumeValue();
      let Settings = navigator.mozSettings;
      let lock = Settings.createLock();
      let req = lock.get('powersave.enabled');
      req.onsuccess = () => {
        let enabled = req.result['powersave.enabled'];
        this._powerSaveEnabled = enabled;
      };
      if (lock.forceClose) {
        lock.forceClose();
      }
    },

    enablePowerSave: function() {
      // Keep the original states of various modules
      for (var j in this._states) {
        this._powerSaveResume[j] = this._states[j];
      }
      this.backupResumeValue();

      var settingsToSet = {
        // Turn off Wifi
        'wifi.enabled': false,
        // Turn off Data
        'ril.data.enabled': false,
        // Turn off Geolocation
        'geolocation.enabled': false
      };

      if (window.navigator.mozNfc) {
        settingsToSet['nfc.enabled'] = false;
      }
      this.setMozSettings(settingsToSet);
      // Turn off Bluetooth
      window.dispatchEvent(new CustomEvent('request-disable-bluetooth'));

      this._powerSaveEnabledLock = false;
    },

    disablePowerSave: function() {
      var settingsToSet = {};
      this.removePowerSavingNotification();

      for (var state in this._powerSaveResume) {
        if (this._powerSaveResume[state] === true) {
          settingsToSet[state] = true;
        }
      }
      if (this._powerSaveResume['bluetooth.enabled'] === true) {
        // Turn on Bluetooth
        window.dispatchEvent(new CustomEvent('request-enable-bluetooth'));
      }

      this.setMozSettings(settingsToSet);
    },

    showPowerSavingNotification: function() {
      var clickCB = function() {
        var activityRequest = new MozActivity({
          name: 'configure',
          data: {
            target: 'device',
            section: 'battery'
          }
        });
        activityRequest.onsuccess = () => {};
      };

      let _ = navigator.mozL10n.get;
      this.powerSaveNotification = new Notification(
        _('notification-powersaving-mode-on-title'), {
          'tag': 'powerSave',
          'body': _('notification-powersaving-mode-on-description'),
          'icon': 'style/icons/Power_saving_mode.png',
          'mozbehavior': {
            showOnlyOnce: true
          }
        });

      this.powerSaveNotification.addEventListener('click', clickCB);
    },

    removePowerSavingNotification() {
      if (this.powerSaveNotification) {
        this.powerSaveNotification.close();
        this.powerSaveNotification = null;
      }
    },

    checkThreshold: function() {
      var key = 'powersave.threshold';
      var lock = navigator.mozSettings.createLock();
      var req = lock.get(key);
      req.onerror = function(e) {
        console.error('Error while quering setting ' + key + ': ' + e);
      };

      req.onsuccess = (function() {
        this.doCheckThreshold(req.result[key] || -1);
      }).bind(this);
    },

    doCheckThreshold: function(value) {
      var battery = batteryOverlay._battery;

      // If 'turn on automatically' is set to 'never', don't change the
      // power saving state
      if (value == -1) {
        return;
      }

      if (battery.level <= value && !this._powerSaveEnabled &&
        !battery.charging) {
        this.setMozSettings({
          'powersave.enabled': true
        });
        if (!this._powerSaveEnabledLock) {
          this.showPowerSavingNotification();
          this._powerSaveEnabledLock = true;
        }
        return;
      }

      if (battery.level > value && this._powerSaveEnabled) {
        this.setMozSettings({
          'powersave.enabled': false
        });
        return;
      }
    },

    onBatteryChange: function() {
      var battery = batteryOverlay._battery;

      if (battery.charging) {
        if (this._powerSaveEnabled) {
          this.setMozSettings({
            'powersave.enabled': false
          });
        }

        return;
      }

      this.checkThreshold();
    }
  };

  exports.PowerSave = PowerSave;

}(window));
