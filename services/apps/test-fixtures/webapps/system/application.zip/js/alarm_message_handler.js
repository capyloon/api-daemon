'use strict';

var AlarmMessageHandler = {
  callbackMap: new Map(),

  alarmFired: function alarm_fired(alarm) {
    this.callbackMap.forEach((value, key, map) => { key(alarm); });
  },

  addCallback: function alarm_add_callback(callback) {
    this.callbackMap.set(callback, true);
  },

  removeCallback: function alarm_remove_callback(callback) {
    this.callbackMap.delete(callback);
  }
};

navigator.mozSetMessageHandler('alarm', function(alarm) {
  AlarmMessageHandler.alarmFired(alarm);
});
