/* globals ScreenManager, Service */

'use strict';
(function(exports) {
  var BrowserKeyEventManager = function BrowserKeyEventManager() {
  };

  BrowserKeyEventManager.prototype = {
    KEY_EVENTS: Object.freeze([
      'mozbrowserbeforekeydown',
      'mozbrowserbeforekeyup',
      'mozbrowserafterkeydown',
      'mozbrowserafterkeyup',
      'keydown',
      'keyup'
    ]),
    SYSTEM_ONLY_KEYS: Object.freeze([
      'power',
      'home',
      'mozhomescreen',
      'exit',
      'notification',
      'custom'
    ]),
    APP_CANCELLED_KEYS: Object.freeze([
      'volumeup',
      'volumedown',
      'browserback',
      'backspace',
      'softleft',
      'softright',
      'endcall',
      'enter',
      'camera',
      'arrowup',
      'arrowdown',
      'contextmenu',
      '1',
      '2',
      '3',
      '4',
      '5',
      '8',
      'e',
      'i',
      'o',
      'r',
      'w',
      'a',
      '*',
      '#'
    ]),
    // Home key has different .key values on different devices.
    HOME_KEY_ALIAS: Object.freeze([
      'home',
      'mozhomescreen',
      'exit'
    ]),
    TRANSLATION_TABLE: Object.freeze({
      'power': 'sleep-button',
      'exit': 'home-button',
      'home': 'home-button',
      'mozhomescreen': 'home-button',
      'contextmenu': 'menu-button',
      'volumeup': 'volume-up-button',
      'volumedown': 'volume-down-button',
      'custom': 'led-button',
      'browserback': 'browserback-button',
      'backspace': 'backspace-button',
      'softleft': 'softleft-button',
      'softright': 'softright-button',
      'endcall': 'endcall-button',
      'enter': 'enter-button',
      'notification': 'sms-button',
      'camera': 'camera-button',
      'arrowup': 'arrowup-button',
      'arrowdown': 'arrowdown-button',
      '1': '1-button',
      '2': '2-button',
      '3': '3-button',
      '4': '4-button',
      '5': '5-button',
      '8': '8-button',
      'e': 'e-button',
      'i': 'i-button',
      'o': 'o-button',
      'r': 'r-button',
      'w': 'w-button',
      'a': 'a-button',
      '*': 'star-button',
      '#': 'hash-button'
    }),
    /**
     * This is to store a complete chain of
     * 1. beforekeydown
     * 2. keydown
     * 3. afterkeydown
     * Because we can't use embeddedCancelled in system app, but we still need
     * to know the keydown is prevented or not.
     * @type {Map}
     */
    _system_key_event_map: new Map(),
    _getLowerCaseKeyName: function bkem_getLowerCaseKeyName(event) {
      return event.key && event.key.toLowerCase();
    },
    _isSystemOnlyKey: function bkem_isSystemOnlyKey(event) {
      var key = this._getLowerCaseKeyName(event);
      return (this.SYSTEM_ONLY_KEYS.indexOf(key) > -1);
    },
    _isAppCancelledKey: function bkem_isAppCancelledKey(event) {
      var key = this._getLowerCaseKeyName(event);
      return (this.APP_CANCELLED_KEYS.indexOf(key) > -1);
    },
    _isBeforeEvent: function bkem_isBeforeEvent(event) {
      return event.type === 'mozbrowserbeforekeyup' ||
        event.type === 'mozbrowserbeforekeydown';
    },
    _isAfterEvent: function bkem_isAfterEvent(event) {
      return event.type === 'mozbrowserafterkeyup' ||
        event.type === 'mozbrowserafterkeydown';
    },
    _isKeyEvent: function bkem_isKeyEvent(event) {
      return event.type === 'keyup' ||
        event.type === 'keydown';
    },
    _targetToIframe: function bkem_targetToIframe(event) {
      return (event.target instanceof HTMLIFrameElement);
    },
    screenOff: function() {
      return !ScreenManager.screenEnabled;
    },
    _applyPolicy: function bkem_applyPolicy(event) {
      // all other unknown keys are default to APP-ONLY
      // so we assume there is no translation needed by default
      var needTranslation = false;
      if (this._isSystemOnlyKey(event)) {
        // We don't know if a before event is mapping to another after event
        // So we use after here.
        if (this._isAfterEvent(event) || this._isKeyEvent(event)) {
          needTranslation = true;
        }
        event.preventDefault();
      } else if (this._isAppCancelledKey(event) && this._isAfterEvent(event)) {
        // if embedded frame cancel the event, we need to translate it then
        if (this.isPreventedInSystem(event)) {
          needTranslation = false;
        } else {
          needTranslation = !event.embeddedCancelled && !event.defaultPrevented;
        }
      } else if (this._isKeyEvent(event) && !this._targetToIframe(event)) {
        // When focus is on embedded iframe and user press hardware key, system
        // app will receive an extra keydown keyup event targeted to the iframe.
        // We should ignore this event otherwise we will have strange state
        // transition in HardwareButton module.
        // Please see https://bugzilla.mozilla.org/show_bug.cgi?id=989198#c194
        // and https://bugzilla.mozilla.org/show_bug.cgi?id=1014418#c20
        if (!this._system_key_event_map.get(event.key).mozbrowserafterkeydown &&
            this._system_key_event_map.get(event.key).mozbrowserbeforekeydown &&
            'EndCall' === event.key &&
            'keyup' === event.type) {
          needTranslation = false;
        } else {
          needTranslation = true;
        }
      } else {
        // Care less about keyup is cancelled or not.
        if (event.type.indexOf('keyup') !== -1 && this._isBeforeEvent(event)) {
          needTranslation = true;
        }
      }
      return needTranslation;
    },
    isHomeKey: function bkem_isHomeKey(event) {
      var key = this._getLowerCaseKeyName(event);
      return (this.HOME_KEY_ALIAS.indexOf(key) > -1);
    },
    isArrowKey: function(event) {
      var key = this._getLowerCaseKeyName(event);
      return (key.indexOf('arrow') > -1);
    },
    isHardwareKeyEvent: function bkem_isHardwareKeyEvent(type) {
      return (this.KEY_EVENTS.indexOf(type) > -1);
    },
    isPreventedInSystem: function(event) {
      var set = this._system_key_event_map.get(event.key);
      if (!set) {
        return false;
      }

      var keyEvent = set.keydown || set.mozbrowserbeforekeydown;
      if (keyEvent) {
        return keyEvent.defaultPrevented;
      } else {
        return false;
      }
    },
    isMissingEndCallKeyup: function(event, needTranslation) {
      return event.key === 'EndCall' &&
             event.type === 'mozbrowserafterkeydown' &&
             needTranslation &&
             (this._system_key_event_map.get('EndCall').mozbrowserbeforekeyup ||
              this._system_key_event_map.get('EndCall').keyup);
    },
    getButtonEventType: function bkem_getButtonEventType(event) {
      // Clean the key set if beforekeydown is caught.
      if (event.type === 'mozbrowserbeforekeydown') {
        this._system_key_event_map.delete(event.key);
      }

      // Store the key set for system app key events.
      if (!this._system_key_event_map.get(event.key)) {
        this._system_key_event_map.set(event.key, {});
      }
      this._system_key_event_map.get(event.key)[event.type] = event;

      var translatedType;
      var key = this._getLowerCaseKeyName(event);
      var suffix;
      var needTranslation =
        this.isHardwareKeyEvent(event.type) ? this._applyPolicy(event) : false;

      if (needTranslation) {
        suffix = (event.type.indexOf('keyup') > -1) ? '-release' : '-press';
        translatedType =
          this.TRANSLATION_TABLE[key] && this.TRANSLATION_TABLE[key] + suffix;
      }
      // XXX: See bug 5558
      // In some case, keyup & afterkeyup of EndCall will be dropped.
      // And beforekeyup is fired before afterkeydown.
      // So we look up the event table for beforekeyup
      // and re-dispatch it if found.
      if (this.isMissingEndCallKeyup(event, needTranslation)) {
        window.setTimeout(() => {
          console.warn('missing keyup, redispatch if possible');
          Service.request('HardwareButtons:handleEvent',
            (this._system_key_event_map.get('EndCall').mozbrowserbeforekeyup ||
             this._system_key_event_map.get('EndCall').keyup));
        });
      }
      return translatedType;
    }
  };

  exports.BrowserKeyEventManager = BrowserKeyEventManager;
}(window));
