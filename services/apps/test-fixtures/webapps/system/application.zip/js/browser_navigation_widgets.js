(function(exports) {
  'use strict';

  var _id = 0;

  var BrowserNavigationWidgets = function(app) {
    this.app = app;
    this.instanceID = _id++;
    this.containerElement = app.element;
    this._zoomScaleIndex = this.DEFAULT_ZOOM_SCALE_INDEX;

    this.render();
  };

  BrowserNavigationWidgets.prototype = Object.create(exports.BaseUI.prototype);

  BrowserNavigationWidgets.prototype.CLASS_NAME = 'BrowserNavigationWidgets';

  BrowserNavigationWidgets.prototype.EVENT_PREFIX = 'browser-zoom-indicator';

  BrowserNavigationWidgets.prototype.DEBUG = false;

  BrowserNavigationWidgets.prototype.ZOOM_INDICATOR_TIMEOUT = 10000;
  // Note that ZOOM_SCALES must be match with pref(greprefs.js):
  // 'toolkit.zoomManager.zoomValues'
  // And the lowest value must be equal or greater then pref
  // 'zoom.minPercent', the highest value must be equal or less then pref
  // 'zoom.maxPercent'.
  BrowserNavigationWidgets.prototype.ZOOM_SCALES =
    Object.freeze([0.33, 0.5, 0.67, 1.0, 1.5, 2.0]);
  BrowserNavigationWidgets.prototype.DEFAULT_ZOOM_SCALE_INDEX = 3;

  BrowserNavigationWidgets.prototype.observe = function(name, value) {
    this.debug('observe [' + name + '] = ' + value);
    if (name === 'browser.zoomIndicator.hide') {
      // Do not show browser overlay if
      // 1. in popup window or
      // 2. 'browser.zoomIndicator.hide' is turn on
      this.disableZoomIndicator =
        !!(value || (this.app.config.chrome && this.app.config.chrome.bar));

      this.disableZoomIndicator ?
        this.hideZoomIndicator() : this.showZoomIndicator();
    }
  };

  BrowserNavigationWidgets.prototype.view = function() {
    var className = this.CLASS_NAME + this.instanceID;

    return `<div class="browser-zoom-indicator" id="${className}">
              <kai-optionmenu class="option-menu">
              </kai-optionmenu>
              <div class="toast-container">
                <div class="widgets zoom-out">
                  <div class="icon" data-icon="browser-zoomin"></div>
                  <div class="text h2">1</div>
                </div>
                <div class="widgets navigation-mode">
                  <div class="icon" data-icon="browser-scroller"></div>
                  <div class="text h2">5</div>
                </div>
                <div class="widgets zoom-in">
                  <div class="icon" data-icon="browser-zoomout"></div>
                  <div class="text h2">3</div>
                </div>
                <div class="widgets go-to-top">
                  <div class="icon" data-icon="go-to-top"></div>
                  <div class="text h2">2</div>
                </div>
                <div class="widgets go-to-end">
                  <div class="icon" data-icon="go-to-end"></div>
                  <div class="text h2">8</div>
                </div>
              </div>
              <div class="scroll-direction-indicator hidden">
                <div class="scroll-direction-icon top"></div>
                <div class="scroll-direction-icon left"></div>
                <div class="scroll-direction-icon right"></div>
                <div class="scroll-direction-icon bottom"></div>
              </div>
            </div>`;
  };

  BrowserNavigationWidgets.prototype.render = function() {
    this.publish('willrender');

    this.app.element.insertAdjacentHTML('afterbegin', this.view());

    this._fetchElements();
    this._registerEvents();

    this.publish('rendered');
  };

  BrowserNavigationWidgets.prototype._fetchElements = function() {
    this.element =
      this.containerElement.querySelector('.browser-zoom-indicator');
    this.zoomIndicator = this.element.querySelector('.toast-container');
    this.navigationModeIcon =
      this.element.querySelector('.navigation-mode > .icon');
    this.navigationModeIndicator =
      this.element.querySelector('.scroll-direction-indicator');
    this.optionMenu = this.element.querySelector('kai-optionmenu');
  };

  BrowserNavigationWidgets.prototype._registerEvents = function() {
    this.app.element.addEventListener('_opened', this);
    this.app.element.addEventListener('_loaded', this);
    this.app.element.addEventListener('_closing', this);
    this.app.element.addEventListener('_scrollerModeChanged', this);
    this.app.browser.element.addEventListener('mozbrowserlocationchange', this);
    window.addEventListener('will-shutdown', this);
    window.addEventListener('soundManagerShow', this);
    window.addEventListener('soundManagerHide', this);
    this.element.addEventListener('optionmenuSelect', this);
    this.element.addEventListener('optionmenu-visibility-change', this);
  };

  BrowserNavigationWidgets.prototype.setOptionMenu = function(options) {
    this.optionMenu.setAttribute('options', JSON.stringify(options));
    this.optionMenu.position = {
      from: 0,
      to: this.element.offsetTop
    };
  };

  BrowserNavigationWidgets.prototype.showOptionMenu = function() {
    this.optionMenu.open = true;
    this.element.classList.add('enablePointerEvents');
  };

  BrowserNavigationWidgets.prototype.startZoomIndicatorTimer = function() {
    if (this.zoomIndicatorTimer) {
      window.clearTimeout(this.zoomIndicatorTimer);
    }
    this.zoomIndicatorTimer = window.setTimeout(() => {
      this.zoomIndicatorTimer = undefined;
      this.hideZoomIndicator();
    }, this.ZOOM_INDICATOR_TIMEOUT);
  };

  BrowserNavigationWidgets.prototype.showZoomIndicator = function() {
    return; // Early return since feature is not ready yet.
    if (!this.disableZoomIndicator) {
      this.zoomIndicator.classList.add('visible');
      this.startZoomIndicatorTimer();
    }
  };

  BrowserNavigationWidgets.prototype.hideZoomIndicator = function() {
    if (this.zoomIndicatorTimer) {
      window.clearTimeout(this.zoomIndicatorTimer);
      this.zoomIndicatorTimer = undefined;
    }
    this.zoomIndicator.classList.remove('visible');
  };

  BrowserNavigationWidgets.prototype.handleEvent = function(evt) {
    switch (evt.type) {
      case '_loaded':
        this.debug('this.disableZoomIndicator: ' + this.disableZoomIndicator);
        if (this.app.isBrowser() && !this.disableZoomIndicator) {
          this.show();
          this.showZoomIndicator();
        }
        this.setNavigationMode('spatial');
        break;
      case '_opened':
        this.debug('this.disableZoomIndicator: ' + this.disableZoomIndicator);
        if (this.app.isBrowser() && !this.disableZoomIndicator) {
          this.show();
          this.showZoomIndicator();
        }
        break;
      case '_closing':
        this.hideZoomIndicator();
        this.hide();
        break;
      case '_scrollerModeChanged':
        this.udpateNavigationMode();
        break;
      case 'mozbrowserlocationchange':
        if (!evt.detail.sameDocument) {
          this.resetZoom();
          this.setNavigationMode('spatial');
        }
        break;
      case 'will-shutdown':
      case 'soundManagerShow':
        this.app.toggleSpatialNavigation(false);
        break;
      case 'soundManagerHide':
        this.app.toggleSpatialNavigation(true);
        break;
      case 'optionmenuSelect':
        if (this.app.isPopupWindow()) {
          this.app.handleOptionMenuClick(evt.detail.selected);
        } else if (
          this.app.appChrome && this.app.appChrome.browserWindowNavigator) {
          this.app.appChrome.browserWindowNavigator.handleOptionMenuClick(
            evt.detail.selected);
        }
        break;
      case 'optionmenu-visibility-change':
        if (!evt.detail.open) {
          this.element.classList.remove('enablePointerEvents');
        }
        break;
    }
  };

  BrowserNavigationWidgets.prototype._unregisterEvents = function() {
    this.app.element.removeEventListener('_opened', this);
    this.app.element.removeEventListener('_loaded', this);
    this.app.element.removeEventListener('_closing', this);
    this.app.element.removeEventListener('_scrollerModeChanged', this);
    this.app.browser.element.removeEventListener(
      'mozbrowserlocationchange', this);
    window.removeEventListener('will-shutdown', this);
    window.removeEventListener('soundManagerShow', this);
    window.removeEventListener('soundManagerHide', this);
    this.element.removeEventListener('optionmenuSelect', this);
  };

  BrowserNavigationWidgets.prototype.zoom = function(direction) {
    var oldScale = this.ZOOM_SCALES[this._zoomScaleIndex];
    var scale;
    switch (direction) {
      case 'in':
        this._zoomScaleIndex =
          (this._zoomScaleIndex + 1 < this.ZOOM_SCALES.length) ?
            this._zoomScaleIndex + 1 : this.ZOOM_SCALES.length - 1;
        break;
      case 'out':
        this._zoomScaleIndex = (this._zoomScaleIndex - 1 >= 0) ?
          this._zoomScaleIndex - 1 : 0;
        break;
    }

    scale = this.ZOOM_SCALES[this._zoomScaleIndex];
    if (scale !== oldScale) {
      this._updateZoomScale(scale);
    }
  };

  BrowserNavigationWidgets.prototype.resetZoom = function() {
    if (this._zoomScaleIndex !== this.DEFAULT_ZOOM_SCALE_INDEX) {
      this._zoomScaleIndex = this.DEFAULT_ZOOM_SCALE_INDEX;
      var scale = this.ZOOM_SCALES[this._zoomScaleIndex];
      this._updateZoomScale(scale);
    }
  };

  BrowserNavigationWidgets.prototype._updateZoomScale = function(scale) {
    if (typeof scale === 'number') {
      this.app.zoom(scale);
      // Publish 'zoomchanged' event if we need to update zoom indicator.
    }
  };

  BrowserNavigationWidgets.prototype.setNavigationMode = function(mode) {
    this.debug('setNavigationMode(): mode = ' + mode);
    switch (mode) {
      case 'spatial':
        this.app.toggleScrollNavigation(false);
        break;
      case 'toggle':
        var enabled = !this.app.browser.element.touchPanningSimulationEnabled;
        if (enabled && !document.mozFullScreen) {
          // Only enable scroll mode while browser is not in full screen mode.
          this.app.toggleScrollNavigation(enabled);
        } else if (!enabled) {
          this.app.toggleScrollNavigation(enabled);
        }
        break;
    }
  };

  BrowserNavigationWidgets.prototype.udpateNavigationMode = function() {
    var isScrollMode = this.app.browser.element.touchPanningSimulationEnabled;
    this.debug('udpateNavigationMode(): isScrollMode = ' + isScrollMode);
    // Enable/Disable indicator for scroll mode.
    if (isScrollMode) {
      this.navigationModeIndicator.classList.remove('hidden');
    } else {
      this.navigationModeIndicator.classList.add('hidden');
    }
    // Update indicator icon.
    var dataIcon = isScrollMode ? 'browser-cursor-view' : 'browser-scroller';
    this.navigationModeIcon.setAttribute('data-icon', dataIcon);
  };

  BrowserNavigationWidgets.prototype.scroll = function(direction) {
    switch (direction) {
      case 'top':
        this.app.browser.element.scrollToTop();
        break;
      case 'down':
        this.app.browser.element.scrollToBottom();
        break;
    }
  };

  exports.BrowserNavigationWidgets = BrowserNavigationWidgets;
}(window));
