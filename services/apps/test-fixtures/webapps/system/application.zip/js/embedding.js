/* eslint-disable quotes */
"use strict";
/* global WebEmbedder, applications */

(function(exports) {

  const kPreallocLaunchDelay = 5000; // ms of wait time before launching a new preallocated process.

  function log(msg) {
    console.log(`Embedding: ${msg}`);
  }

  function error(msg) {
    console.error(`Embedding: ${msg}`);
  }

  const windowProvider = {
    openURI: function(aURI, aOpener, aWhere, aFlags, aTriggeringPrincipal, aCsp) {
      log(`browserWindow::openURI ${aURI.spec}`);
      throw "NOT IMPLEMENTED 1";
    },

    createContentWindow: function(aURI, aOpener, aWhere, aFlags, aTriggeringPrincipal, aCsp) {
      log(`browserWindow::createContentWindow ${aURI.spec}`);
      throw "NOT IMPLEMENTED 2";
    },

    openURIInFrame: function(aURI, aParams, aWhere, aFlags, aNextRemoteTabId, aName) {
      // We currently ignore aNextRemoteTabId on mobile.  This needs to change
      // when Fennec starts to support e10s.  Assertions will fire if this code
      // isn't fixed by then.
      //
      // We also ignore aName if it is set, as it is currently only used on the
      // e10s codepath.
      log(`browserWindow::openURIInFrame ${aURI.spec} ${aParams} ${aWhere} ${aFlags} ${aName}`);

      // Need to return the new WebView here.
      return null;
    },

    // Called to open a window for window.open(url, "_blank")
    createContentWindowInFrame: function(aURI, aParams, aWhere, aFlags, aNextRemoteTabId, aName) {
      let url = aURI.spec;
      log(`browserWindow::createContentWindowInFrame ${url} ${aParams.features}`);

      // Launching an app, mocking the way it is done in gecko48 for now.
      if (aParams.features === "kind=app") {
        let app = applications.getByManifestURL(url);
        if (!app) {
          console.error(`No application found for manifest url ${url}`);
          return null;
        }

        let start_url = `${app.origin}${(app.manifest && app.manifest.launch_path) || "/index.html"}`;
        let payload = {
          timestamp: Date.now(),
          url: start_url,
          manifestURL: url
        };
        window.dispatchEvent(new CustomEvent("webapps-launch", { detail: payload }));

        // Hack to find the newly created WebView: iterate over web views and find the one with
        // the `src` attribute set to our start_url
        let web_views = document.querySelectorAll("web-view");
        for (let web_view of web_views) {
          if (web_view.src == start_url) {
            console.log(`Found new <web-view> frame=${web_view.frame}`);
            return web_view;
          }
        }
      }

      // Need to return the new WebView here.
      console.warn(`No window created!!`);
      return null;
    },

    isTabContentWindow: function(aWindow) {
      log(`browserWindow::isTabContentWindow`);
      return false;
    },

    canClose() {
      log(`browserWindow::canClose`);
      return true;
    },
  };

  const processSelector = {
    NEW_PROCESS: -1,

    provideProcess: function(aType, aOpener, aProcesses, aMaxCount) {
      log(`provideProcess ${JSON.stringify(aProcesses)} (max=${aMaxCount})`);

      // If we find an existing process with no tab, use it.
      for (let i = 0; i < aProcesses.length; i++) {
        if (aProcesses[i].tabCount == 0) {
          log(`Re-using process #${i}`);
          // If we re-use a preallocated process, spawn a new one.
          window.setTimeout(() => {
            embedder.launch_preallocated_process();
          }, kPreallocLaunchDelay);
          return i;
        }
      }

      // Fallback to creating a new process.
      return processSelector.NEW_PROCESS;
    },
  };

  const embedder = new WebEmbedder({
    window_provider: windowProvider,
    process_selector: processSelector
  });
  embedder.addEventListener("runtime-ready", e => {
    log(`Embedder event: ${e.type}`);
    embedder.launch_preallocated_process();
  });
}(window));
