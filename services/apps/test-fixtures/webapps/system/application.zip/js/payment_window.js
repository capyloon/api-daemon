/* global AttentionWindow, Service */
'use strict';

(function(exports) {
  /**
   * PaymentWindow is a special case of attention window.
   * It's the call screen UI but lives in system app.
   *
   * @example
   * var attention = new PaymentWindow();
   *
   * @class PaymentWindow
   * @requires System
   * @extends AttentionWindow
   */
  /**
   * Fired when the attention window is created.
   * @event AttentionWindow#attentioncreated
   */
  /**
   * Fired when the attention window is removed.
   * @event AttentionWindow#attentionterminated
   */
  /**
   * Fired when the attention window is opening.
   * @event AttentionWindow#attentionopening
   */
  /**
   * Fired when the attention window is opened.
   * @event AttentionWindow#attentionopened
   */
  /**
   * Fired when the attention window is closing.
   * @event AttentionWindow#attentionclosing
   */
  /**
   * Fired when the attention window is closed.
   * @event AttentionWindow#attentionclosed
   */
  /**
   * Fired before the attention window is rendered.
   * @event AttentionWindow#attentionwillrender
   */
  /**
   * Fired when the attention window is rendered to the DOM tree.
   * @event AttentionWindow#attentionrendered
   */
  var ORIGIN = 'app://kaios-pay.kaiostech.com/';
  var PaymentWindow = function PaymentWindow(config) {
    this.config = {
      manifestURL: ORIGIN + 'manifest.webapp',
      url: ORIGIN + 'index.html',
      origin: ORIGIN
    };
    if (config && config.manifestURL) {
      this.config.manifestURL = config.manifestURL;
    }
    this.isPaymentWindow = true;
    this.reConfig(this.config);
    this.render();
    this.publish('created');
  };

  PaymentWindow.prototype = Object.create(ActivityWindow.prototype);
  PaymentWindow.prototype.constructor = PaymentWindow;
  /**
   * Turn on this flag to dump debugging messages for all attention windows.
   * @type {Boolean}
   */ 
  PaymentWindow.prototype.CLASS_LIST =
    'appWindow activityWindow paymentWindow transparent-background inline-activity';
  PaymentWindow.prototype.CLASS_NAME = 'paymentWindow';

  PaymentWindow.prototype.containerElement = document.getElementById('payment-root');

  PaymentWindow.SUB_COMPONENTS = {
    'transitionController': window.AppTransitionController,
    'childWindowFactory': window.ChildWindowFactory
  };

  PaymentWindow.REGISTERED_EVENTS =
    ActivityWindow.REGISTERED_EVENTS;

  PaymentWindow.prototype.eventPrefix = 'payment';
  PaymentWindow.prototype.HIERARCHY_MANAGER = 'PaymentManager';
  PaymentWindow.prototype._DEBUG = false;

  PaymentWindow.prototype.render = function cw_render() {
    this.publish('willrender');
    this.containerElement.insertAdjacentHTML('beforeend', this.view());

    this.element =
      document.getElementById(this.instanceID);
    // XXX: don't hardcode but use manifest config.
    this.element.classList.add('statusbar-overlapped');
    // XXX: Use BrowserFrame
    var iframe = document.createElement('iframe');
    iframe.setAttribute('name', 'payment');
    iframe.setAttribute('mozbrowser', 'true');
    iframe.setAttribute('remote', 'false');
    iframe.setAttribute('mozapp', this.config.manifestURL);
    iframe.src = this.config.url;
    this.browser = {
      element: iframe
    };
    this.browserContainer = this.element.querySelector('.browser-container');
    this.browserContainer.insertBefore(this.browser.element, null);
    this.frame = this.element;
    this.iframe = this.browser.element;
    this.screenshotOverlay = this.element.querySelector('.screenshot-overlay');

    this._registerEvents();
    this.installSubComponents();
    this.publish('rendered');
  };

  PaymentWindow.prototype._handle_mozbrowserlocationchange = function() {
    this.publish('locationchange');
  };

  PaymentWindow.prototype.ensure = function() {
    if (!this.element) {
      this.render();
      this._killed = false;
      return;
    }
    this._terminated = false;
    this.show();
  };

  PaymentWindow.prototype.closeWindow = function() {
    if (this._terminated) {
      return;
    }
    this._terminated = true;
    this.publish('terminated');
    if (this.isActive()) {
      var self = this;
      this.element.addEventListener('_closed', function onclosed() {
        self.element.removeEventListener('_closed', onclosed);
        self.hide();
      });
      this.requestClose();
    } else {
      this.hide();
    }
    // XXX: We are leaving the focus in the callscreen iframe
    if (document.activeElement === this.browser.element) {
      document.activeElement.blur();
    }
  };

  PaymentWindow.prototype._handle_mozbrowseractivitydone = function() {
    this.close();
  };

  PaymentWindow.prototype.reloadWindow = function() {
    var src = this.browser.element.src.split('#')[0];
    this.browser.element.src = ''; // cocotte
    setTimeout(function nextTick() {
      this.browser.element.src = src;
    }.bind(this));
    this.setVisible(false);
  };

  PaymentWindow.prototype.free = function() {
    if (this.browser.element) {
      this.browser.element.src = '';
    }
  };

  exports.PaymentWindow = PaymentWindow;

}(window));
