/* -*- Mode: Java; tab-width: 2; indent-tabs-mode: nil; c-basic-offset: 2 -*- /
/* vim: set shiftwidth=2 tabstop=2 autoindent cindent expandtab: */

'use strict';

var Wifi = {
  name: 'Wifi',
  wifiEnabled: true,

  OPEN_NETWORK_TAG: 'open-network-notification',
  NO_INTERNET_TAG: 'no-internet-notification',

  closeWifiNotificationByTag: function(tag) {
    return Notification.get().then((notifications) => {
      notifications.forEach((notification) => {
        if (!notification) {
          return;
        }

        // We cannot search for 'tag=voicemailNotification:*'
        // so we do it by ourselves.
        // Bail out if the notification does not match our tag.
        if (!notification.tag || !notification.tag.startsWith(tag)) {
          return;
        }

        // Let's remove voicemail notification.
        notification.close();
      });
      return Promise.resolve();
    });
  },

  showNoInternetNotification: function(network) {
    if (this.noInternetNotification) {
      this.noInternetNotification.close();
      this.noInternetNotification = null;
    }
    var _ = navigator.mozL10n.get;
    var title = _('wifi-no-internet-title');
    var body = _('wifi-no-internet-body');

    this.noInternetNotification = new window.Notification(title, {
      body: body,
      tag: this.NO_INTERNET_TAG,
      data: {
        icon: 'wifi-32px'
      },
      mozbehavior: {
        showOnlyOnce: true
      }
    });

    this.noInternetNotification.onclick = () => {
      var _ = navigator.mozL10n.get;
      var header = _('wifi-no-internet-header');
      var content = _('wifi-no-internet-content', {
        'name': network.ssid
      });
      if (this.noInternetNotification) {
        this.noInternetNotification.close();
        this.noInternetNotification = null;
      }
      const id = 'no-internet-dialog';
      const config = {
        id,
        title: header,
        message: content,
        primarybtntext: _('yes'),
        secondarybtntext: _('no'),
        onDialogPrimaryBtnClick: () => {
          Service.request('DialogService:hide', id);
        },
        onDialogSecondaryBtnClick: () => {
          window.navigator.mozWifiManager.forget(network);
          Service.request('DialogService:hide', id);
        },
      };
      Service.request('DialogService:show', config);
    };
  },

  init: function wf_init() {
    if (!window.navigator.mozSettings) {
      return;
    }

    if (!window.navigator.mozWifiManager) {
      let key = 'wifi.enabled';
      let req = navigator.mozSettings.createLock().get(key);
      req.onsuccess = function() {
        if (req.result[key]) {
          SettingsListener.getSettingsLock().set({
            'wifi.enabled': false
          });
        }
      };
      return;
    }

    var self = this;
    var wifiManager = window.navigator.mozWifiManager;
    // when wifi is really enabled, emit event to notify QuickSettings
    wifiManager.onenabled = function onWifiEnabled() {
      var evt = document.createEvent('CustomEvent');
      evt.initCustomEvent('wifi-enabled',
        /* canBubble */ true, /* cancelable */ false, null);
      window.dispatchEvent(evt);
    };

    // when wifi is really disabled, emit event to notify QuickSettings
    wifiManager.ondisabled = function onWifiDisabled() {
      var evt = document.createEvent('CustomEvent');
      evt.initCustomEvent('wifi-disabled',
        /* canBubble */ true, /* cancelable */ false, null);
      window.dispatchEvent(evt);
    };

    // when wifi status change, emit event to notify StatusBar/UpdateManager
    wifiManager.onstatuschange = function onWifiStatusChange(event) {
      var evt = document.createEvent('CustomEvent');
      evt.initCustomEvent('wifi-statuschange',
        /* canBubble */ true, /* cancelable */ false, null);
      window.dispatchEvent(evt);
      if (event.status === 'disconnected') {
        if (self.noInternetNotification) {
          self.noInternetNotification.close();
          self.noInternetNotification = null;
        }
      }
    };

    wifiManager.onstationinfoupdate = (event) => {
      this.connectedClients = event.station;
      var evt = document.createEvent('CustomEvent');
      evt.initCustomEvent('wifi-stationchange',
        /* canBubble */ true, /* cancelable */ false, null);
      window.dispatchEvent(evt);
    };

    this.closeWifiNotificationByTag(this.OPEN_NETWORK_TAG).then(() => {
      wifiManager.onopennetwork = (e) => {
        if (e.availability) {
          if (this.openNetworkNotifyEnabled) {
            this.showOpenNetworkNotification();
          }
        } else {
          if (this.notification) {
            this.notification.close();
            this.notification = null;
          }
        }
      };
    });

    this.closeWifiNotificationByTag(this.NO_INTERNET_TAG).then(() => {
      wifiManager.onwifihasinternet = (e) => {
        if (!e.hasInternet) {
          this.showNoInternetNotification(e.network);
        } else {
          if (this.noInternetNotification) {
            this.noInternetNotification.close();
            this.noInternetNotification = null;
          }
        }
      };
    });

    // Track the wifi.enabled mozSettings value
    SettingsListener.observe('wifi.enabled', true, function(value) {
      if (!wifiManager && value) {
        self.wifiEnabled = false;

        // roll back the setting value to notify the UIs
        // that wifi interface is not available
        if (value) {
          SettingsListener.getSettingsLock().set({
            'wifi.enabled': false
          });
        }

        return;
      }

      self.wifiEnabled = value;
    });

    Service.register('closeWifiNotificationByTag', this);
    Service.registerState('connectedClients', this);
    window.Service.request('addObserver', 'wifi.notification', this);
  },

  showOpenNetworkNotification: function() {
    let notifOptions = {
      body: navigator.mozL10n.get('open-wifi-available'),
      icon: window.location.protocol + '//' + window.location.hostname + '/style/icons/captivePortal.png',
      tag: this.OPEN_NETWORK_TAG,
      mozbehavior: {
        showOnlyOnce: true
      }
    };

    this.notification = new Notification(navigator.mozL10n.get('wifi-available'), notifOptions);
    this.notification.addEventListener('click', () => {
      new window.MozActivity({
        name: 'configure',
        data: {
          target: 'device',
          section: 'wifi-available-networks'
        }
      });
    });
  },

  observe: function(key, value) {
    if (value) {
      this.openNetworkNotifyEnabled = true;
      if (window.navigator.mozWifiManager.openNetworkNotify) {
        this.showOpenNetworkNotification();
      }
    } else {
      this.openNetworkNotifyEnabled = false;
    }
  }
};

Wifi.init();
