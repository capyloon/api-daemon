/* global BookmarksDatabase, BaseUI */
/* global eventSafety */
/* global IconsHelper */
/* global LazyLoader */
/* global BrowserWindowNavigator */

'use strict';

(function(exports) {
  var _id = 0;

  /**
   * The chrome UI of the AppWindow.
   *
   * @class AppChrome
   * @param {AppWindow} app The app window instance this chrome belongs to.
   * @extends BaseUI
   */
  var AppChrome = function AppChrome(app) {
    this.app = app;
    this.instanceID = _id++;
    this.containerElement = app.element;
    this._recentTitle = false;
    this._titleTimeout = null;
    this.scrollable = app.browserContainer;
    this.render();

    if (this.app.themeColor) {
      this.setThemeColor(this.app.themeColor);
    }

    var chrome = this.app.config.chrome;
    if (!this.app.isBrowser() && chrome && !chrome.scrollable) {
      this._fixedTitle = true;
      this.title.dataset.l10nId = 'search-the-web';
    } else if (!this.app.isBrowser() && this.app.name) {
      this._gotName = true;
      this.setFreshTitle(this.app.name);
    }

    this.reConfig();
  };

  AppChrome.prototype = Object.create(window.BaseUI.prototype);

  AppChrome.prototype.CLASS_NAME = 'AppChrome';

  AppChrome.prototype.EVENT_PREFIX = 'chrome';

  AppChrome.prototype.FRESH_TITLE = 500;

  AppChrome.prototype.LOCATION_COALESCE = 250;

  AppChrome.prototype._DEBUG = false;

  AppChrome.prototype.destroy = function() {
    if (this.browserWindowNavigator) {
      this.browserWindowNavigator.destroy();
      this.browserWindowNavigator = undefined;
    }
    BaseUI.prototype.destroy.call(this);
  };

  AppChrome.prototype.reConfig = function() {
    var chrome = this.app.config.chrome;
    if (!chrome) {
      return;
    }

    if (this.isSearchApp()) {
      this.app.element.classList.add('search-app');
      this.title.setAttribute('data-l10n-id', 'search-or-type-url');
    } else {
      this.app.element.classList.remove('search-app');
    }

    if (chrome.bar) {
      this.app.element.classList.add('bar');
      this.bar.classList.add('visible');  // visible for browser window
    }

    if (chrome.scrollable) {
      this.app.element.classList.add('collapsible');
      this.scrollable.scrollgrab = true;
    }

    if (chrome.maximized) {
      this.element.classList.add('maximized');

      if (!this.app.isBrowser()) {
        this.app.element.classList.add('scrollable');
      }
    }

    if (!this.app.isPopupWindow() &&
        (this.app.isBrowserOrSearch() || this.app.isCursorEnabled())) {
      if (this.browserWindowNavigator) {
        this.browserWindowNavigator.destroy();
      }
      this.browserWindowNavigator = new BrowserWindowNavigator(this);
    }
  };

  AppChrome.prototype.combinedView = function an_combinedView() {
    var className = this.CLASS_NAME + this.instanceID;

    return `<div class="chrome chrome-combined" id="${className}">
              <div class="controls">
                <div class="urlbar js-chrome-ssl-information">
                  <div class="chrome-ssl-indicator chrome-title-container">
                    <span data-icon="lock" class="hide"></span>
                    <span class="title" dir="auto"></span>
                    <div class="reload-stop-button"></div>
                  </div>
                  <div class="chrome-progress">
                    <div class="indicator-indeterminate"></div>
                  </div>
                </div>
                <div class="add-to-collection-button" data-icon="browser-add"></div>
                <div class="option-menu-button" data-icon="menu"></div>
              </div>
              <div class="tool-bar">
                <div class="tool-bar-button home" data-icon="browser-home"></div>
                <div class="tool-bar-button collection" data-icon="browser-collection"></div>
                <div class="tool-bar-button tab">
                  <div data-icon="check-off"></div>
                  <div class="tab-counter">0</div>
                </div>
              </div>
            </div>`;
  };

  AppChrome.prototype.view = function an_view() {
    var className = this.CLASS_NAME + this.instanceID;

    return `<div class="chrome chrome-plain" id="${className}">
              <div role="region" class="bar">
                <div class="cancel-button" data-icon="cancel"></div>
                <div class='js-chrome-ssl-information'>
                  <div class="chrome-title-container">
                    <div class="chrome-ssl-indicator">
                      <span data-icon="lock" class="hide"></span>
                    </div>
                    <bdi dir="auto" class="title"></bdi>
                    <div class="reload-stop-button"></div>
                  </div>
                  <div class="chrome-progress">
                    <div class="indicator-indeterminate"></div>
                  </div>
                </div>
                <div class="option-menu-button" data-icon="menu"></div>
              </div>
            </div>`;
  };

  AppChrome.prototype.__defineGetter__('height', function ac_getHeight() {
    if (this._height) {
      return this._height;
    }

    this._height = this.element.getBoundingClientRect().height;
    return this._height;
  });

  AppChrome.prototype._fetchElements = function ac__fetchElements() {
    this.element = this.containerElement.querySelector('.chrome');

    this.progress = this.element.querySelector('.chrome-progress');
    this.reloadStopButton = this.element.querySelector('.reload-stop-button');
    // this.forwardButton = this.element.querySelector('.forward-button');
    // this.backButton = this.element.querySelector('.back-button');
    this.addToCollectionButton = this.element.querySelector('.add-to-collection-button');
    this.optionMenuButton = this.element.querySelector('.option-menu-button');
    this.title = this.element.querySelector('.chrome-title-container > .title');
    this.sslIndicator =
      this.element.querySelector('.js-chrome-ssl-information');

    this.sslDataIcon =
      this.element.querySelector('.js-chrome-ssl-information  > span[data-icon]');

    this.bar = this.element.querySelector('.bar');
    if (this.bar) {
      // popup window has cancel button
      this.cancelButton = this.element.querySelector('.cancel-button');
    } else {
      // Compute toolbar top offset since its container cannot be
      // hover on browser content element.
      this.toolbar = this.element.querySelector('.tool-bar');
      this.toolbar.style.top =
        this.app.element.clientHeight - this.toolbar.clientHeight + 'px';
      this.toolbarHomeButton = this.element.querySelector('.tool-bar > .home');
      this.toolbarCollectionButton = this.element.querySelector('.tool-bar > .collection');
      this.toolbarTabButton = this.element.querySelector('.tool-bar > .tab');
      this.tabCounter = this.element.querySelector('.tab-counter');
    }

    if (this.app && this.app.loading) {
      this.updateReloadStopButton('loading');
    } else {
      this.updateReloadStopButton();
    }
  };

  AppChrome.prototype.handleEvent = function ac_handleEvent(evt) {
    switch (evt.type) {
      case 'rocketbar-overlayclosed':
        this.collapse();
        break;

      case 'click':
        this.handleClickEvent(evt);
        break;

      case 'scroll':
        this.handleScrollEvent(evt);
        break;

      case '_loading':
        let currentURL =
          (evt.detail && evt.detail.url) ? evt.detail.url : this._currentURL;
        this.updateLoadingLocation(currentURL);
        this.updateReloadStopButton('loading');
        break;

      case '_loaded':
        this.updateReloadStopButton();
        break;

      case 'mozbrowserloadstart':
        this.handleLoadStart(evt);
        this.updateTabCount();
        break;

      case 'mozbrowserloadend':
        this.handleLoadEnd(evt);
        break;

      case 'mozbrowsererror':
        this.handleError(evt);
        break;

      case 'mozbrowserlocationchange':
        this.handleLocationChanged(evt);
        break;

      case 'mozbrowserscrollareachanged':
        this.handleScrollAreaChanged(evt);
        break;

      case '_securitychange':
        this.handleSecurityChanged(evt);
        break;

      case 'mozbrowsertitlechange':
        this.handleTitleChanged(evt);
        break;

      case 'mozbrowsermetachange':
        this.handleMetaChange(evt);
        break;

      case '_namechanged':
        this.handleNameChanged(evt);
        break;
    }
  };

  AppChrome.prototype.handleClickEvent = function(evt) {
    switch (evt.target) {
      case this.reloadStopButton:
        let action = this.reloadStopButton.dataset.action;
        this.app[action]();
        break;

      case this.backButton:
        this.app.back();
        break;

      case this.forwardButton:
        this.app.forward();
        break;

      case this.title:
        this.titleClicked();
        break;

      case this.addToCollectionButton:
        // original button is menu button
        this.showOverflowMenu();
        break;

      case this.optionMenuButton:
        // handle popup window first since it is belong to browser
        if (this.app.isPopupWindow()) {
          this.app.showOptionMenu()
        } else if (this.app.isBrowser()) {
          if (this.browserWindowNavigator) {
            this.browserWindowNavigator.showOptionMenu('browser');
          }
        } else if (this.isSearchApp()) {
          // TODO: display option menu according to search app state..
        }
        break;

      case this.toolbarHomeButton:
        if (this.browserWindowNavigator) {
          this.browserWindowNavigator.goToBrowserTop('home');
        }
        break;

      case this.toolbarCollectionButton:
        if (this.browserWindowNavigator) {
          this.browserWindowNavigator.goToBrowserTop('collection');
        }
        break;

      case this.toolbarTabButton:
        if (this.browserWindowNavigator) {
          this.browserWindowNavigator.goToBrowserTop('tab');
        }
        break;

      case this.cancelButton:
        if (!this.app.isHomescreen) {
          this.app.kill();
        }
        break;
    }
  };

  AppChrome.prototype.titleClicked = function ac_titleClicked() {
    window.dispatchEvent(new CustomEvent('global-search-request'));
  };

  AppChrome.prototype.handleKey = function(key) {
    let isPopupWindow = this.app.getTopMostWindow().isPopupWindow();
    if (isPopupWindow) {
      return this.app.getTopMostWindow().handleKey(key);
    } else if (this.app.isBrowserOrSearch() || this.app.isCursorEnabled()) {
      return this.browserWindowNavigator.handleKey(key);
    }
    return false;
  };

  AppChrome.prototype.handleScrollEvent = function ac_handleScrollEvent() {
    if (!this.containerElement.classList.contains('scrollable')) {
      return;
    }

    // Ideally we'd animate based on scroll position, but until we have
    // the necessary spec and implementation, we'll animate completely to
    // the expanded or collapsed state depending on whether it's at the
    // top or not.
    // XXX Open a bug since I wonder if there is scrollgrab rounding issue
    // somewhere. While panning from the bottom to the top, there is often
    // a scrollTop position of scrollTopMax - 1, which triggers the transition!
    var element = this.element;
    if (this.scrollable.scrollTop >= this.scrollable.scrollTopMax - 1) {
      element.classList.remove('maximized');
    } else {
      element.classList.add('maximized');
    }

    if (this.app.isActive()) {
      this.app.publish('titlestatechanged');
    }
  };

  AppChrome.prototype._registerEvents = function ac__registerEvents() {
    if (this.useCombinedChrome()) {
      LazyLoader.load('https://gaia.local/shared/js/bookmarks_database.js');
      this.reloadStopButton.addEventListener('click', this);
      this.addToCollectionButton.addEventListener('click', this);
      this.optionMenuButton.addEventListener('click', this);
      this.toolbar.addEventListener('click', this);
      // this.backButton.addEventListener('click', this);
      // this.forwardButton.addEventListener('click', this);
      this.title.addEventListener('click', this);
      this.scrollable.addEventListener('scroll', this);
    } else {
      this.cancelButton.addEventListener('click', this);
      this.reloadStopButton.addEventListener('click', this);
      this.optionMenuButton.addEventListener('click', this);
    }

    this.app.element.addEventListener('mozbrowserloadstart', this);
    this.app.element.addEventListener('mozbrowserloadend', this);
    this.app.element.addEventListener('mozbrowsererror', this);
    this.app.element.addEventListener('mozbrowserlocationchange', this);
    this.app.element.addEventListener('mozbrowsertitlechange', this);
    this.app.element.addEventListener('mozbrowsermetachange', this);
    this.app.element.addEventListener('mozbrowserscrollareachanged', this);
    this.app.element.addEventListener('_securitychange', this);
    this.app.element.addEventListener('_loading', this);
    this.app.element.addEventListener('_loaded', this);
    this.app.element.addEventListener('_namechanged', this);

    var element = this.element;

    var animEnd = function(evt) {
      if (evt && evt.target !== element) {
        return;
      }
      var publishEvent = this.isMaximized() ? 'expanded' : 'collapsed';
      this.app.publish('chrome' + publishEvent);
    }.bind(this);

    element.addEventListener('transitionend', animEnd);
  };

  AppChrome.prototype._unregisterEvents = function ac__unregisterEvents() {

    if (this.useCombinedChrome()) {
      this.reloadStopButton.removeEventListener('click', this);
      this.addToCollectionButton.removeEventListener('click', this);
      this.optionMenuButton.removeEventListener('click', this);
      this.toolbar.removeEventListener('click', this);
      this.title.addEventListener('click', this);
      this.scrollable.removeEventListener('scroll', this);
    } else {
      this.cancelButton.removeEventListener('click', this);
      this.reloadStopButton.removeEventListener('click', this);
      this.optionMenuButton.removeEventListener('click', this);
    }

    if (!this.app) {
      return;
    }

    this.app.element.removeEventListener('mozbrowserloadstart', this);
    this.app.element.removeEventListener('mozbrowserloadend', this);
    this.app.element.removeEventListener('mozbrowsererror', this);
    this.app.element.removeEventListener('mozbrowserlocationchange', this);
    this.app.element.removeEventListener('mozbrowsertitlechange', this);
    this.app.element.removeEventListener('mozbrowsermetachange', this);
    this.app.element.removeEventListener('mozbrowserscrollareachanged', this);
    this.app.element.removeEventListener('_securitychange', this);
    this.app.element.removeEventListener('_loading', this);
    this.app.element.removeEventListener('_loaded', this);
    this.app.element.removeEventListener('_namechanged', this);

    this.app = null;
  };

  // Name has priority over the rest
  AppChrome.prototype.handleNameChanged =
    function ac_handleNameChanged() {
      this._title = this.app.name;
      this._gotName = true;
    };

  AppChrome.prototype.setFreshTitle = function ac_setFreshTitle(title) {
    if (this.isSearchApp()) {
      return;
    }
    // Update title changed immediately.
    this._title = this.title.textContent = title;
    clearTimeout(this._titleTimeout);
    this._recentTitle = true;
    this._titleTimeout = setTimeout((function() {
      this._recentTitle = false;
    }).bind(this), this.FRESH_TITLE);
  };

  AppChrome.prototype.handleScrollAreaChanged = function(evt) {
    // Check if the page has become scrollable and add the scrollable class.
    // We don't check if a page has stopped being scrollable to avoid oddness
    // with a page oscillating between scrollable/non-scrollable states, and
    // other similar issues that Firefox for Android is still dealing with
    // today.
    if (this.containerElement.classList.contains('scrollable')) {
      return;
    }

    // We allow the bar to collapse if the page is greater than or equal to
    // the area of the window with a collapsed bar. Strictly speaking, we'd
    // allow it to collapse if it was greater than the area of the window with
    // the expanded bar, but due to prevalent use of -webkit-box-sizing and
    // plain mistakes, this causes too many false-positives.
    if (evt.detail.height >= this.containerElement.clientHeight) {
      this.containerElement.classList.add('scrollable');
    }
  };

  AppChrome.prototype.handleSecurityChanged = function() {
    if (!this.sslIndicator) {
      return;
    }

    var sslState = this.app.getSSLState();
    this.sslIndicator.dataset.ssl = sslState;
    this.sslIndicator.classList.toggle(
      'chrome-has-ssl-indicator', sslState === 'broken' || sslState === 'secure'
    );

    if (!this.sslDataIcon) {
      return;
    }

    if (sslState === 'broken') {
      this.sslDataIcon.setAttribute('data-icon', 'lock-broken');
    } else if (sslState === 'secure') {
      this.sslDataIcon.setAttribute('data-icon', 'lock');
    } else {
      this.sslDataIcon.setAttribute('data-icon', '');
    }
  };

  AppChrome.prototype.handleTitleChanged = function(evt) {
    if (this._gotName || this._fixedTitle) {
      return;
    }

    this.setFreshTitle(evt.detail || this._currentURL);
    this._titleChanged = true;
  };

  AppChrome.prototype.handleMetaChange =
    function ac__handleMetaChange(evt) {
      var detail = evt.detail;
      if (detail.name !== 'theme-color' || !detail.type) {
        return;
      }

      // If the theme-color meta is removed, let's reset the color.
      var color = '';

      // Otherwise, set it to the color that has been asked.
      if (detail.type !== 'removed') {
        color = detail.content;
      }

      this.setThemeColor(color);
    };

  AppChrome.prototype.setThemeColor = function ac_setThemColor(color) {
    // Do not set theme color for browser windows.
    if (this.app.isBrowser()) {
      return;
    }

    var bottomApp = this.app.getBottomMostWindow();

    if (this.app.CLASS_NAME === 'PopupWindow' &&
      bottomApp &&
      bottomApp.themeColor) {
      color = bottomApp.themeColor;
    }

    this.app.themeColor = color;
    this.element.style.backgroundColor = color;

    if (!this.app.isHomescreen) {
      this.scrollable.style.backgroundColor = color;
    }

    if (color === 'transparent' || color === '') {
      this.app.element.classList.remove('light');
      this.app.publish('titlestatechanged');
      return;
    }

    // Apply style for hosted app progress bar.
    if (this.app.isHostedApp()) {
      this.app.element.classList.add('hosted');
      if (this.app.isProgressBarEnabled()) {
        this.element.classList.add('progress-bar-enabled');
      }
    }

    var self = this;
    var finishedFade = false;
    var endBackgroundFade = (evt) => {
      if (evt && evt.propertyName != 'background-color') {
        return;
      }
      finishedFade = true;
      if (this.element) { // element of search app will be killed
        this.element.removeEventListener('transitionend', endBackgroundFade);
      }
    };
    eventSafety(this.element, 'transitionend', endBackgroundFade, 1000);

    window.requestAnimationFrame(function updateAppColor() {
      if (finishedFade || !self.element) {
        return;
      }
      var computedColor = self.app.themeColor;
      var colorCodes = /rgb\((\d+), (\d+), (\d+)\)/.exec(computedColor);
      if (!colorCodes || colorCodes.length === 0) {
        return;
      }

      var r = parseInt(colorCodes[1]);
      var g = parseInt(colorCodes[2]);
      var b = parseInt(colorCodes[3]);
      var brightness =
        Math.sqrt((r*r) * 0.241 + (g*g) * 0.691 + (b*b) * 0.068);

      var wasLight = self.app.element.classList.contains('light');
      var isLight  = brightness > 200;
      if (wasLight != isLight) {
        self.app.element.classList.toggle('light', isLight);
        self.app.publish('titlestatechanged');
      }
      window.requestAnimationFrame(updateAppColor);
    });
  };

  AppChrome.prototype.render = function() {
    this.publish('willrender');

    var view = this.useCombinedChrome() ? this.combinedView() : this.view();
    this.app.element.insertAdjacentHTML('afterbegin', view);

    this._fetchElements();
    this._registerEvents();
    this.publish('rendered');
  };

  AppChrome.prototype.useLightTheming = function ac_useLightTheming() {
    // The rear window should dictate the status bar color when the front
    // window is a popup.
    if (this.app.CLASS_NAME == 'PopupWindow' &&
        this.app.rearWindow &&
        this.app.rearWindow.appChrome) {
      return this.app.rearWindow.appChrome.useLightTheming();
    }
    // All other cases can use the front window.
    return this.app.element.classList.contains('light');
  };

  AppChrome.prototype.useCombinedChrome = function ac_useCombinedChrome(evt) {
    return this.app.config.chrome && !this.app.config.chrome.bar;
  };

  AppChrome.prototype._updateLocation =
    function ac_updateTitle(title) {
      if (this._titleChanged || this._gotName || this._recentTitle ||
          this._fixedTitle) {
        return;
      }
      this._title = title;
      this.updateLoadingLocation(title);
    };

  AppChrome.prototype.handleLocationChanged =
    function ac_handleLocationChange(evt) {
      if (!this.app) {
        return;
      }

      // Check if this is just a location-change to an anchor tag.
      var anchorChange = false;
      if (this._currentURL && evt.detail.url) {
        anchorChange =
          this._currentURL.replace(/#.*/g, '') ===
          evt.detail.url.replace(/#.*/g, '');
      }

      // We wait a small while because if we get a title/name it's even better
      // and we don't want the label to flash
      setTimeout(this._updateLocation.bind(this, evt.detail.url),
        this.LOCATION_COALESCE);
      this._currentURL = evt.detail.url;

      if (this.backButton && this.forwardButton) {
        this.app.canGoForward(function forwardSuccess(result) {
          if (!this.hasNavigation()) {
            return;
          }
          this.forwardButton.disabled = !result;
        }.bind(this));

        this.app.canGoBack(function backSuccess(result) {
          if (!this.hasNavigation()) {
            return;
          }
          this.backButton.disabled = !result;
        }.bind(this));
      }

      if (!this.app.isBrowser()) {
        return;
      }

      // We havent got a name for this location
      this._gotName = false;

      if (!anchorChange) {
        // Make the rocketbar unscrollable until the page resizes to the
        // appropriate height.
        this.containerElement.classList.remove('scrollable');

        // Expand
        if (!this.isMaximized()) {
          this.element.classList.add('maximized');
        }
        this.scrollable.scrollTop = 0;
      }
    };

  AppChrome.prototype.updateLoadingLocation = function(url) {
    if (url && this.app && this.app.loading) {
      this.title.textContent = url;
    }
  };

  AppChrome.prototype.updateReloadStopButton = function(state) {
    if (!this.hasNavigation()) {
      return;
    }

    if (state === 'loading') {
      this.reloadStopButton.setAttribute('data-icon', 'input-clear');
      this.reloadStopButton.dataset.action = 'stop';
      this.progress.classList.add('loading');
    } else {
      this.reloadStopButton.setAttribute('data-icon', 'browser-refresh');
      this.reloadStopButton.dataset.action = 'reload';
      this.progress.classList.remove('loading');
    }
  };

  AppChrome.prototype.updateTabCount = function() {
    browserSitesDataStore.getSiteLength('tab').then((length) => {
      this.tabCounter.innerHTML = length;
    });
  }

  AppChrome.prototype.handleLoadStart = function ac_handleLoadStart() {
    this.containerElement.classList.add('loading');
    this._titleChanged = false;
  };

  AppChrome.prototype.handleLoadEnd = function ac_handleLoadEnd() {
    this.containerElement.classList.remove('loading');
  };

  AppChrome.prototype.handleError = function ac_handleError(evt) {
    if (evt.detail && evt.detail.type === 'fatal') {
      return;
    }
    if (this.useCombinedChrome() && this.app.config.chrome.scrollable) {
      // When we get an error, keep the rocketbar maximized.
      this.element.classList.add('maximized');
      this.containerElement.classList.remove('scrollable');
    }
  };

  AppChrome.prototype.maximize = function ac_maximize(callback) {
    var element = this.element;
    element.classList.add('maximized');
    window.addEventListener('rocketbar-overlayclosed', this);

    if (!callback) {
      return;
    }
    eventSafety(element, 'transitionend', callback, 250);
  };

  AppChrome.prototype.collapse = function ac_collapse() {
    window.removeEventListener('rocketbar-overlayclosed', this);
    this.element.classList.remove('maximized');
  };

  AppChrome.prototype.isMaximized = function ac_isMaximized() {
    return this.element.classList.contains('maximized');
  };

  AppChrome.prototype.isSearch = function ac_isSearch() {
    var dataset = this.app.config;
    return dataset.searchURL && this._currentURL === dataset.searchURL;
  };

  AppChrome.prototype.isSearchApp = function() {
    return this.app.config.manifest &&
      this.app.config.manifest.role === 'search';
  };

  AppChrome.prototype.hasNavigation = function ac_hasNavigation() {
    return this.app.isBrowser() ||
      (this.app.config.chrome && this.app.config.chrome.navigation);
  };

  AppChrome.prototype.addBookmark = function ac_addBookmark() {
    var dataset = this.app.config;
    var favicons = this.app.favicons;

    var name;
    if (this.isSearch()) {
      name = dataset.searchName;
    } else {
      name = this.title.textContent;
    }
    var url = this._currentURL || dataset.url;

    return LazyLoader.load('shared/js/icons_helper.js').then(() => {
      return IconsHelper.getIcon(url, null, {icons: favicons}).then(icon => {
        return BookmarksDatabase.add({
          url: url,
          name: name,
          icon: icon
        }).then(() => {
          return Promise.resolve();
        }, () => {
          return Promise.reject('hasPinned');
        });
      }, (reason) => {
        return Promise.reject(reason);
      });
    }, (reason) => {
      return Promise.reject(reason);
    });
  };

  exports.AppChrome = AppChrome;
}(window));
