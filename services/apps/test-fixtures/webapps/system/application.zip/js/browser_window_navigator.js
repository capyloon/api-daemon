/* global browserSitesDataStore, Service, places, MozActivity */

(function(exports) {
  'use strict';

  var _ = navigator.mozL10n.get;

  var BrowserWindowNavigator = function BrowserWindowNavigator(appChrome) {
    // belongs to which appChrome
    this.appChrome = appChrome;
    this.app = appChrome.app;

    this.app.browser.element.addEventListener('focus', this);
    this.app.browser.element.addEventListener('blur', this);
    this.app.browser.element.addEventListener('mozbrowserlocationchange', this);
    window.addEventListener('mozfullscreenchange', this);
    window.addEventListener('fullscreenchange', this);

    this.app.element.addEventListener('_opened', this);
    this.app.element.addEventListener('_closing', this);
    this.app.element.addEventListener('_loading', this);
    this.app.element.addEventListener('_loaded', this);
    this.app.element.addEventListener('_scrollerModeChanged', this);
  };

  BrowserWindowNavigator.prototype = {
    backEnabled: false,
    forwardEnabled: false,

    _DEBUG: false,

    saveFocus: function bwm_saveFocus() {
      // XXX: For browser app, sometimes its focus is on option menu in app.
      // So we need to save its focus before browser app closes. However,
      // sometimes focus would be on body so we only save focus when focus is on
      // iframe of browser app.
      if (this.isFocusInScope()) {
        this._lastFocus = document.activeElement;
      }
    },

    restoreFocus: function bwm_restoreFocus() {
      if (this._lastFocus) {
        this._lastFocus.focus();
        this._lastFocus = undefined;
      }
    },

    _focusOnApp: function bwm_focusOnApp() {
      this.app.publish('focus');
    },

    handleEvent: function bwm_handleEvent(evt) {
      switch (evt.type) {
        case 'mozfullscreenchange':
        case 'fullscreenchange':
          this.handleFullScreenChange(evt);
          break;
        case '_opened':
          this.restoreFocus();
          break;
        case '_closing':
          this.saveFocus();
          break;
        case '_loading':
        case '_loaded':
          this.updateOptionMenu();
          break;
        case '_scrollerModeChanged':
          this.setSoftkey(document.mozFullScreen);
          break;
        case 'focus':
        case 'blur':
          this.handleFocusOrBlur(evt);
          break;
        case 'mozbrowserlocationchange':
          this.updateGoBackForwardOptions();
          break;
      }
    },

    handleFocusOrBlur: function bwm_handleFocusOrBlur(evt) {
      var targetOnApp = evt.target === this.app.browser.element;
      if (!targetOnApp) {
        return;
      }

      if (evt.type === 'focus' && this.app.isBrowser()) {
        this.setSoftkey(document.mozFullScreen);
      }
    },

    handleKey: function bwm_handleKey(key) {
      var handled = false;
      switch (key) {
        case 'softleft':
          if (this.app && this.app.isBrowser()) {
            handled = true;
            if (this.isFocusOnApp() && !document.mozFullScreen) {
              // Focus on rocket bar for action search.
              window.dispatchEvent(new CustomEvent('global-search-request'));
              // Set spatial navigation back to 'spatial' mode.
              if (this.app && this.app.browserNavigationWidgets) {
                this.app.browserNavigationWidgets.setNavigationMode('spatial');
              }
              // Send `focusonurlbar` event to disable virtual cursor.
              if (this.app) {
                this.app.publish('focusonurlbar');
              }
            } else {
              // Leave from full screen mode.
              document.mozCancelFullScreen();
            }
          }
          break;
        case 'softright':
          if (this.app && this.app.isBrowser()) {
            if (this.isFocusInScope()) {
              if (!document.mozFullScreen) {
                this.showOptionMenu();
                handled = true;
              } else {
                if (!Service.query('hasVolumeKey')) {
                  this.requestVolume('show');
                  handled = true;
                }
              }
            }
          }
          break;
        case '1':
        case 'i':
        case 'w':
          if (this.app && this.app.isBrowser()) {
            this.app.browserNavigationWidgets &&
              this.app.browserNavigationWidgets.zoom('out');
            handled = true;
          }
          break;
        case '3':
        case 'o':
        case 'r':
          if (this.app && this.app.isBrowser()) {
            this.app.browserNavigationWidgets &&
              this.app.browserNavigationWidgets.zoom('in');
            handled = true;
          }
          break;
        case '5':
          if (this.app && this.app.isBrowser()) {
            this.app.browserNavigationWidgets.setNavigationMode('toggle');
            handled = true;
          }
          break;
        case '2':
        case 'e':
          if (this.app && this.app.isBrowser()) {
            this.app.browserNavigationWidgets &&
              this.app.browserNavigationWidgets.scroll('top');
            handled = true;
          }
          break;
        case '8':
          if (this.app && this.app.isBrowser()) {
            this.app.browserNavigationWidgets &&
              this.app.browserNavigationWidgets.scroll('down');
            handled = true;
          }
          break;
        case 'arrowup':
          if (this.app && this.app.isBrowser()) {
            this.requestVolume('up');
            handled = true;
          }
          break;
        case 'arrowdown':
          if (this.app && this.app.isBrowser()) {
            this.requestVolume('down');
            handled = true;
          }
          break;
        case 'enter':
          if (this.app && this.app.isBrowser() &&
              this.app.browser.element &&
              this.app.browser.element.touchPanningSimulationEnabled) {
            this.app.browserNavigationWidgets.setNavigationMode('spatial');
            handled = true;
          }
          break;
        case 'home':
          // It's a combined event with "event.detail.back = true";
          if (document.mozFullScreen) {
            // Leave from full screen mode.
            document.mozCancelFullScreen();
            handled = true;
            break;
          }
          this.app.canGoBack((result) => {
            // If cursor is enabled, let back key to act as we used in Broswer.
            if (this.app.isCursorEnabled() && !this.app.isBrowser()) {
              if (result) {
                this.app.back();
              } else if (Service.query('isLowMemoryDevice')) {
                this.app.kill();
              } else {
                appWindowManager.display(null, null, null, 'home');
              }
              return;
            }
            if (result && this.app.isBrowser()) {
              // If has history, navigate back to previous site.
              this.app.back();
              // Prevent user to press back key without toast guidance.
              this.hasLeaveAppToast = false;
            } else {
              let toastl10n = 'pressBackAgainToMinimizeBrowser';
              if (Service.query('isLowMemoryDevice')) {
                toastl10n = 'pressBackAgainToQuitBrowser';
              }
              if (!this.hasLeaveAppToast) {
                // A toast to guidance user press back again for quit.
                Service.request('AppToast:show',
                  { message: _(toastl10n) });
                this.hasLeaveAppToast = true;
              } else {
                if (Service.query('isFtuRunning')) {
                  let origin = FtuLauncher.getFtuOrigin();
                  appWindowManager.display(appWindowManager.getApp(origin));
                } else if (Service.query('isLowMemoryDevice')) {
                  this.app.kill();
                } else {
                  appWindowManager.display(null, null, null, 'home');
                }
              }
            }
          });
          break;
      }
      return handled;
    },

    goToBrowserTop: function(gotoView) {
      // Request activity 'browser-top', then go back to search app.
      var activityReq = new MozActivity({
        name: 'browser-top',
        data: {view: gotoView ? gotoView : 'home'}
      });
      activityReq.onerror = (e) => {
        var msg = '[BrowserWindowNavigator] open "browser-top" activity ' +
                  'error:' + activityReq.error.name;
        this.debug(msg);
      };
      activityReq.onsuccess = (e) => {
        var msg = '[BrowserWindowNavigator] open "browser-top" activity ' +
                  'onsuccess';
        this.debug(msg);
        // XXX In order to avoid TransitionController runs into wrong state,
        // we make a short delay to kill itself
        // since browser-top page(Search app) is opening now.
        setTimeout(() => {
          this.app.kill();
        });
      };
    },

    requestVolume: function(option) {
      switch (option) {
        case 'show':
          if (navigator.volumeManager) {
            navigator.volumeManager.requestShow();
          }
          break;
        case 'up':
          if (Service.query('SoundManager.isActivated') &&
              !Service.query('hasVolumeKey')) {
            if (navigator.volumeManager) {
              navigator.volumeManager.requestUp();
            }
          }
          break;
        case 'down':
          if (Service.query('SoundManager.isActivated') &&
              !Service.query('hasVolumeKey')) {
            if (navigator.volumeManager) {
              navigator.volumeManager.requestDown();
            }
          }
          break;
        default:
          return;
      }
    },

    buildOptionMenu: function() {
      var menu = [{
        label: _('newtab'),
        value: 'newtab'
      }, {
        label: _('history'),
        value: 'history'
      }, {
        label: _('settings'),
        value: 'settings'
      }];

      if (this.forwardEnabled) {
        menu.splice(0, 0, {
          label: _('goForward'),
          value: 'goForward'
        });
      }

      if (this.backEnabled) {
        menu.splice(0, 0, {
          label: _('goBack'),
          value: 'goBack'
        });
      }

      return menu;
    },

    showOptionMenu: function(mode) {
      if (this.app && this.app.browserNavigationWidgets) {
        this.app.browserNavigationWidgets.setOptionMenu(this.buildOptionMenu());
        this.app.browserNavigationWidgets.showOptionMenu();
      }
    },

    updateOptionMenu: function() {
      if (this.app && this.app.browserNavigationWidgets) {
        this.app.browserNavigationWidgets.setOptionMenu(this.buildOptionMenu());
      }
    },

    updateGoBackForwardOptions: function() {
      this.app.canGoForward((result) => {
        if (!this.appChrome.hasNavigation()) {
          this.forwardEnabled = false;
        } else {
          this.forwardEnabled = (result) ? true : false;
        }
        this.updateOptionMenu();
      });

      this.app.canGoBack((result) => {
        if (!this.appChrome.hasNavigation()) {
          this.backEnabled = false;
        } else {
          this.backEnabled = (result) ? true : false;
        }
        this.updateOptionMenu();
      });
    },

    handleOptionMenuClick: function(action) {
      switch (action) {
        case 'goForward':
          this.app.forward();
          break;
        case 'goBack':
          this.app.back();
          break;
        case 'newtab':
          this.goToBrowserTop();
          break;
        case 'history':
        case 'settings':
          this.goToBrowserTop(action);
          break;
        default:
          break;
      }
    },

    handleFullScreenChange: function () {
      if (this.isFocusOnApp()) {
        // Update soft key according to full screen mode.
        this.setSoftkey(document.mozFullScreen);
      }
    },

    setSoftkey: function (isFullScreen) {
      if (!this.app || !this.app.isBrowser()) {
        return;
      }

      var centerIcon = this.app.browser.element &&
            this.app.browser.element.touchPanningSimulationEnabled ?
        'icon=browser-softkey-cursor' : 'select';

      if (!isFullScreen) {
        Service.request(
          'SoftKeyStore:register',
          {left: 'search', center: centerIcon, right: 'options'},
          this.app.browser.element);
      } else {
        var rskText = Service.query('hasVolumeKey') ? '' : 'volume';
        Service.request(
          'SoftKeyStore:register',
          {left: 'exit', center: centerIcon, right: rskText},
          this.app.browser.element);
      }
    },

    isFocusOnApp: function bwm_isFocusOnApp() {
      if (this.app && this.app.browser && this.app.browser.element) {
        return document.activeElement === this.app.browser.element;
      } else {
        return false;
      }
    },

    isFocusInScope: function bwm_isFocusInScope() {
      // Add condition if we have other focus scope.
      return (this.isFocusOnApp() ||
              (this.app && this.app._modalDialog &&
                !this.app._modalDialog.element.hidden));
    },

    refresh: function() {
      this.app.loading ? this.app.stop() : this.app.reload();
    },

    pinToTopSites: function() {
      // Store the site to browser store(pinned site store).
      places.getPlace(this.app.config.url).then((place) => {
        browserSitesDataStore.saveSite('pin', {
          url: place.url,
          title: place.title,
          screenshot: place.screenshot,
          tile: place.tile,
          icons: place.icons
        }).then((result) => {
          // Display toast to indicate that pinned site completely.
          switch (result) {
            case 'pinCompleted':
              Service.request('AppToast:show',
                { message: _('pinSiteCompletely')});
              break;
            case 'wasPinnedBefore':
              Service.request('AppToast:show',
                { message: _('siteWasPinnedBefore')});
              break;
            case 'pinnedSitesOverLimit':
              Service.request('AppToast:show',
                { message: _('pinnedSitesOverLimit')});
              break;
            default:
              this.debug('pin site failed with other reason: ' + result);
              break;
          }
        });
      });
    },

    pinToAppsMenu: function () {
      this.appChrome.addBookmark().then(() => {
        Service.request('AppToast:show',
          { message: _('pinSiteToAppsMenuCompletely')});
      }, (reason) => {
        Service.request('AppToast:show',
          { message: _('siteWasPinnedToAppsMenuBefore')});
      });
    },

    destroy: function() {
      this.app.element.removeEventListener('_opened', this);
      this.app.element.removeEventListener('_closing', this);
      this.app.element.removeEventListener('_loading', this);
      this.app.element.removeEventListener('_loaded', this);
      this.app.element.removeEventListener('_scrollerModeChanged', this);

      this.app.browser.element.removeEventListener('focus', this);
      this.app.browser.element.removeEventListener('blur', this);
      this.app.browser.element.removeEventListener(
        'mozbrowserlocationchange', this);
      window.removeEventListener('mozfullscreenchange', this);
      window.removeEventListener('fullscreenchange', this);

      this.app = null;
      this.appChrome = null;
      this._lastFocus = null;
    },

    debug: function(msg) {
      if (this._DEBUG) {
        console.log('[BrowserWindowNavigator]: ' + msg);
      }
    }
  };

  exports.BrowserWindowNavigator = BrowserWindowNavigator;

}(window));
