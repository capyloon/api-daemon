'use strict';

let Messages = {
  silent: false,
  vibrates: true,

  init: function() {
    window.navigator.mozSetMessageHandler('sms-received',
      this.messagesHandler.bind(this));

    SettingsListener.observe('audio.volume.notification', 7, (value) => {
      this.silent = (value === 0);
    });

    SettingsListener.observe('vibration.enabled', true, (value) => {
      this.vibrates = value;
    });
  },

  messagesHandler: function(message) {
    // Prevent the class 0 message if lock mode.
    if (Service.query('remoteLockEnabled')) {
      return;
    }

    if (message.messageClass === 'class-0') {
      let ringtoneFile = '/resources/sounds/New Message_MA.ogg';
      this.ringtone(ringtoneFile);
      this.vibrate();
      const _ = navigator.mozL10n.get;
      const id = 'new-message-dialog';
      const config = {
        id,
        title: message.sender,
        message: message.body,
        primarybtntext: _('ok'),
        onDialogPrimaryBtnClick: () => {
          Service.request('DialogService:hide', id);
        },
      };
      Service.request('DialogService:show', config);
    }
  },

  ringtone: function(file) {
    if (!this.silent) {
      let ringtonePlayer = new Audio();
      ringtonePlayer.src = file;
      ringtonePlayer.mozAudioChannelType = 'notification';
      ringtonePlayer.play();
      window.setTimeout(function ringtoneEnder() {
        ringtonePlayer.pause();
        ringtonePlayer.src = '';
      }, 2000);
    }
  },

  vibrate: function() {
    if (this.vibrates) {
      navigator.vibrate([200, 200, 200, 200]);
    }
  }
};

Messages.init();
