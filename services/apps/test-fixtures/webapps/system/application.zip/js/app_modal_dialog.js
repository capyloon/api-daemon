/* global AppModalDialog, BaseUI, Service */
'use strict';

(function(exports) {
  /**
   * The ModalDialog of the AppWindow.
   *
   * Including **alert**, **prompt**, **confirm**, and
   * **single select** dialogs.
   *
   * @class AppModalDialog
   * @param {AppWindow} app The app window instance
   *                        where this dialog should popup.
   * @extends BaseUI
   */
  exports.AppModalDialog = function AppModalDialog(app) {
    this.app = app;
    this.events = [];
    // One to one mapping.
    this._visible = false;
    app.element.addEventListener('mozbrowsershowmodalprompt', this);
    return this;
  };

  AppModalDialog.prototype = Object.create(BaseUI.prototype);

  AppModalDialog.prototype.CLASS_NAME = 'AppModalDialog';

  AppModalDialog.prototype.ELEMENT_PREFIX = 'modal-dialog-';

  AppModalDialog.prototype.destroy = function() {
    this.app.element.removeEventListener('mozbrowsershowmodalprompt', this);
    this.app = null;
  };

  AppModalDialog.prototype.customID = function amd_customID() {
    if (this.app) {
      return '[' + this.app.origin + ']';
    } else {
      return '';
    }
  };

  AppModalDialog.prototype.handleEvent = function amd_handleEvent(evt) {
    this.app.debug('handling ' + evt.type);
    evt.preventDefault();
    evt.stopPropagation();
    this.events.push(evt);
    this.show();
  };

  AppModalDialog.prototype.isVisible = function amd_isVisible() {
    return this._visible;
  };

  // Show relative dialog and set message/input value well
  AppModalDialog.prototype.show = function amd_show() {
    if (!this.events.length) {
      return;
    }

    this._visible = true;
    var evt = this.events.shift();

    var message = evt.detail.message || '';
    var title = this._getTitle(evt.detail.title);

    var type = evt.detail.promptType || evt.detail.type;
    this.app._setVisibleForScreenReader(false);
    switch (type) {
      case 'alert':
        Service.request('ModalDialogRenderer:showModalDialog', {
          header: title,
          content: message,
          type: 'alert',
          ok: evt.yesText ? evt.yesText : 'ok',
          onOk: () => {
            evt.detail.returnValue = true;
            evt.detail.unblock && evt.detail.unblock();
            this.hide();
          },
          onBack: () => {
            evt.detail.returnValue = false;
            evt.detail.unblock && evt.detail.unblock();
            this.hide();
          }
        }, this.app);
        break;

      case 'prompt':
        Service.request('ModalDialogRenderer:showModalDialog', {
          header: title,
          content: message,
          type: 'prompt',
          ok: evt.yesText ? evt.yesText : 'ok',
          cancel: evt.noText ? evt.noText : 'cancel',
          onOk: (value) => {
            evt.detail.returnValue = value;
            evt.detail.unblock && evt.detail.unblock();
            this.hide();
          },
          onCancel: () => {
            evt.detail.unblock && evt.detail.unblock();
            this.hide();
          },
          onBack: () => {
            evt.detail.unblock && evt.detail.unblock();
            this.hide();
          }
        }, this.app);
        break;

      case 'confirm':
        Service.request('ModalDialogRenderer:showModalDialog', {
          header: title,
          content: message,
          type: 'confirm',
          ok: evt.yesText ? evt.yesText : 'ok',
          cancel: evt.noText ? evt.noText : 'cancel',
          onOk: () => {
            evt.detail.returnValue = true;
            evt.detail.unblock && evt.detail.unblock();
            this.hide();
          },
          onCancel: () => {
            evt.detail.returnValue = false;
            evt.detail.unblock && evt.detail.unblock();
            this.hide();
          },
          onBack: () => {
            evt.detail.returnValue = false;
            evt.detail.unblock && evt.detail.unblock();
            this.hide();
          }
        }, this.app);
        break;

      case 'custom-prompt':
        Service.request('ModalDialogRenderer:showModalDialog', {
          header: title,
          content: message,
          type: 'custom',
          buttons: evt.detail.buttons,
          showCheckbox: evt.detail.showCheckbox,
          checkboxCheckedByDefault: evt.detail.checkboxCheckedByDefault,
          checkboxMessage: evt.detail.checkboxMessage,
          onOk: (value) => {
            evt.detail.returnValue = value;
            evt.detail.unblock && evt.detail.unblock();
            this.hide();
          },
          onCancel: () => {
            evt.detail.unblock && evt.detail.unblock();
            this.hide();
          },
          onBack: () => {
            evt.detail.unblock && evt.detail.unblock();
            this.hide();
          }
        }, this.app);
        break;
    }

    this.app.browser.element.setAttribute('aria-hidden', true);
  };

  AppModalDialog.prototype.hide = function amd_hide() {
    this._visible = false;
    this.app._setVisibleForScreenReader(true);
  };

  AppModalDialog.prototype._getTitle =
    function amd__getTitle(title) {
      //
      // XXX Bug 982006, subsystems like uriloader still report errors with
      // titles which are important to the user for context in diagnosing
      // issues.
      //
      // However, we will ignore all titles containing a URL using the app
      // protocol. These types of titles simply indicate that the active
      // application is prompting and are more confusing to the user than
      // useful. Instead we will return the application name if there is one
      // or an empty string.
      //
      if (!title ||
          title.indexOf('app://') >= 0) {
        return this.app.name || '';
      }

      return title;
    };
}(window));
