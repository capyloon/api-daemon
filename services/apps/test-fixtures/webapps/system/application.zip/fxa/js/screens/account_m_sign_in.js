﻿/* -*- Mode: Java; tab-width: 2; indent-tabs-mode: nil; c-basic-offset: 2 -*- /
/* vim: set shiftwidth=2 tabstop=2 autoindent cindent expandtab: */

/* global FxaModuleStates, FxaModuleUI, FxaModule, FxaModuleNavigation,
   FxModuleServerRequest, FxaModuleManager */
/* exported AccountModuleSignIn */

'use strict';

/**
 * This module supports to sign in KaiOS account with either
 * phone number or email.
 */
var AccountModuleSignIn = (function() {
  let Module = Object.create(FxaModule);
  let checkFunctions = {
    _checkRegion: function() {
      if (Module.mode !== 'PHONE') {
        return '';
      }

      let regionEl = $('account-sign-in-region');

      if (regionEl.dataset.id) {
        return '';
      } else {
        return 'ERROR_NO_REGION';
      }
    },
    _checkPhoneNumber: function() {
      if (Module.mode !== 'PHONE') {
        return '';
      }

      let phoneEl = $('account-sign-in-phone');

      if (!phoneEl.value) {
        phoneEl.errorstate = true;
        return 'ERROR_EMPTY_PHONE';
      } else {
        phoneEl.errorstate = false;
        return '';
      }
    },
    _checkEmail: function() {
      if (Module.mode !== 'EMAIL') {
        return '';
      }

      let emailEl = $('account-sign-in-email');
      let email = emailEl.value;

      if (email && AccountTypeValidator.isEmailValid(emailEl)) {
        emailEl.errorstate = false;
        return '';
      } else {
        emailEl.errorstate = true;
        return 'ERROR_INVALID_EMAIL';
      }
    },
    _checkPassword: function() {
      let pwdEl = $('account-sign-in-pwd');

      if (!pwdEl.value) {
        pwdEl.errorstate = true;
        return 'ERROR_EMPTY_PASSWORD';
      } else {
        pwdEl.errorstate = false;
        return '';
      }
    }
  };

  // accountId would be phone number or email
  function _signInWithAccountId(accountId, password) {
    return new Promise((resolve, reject) => {
      FxModuleServerRequest.signIn(
        accountId,
        password,
        response => resolve(response),
        error => reject(error)
      );
    });
  }

  Module.init = function init(options) {
    // Cache static HTML elements
    this.importElements(
      'account-sign-in-separator',
      'account-sign-in-phone-mode',
      'account-sign-in-region',
      'account-sign-in-phone',
      'account-sign-in-email-mode',
      'account-sign-in-email',
      'account-sign-in-pwd',
      'account-sign-in-btn',
      'account-forgot-pwd-link'
    );

    // check the internet
    this.onLine = navigator.onLine;
    this.accountSignInBtn.disabled = !this.onLine;
    if (!this.onLine) {
      this.showToastMessage('ERROR_NO_INTERNET');
    }

    // Hide all buttons
    FxaModuleUI.setButtonsVisible('00');
    FxaModuleUI.setHeaderMenu();
    // Swtich page layout to phone mode or email mode
    this.flow = options && options.flow;
    this.switchMode(this.flow);

    if (this.initialized) {
      return;
    }

    // FTU
    this.isFTU = !!(options && options.isftu);
    // Initialize the component text with l10n
    this.initL10n();
    // Create Event listeners
    this.createListeners();
    // Avoid to add listener twice
    this.initialized = true;
  };

  Module.initL10n = function initL10n() {
    this.accountSignInSeparator.label = lget('account-separator-account-info');
    this.accountSignInRegion.text = lget('account-region');
    this.accountSignInRegion.subtext = lget('account-select');
    this.accountSignInPhone.label = lget('account-phone-number');
    this.accountSignInPhone.placeholder = lget('account-phone-placeholder');
    this.accountSignInEmail.label = lget('account-email');
    this.accountSignInPwd.label = lget('account-password');
    this.accountSignInBtn.text = lget('account-sign-in');
  };

  Module.createListeners = function createListeners() {
    this.accountSignInBtn.addEventListener('click', this);
    this.accountForgotPwdLink.addEventListener('click', this);
    this.accountSignInRegion.addEventListener('click', this);
    this.accountSignInRegion.addEventListener('change', this);
  };

  Module.switchMode = function switchMode(flow) {
    switch (flow) {
      case AccountModuleFlows.PHONE_SIGN_IN:
        this.mode = 'PHONE';
        this.accountSignInEmailMode.classList.add('hidden');
        this.accountSignInPhoneMode.classList.remove('hidden');
        break;
      case AccountModuleFlows.EMAIL_SIGN_IN:
        this.mode = 'EMAIL';
        this.accountSignInEmailMode.classList.remove('hidden');
        this.accountSignInPhoneMode.classList.add('hidden');
        break;
      default:
        break;
    }
  };

  Module.onNext = function onNext(gotoNextStepCallback) {
    /**
     * Forgot Password
     */
    if (this.flow === AccountModuleFlows.FORGOT_PWD) {
      gotoNextStepCallback(FxaModuleStates.FORGOT_PASSWORD);
      return;
    }

    /**
     * Sign In: Verify the input data before login via Gecko API.
     */
    const error = validateType(checkFunctions);

    if (error) {
      this.showToastMessage(error);
      return;
    }

    switch (this.flow) {
      case AccountModuleFlows.PHONE_SIGN_IN:
        const regionObj = this.accountSignInRegion.dataset;
        const phoneNumber = this.accountSignInPhone.value;
        let fullPhoneNumber = regionObj.prefix + phoneNumber;

        loadPhoneUtils(fullPhoneNumber).then(phone => {
          if (phone) {
            this.login(fullPhoneNumber, gotoNextStepCallback);
          } else {
            this.showToastMessage('ERROR_INVALID_PHONE_NUMBER');
          }
        });
        break;
      case AccountModuleFlows.EMAIL_SIGN_IN:
        const email = this.accountSignInEmail.value;
        this.login(email, gotoNextStepCallback);
        break;
      default:
        break;
    }
  };

  Module.handleClickEvent = function handleClickEvent(evt) {
    const target = evt.target;

    switch (target) {
      case this.accountSignInBtn:
        FxaModuleNavigation.next();
        break;
      case this.accountForgotPwdLink:
        this.flow = AccountModuleFlows.FORGOT_PWD;
        FxaModuleNavigation.next();
        break;
      case this.accountSignInRegion:
        regionSelector.open(target);
        break;
      default:
        break;
    }
  };

  Module.handleChangeEvent = function handleChangeEvent(evt) {
    const target = evt.target;

    switch (target) {
      case this.accountSignInRegion:
        regionSelector.setListItemValue(regionSelector.selected);
        break;
      default:
        break;
    }
  };

  /**
   * If the email doesn't exist, show the toast "Account does not extst".
   * If password is incorrect, show the toast "Incorrect Password".
   * If the email is unverified, go to verify email page to resend the mail.
   * Otherwise, sign in successfully and go to page "Your Account".
   */
  Module.login = function login(accountId, callback) {
    const password = this.accountSignInPwd.value;
    let state = null;

    // Check wrong password multiple times
    InvalidPasswordHelper.checkEnableDateTime().then(
      () => {
        AccountLoader.mask('account-signing-in');
        _signInWithAccountId(accountId, password)
          .then(
            resp => {
              if (!resp.authenticated) {
                window.parent.FxAccountsUI.done({ success: false });
                return;
              }

              InvalidPasswordHelper.resetWrongTimes();
              FxaModuleManager.setParam('success', true);
              callback && callback(FxaModuleStates.ACCOUNT_INFO);
            },
            err => {
              switch (err.error) {
                case 'UNVERIFIED_ACCOUNT':
                  if (this.flow === AccountModuleFlows.EMAIL_SIGN_IN) {
                    FxaModuleManager.setParam('email', email);
                    state = FxaModuleStates.VERIFY_EMAIL;
                  } else {
                    // XXX: Use it and wait for UX to define the message.
                    this.showToastMessage('ERROR_ACCOUNT_DOES_NOT_EXIST');
                  }
                  break;
                case 'ACCOUNT_DOES_NOT_EXIST':
                  this.showToastMessage('ERROR_ACCOUNT_DOES_NOT_EXIST');
                  break;
                case 'INVALID_PASSWORD':
                  InvalidPasswordHelper.setWrongTimes();
                  this.showToastMessage('ERROR_PASSWORD_INCORRECT');
                  break;
                default:
                  this.showToastMessage('ERROR_SERVER_ERROR');
                  break;
              }
            }
          )
          .then(() => {
            AccountLoader.unmask();
            state && callback && callback(state);
          });
      },
      () => {}
    );
  };

  return Module;
})();
