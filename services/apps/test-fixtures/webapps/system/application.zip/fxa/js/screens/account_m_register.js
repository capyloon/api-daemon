/* -*- Mode: Java; tab-width: 2; indent-tabs-mode: nil; c-basic-offset: 2 -*- /
/* vim: set shiftwidth=2 tabstop=2 autoindent cindent expandtab: */

/* global FxaModuleStates, FxaModuleUI, FxaModule, FxaModuleNavigation,
   FxModuleServerRequest, FxaModuleOverlay, FxaModuleManager, BrowserFrame */
/* exported FxaModuleEnterEmail */

'use strict';

var AccountModuleRegister = (function() {
  let Module = Object.create(FxaModule);
  let checkFunctions = {
    _checkRegion: function() {
      let regionEl = $('account-register-region');

      if (regionEl.dataset.id) {
        return '';
      } else {
        return 'ERROR_NO_REGION';
      }
    },
    _checkPhoneNumber: function() {
      let phoneEl = $('account-register-phone-input');

      if (!phoneEl.value) {
        return 'ERROR_EMPTY_PHONE';
      } else {
        return '';
      }
    },
    _checkPassword: function() {
      const passwordEl = $('account-register-password-input');
      const passwordCheck = $('account-register-password-confirm-input');
      let passwordValue = passwordEl.value;

      if (!passwordValue || passwordValue.length < 8) {
        return 'ERROR_PASSWORD_LESS';
      }

      if (passwordValue.length > 20) {
        return 'ERROR_PASSWORD_MORE';
      }

      if (passwordValue !== passwordCheck.value) {
        return 'ERROR_PASSWORD_DONT_MATCH';
      }

      if (!/^(?![^a-zA-Z]+$)(?!\D+$).{8,20}$/.test(passwordValue)) {
        return 'ERROR_INVALID_PASSWORD';
      }

      return '';
    }
  };

  Module.init = function init(options) {
    // Cache static HTML elements
    this.importElements(
      'account-register-separator',
      'account-register-region',
      'account-register-phone-input',
      'account-register-password-input',
      'account-register-password-input-tips',
      'account-register-password-confirm-input',
      'account-register-show-password',
      'account-register-show-password-checkbox'
    );
    this.options = options || {};

    // Show the buttons: Cancel & Next
    FxaModuleUI.setButtonsVisible('11');
    FxaModuleUI.setCancelButtonLevel('secondary');
    FxaModuleUI.setHeaderMenu();

    if (this.initialized) {
      return;
    }

    this.isFTU = !!(options && options.isftu);
    // ininialize region selector
    regionSelector.reset();
    // L10n
    this.initL10n();
    // Add listeners
    this.createListeners();
    // Avoid to add listener twice
    this.initialized = true;
  };

  Module.initL10n = function initL10n() {
    /**
     * In the page, when there is one text field has placeholder text, UX team
     * defined that all text fields should also display with the same format
     * in that page. For that reason, if the text field without placeholder value,
     * we will assign a whitespace to it.
     */
    const whitespace = '\u00a0';

    this.accountRegisterSeparator.label = lget(
      'account-separator-account-info'
    );
    this.accountRegisterRegion.text = lget('account-region');
    this.accountRegisterRegion.subtext = lget('account-select');
    this.accountRegisterPhoneInput.label = lget('account-phone-number');
    this.accountRegisterPhoneInput.setAttribute(
      'placeholder',
      lget('account-phone-placeholder')
    );
    this.accountRegisterPasswordInput.label = lget('account-password');
    this.accountRegisterPasswordInput.placeholder = lget(
      'account-password-placeholder'
    );
    this.accountRegisterPasswordConfirmInput.label = lget(
      'account-change-password-confirm-pwd'
    );
    this.accountRegisterPasswordConfirmInput.placeholder = whitespace;
    this.accountRegisterShowPassword.text = lget('account-show-password');
  };

  Module.createListeners = function createListeners() {
    this.accountRegisterRegion.addEventListener('click', this);
    this.accountRegisterRegion.addEventListener('change', this);
    this.accountRegisterPasswordInput.addEventListener('focus', this);
    this.accountRegisterPasswordInput.addEventListener('blur', this);
    this.accountRegisterShowPasswordCheckbox.addEventListener('click', this);
  };

  Module.handleClickEvent = function handleClickEvent(evt) {
    const target = evt.target;

    switch (target) {
      case this.accountRegisterRegion:
        regionSelector.open(target);
        break;
      case this.accountRegisterShowPasswordCheckbox:
        let inputType = target.checked ? 'text' : 'password';

        this.accountRegisterPasswordInput.type = inputType;
        this.accountRegisterPasswordConfirmInput.type = inputType;
        break;
    }
  };

  Module.handleChangeEvent = function handleChangeEvent(evt) {
    const target = evt.target;

    switch (target) {
      case this.accountRegisterRegion:
        regionSelector.setListItemValue(regionSelector.selected);
        break;
    }
  };

  Module.handleFocusEvent = function handleFocusEvent(evt) {
    const target = evt.target;

    switch (target) {
      case this.accountRegisterPasswordInput:
        this.accountRegisterPasswordInputTips.classList.add('focusInput');
        break;
    }
  };

  Module.handleBlurEvent = function handleBlurEvent(evt) {
    const target = evt.target;

    switch (target) {
      case this.accountRegisterPasswordInput:
        this.accountRegisterPasswordInputTips.classList.remove('focusInput');
        break;
    }
  };

  Module.dialogPrimaryBtnHandler = function dialogPrimaryBtnHandler() {
    FxaModuleNavigation.goBackByStepIndex(1);
  };

  Module.onCancel = function onCancel(showDialog) {
    showDialog(...this.options['signup_leave_msg']);
  };

  Module.onNext = function onNext(gotoNextStepCallback) {
    // Verify all data in this page, and go to next step if there is no error.
    let error = validateType(checkFunctions);
    if (error) {
      this.showToastMessage(error);
      return;
    }

    let regionDataSet = this.accountRegisterRegion.dataset;
    let phoneNumber = this.accountRegisterPhoneInput.value;
    let fullPhoneNumber = regionDataSet.prefix + phoneNumber;
    let password = this.accountRegisterPasswordInput.value;

    loadPhoneUtils(fullPhoneNumber).then(phone => {
      if (phone) {
        FxaModuleManager.setParam('region', regionDataSet);
        FxaModuleManager.setParam('phone', fullPhoneNumber);
        FxaModuleManager.setParam('password', password);
        gotoNextStepCallback(FxaModuleStates.ENTER_ACCOUNT_INFO);
      } else {
        this.showToastMessage('ERROR_INVALID_PHONE_NUMBER');
      }
    });
  };

  return Module;
})();
