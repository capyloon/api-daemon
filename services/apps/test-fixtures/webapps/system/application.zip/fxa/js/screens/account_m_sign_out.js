/* -*- Mode: Java; tab-width: 2; indent-tabs-mode: nil; c-basic-offset: 2 -*- /
/* vim: set shiftwidth=2 tabstop=2 autoindent cindent expandtab: */

/* global FxaModule, FxModuleServerRequest, FxaModuleOverlay,
          NavigationMap, ViewManager, $ */
/* exported AccountModuleSignOut */

'use strict';

/**
 * This module checks the validity of an email address, and if valid,
 * determines which screen to go next.
 */
var AccountModuleSignOut = (function () {
  const ANTITHEFT_ENABLED = 'antitheft.enabled';
  let Module = Object.create(FxaModule);

  function _ensureFxaClient(callback) {
    window.parent.LazyLoader.load('../js/fxa_client.js', function () {
      callback && callback();
    });
  }

  function _showMask() {
    AccountLoader.mask('account-signing-out');
  }

  function _hideMask() {
    AccountLoader.unmask();
  }

  function _signOut() {
    NavigationMap.currentActivatedLength = 0;
    window.parent.FxAccountsClient.logout(
      () => {
        window.parent.FxAccountsUI.done({ success: true });
        _hideMask();
      },
      err => {
      console.error('[KaiOS Account]Verify Password Error:', err);
      FxaModuleNavigation.goBackByStepIndex(1, 'ERROR_UNABLE_SIGN_OUT');
      _hideMask();
      }
    );
  }

  function _signOutWithAntitheft(email, password, logout) {
    _showMask();
    FxModuleServerRequest.signIn(email, password,
      () => {
        InvalidPasswordHelper.resetWrongTimes();
        //We just need to remove push subscription, no matter the result.
        window.parent.FMDManager.removeSubscription().then(() => {
          logout && logout();
        },() => {
          logout && logout();
        });
      },
      err => {
        console.error('[KaiOS Account]Verify Password Error:', err);
        NavigationMap.currentActivatedLength = 0;
        if (err && (err.error === 'INVALID_PASSWORD')){
          InvalidPasswordHelper.setWrongTimes();
          FxaModuleNavigation.goBackByStepIndex(1, 'ERROR_PASSWORD_INCORRECT');
        } else {
          FxaModuleNavigation.goBackByStepIndex(1, 'ERROR_UNABLE_SIGN_OUT');
        }
        _hideMask();
      }
    );
  }

  function _signOutWithoutAntitheft(logout) {
    _showMask();
    _ensureFxaClient(() => {
      logout && logout();
    });
  }

  Module.init = function init(options) {
    FxaModuleUI.setButtonsVisible('00');
    FxaModuleUI.setHeaderMenu();

    window.parent.SettingsListener.observe(ANTITHEFT_ENABLED, false,
      value => {
        window.parent.SettingsListener.unobserve(ANTITHEFT_ENABLED, () => {});
        if (!value) {
          _signOutWithoutAntitheft(_signOut);
        } else {
          const email = options.email;
          const password = options.password;

          _signOutWithAntitheft(email, password, _signOut);
        }
      }
    );
  };

  return Module;
}());
