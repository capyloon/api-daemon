/**
 * This module not only supports to edit account's email,
 * but also phone number modification. We use options.flow
 * to determine which screen will go next. So, there are
 * three flows into this module:
 * 1. AccountModuleFlows.EDIT_PHONE
 * 2. AccountModuleFlows.EDIT_EMAIL
 * 3. AccountModuleFlows.EDIT_ALT_PHONE
 */

'use strict';

var AccountModuleEditInfo = (function() {
  let Module = Object.create(FxaModule);
  let checkFunctions = {
    _checkEmail: function() {
      if (Module.mode !== 'EMAIL') {
        return '';
      }

      let emailEl = $('account-edit-info-email');
      let email = emailEl.value;

      if (email && AccountTypeValidator.isEmailValid(emailEl)) {
        emailEl.errorstate = false;
        return '';
      } else {
        emailEl.errorstate = true;
        return 'ERROR_INVALID_EMAIL';
      }
    },
    _checkRegion: function() {
      if (Module.mode !== 'PHONE') {
        // skip this check
        return '';
      }

      let regionEl = $('account-edit-info-region');

      if (regionEl.dataset.id) {
        return '';
      } else {
        return 'ERROR_NO_REGION';
      }
    },
    _checkPhoneNumber: function() {
      if (Module.mode !== 'PHONE') {
        // skip this check
        return '';
      }

      let phoneEl = $('account-edit-info-phone');

      if (!phoneEl.value) {
        phoneEl.errorstate = true;
        return 'ERROR_EMPTY_PHONE';
      } else {
        phoneEl.errorstate = false;
        return '';
      }
    }
  };
  let eliminateRepetition = function(array) {
    return array.map(el => el.full)
      .map((el, idx, final) => final.indexOf(el) === idx && idx)
      .filter(el => array[el])
      .map(el => array[el]);
  };

  Module.init = function init(options) {
    this.importElements(
      'account-edit-info-email-mode',
      'account-edit-info-email',
      'account-edit-info-phone-mode',
      'account-edit-info-region',
      'account-edit-info-phone'
    );

    this.options = options || {};
    this.initL10n();
    this.switchMode(this.options.flow);
    this.setAccountPhone(this.options.flow);

    FxaModuleUI.setButtonsVisible('11');
    FxaModuleUI.setHeaderMenu();

    if (this.initialized) {
      return;
    }

    this.accountEditInfoRegion.addEventListener('click', this);
    this.accountEditInfoRegion.addEventListener('change', this);
    this.initialized = true;
  };

  Module.initL10n = function initL10n() {
    this.accountEditInfoEmail.label = lget('account-email');
    this.accountEditInfoEmail.errormessage = lget('error-invalid-email');
    this.accountEditInfoRegion.text = lget('account-region');
    this.accountEditInfoRegion.subtext = lget('account-select');
    this.accountEditInfoPhone.label = lget('account-phone-number');
  };

  Module.switchMode = function switchMode(flow) {
    switch (flow) {
      case AccountModuleFlows.EDIT_PHONE:
      case AccountModuleFlows.EDIT_ALT_PHONE:
        this.mode = 'PHONE';
        this.accountEditInfoEmailMode.classList.add('hidden');
        this.accountEditInfoPhoneMode.classList.remove('hidden');
        break;
      case AccountModuleFlows.EDIT_EMAIL:
        this.mode = 'EMAIL';
        this.accountEditInfoEmailMode.classList.remove('hidden');
        this.accountEditInfoPhoneMode.classList.add('hidden');
        break;
      default:
        break;
    }
  };

  Module.handleClickEvent = function handleClickEvent(evt) {
    const target = evt.target;

    switch (target) {
      case this.accountEditInfoRegion:
        regionSelector.open(target);
        break;
      default:
        break;
    }
  };

  Module.handleChangeEvent = function handleChangeEvent(evt) {
    const target = evt.target;

    switch (target) {
      case this.accountEditInfoRegion:
        regionSelector.setListItemValue(regionSelector.selected);
        break;
      default:
        break;
    }
  };

  Module.onNext = function onNext(gotoNextStepCallback) {
    let error = validateType(checkFunctions);

    if (error) {
      this.showToastMessage(error);
      return;
    }

    // If succeed, go back to "Your Account" and reload the account info.
    // If fail, show the toast with the error message.
    switch (this.options.flow) {
      case AccountModuleFlows.EDIT_EMAIL:
        const email = this.accountEditInfoEmail.value.trim();

        AccountLoader.mask();
        // update the email
        this.updateEmail(email)
          .then(() => {
            // Request to send a verification email
            this.requestEmailVerification(email);
          })
          .then(() => AccountLoader.unmask());
        break;
      case AccountModuleFlows.EDIT_ALT_PHONE:
      case AccountModuleFlows.EDIT_PHONE:
        const regionObj = this.accountEditInfoRegion.dataset;
        const phoneNumber = this.accountEditInfoPhone.value;
        const fullPhoneNumber = regionObj.prefix + phoneNumber;

        AccountLoader.mask();
        // check phone format
        loadPhoneUtils(fullPhoneNumber)
          .then(phone => {
            if (phone) {
              // correct format and update the phone
              this.updatePhoneNumber(fullPhoneNumber).then(() => {
                // Request an OTP to verify the phone
                this.requestPhoneVerification(
                  fullPhoneNumber,
                  gotoNextStepCallback
                );
              });
            } else {
              this.showToastMessage('ERROR_INVALID_PHONE_NUMBER');
            }
          })
          .then(() => AccountLoader.unmask());
        break;
      default:
        break;
    }
  };

  Module.onCancel = function onNext(showDialog) {
    // Back to the page: Your Account, and nothing change.
    FxaModuleNavigation.goBackByStepIndex(1);
  };

  Module.setAccountPhone = function setAccountPhone(flow) {
    const { phone, altPhone } = this.options.user;
    let phoneNumber = null;

    switch (flow) {
      case AccountModuleFlows.EDIT_PHONE:
        phoneNumber = phone;
        break;
      case AccountModuleFlows.EDIT_ALT_PHONE:
        phoneNumber = altPhone;
        break;
      default:
        break;
    }

    if (phoneNumber) {
      loadPhoneUtils(phoneNumber).then(result => {
        if (result) {
          const regionEl = this.accountEditInfoRegion;
          const { nationalNumber, region } = result;
          let mccList = null;

          // To display the region info correctly
          loadJSON('/shared/resources/mcc.json', response => {
            mccList = Object.values(response);
            mccList = eliminateRepetition(mccList);
            mccList.forEach(mcc => {
              if (mcc.code === region.toLowerCase()) {
                regionEl.setAttribute('data-id', mcc.code);
                regionEl.setAttribute('data-name', mcc.full);
                regionEl.setAttribute('data-prefix', mcc.prefix);
                regionEl.subtext = `${mcc.full} ${mcc.prefix}`;
                this.accountEditInfoPhone.value = nationalNumber;
              }
            });
          });
        }
      });
    }
  };

  Module.requestPhoneVerification = function requestPhoneVerification(
    phone, callback
  ) {
    switch (this.options.flow) {
      case AccountModuleFlows.EDIT_PHONE:
        FxModuleServerRequest.requestPhoneVerification(
          phone, '',
          resp => {
            this.onRequestOTPSuccess(resp, phone, callback);
          },
          err => {
            console.error('[Account] Request OTP error.', err);
            this.showToastMessage('ERROR_SERVER_ERROR');
          }
        );
        break;
      case AccountModuleFlows.EDIT_ALT_PHONE:
        // user's 1st phone
        const accountPhone = this.options.user.phone;
        // user's 2nd phone
        const altPhone = phone;

        FxModuleServerRequest.requestPhoneVerification(
          accountPhone, altPhone,
          resp => {
            this.onRequestOTPSuccess(resp, altPhone, callback);
          },
          err => {
            console.error('[Account] Request OTP error.', err);
            this.showToastMessage('ERROR_SERVER_ERROR');
          }
        );
        break;
      default:
        break;
    }
  };

  Module.onRequestOTPSuccess = function onRequestOTPSuccess(
    response, phone, callback
  ) {
    if (!response || (response && !response.verificationId)) {
      console.error(
        '[Account] Request OTP: response without verificationId.'
      );
      return;
    }
    // To resolve the phone verification at next step
    FxaModuleManager.paramsRetrieved.phone = phone;
    FxaModuleManager.paramsRetrieved.verificationId =
      response.verificationId;
    callback && callback(FxaModuleStates.ENTER_PHONE_OTP);
  };

  Module.requestEmailVerification = function requestEmailVerification(
    email, altEmail = ''
  ) {
    const dialogMsg = [
      lget('account-dialog-confirm'),
      lget('account-change-email-success-message'),
      lget('account-dialog-ok'),
      ''
    ];

    FxModuleServerRequest.requestEmailVerification(
      email, altEmail,
      () => {
        FxaModuleNavigation.showDialog(...dialogMsg);
        FxaModuleNavigation.goBackByStepIndex(1);
      },
      err => {
        console.error('[Account] Resend verification email error.', err);
        this.showToastMessage('ERROR_SERVER_ERROR');
      }
    );
  };

  Module.updatePhoneNumber = function updatePhoneNumber(phone) {
    return new Promise((resolve, reject) => {
      switch (this.options.flow) {
        case AccountModuleFlows.EDIT_PHONE:
          FxModuleServerRequest.updateAccount(
            phone, '', FxaModuleManager.paramsRetrieved.password, '',
            () => {
              this.onUpdatePhoneNumberSuccess(phone);
              resolve();
            },
            err => {
              console.error('[Account] Update phone fail', err);
              this.showToastMessage('ERROR_SERVER_ERROR');
              reject(err);
            }
          );
          break;
        case AccountModuleFlows.EDIT_ALT_PHONE:
          FxModuleServerRequest.updateAccount(
            '', '', '', { altPhone: phone },
            () => {
              this.onUpdatePhoneNumberSuccess(phone);
              resolve();
            },
            err => {
              console.error('[Account] Update alternative phone fail', err);
              this.showToastMessage('ERROR_SERVER_ERROR');
              reject(err);
            }
          );
          break;
        default:
          break;
      }
    });
  };

  Module.onUpdatePhoneNumberSuccess = function onUpdatePhoneNumberSuccess(phone) {
    // Use to resovle the phone verification at next step.
    FxaModuleManager.setParam('phone', phone);
    // Force fetch account data from server not cache.
    FxaModuleManager.setParam('forceFetch', true);
    delete FxaModuleManager.paramsRetrieved.password;
  };

  Module.updateEmail = function updateEmail(email) {
    return new Promise((resolve, reject) => {
      FxModuleServerRequest.updateAccount(
        '', email, FxaModuleManager.paramsRetrieved.password, '',
        () => {
          FxaModuleManager.setParam('email', email);
          FxaModuleManager.setParam('forceFetch', true);
          delete FxaModuleManager.paramsRetrieved.password;
          resolve();
        },
        err => {
          console.error('[Account] Update email fail', err);
          this.showToastMessage('ERROR_SERVER_ERROR');
          reject(err);
        }
      );
    });
  };

  return Module;
})();
