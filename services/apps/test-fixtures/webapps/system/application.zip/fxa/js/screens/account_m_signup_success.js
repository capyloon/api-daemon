/* -*- Mode: Java; tab-width: 2; indent-tabs-mode: nil; c-basic-offset: 2 -*- /
/* vim: set shiftwidth=2 tabstop=2 autoindent cindent expandtab: */

/* global FxaModule, FxaModuleStates */
/* exported FxaModuleSignupSuccess */

'use strict';

/**
 * Display the signup success message to the user.
 */
var AccountModuleSignupSuccess = (function() {
  var Module = Object.create(FxaModule);
  Module.init = function init(options) {
    options = options || {};
    this.importElements('account-account-created-content');

    FxaModuleUI.setButtonsVisible('01');
    FxaModuleUI.setHeaderMenu();

    if (this.initialized) {
      return;
    }

    if (options.email && options.altPhone) {
      this.accountAccountCreatedContent.textContent = lget(
        'account-account-created-text2'
      );
    } else if (options.email) {
      this.accountAccountCreatedContent.textContent = lget(
        'account-account-created-text3'
      );
    } else if (options.altPhone) {
      this.accountAccountCreatedContent.textContent = lget(
        'account-account-created-text4'
      );
    }

    this.initialized = true;
  };

  Module.onNext = function onNext(gotoNextStepCallback) {
    window.parent.FxAccountsUI.done({
      success: true
    });
  };

  return Module;
})();
