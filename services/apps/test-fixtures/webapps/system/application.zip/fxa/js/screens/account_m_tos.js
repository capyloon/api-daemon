'use strict';

var AccountModuleToS = (function() {
  let Module = Object.create(FxaModule);

  Module.init = function init() {
    // Show the buttons: Cancel & Next
    FxaModuleUI.setButtonsVisible('00');
  };

  return Module;
}());
