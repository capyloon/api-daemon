/* -*- Mode: Java; tab-width: 2; indent-tabs-mode: nil; c-basic-offset: 2 -*- /
/* vim: set shiftwidth=2 tabstop=2 autoindent cindent expandtab: */

/* global FxaModuleStates, FxaModule, FxModuleServerRequest,
          FxaModuleManager, ViewManager, $, FxaModuleOverlay, NavigationMap */
/* exported FxaModuleEnterAccountInfo */

'use strict';

/**
 * This module provides birthday and gender field, and if filled,
 * determines which screen to go next.
 */

var AccountModuleEnterAccountInfo = (function() {
  const minYear = 1900;
  const maxYear = new Date().getFullYear();
  let Module = Object.create(FxaModule);
  let checkFunctions = {
    _checkBirthday: function() {
      const pattern = new RegExp('^[0-9]{4}$');
      let birthEl = $('account-birthday');
      let value = birthEl.value.trim();
      let valueInt = parseInt(value, 10);

      if (value === '') {
        return 'ERROR_NO_BIRTH';
      } else if (
        value.match(pattern) === null || valueInt < minYear ||
        valueInt > maxYear
      ) {
        return 'ERROR_INVALID_BIRTH';
      } else if (valueInt && maxYear - valueInt <= 13) {
        return 'ERROR_UNDER_14';
      } else {
        return '';
      }
    },
    _checkGender: function() {
      let genderGroup = $('account-gender');
      let genders = genderGroup.querySelectorAll('kai-radio');
      let gender = null;

      genders.forEach(radio => {
        if (radio.checked) {
          gender = radio.parentNode.dataset.value;
        }
      });

      if (gender) {
        return '';
      } else {
        return 'ERROR_NO_GENDER';
      }
    }
  };

  Module.init = function init(options) {
    // Cache static HTML elements
    this.importElements(
      'account-personal-info',
      'account-birthday',
      'account-gender',
      'account-gender-male',
      'account-gender-female',
      'account-gender-confidential'
    );

    this.options = options || {};

    // Show the buttons: Cancel & Next
    FxaModuleUI.setButtonsVisible('11');
    FxaModuleUI.setCancelButtonLevel('secondary');
    FxaModuleUI.setHeaderMenu();

    if (this.options.flow === AccountModuleFlows.EDIT_INFO) {
      const { yob, gender } = FxaModuleManager.paramsRetrieved.user;
      const header = $('account-module-header');
      const genders = this.accountGender.querySelectorAll('kai-radio');

      // set the header text
      header.title = lget('account-personal-info');
      // set the button text from 'Next" to "Save"
      FxaModuleUI.setNextText(lget('account-save'));
      // set the user info (covert to string)
      this.accountBirthday.value = `${yob}`;
      // set the gender selected
      genders.forEach(radio => {
        if (radio.parentNode.id === 'account-gender-' + gender.toLowerCase()) {
          radio.checked = true;
        } else {
          radio.checked = false;
        }
      });
    }

    // l10n
    this.accountPersonalInfo.label = lget('account-personal-info');
    this.accountBirthday.label = lget('account-year-of-birth');
    this.accountBirthday.placeholder =
      lget('account-year-of-birth-placeholder');
    this.accountGenderMale.text = lget('account-gender-male');
    this.accountGenderFemale.text = lget('account-gender-female');
    this.accountGenderConfidential.text = lget('account-gender-confidential');

    if (this.initialized) {
      return;
    }

    // Check message sent or not
    this.email = options.email;
    this.password = options.password;

    // Avoid to add listener twice
    this.initialized = true;
  };

  Module.dialogPrimaryBtnHandler = function dialogPrimaryBtnHandler() {
    FxaModuleNavigation.goBackByStepIndex(1);
  };

  Module.onCancel = function onCancel(showDialog) {
    const flow = this.options.flow;
    switch (flow) {
      case AccountModuleFlows.CREATE_ACCOUNT:
        showDialog(...this.options['signup_leave_msg']);
        break;
      default:
        FxaModuleNavigation.back();
        break;
    }
  };

  Module.onNext = function onNext(gotoNextStepCallback) {
    // Verify all data in this page, and go to next step if there is no error.
    let error = validateType(checkFunctions);
    if (error) {
      this.showToastMessage(error);
      return;
    }

    let genders = this.accountGender.querySelectorAll('kai-radio');
    let birthday = this.accountBirthday.value.trim();
    let gender = null;

    genders.forEach(radio => {
      if (radio.checked) {
        gender = radio.parentNode.dataset.value.toLowerCase();
      }
    });

    FxaModuleManager.setParam('yob', Number(birthday));
    FxaModuleManager.setParam('gender', gender);

    switch (this.options.flow) {
      case AccountModuleFlows.CREATE_ACCOUNT:
        gotoNextStepCallback(FxaModuleStates.PASSWORD_RETRIEVAL);
        break;
      case AccountModuleFlows.EDIT_INFO:
        const info = {
          yob: Number(birthday),
          gender: gender
        };
        this.updateAccountInfo(info, gotoNextStepCallback);
        break;
      default:
        break;
    }
  };

  Module.updateAccountInfo = function updateAccountInfo(info, callback) {
    AccountLoader.mask();
    FxModuleServerRequest.updateAccount('', '', '', info,
      () => {
        AccountLoader.unmask();
        FxaModuleManager.setParam('forceFetch', true);
        callback(FxaModuleStates.ACCOUNT_INFO);
      },
      err => {
        AccountLoader.unmask();
        console.error('[Account] Update account fail', err);
        this.showToastMessage('ERROR_SERVER_ERROR');
      }
    );
  };

  return Module;
})();
