'use strict';

var AccountModulePasswordRetrieval = (function() {
  let Module = Object.create(FxaModule);
  let checkFunctions = {
    _checkEmail: function() {
      let emailEl = $('account-password-retrieval-email-input');
      let email = emailEl.value;

      if (email && !AccountTypeValidator.isEmailValid(emailEl)) {
        emailEl.errorstate = true;
        return 'ERROR_INVALID_EMAIL';
      } else {
        emailEl.errorstate = false;
        return '';
      }
    }
  };

  Module.init = function init(options) {
    this.importElements(
      'account-password-retrieval-email',
      'account-password-retrieval-email-slot',
      'account-password-retrieval-email-input',
      'account-password-retrieval-phone',
      'account-password-retrieval-phone-slot',
      'account-password-retrieval-region',
      'account-password-retrieval-phone-input'
    );
    this.options = options || {};

    // Show the buttons: Cancel & Next
    FxaModuleUI.setButtonsVisible('11');
    FxaModuleUI.setCancelButtonLevel('secondary');
    FxaModuleUI.setHeaderMenu();

    this.initL10n();
    this.resetForm();

    if (this.initialized) {
      return;
    }

    // XXX: we should make sure it works well after bug-69317 is fixed.
    this.accountPasswordRetrievalEmail.isExtandabled = true;
    this.accountPasswordRetrievalPhone.isExtandabled = false;
    this.setAltPhoneVisible(false);
    this.createListeners();
    this.initialized = true;
  };

  Module.initL10n = function initL10n() {
    this.accountPasswordRetrievalEmail.label = lget('account-email');
    this.accountPasswordRetrievalEmailInput.label = lget('account-email');
    this.accountPasswordRetrievalEmailInput.errormessage = lget(
      'error-invalid-email'
    );
    this.accountPasswordRetrievalPhone.label = lget('account-phone');
    this.accountPasswordRetrievalRegion.text = lget('account-region');
    this.accountPasswordRetrievalRegion.subtext = lget('account-select');
    this.accountPasswordRetrievalPhoneInput.label = lget(
      'account-phone-number'
    );
  };

  Module.resetForm = function resetForm() {
    const regionObj = this.options.region;

    if (regionObj) {
      this.accountPasswordRetrievalRegion.setAttribute(
        'data-name',
        regionObj.name
      );
      this.accountPasswordRetrievalRegion.setAttribute(
        'data-prefix',
        regionObj.prefix
      );
      this.accountPasswordRetrievalRegion.setAttribute('data-id', regionObj.id);
      this.accountPasswordRetrievalRegion.subtext = `${regionObj.name} ${regionObj.prefix}`;
    }
    this.accountPasswordRetrievalEmailInput.value = '';
    this.accountPasswordRetrievalPhoneInput.value = '';
    FxaModuleUI.disableNextButton();
    setTimeout(() => {
      this.accountPasswordRetrievalEmailInput.focus();
    }, 100);
  };

  Module.createListeners = function createListeners() {
    this.accountPasswordRetrievalRegion.addEventListener('click', this);
    this.accountPasswordRetrievalRegion.addEventListener('change', this);
    this.accountPasswordRetrievalEmailInput.addEventListener('change', this);
    this.accountPasswordRetrievalPhoneInput.addEventListener('change', this);
    this.accountPasswordRetrievalEmailInput.addEventListener(
      'input',
      this.handleNextButton.bind(this)
    );
    this.accountPasswordRetrievalPhoneInput.addEventListener(
      'input',
      this.handleNextButton.bind(this)
    );
    this.accountPasswordRetrievalEmail.addEventListener('click', this);
    this.accountPasswordRetrievalPhone.addEventListener('click', this);
  };

  Module.handleNextButton = function handleNextButton() {
    const email = this.accountPasswordRetrievalEmailInput.value;
    const altPhone = this.accountPasswordRetrievalPhoneInput.value;

    if (email || altPhone) {
      FxaModuleUI.enableNextButton();
    } else {
      FxaModuleUI.disableNextButton();
    }
  };

  Module.handleClickEvent = function handleClickEvent(evt) {
    const target = evt.target;

    switch (target) {
      case this.accountPasswordRetrievalRegion:
        regionSelector.open(target);
        break;
      case this.accountPasswordRetrievalEmail:
        this.setEmailVisible(target.isExtandabled);
        break;
      case this.accountPasswordRetrievalEmailSlot:
        this.setEmailVisible(target.parentNode.isExtandabled);
        break;
      case this.accountPasswordRetrievalPhone:
        this.setAltPhoneVisible(target.isExtandabled);
        break;
      case this.accountPasswordRetrievalPhoneSlot:
        this.setAltPhoneVisible(target.parentNode.isExtandabled);
        break;
      default:
        break;
    }
  };

  Module.handleChangeEvent = function handleChangeEvent(evt) {
    const target = evt.target;

    switch (target) {
      case this.accountPasswordRetrievalRegion:
        regionSelector.setListItemValue(regionSelector.selected);
        break;
      case this.accountPasswordRetrievalEmailInput:
      case this.accountPasswordRetrievalPhoneInput:
        this.handleNextButton();
        break;
      default:
        break;
    }
  };

  Module.onCancel = function onCancel(showDialog) {
    showDialog(...this.options['signup_leave_msg']);
  };

  Module.onNext = function onNext(gotoNextStepCallback) {
    let error = validateType(checkFunctions);

    if (error) {
      this.showToastMessage(error);
      return;
    }

    let regionDataSet = this.accountPasswordRetrievalRegion.dataset;
    let altPhoneNumber = this.accountPasswordRetrievalPhoneInput.value;
    let email = this.accountPasswordRetrievalEmailInput.value;
    let info = {};
    let data = null;

    // Email
    if (email) {
      FxaModuleManager.setParam('email', email);
    } else {
      delete FxaModuleManager.paramsRetrieved.email;
    }

    // Alternative phone number
    // XXX: Need to check alternative phone number's format
    if (altPhoneNumber) {
      altPhoneNumber = this.getFullPhoneNumber(regionDataSet, altPhoneNumber);
      FxaModuleManager.setParam('altPhone', altPhoneNumber);
    } else {
      delete FxaModuleManager.paramsRetrieved.altPhone;
    }

    data = FxaModuleManager.paramsRetrieved;
    info = {
      yob: Number(data.yob),
      gender: data.gender.toLowerCase(),
      altPhone: data.altPhone
    };

    // Sign up the account before request OTP. Unverified phone can't be used to login.
    FxModuleServerRequest.signUp(
      data.phone,
      data.email,
      data.password,
      info,
      () => {
        this.requestPhoneVerification(data.phone, gotoNextStepCallback);
      },
      err => {
        let errMsg = '';

        switch (err.error) {
          case 'ACCOUNT_ALREADY_EXISTS':
            errMsg = 'ERROR_ACCOUNT_EXIST';
            break;
          default:
            errMsg = 'ERROR_UNABLE_TO_CREATE';
            break;
        }
        console.error('[Account] Sign up error.', err);
        this.showToastMessage(errMsg);
      }
    );
  };

  // Request OTP to verify the phone
  Module.requestPhoneVerification = function requestPhoneVerification(
    phone,
    callback
  ) {
    FxModuleServerRequest.requestPhoneVerification(
      phone,
      '',
      response => {
        if (!response || (response && !response.verificationId)) {
          console.error(
            '[Account] Request OTP: response without verificationId.'
          );
          return;
        }
        FxaModuleManager.paramsRetrieved.phone = phone;
        FxaModuleManager.paramsRetrieved.verificationId =
          response.verificationId;
        callback(FxaModuleStates.ENTER_PHONE_OTP);
      },
      err => {
        console.error('[Account] Request OTP error.', err);
        this.showToastMessage('ERROR_SERVER_ERROR');
      }
    );
  };

  Module.onBack = function onBack() {
    FxaModuleUI.enableNextButton();
  };

  Module.getFullPhoneNumber = function getFullPhoneNumber(regionObj, phone) {
    return regionObj.prefix + (phone.startsWith(0) ? phone.slice(1) : phone);
  };

  Module.setEmailVisible = function setEmailVisible(isVisible) {
    if (isVisible) {
      this.accountPasswordRetrievalEmailInput.classList.remove('hidden');
    } else {
      this.accountPasswordRetrievalEmailInput.value = '';
      this.accountPasswordRetrievalEmailInput.classList.add('hidden');
      this.handleNextButton();
    }
  };

  Module.setAltPhoneVisible = function setAltPhoneVisible(isVisible) {
    if (isVisible) {
      this.accountPasswordRetrievalRegion.classList.remove('hidden');
      this.accountPasswordRetrievalPhoneInput.classList.remove('hidden');
    } else {
      this.accountPasswordRetrievalPhoneInput.value = '';
      this.accountPasswordRetrievalRegion.classList.add('hidden');
      this.accountPasswordRetrievalPhoneInput.classList.add('hidden');
      this.handleNextButton();
    }
  };

  return Module;
})();
