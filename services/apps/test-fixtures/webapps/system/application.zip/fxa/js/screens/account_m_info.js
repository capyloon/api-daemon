'use strict';

var AccountModuleInfo = (function() {
  const HEADER_MENU = [{
    label: lget('account-change-pwd'),
    value: AccountModuleFlows.CHANGE_PWD
  }, {
    label: lget('account-edit-account-info'),
    value: AccountModuleFlows.EDIT_INFO
  }, {
    label: lget('account-sign-out'),
    value: AccountModuleFlows.SIGN_OUT
  }, {
    label: lget('account-delete'),
    value: AccountModuleFlows.DELETE_ACCOUNT
  }];
  let Module = Object.create(FxaModule);

  function _getSettings(key) {
    return new Promise((resolve, reject) => {
      let getRequest = navigator.mozSettings.createLock().get(key);

      getRequest.onsuccess = () => {
        resolve(getRequest.result[key]);
      };

      getRequest.onerror = () => {
        console.error(`[KaiOS Account]: get config [${key}] failed.`);
        reject();
      };
    });
  }

  Module.init = function init(options) {
    this.importElements(
      'account-info-separator',
      'account-info-id',
      'account-info-email',
      'account-info-resend-email',
      'account-personal-info-separator',
      'account-info-alt-phone',
      'account-info-resend-sms',
      'account-info-birth',
      'account-info-edit-dialog',
      'account-info-edit-phone',
      'account-info-edit-email',
      'account-info-edit-alt-phone',
      'account-info-edit-personal-info'
    );

    window.focus();
    this.options = options || {};
    // set the step count to 1
    FxaModuleNavigation.stepCount = 1;
    FxaModuleUI.setButtonsVisible('00');
    FxaModuleUI.setHeaderMenu(HEADER_MENU);

    this.initL10n();
    // Only fetch account info from server after users update their
    // data; otherwise, fetch from cache.
    this.setAccountInfo(this.options.forceFetch ? true : false);
    // Remove forceFetch flag to avoid fetching from server again
    if (FxaModuleManager.paramsRetrieved) {
      delete FxaModuleManager.paramsRetrieved.forceFetch;
    }

    if (this.initialized) {
      return;
    }

    this.createListeners();
    this.initialized = true;
  };

  Module.initL10n = function initL10n() {
    this.accountInfoSeparator.label = lget('account-separator-account-info');
    this.accountInfoId.text = lget('account-phone-number1');
    this.accountInfoEmail.text = lget('account-email');
    this.accountInfoResendEmail.text =
      lget('account-resend-verification-email');
    this.accountPersonalInfoSeparator.label = lget('account-personal-info');
    this.accountInfoAltPhone.text = lget('account-alternative-phone');
    this.accountInfoResendSms.text = lget('account-resend-verification-sms');
    this.accountInfoBirth.text = lget('account-year-of-birth');
    this.accountInfoEditDialog.title = lget('account-edit-account-info1');
    this.accountInfoEditPhone.text = lget('account-phone-number');
    this.accountInfoEditEmail.text = lget('account-email');
    this.accountInfoEditAltPhone.text = lget('account-alternative-phone1');
    this.accountInfoEditPersonalInfo.text = lget('account-personal-info1');
  };

  Module.setAccountInfo = function setAccountInfo(fromServer = false) {
    AccountLoader.mask();

    if (!navigator.onLine) {
      this.showToastMessage('ERROR_NO_INTERNET');
      setTimeout(() => window.parent.FxAccountsUI.done(), 2000);
      return;
    }

    FxModuleServerRequest.getAccounts(
      info => {
        // If KaiOS account has not been signed in, we will close the page.
        if (!info) {
          window.parent.FxAccountsUI.done({
            success: false,
            msg: 'NO_SIGNED_IN_ACCOUNT'
          });
        }

        const {
          accountId, phone, phoneVerified, altPhone, altPhoneVerified,
          email, emailVerified, altEmail, altEmailVerified, yob, gender
        } = info;
        const genderL10n = `account-gender-${gender.toLowerCase()}`;
        const emailMethod = emailVerified ? 'add' : 'remove';
        const smsMethod = altPhoneVerified ? 'add' : 'remove';

        if (!FxaModuleManager.paramsRetrieved) {
          FxaModuleManager.paramsRetrieved = {};
        }
        FxaModuleManager.paramsRetrieved.user = info;

        if (email) {
          this.accountInfoEmail.text = emailVerified
            ? lget('account-email-verified')
            : lget('account-email-unverified');
          this.accountInfoResendEmail.classList[emailMethod]('hidden');
        }
        if (altPhone) {
          this.accountInfoAltPhone.text = altPhoneVerified
            ? lget('account-alternative-phone-verified')
            : lget('account-alternative-phone-unverified');
          this.accountInfoResendSms.classList[smsMethod]('hidden');
        }
        this.accountInfoId.subtext = phone;
        this.accountInfoEmail.subtext =
          email ? email : lget('account-no-email');
        this.accountInfoAltPhone.subtext =
          altPhone ? altPhone : lget('account-no-alt-phone');
        this.accountInfoBirth.subtext = `${yob} / ${lget(genderL10n)}`;
        this.accountInfoBirth.setAttribute('data-yob', yob);
        this.accountInfoBirth.setAttribute('data-gender', gender);
        AccountLoader.unmask();
      },
      err => {
        AccountLoader.unmask();
        console.error('[Account] Get account info error.', err);
        this.showToastMessage('ERROR_SERVER_ERROR');
      },
      fromServer
    );
  };

  Module.createListeners = function createListeners() {
    window.addEventListener(
      'optionmenuSelect',
      this.handleOptionMenuSelectEvent.bind(this)
    );
    this.accountInfoResendEmail.addEventListener('click', this);
    this.accountInfoResendSms.addEventListener('click', this);
    this.accountInfoEditPhone.addEventListener('click', this);
    this.accountInfoEditEmail.addEventListener('click', this);
    this.accountInfoEditAltPhone.addEventListener('click', this);
    this.accountInfoEditPersonalInfo.addEventListener('click', this);
  };

  Module.handleOptionMenuSelectEvent = function handleOptionMenuSelectEvent(
    evt
  ) {
    this.action = evt.detail.selected;

    switch (this.action) {
      case AccountModuleFlows.EDIT_INFO:
        this.accountInfoEditDialog.open = true;
        break;
      default:
        FxaModuleNavigation.next();
        break;
    }
  };

  Module.handleClickEvent = function handleClickEvent(evt) {
    const target = evt.target;
    const onLine = navigator.onLine;
    const userInfo = FxaModuleManager.paramsRetrieved.user;

    if (!onLine) {
      this.showToastMessage('ERROR_NO_INTERNET');
      return;
    }

    switch (target) {
      case this.accountInfoResendEmail:
        this.requestEmailVerification(userInfo.email);
        break;
      case this.accountInfoResendSms:
        this.action = AccountModuleFlows.VERIFY_ALT_PHONE;
        const dialogMsg = [
          lget('account-dialog-confirm'),
          lget('account-resend-sms-tips'),
          lget('account-send-sms'),
          lget('account-dialog-cancel')
        ];
        FxaModuleNavigation.showDialog(...dialogMsg);
        break;
      case this.accountInfoEditPhone:
        this.accountInfoEditDialog.open = false;
        this.action = AccountModuleFlows.EDIT_PHONE;
        FxaModuleNavigation.next();
        break;
      case this.accountInfoEditEmail:
        this.accountInfoEditDialog.open = false;
        this.action = AccountModuleFlows.EDIT_EMAIL;
        FxaModuleNavigation.next();
        break;
      case this.accountInfoEditAltPhone:
        this.accountInfoEditDialog.open = false;
        this.action = AccountModuleFlows.EDIT_ALT_PHONE;
        FxaModuleNavigation.next();
        break;
      case this.accountInfoEditPersonalInfo:
        this.accountInfoEditDialog.open = false;
        this.action = AccountModuleFlows.EDIT_INFO;
        FxaModuleNavigation.next();
        break;
      default:
        break;
    }
  };

  Module.onNext = function onNext(gotoNextStepCallback) {
    FxaModuleManager.setParam('flow', this.action);

    switch (this.action) {
      case AccountModuleFlows.CHANGE_PWD:
        gotoNextStepCallback(FxaModuleStates.CHANGE_PASSWORD);
        break;
      case AccountModuleFlows.SIGN_OUT:
        _getSettings('antitheft.enabled').then(
          result => {
            if (result) {
              // Enabled
              gotoNextStepCallback(FxaModuleStates.ANTI_THEFT_RECONFIRM);
            } else {
              // Disabled
              gotoNextStepCallback(FxaModuleStates.SIGN_OUT);
            }
          },
          () => {}
        );
        break;
      case AccountModuleFlows.DELETE_ACCOUNT:
      case AccountModuleFlows.EDIT_PHONE:
      case AccountModuleFlows.EDIT_EMAIL:
      case AccountModuleFlows.EDIT_ALT_PHONE:
        gotoNextStepCallback(FxaModuleStates.CHECK_PASSWORD);
        break;
      case AccountModuleFlows.EDIT_INFO:
        gotoNextStepCallback(FxaModuleStates.ENTER_ACCOUNT_INFO);
        break;
      case AccountModuleFlows.VERIFY_ALT_PHONE:
        this.requestPhoneVerification(gotoNextStepCallback);
        break;
      default:
        break;
    }
  };

  Module.requestEmailVerification = function requestEmailVerification(
    email, altEmail = ''
  ) {
    FxModuleServerRequest.requestEmailVerification(email, altEmail,
      () => this.showToastMessage('NOTIFY_RESEND_SUCCESS'),
      err => {
        console.error('[Account] Resend verification email error.', err);
        this.showToastMessage('ERROR_SERVER_ERROR');
      }
    );
  };

  Module.requestPhoneVerification = function requestPhoneVerification(
    callback
  ) {
    const { phone, altPhone } = FxaModuleManager.paramsRetrieved.user;

    FxModuleServerRequest.requestPhoneVerification(
      phone, altPhone,
      resp => {
        if (!resp || (resp && !resp.verificationId)) {
          console.error(
            '[Account] Request OTP: response without verificationId.'
          );
          return;
        }
        // To resolve the phone verification at next step
        FxaModuleManager.paramsRetrieved.phone = altPhone;
        FxaModuleManager.paramsRetrieved.verificationId =
          resp.verificationId;
        callback && callback(FxaModuleStates.ENTER_PHONE_OTP);
      },
      err => {
        console.error('[Account] Request OTP error.', err);
        this.showToastMessage('ERROR_SERVER_ERROR');
      }
    );
  };

  Module.dialogPrimaryBtnHandler = function dialogPrimaryBtnHandler() {
    FxaModuleNavigation.next();
  };

  return Module;
})();
