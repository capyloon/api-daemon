'use strict';

var AccountAntitheftDisable = (function() {
  let Module = Object.create(FxaModule);

  // accountId would be phone number or email
  function _signInWithAccountId(accountId, password) {
    return new Promise((resolve, reject) => {
      FxModuleServerRequest.signIn(
        accountId,
        password,
        response => resolve(response),
        error => reject(error)
      );
    });
  }

  function nextButtonIsDisabled(userAccountId, inputVal) {
    return userAccountId && inputVal.length > 7 ? false : true;
  }

  Module.init = function init(options) {
    // Cache static HTML elements
    this.importElements(
      'account-antitheft-disable-email',
      'account-antitheft-disable-pwd',
      'account-antitheft-disable-show-password',
      'account-antitheft-disable-show-password-checkbox',
      'account-antitheft-disable-forgot-pwd-link',
      'account-module-next'
    );

    window.focus();
    // set the step count to 1
    FxaModuleNavigation.stepCount = 1;
    FxaModuleUI.setButtonsVisible('11');
    FxaModuleUI.setHeaderMenu();

    this.flow = options && options.flow;
    this.userAccountId = options && options.user && options.user.accountId;

    if (!this.userAccountId) {
      this.setAccountInfo();
    } else {
      this.setInitialUI(this.userAccountId);
    }

    this.initL10n();

    if (this.initialized) {
      return;
    }

    this.createListeners();
    this.initialized = true;
  };

  Module.setInitialUI = function setInitialUI (userAccountId) {
    this.accountAntitheftDisableEmail.value = userAccountId;
    this.accountModuleNext.disabled = nextButtonIsDisabled(
      userAccountId,
      this.accountAntitheftDisablePwd.value
    );
  }

  Module.initL10n = function initL10n() {
    this.accountAntitheftDisableEmail.label = lget('account-phone-number');
    this.accountAntitheftDisableEmail.placeholder = lget(
      'account-phone-placeholder'
    );
    this.accountAntitheftDisablePwd.label = lget('account-password');
    this.accountAntitheftDisablePwd.placeholder = lget(
      'account-password-placeholder'
    );
    this.accountAntitheftDisableShowPassword.text = lget(
      'account-show-password'
    );
  };

  Module.setAccountInfo = function setAccountInfo() {
    AccountLoader.mask();

    if (!navigator.onLine) {
      this.showToastMessage('ERROR_NO_INTERNET');
      setTimeout(() => window.parent.FxAccountsUI.done(), 2000);
      return;
    }

    FxModuleServerRequest.getAccounts(
      (info) => {
        // If KaiOS account has not been signed in, we will close the page.
        if (!info) {
          window.parent.FxAccountsUI.done({
            success: false,
            msg: 'NO_SIGNED_IN_ACCOUNT'
          });
        }

        const { accountId } = info;

        this.userAccountId = accountId;
        this.setInitialUI(this.userAccountId);

        AccountLoader.unmask();
      },
      (err) => {
        AccountLoader.unmask();
        console.error('[Account] Get account info error.', err);
        this.showToastMessage('ERROR_SERVER_ERROR');
        window.parent.FxAccountsUI.done({
          reason: 'ERROR_SERVER_ERROR',
          success: false
        });
      },
      true
    );
  };

  Module.createListeners = function createListeners() {
    this.accountAntitheftDisableShowPassword.addEventListener('click', this);
    this.accountAntitheftDisableForgotPwdLink.addEventListener('click', this);
    this.accountAntitheftDisablePwd.addEventListener('change', this);
  };

  Module.handleChangeEvent = function handleChangeEvent(evt) {
    const target = evt.target;

    switch (target) {
      case this.accountAntitheftDisablePwd:
        this.accountModuleNext.disabled = nextButtonIsDisabled(
          this.userAccountId,
          target.value
        );
        break;
      default:
        break;
    }
  };

  Module.handleClickEvent = function handleClickEvent(evt) {
    const target = evt.target;

    switch (target) {
      case this.accountAntitheftDisableShowPasswordCheckbox:
        let inputType = target.checked ? 'text' : 'password';
        this.accountAntitheftDisablePwd.type = inputType;
        break;
      case this.accountAntitheftDisableForgotPwdLink:
        this.flow = AccountModuleFlows.FORGOT_PWD;
        FxaModuleNavigation.next();
        break;
      default:
        break;
    }
  };

  Module.login = function login(accountId, callback) {
    const password = this.accountAntitheftDisablePwd.value;

    // Check wrong password multiple times
    InvalidPasswordHelper.checkEnableDateTime().then(
      () => {
        AccountLoader.mask('account-signing-in');
        _signInWithAccountId(accountId, password)
          .then(
            resp => {
              if (!resp.authenticated) {
                window.parent.FxAccountsUI.done({ success: false });
                return;
              }

              InvalidPasswordHelper.resetWrongTimes();
              window.navigator.mozSettings
                .createLock()
                .set({ 'antitheft.enabled': false });
              window.parent.FxAccountsUI.done({
                success: true
              });
            },
            err => {
              /**
               * If the account doesn't exist, show the toast "Account does not extst".
               * If password is incorrect, show the toast "Incorrect Password".
               */
              switch (err.error) {
                case 'ACCOUNT_DOES_NOT_EXIST':
                  this.showToastMessage('ERROR_ACCOUNT_DOES_NOT_EXIST');
                  break;
                case 'INVALID_PASSWORD':
                  InvalidPasswordHelper.setWrongTimes();
                  this.showToastMessage('ERROR_PASSWORD_INCORRECT');
                  break;
                default:
                  this.showToastMessage('ERROR_SERVER_ERROR');
                  break;
              }
            }
          )
          .then(() => {
            AccountLoader.unmask();
          })
          .catch(console.error);
      },
      () => {}
    );
  };

  Module.onCancel = function onCancel() {
    FxaModuleNavigation.back();
  };

  Module.onNext = function onNext(gotoNextStepCallback) {
    /**
     * Forgot Password
     */
    if (this.flow === AccountModuleFlows.FORGOT_PWD) {
      gotoNextStepCallback(FxaModuleStates.FORGOT_PASSWORD);
      return;
    }

    this.userAccountId && this.login(this.userAccountId, gotoNextStepCallback);
  };

  return Module;
})();
