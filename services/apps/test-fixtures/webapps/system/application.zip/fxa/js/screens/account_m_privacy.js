'use strict';

var AccountModulePrivacy = (function() {
  let Module = Object.create(FxaModule);

  Module.init = function init() {
    FxaModuleUI.setButtonsVisible('00');
  };

  return Module;
}());
