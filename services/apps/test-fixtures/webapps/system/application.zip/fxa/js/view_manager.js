/* global VerticalNavigator, FxaModuleStates, FxaModuleNavigation, ViewHelper,
          $, lget, NavigationMap */
/*
 * view manager
 */
'use strict';

var ViewManager = {
  menuItems: null,
  navigator: VerticalNavigator,
  controls: null,
  selector: null,
  focus: null,
  curView: null,
  mainHeader: null,
  previousItem: null,

  init: function() {
    this.mainHeader = $('account-module-header');
    this.controls = this.getControls.bind(this);
  },

  get curViewId() {
    var viewId = null;
    if (this.curView) {
      viewId = this.curView.id;
      var subId = this.curView.dataset.subid;
      if (subId && subId.length > 0) {
        viewId += '.' + subId;
      }
    }
    return viewId;
  },

  getControls: function() {
    var controls = null;
    if (this.selector && this.curView) {
      controls = this.curView.querySelectorAll(this.selector);
    }
    return controls;
  },

  // back key handle
  backKeyHandler: function() {
    var self = ViewManager;
    console.log(self.curView.id);
    switch (self.curView.id) {
      case 'account-home':
      case 'account-entry':
        window.parent.FxAccountsUI.done(FxaModuleStates.DONE);
        break;
      case 'account-about':
        if (FxaModuleManager.paramsRetrieved.isftu) {
          delete FxaModuleManager.paramsRetrieved.isftu;
          window.parent.FxAccountsUI.done(FxaModuleStates.DONE);
        } else {
          FxaModuleNavigation.back();
        }
        break;
      case 'account-info':
        // close the info page and return value to caller.
        window.parent.FxAccountsUI.done({ success: true });
        break;
      case 'account-password-retrieval':
      case 'account-register':
      case 'account-enter-info':
      case 'account-agree-tos':
      case 'account-tos':
      case 'account-sign-in':
      case 'account-forgot-password':
      case 'account-verify-email':
      case 'account-change-password':
      case 'account-check-password':
      case 'account-edit-info':
      case 'account-delete':
      case 'account-antitheft-reconfirm':
      case 'account-antitheft-disable':
      case 'account-privacy-policy':
        FxaModuleNavigation.back();
        break;
      case 'account-enter-otp':
      case 'account-signup-success':
      case 'account-sign-out':
        // Back key is not permitted.
        break;
      default:
        window.parent.FxAccountsUI.done(FxaModuleStates.DONE);
        break;
    }
  },

  switchSection: function(sectionId) {
    this.curView = $(sectionId);
    var headerId = '';
    switch (sectionId) {
      case 'account-home':
        headerId = 'account';
        break;
      case 'account-entry':
        break;
      case 'account-about':
        headerId = 'account-about-kaios-title';
        break;
      case 'account-register':
      case 'account-enter-info':
      case 'account-password-retrieval':
      case 'account-agree-tos':
        headerId = 'account-create-account-title';
        break;
      case 'account-tos':
        headerId = 'account-tos';
        break;
      case 'account-enter-otp':
        headerId = 'account-phone-verification';
        break;
      case 'account-signup-success':
        headerId = 'account-signup-success-title';
        break;
      case 'account-sign-in':
        headerId = 'account-sign-in';
        break;
      case 'account-info':
        headerId = 'account-your-account';
        break;
      case 'account-forgot-password':
        headerId = 'account-reset-pwd';
        break;
      case 'account-verify-email':
        headerId = 'account-verify-email';
        break;
      case 'account-change-password':
        headerId = 'account-change-password';
        break;
      case 'account-check-password':
        headerId = 'account-check-password';
        break;
      case 'account-edit-info':
        headerId = 'account-edit-info';
        break;
      case 'account-delete':
        headerId = 'account-delete1';
        break;
      case 'account-sign-out':
        headerId = 'account-sign-out1';
        break;
      case 'account-antitheft-reconfirm':
        headerId = 'anti-theft-enabled';
        break;
      case 'account-antitheft-disable':
        headerId = 'account-antitheft-disable';
        break;
      case 'account-privacy-policy':
        headerId = 'account-privacy-policy';
        break;
    }
    this.mainHeader.setAttribute('title', lget(headerId));
  },

  // -----------------------------------
  // Key Handler
  // -----------------------------------

  dirKeyHandler: function(arrowDir) {
    if (ViewHelper.dirChange) {
      ViewHelper.dirChange.call(ViewHelper, arrowDir);
    }
  },

  endKeyHandler: function() {
    window.close();
  },

  enterKeyHandler: function() {},

  otherHandler: function(key) {
    this.debug(key);
    switch (key) {
      case '*':
        break;
      case '#':
        break;
    }
  },

  defaultBackHandler: function(viewId) {
    if (undefined === viewId) {
      viewId = ViewHelper.curViewId;
    }

    delete NavigationMap.focusedControls[viewId];
  },

  get showingMenu() {
    /*
    var focusedMenus = document.getElementsByClassName('group-menu visible');
    return focusedMenus && focusedMenus.length > 0;
    */
    return false;
  }
};
