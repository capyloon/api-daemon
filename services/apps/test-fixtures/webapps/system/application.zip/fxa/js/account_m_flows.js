var AccountModuleFlows = (function() {
  return {
    CREATE_ACCOUNT: 'sign-up',
    PHONE_SIGN_IN: 'phone-sign-in',
    EMAIL_SIGN_IN: 'email-sign-in',
    EDIT_PHONE: 'edit-phone',
    EDIT_EMAIL: 'edit-email',
    EDIT_ALT_PHONE: 'edit-alt-phone',
    EDIT_INFO: 'edit-account-info',
    VERIFY_ALT_PHONE: 'verify-alt-phone',
    CHANGE_PWD: 'change-password',
    FORGOT_PWD: 'forgot-password',
    SIGN_OUT: 'sign-out',
    DELETE_ACCOUNT: 'delete-account',
    ANTI_THEFT_DISABLE: 'anti-theft-disable'
  };
})();
