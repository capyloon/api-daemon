/**
 * number-picker
 */

'use strict';

var numberPicker = {
  element: $('number-picker'),
  title: 'Year of Birth',
  minValue: 1900,
  maxValue: new Date().getFullYear(),
  selectValue: 1900,
  enabled: false,
  centerPosition: null,

  // Create event listeners here
  init: function() {
    let scrollTimer = null;

    this.listDiv = document.querySelector('.number-picker-list');
    this.ul = this.listDiv.querySelector('ul');
    this.ok = $('number-picker-ok');
    this.cancel = $('number-picker-cancel');
    this.selectValue = this.maxValue;

    // Set l10n when mozL10n is ready.
    navigator.mozL10n.ready(() => {
      this.ok.text = lget('account-dialog-ok');
      this.cancel.text = lget('account-dialog-cancel');
    });

    // Click on OK button.
    this.ok.addEventListener('click', () => {
      if (this.ok.disabled) {
        return;
      }

      let now = this.ul.querySelector('li.highlight');

      this.selectValue = now.dataset.value;
      this.component.dispatchEvent(new CustomEvent('change'));
      this.hide();
    });

    // Click on CANCEL button.
    this.cancel.addEventListener('click', () => {
      this.hide();
    });

    // Update the highlight item
    this.ul.addEventListener('scroll', () => {
      if (scrollTimer) {
        this.ok.disabled = true;
        clearTimeout(scrollTimer);
      }
      // waiting for the end of scroll and unlock the ok button
      scrollTimer = setTimeout(() => {
        this.ok.disabled = false;
      }, 150);

      // switch the highlight item when scolling
      let liAry = this.ul.querySelectorAll('li:not(.highlight)');
      let centerTopBound = 0;
      let centerBottomBound = 0;

      liAry.forEach((el, index) => {
        let liRect = el.getBoundingClientRect();

        if (index === 0) {
          centerTopBound = this.centerPosition - (liRect.height / 2);
          centerBottomBound = this.centerPosition + (liRect.height / 2);
        }

        if (liRect.y >= centerTopBound && liRect.y <= centerBottomBound) {
          this.removeHighlight();
          el.classList.add('highlight');
        }
      });
    });
  },

  // Set the picker's title
  setTitle: function(text) {
    let title = document.querySelector('.number-picker-title');

    if (text) {
      this.title = text;
    }
    title.textContent = this.title;
  },

  // Add the <li> items into <ul>, then set the title and show the page.
  createItems: function() {
    let fragment = document.createDocumentFragment();

    for (let i = this.minValue; i <= this.maxValue; i++) {
      let item = document.createElement('li');
      let str = i.toString();
      let len = str.length;

      item.setAttribute('data-value', i);
      // Created number item by gaia-icon
      for (let j = 0; j < len; j++) {
        let numIcon = document.createElement('i');
        numIcon.setAttribute('data-icon', `numeric_${str[j]}_rounded_bold`);
        item.appendChild(numIcon);
      }
      fragment.appendChild(item);
    }

    this.ul.appendChild(fragment);
    this.setTitle();
    this.show();
  },

  // Clear all items in the <ul>
  clearAllItems: function() {
    while (this.ul.firstChild) {
      this.ul.removeChild(this.ul.firstChild);
    }
  },

  // Get the <li> element by data-value
  getItemByValue: function(value) {
    return this.ul.querySelector(`li[data-value="${value}"]`);
  },

  // Show the number picker, and highlight the selected value.
  show: function() {
    this.ok.disabled = true;
    this.element.classList.remove('hidden');
    this.enabled = true;
    this.scrollToMiddle();
  },

  scrollToMiddle: function() {
    let firstItem = this.getItemByValue(this.minValue);
    let selectItem = this.getItemByValue(this.selectValue);
    let rect = this.listDiv.getBoundingClientRect();
    let selectItemRect = selectItem.getBoundingClientRect();

    // Scroll the selected item to the middle of box.
    this.centerPosition = (rect.top + rect.bottom) / 2;
    this.ul.scrollTo(0, selectItemRect.y - (firstItem.offsetTop + rect.y));
  },

  // To have no highlight item in the list
  removeHighlight: function() {
    let elements = this.ul.querySelectorAll('li.highlight');

    elements.forEach(el => {
      el.classList.remove('highlight');
    });
  },

  // Scroll to the top and hide the number picker
  hide: function() {
    this.ul.scrollTo(0, 0);
    this.enabled = false;
    this.element.classList.add('hidden');
    this.removeHighlight();
  }
};

numberPicker.init();
