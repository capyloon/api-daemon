'use strict'

if (typeof window.$ !== 'function') {
  window.$ = function(id) {
    return (typeof id === 'string')
      ? document.getElementById(id)
      : id;
  };
}

if (typeof window.lget !== 'function') {
  window.lget = function(l10nId) {
    return navigator.mozL10n.get(l10nId);
  };
}

if (typeof window.replaceText !== 'function') {
  window.replaceText = function replaceText(str, newValueObject) {
    var regexp = new RegExp('{{([A-Za-z0-9 ]*)}}', 'g');
    return str.replace(regexp, function getNewValue(matched, key) {
      var trimedKey = key.trim();
      if (!newValueObject[trimedKey]) {
        console.warn(trimedKey + ' not existing in newValueObject');
        return matched;
      } else {
        return newValueObject[trimedKey];
      }
    });
  }
}

if (typeof window.validateType !== 'function') {
  /**
   * How to use:
   *
   * let checkFunctionsObj = {
   *    _checkXXX: function() { ... return 'ERROR_CODE'; }, // if error exists
   *    _checkOOO: function() { ... return ''; }            // if no error
   * };
   */
  window.validateType = function(checkFunctionsObj) {
    let list = Object.keys(checkFunctionsObj);

    for (let i = 0; i < list.length; i++) {
      let error = checkFunctionsObj[list[i]]();
      if (error) {
        return error;
      }
    }
    return '';
  }
}

if (typeof window.loadJSON !== 'function') {
  window.loadJSON = function(href, callback) {
    let xhr = new XMLHttpRequest();

    xhr.open('GET', href, true);
    xhr.responseType = 'json';
    xhr.onerror = callback;
    xhr.onload = () => {
      callback(xhr.response);
    };
    xhr.onerror = () => {
     console.error('Error getting file');
     callback(xhr.response);
    };
    xhr.send();
  }
}

if (typeof String.prototype.contains !== 'function') {
  String.prototype.contains = function (substr) {
    return -1 !== this.indexOf(substr);
  };
}

if (typeof Array.prototype.contains !== 'function') {
  Array.prototype.contains = function (item) {
    return -1 !== this.indexOf(item);
  };
}

var AccountTypeValidator = {
  checkEmailFormat: function(email) {
    // Same regex as server side
    var reg = /^(?:[0-9A-Za-z]{1,30})(?:[-._][0-9A-Za-z_]{1,30}){0,2}@(?:[0-9A-Za-z]{1,30})(?:[-._][0-9A-Za-z]{1,30}){0,2}[.][0-9A-Za-z]{2,20}$/;
    return reg.test(email);
  },
  isEmailValid: function(el) {
    let self = AccountTypeValidator;
    return el && el.value && self.checkEmailFormat(el.value);
  }
};

var loadPhoneUtils = function(number) {
  return new Promise(resolve => {
    if (!number) {
      resolve(null);
      return;
    }
    LazyLoader.load([
      "js/phoneutils/PhoneNumber.js",
      "js/phoneutils/PhoneNumberNormalizer.js",
      "js/phoneutils/PhoneNumberUtils.js"
    ], () => {
      PhoneNumberUtils.parse(number).then(phone => {
        resolve(phone);
      });
    });
  });
};

var AccountLoader = {
  mask: function(l10nkey) {
    let contentElement = $('loading-text');
    let msg = '';
    if(l10nkey) {
      msg = lget(l10nkey) + '&hellip;';
    } else {
      msg = lget('account-loading') + '&hellip;';
    }
    contentElement.innerHTML = msg;
    $('loading-mask').style = "top: calc(8rem + " + window.scrollY + "px)";
    $('loading-mask').classList.remove('hidden');
    document.body.classList.add('unscrollable');
  },
  unmask: function() {
    document.body.classList.remove('unscrollable');
    $('loading-mask').classList.add('hidden');
  }
};

var AccountToaster = {
  showToast: text => {
    let toast = $('toast');

    toast.setAttribute('text', text);
    toast.classList.add('show');

    // XXX: This is a workaround.
    // We should remove it if kai-component or system app supports the toast show/hide mechanism.
    setTimeout(() => {
      toast.classList.remove('show');
    }, 3000);
  }
};
