'use strict';

var AccountModuleVerifyEmail = (function() {
  let Module = Object.create(FxaModule);

  Module.init = function init(options) {
    this.importElements('account-verify-email-resend-button');

    this.options = options || {};
    // Show the cancel button
    FxaModuleUI.setButtonsVisible('10');
    FxaModuleUI.setHeaderMenu();
    // Set l10n
    this.accountVerifyEmailResendButton.text = lget(
      'account-resend-verification-email'
    );

    if (this.initialized) {
      return;
    }

    // Event listeners
    this.accountVerifyEmailResendButton.addEventListener('click', this);
    this.initialized = true;
  };

  Module.requestEmailVerification = function requestEmailVerification(
    email,
    altEmail = ''
  ) {
    FxModuleServerRequest.requestEmailVerification(
      email,
      altEmail,
      () => {
        FxaModuleNavigation.back();
        this.showToastMessage('NOTIFY_RESEND_SUCCESS');
      },
      err => {
        console.error('[Account] Resend verification email error.', err);
        this.showToastMessage('ERROR_SERVER_ERROR');
      }
    );
  };

  Module.handleClickEvent = function handleClickEvent(evt) {
    const target = evt.target;

    switch (target) {
      case this.accountVerifyEmailResendButton:
        this.requestEmailVerification(this.options.email);
        break;
      default:
        break;
    }
  };

  Module.onCancel = function onCancel(showDialog) {
    switch (this.options.flow) {
      case AccountModuleFlows.PHONE_SIGN_IN:
        FxaModuleNavigation.goBackByStepIndex(2);
        break;
      case AccountModuleFlows.EMAIL_SIGN_IN:
        this.showToastMessage('NOTIFY_VERIFY_EMAIL');
        FxaModuleNavigation.goBackByStepIndex(2);
        break;
      default:
        FxaModuleNavigation.goBackByStepIndex(1);
        break;
    }
  };

  return Module;
})();
