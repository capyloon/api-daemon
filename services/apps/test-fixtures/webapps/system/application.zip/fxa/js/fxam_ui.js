/* -*- Mode: Java; tab-width: 2; indent-tabs-mode: nil; c-basic-offset: 2 -*- /
/* vim: set shiftwidth=2 tabstop=2 autoindent cindent expandtab: */

/* global HtmlHelper, FxaModule, FxaModuleManager, FxaModuleNavigation,
   LazyLoader */
/* exported FxaModuleUI */

'use strict';

const OFFLINE_TIMEOUT = 30 * 1000;

var FxaModuleUI = {
  maxSteps: null,
  init: function(flow) {
    // Add listeners to the main elements
    HtmlHelper.importElements(
      this,
      'account-module-header',
      'account-module-cancel',
      'account-module-next'
    );

    this.accountModuleHeader.addEventListener('action', function() {
      FxaModuleManager.close('DIALOG_CLOSED_BY_USER');
    });

    this.accountModuleCancel.addEventListener('mousedown', function() {
      FxaModuleNavigation.cancel();
    });

    this.accountModuleNext.addEventListener('mousedown', function(evt) {
      if (evt.target && evt.target.disabled) {
        return;
      }

      FxaModuleNavigation.next();
    });

    // Give up if the network goes offline for more than 30 seconds straight.
    var offlineTimer;
    window.addEventListener('online', function onOnline(evt) {
      clearTimeout(offlineTimer);
    });

    window.addEventListener('offline', function onOffline(evt) {
      if (offlineTimer) {
        return;
      }
      offlineTimer = setTimeout(function onOfflineTimeout() {
        // XXX TODO: do something to handle offline issue here.
        return FxaModule.showToastMessage('ERROR_NO_INTERNET');
      }, OFFLINE_TIMEOUT);
    });

    FxaModuleNavigation.init(flow);
  },
  setMaxSteps: function(num) {
    this.maxSteps = num;
  },
  increaseMaxStepsBy: function(inc) {
    this.maxSteps = this.maxSteps + inc;
  },
  decreaseMaxStepsBy: function(dec) {
    this.maxSteps = this.maxSteps - dec;
  },
  loadScreen: function(params) {
    var currentScreen = document.querySelector('.current');
    var nextScreen = params.panel;
    // Lazy load current panel
    LazyLoader.load(
      nextScreen,
      function() {
        // If the panel contains any new script elements,
        // lazy load those as well.
        var scripts = [].slice
          .call(nextScreen.querySelectorAll('script'))
          .map(function(script) {
            return script.getAttribute('src');
          });

        // Once all scripts are loaded, load the modules/UI
        LazyLoader.load(
          scripts,
          function() {
            // XXX TODO: Hide or show the wizard buttons by params.count and this.maxSteps
            navigator.mozL10n.once(
              function() {
                // fire module's init method
                params.onload && params.onload();
                // animate it into view - TODO unclear how nextScreen could be falsy
                if (nextScreen) {
                  this._animate(
                    currentScreen,
                    nextScreen,
                    params.back,
                    params.onanimate
                  );
                }
              }.bind(this)
            );
          }.bind(this)
        );
      }.bind(this)
    );
  },
  _animate: function(from, to, back, callback) {
    if (!to) {
      callback && callback();
      return;
    }

    if (!from) {
      to.classList.add('current');
      callback && callback();
      return;
    }

    if (this._inTransition(from) || this._inTransition(to)) {
      return;
    }

    from.addEventListener(
      'animationend',
      function fromAnimEnd() {
        from.removeEventListener('animationend', fromAnimEnd, false);
        from.classList.remove(back ? 'currentToRight' : 'currentToLeft');
        from.classList.remove('current');
        from.classList.remove('back');
      },
      false
    );

    to.addEventListener(
      'animationend',
      function toAnimEnd() {
        to.removeEventListener('animationend', toAnimEnd, false);
        to.classList.remove(back ? 'leftToCurrent' : 'rightToCurrent');
        to.classList.add('current');
        callback && callback();
      },
      false
    );

    //the settimeout function is for fear of animation faild
    //during animation doing, the navigation_map will make animation faild.
    setTimeout(function() {
      from.classList.add(back ? 'currentToRight' : 'currentToLeft');
    }, 0);
    setTimeout(function() {
      to.classList.add(back ? 'leftToCurrent' : 'rightToCurrent');
    }, 20);
  },
  _inTransition: function(elem) {
    return (
      elem.classList.contains('currentToRight') ||
      elem.classList.contains('currentToLeft') ||
      elem.classList.contains('rightToCurrent') ||
      elem.classList.contains('leftToCurrent') ||
      false
    );
  },
  setProgressBar: function(value) {},
  setNextText: function(l10n) {
    this.accountModuleNext.text = l10n;
  },
  disableNextButton: function() {
    this.accountModuleNext.setAttribute('disabled', 'disabled');
  },
  enableNextButton: function() {
    this.accountModuleNext.removeAttribute('disabled');
  },
  disableDoneButton: function() {},
  enableDoneButton: function() {},
  setCancelButtonLevel: function(level) {
    if (level === 'secondary') {
      this.accountModuleCancel.level = level;
    } else {
      this.accountModuleCancel.level = 'primary';
    }
  },
  setHeaderVisible: function(isVisible) {
    if (isVisible) {
      this.accountModuleHeader.removeAttribute('hidden');
    } else {
      this.accountModuleHeader.setAttribute('hidden');
    }
  },
  setHeaderMenu: function(menuOptions = null) {
    if (menuOptions) {
      this.accountModuleHeader.setAttribute(
        'menuoptions',
        JSON.stringify(menuOptions)
      );
    } else {
      // No menu item on the header.
      this.accountModuleHeader.removeAttribute('menuoptions');
    }
  },
  setButtonsVisible: function(str) {
    let buttons = [ this.accountModuleCancel, this.accountModuleNext ];

    if (str.length !== buttons.length) {
      console.error(
        '[Error]setButtonsVisible: str.length is not equal to buttons.length.'
      );
      return;
    }
    for (let i = 0; i < buttons.length; i++) {
      if (str[i] === '1') {
        buttons[i].removeAttribute('hidden');
      } else {
        buttons[i].setAttribute('hidden');
      }
    }
  }
};
