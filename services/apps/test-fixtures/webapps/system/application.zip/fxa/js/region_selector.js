/**
 * region-selector
 */

'use strict';

/**
 * How to use:
 *
 * 1. regionSelector.component
 *   A component which can listen to the 'change' event emitted from regionSelector.
 * 2. regionSelector.selected
 *   The selected object will be recorded here, e.g:
 *      {
 *        name: 'Taiwan',
 *        prefix: '+886',
 *        code: 'tw'
 *      }
 * 3. regionSelector.enabled
 *   When the "Region Select" page is shown, the value is true;
 *   Conversely, the value will be false.
 *
 */

const LAZYLOAD_NUM = 30;

var regionSelector = {
  lazyloadCounter: 0,
  totalPage: 0,
  enabled: false,
  filterValue: '',
  element: null,
  component: null,
  selected: null,

  init: function() {
    this.element = $('region-selector');
    this.getRegions();
    this.createListeners();
  },

  createListeners: function() {
    let self = this;
    let search = $('region-selector-search');

    window.addEventListener('scroll', () => {
      let yCurrent = window.scrollY;
      let yMax = window.scrollMaxY;
      let searchValue = search.value.trim();

      if(self.enabled && searchValue === "" && yCurrent === yMax) {
        self.lazyload();
      }
    });

    search.addEventListener('input', e => {
      let value = e.detail.value.trim().toLowerCase();
      let filterData = null;

      if (value === '' && self.filterValue === '') {
        return;
      } else if (value === '' && self.filterValue !== '') {
        self.filterValue = value;
        this.clearAllItems();
        this.lazyload();
        return;
      }

      filterData = this.allRegions.filter(region => {
        const name = region.full.toLowerCase();
        return name.startsWith(value);
      });
      // Clear all items and load the filter data into list
      self.filterValue = value;
      self.clearAllItems();
      self.addItems(filterData);
      window.scrollTo(0,0);
    });

    search.addEventListener('change', e => {
      let value = e.detail.value.trim();

      if(value === self.filterValue) {
        return;
      }
      // Clear all items and lazyload the first LAZYLOAD_NUM items
      self.filterValue = value;
      if(value === "") {
        this.clearAllItems();
        this.lazyload();
      }
    });
  },

  _noRepeatData: function(array) {
    const unique = array
      // Get the full name array
      .map(el => el.full)
      // When an element's full name is duplicated, return false;
      // otherwise, return the index value.
      .map((el, idx, final) => final.indexOf(el) === idx && idx)
      // Filter the array whose elements are not false.
      .filter(el => array[el])
      // Get the unique region data.
      .map(el => array[el]);

      return unique;
  },

  getRegions: function() {
    const REGION_FILE = '/shared/resources/mcc.json';
    let result = null;

    this.allRegions = [];
    window.loadJSON(REGION_FILE, (response) => {
      result = Object.values(response);
      result.sort((a, b) => {
        return a.full > b.full ? 1 : -1;
      });
      this.allRegions = this._noRepeatData(result);
      this.totalPage = Math.ceil(result.length / LAZYLOAD_NUM);
    });
  },

  clearAllItems: function() {
    let radioGroup = $('region-selector-radio-group');
    while (radioGroup.firstChild) {
      radioGroup.removeChild(radioGroup.firstChild);
    }
    this.lazyloadCounter = 0;
  },

  addItems: function(regionArray) {
    let self = this;
    let fragment = document.createDocumentFragment();

    regionArray.forEach(region => {
      let item = document.createElement('kai-1line-listitem');
      let radio = document.createElement('kai-radio');

      // Add the click handler for the list item
      item.addEventListener('click', function(event){
        radio._clickHandler();
        self.selected = {
          name: region.full,
          prefix: region.prefix,
          code: region.code
        };
        self.hide();
        self.component.dispatchEvent(new CustomEvent('change'));
      });

      radio.setAttribute('name', 'rg_region');
      radio.setAttribute('slot', 'listitem-right-slot');
      item.setAttribute('text', `${region.full} ${region.prefix}`);
      item.setAttribute('data-id', region.code);
      item.setAttribute('data-prefix', region.prefix);
      item.appendChild(radio);
      fragment.appendChild(item);
    });
    $('region-selector-radio-group').appendChild(fragment);
  },

  // lazyload region data and show the loading mask.
  lazyload: function() {
    this.lazyloadCounter++;

    if(this.lazyloadCounter > this.totalPage) {
      return;
    }

    AccountLoader.mask();

    if(!this.enabled) {
      this.show();
    }

    let start = (this.lazyloadCounter - 1) * LAZYLOAD_NUM;
    let end = this.lazyloadCounter * LAZYLOAD_NUM;
    let data = this.allRegions.slice(start, end);

    setTimeout(() => {
      this.addItems(data);
      AccountLoader.unmask();
    }, 300);
  },

  /**
   * Display the region selector and scroll to a selected
   * item if exists.
   */
  show: function() {
    var self = this;

    this.element.classList.remove('hidden');

    setTimeout(function(){
      if(self.selected !== null) {
        let rg = $('region-selector-radio-group');
        let selector = 'kai-1line-listitem[data-id="' + self.selected.code + '"]';
        let element = rg.querySelector(selector);
        let y = element && element.offsetTop;
        window.scrollTo(0, y);
      }
      self.enabled = true;
    }, 300);
  },

  /**
   * Not only display the region selector, but also reset
   * the region selector if the caller ${component} has been
   * changed.
   */
  open: function(component) {
    this.changeComponent(component);

    if(this.lazyloadCounter === 0 && this.selected === null) {
      this.lazyload();
    } else {
      this.show();
    }
  },

  hide: function() {
    this.enabled = false;
    this.element.classList.add('hidden');
  },

  changeComponent: function(element) {
    if (this.component && this.component.id === element.id) {
      return;
    }

    this.reset();
    this.component = element;
  },

  reset: function() {
    let search = $('region-selector-search');

    search._clickClearButton();
    this.clearAllItems();
    this.component = null;
    this.selected = null;
    this.filterValue = '';
  },

  // Set the selected value into kai-2lines-listitem
  setListItemValue: function(valueObj = null, region = null) {
    if (!region) {
      region = this.component;
    }
    if (!valueObj) {
      valueObj = this.selected;
    }
    region.setAttribute('subtext', `${valueObj.name} ${valueObj.prefix}`);
    region.setAttribute('data-id', valueObj.code);
    region.setAttribute('data-name', valueObj.name);
    region.setAttribute('data-prefix', valueObj.prefix);
  }
};

regionSelector.init();
