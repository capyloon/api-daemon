'use strict';

var AccountModuleAbout = (function() {
  let Module = Object.create(FxaModule);

  Module.init = function init(options) {
    // FTU
    this.isFTU = !!(options && options.isftu);

    if (this.isFTU) {
      FxaModuleNavigation.stepCount = 1;
      window.focus();
    }

    // Hide the buttons: Cancel & Next
    FxaModuleUI.setButtonsVisible('00');
    FxaModuleUI.setHeaderMenu();

    this.flow = FxaModuleStates.REGISTER;

    this.importElements(
      'account-about-accept-button',
      'account-about-decline-button',
      'account-about-kaios-text3'
    );

    // L10n
    this.accountAboutAcceptButton.text = lget('account-accept');
    this.accountAboutDeclineButton.text = lget('account-decline');
    this.accountAboutKaiosText3.innerHTML = replaceText(
      lget('account-about-kaios-text3'),
      {
        term: '<span data-l10n-id="account-about-text-link-terms" id="account-about-text-link-terms" class="account-about-text-link"></span>',
        privacy: '<span data-l10n-id="account-about-text-link-privacy" id="account-about-text-link-privacy" class="account-about-text-link"></span>',
      }
    );

    if (this.initialized) {
      return;
    }

    // Events
    this.accountAboutAcceptButton.addEventListener('click', this);
    this.accountAboutDeclineButton.addEventListener('click', this);
    this.accountAboutKaiosText3.addEventListener('click', this);
    this.initialized = true;
  };

  Module.handleClickEvent = function handleClickEvent(evt) {
    const target = evt.target;

    switch (target) {
      case this.accountAboutAcceptButton:
        FxaModuleManager.setParam('signup_leave_msg', [
          // title
          lget('account-dialog-confirm'),
          // message
          lget('account-signup-incomplete-msg'),
          // primary button text
          lget('account-dialog-leave'),
          // secondary button text
          lget('account-dialog-cancel')
        ]);
        this.flow = FxaModuleStates.REGISTER;
        FxaModuleNavigation.next();
        break;
      case this.accountAboutDeclineButton:
        if (this.isFTU) {
          delete FxaModuleManager.paramsRetrieved.isftu;
          window.parent.FxAccountsUI.done({
            reason: 'DECLINE_ACCOUNT_TOS',
            success: false
          });
        } else {
          FxaModuleNavigation.back();
          this.showToastMessage('ERROR_AGREE_TOS');
        }
        break;
      default:
        if (target.id === "account-about-text-link-terms") {
          this.flow = FxaModuleStates.TOS;
          FxaModuleNavigation.next();
        } else if (target.id === "account-about-text-link-privacy") {
          this.flow = FxaModuleStates.ACCOUNT_PRIVACY_POLICY;
          FxaModuleNavigation.next();
        }
        break;
    }
  };

  Module.onNext = function onNext(gotoNextStepCallback) {
    gotoNextStepCallback(this.flow);
  };

  return Module;
})();
