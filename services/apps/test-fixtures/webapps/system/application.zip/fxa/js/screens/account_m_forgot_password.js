﻿/* -*- Mode: Java; tab-width: 2; indent-tabs-mode: nil; c-basic-offset: 2 -*- /
/* vim: set shiftwidth=2 tabstop=2 autoindent cindent expandtab: */

/* global FxaModuleStates, FxaModuleUI, FxaModule, FxaModuleNavigation,
   FxModuleServerRequest, FxaModuleOverlay, $, FxaModuleManager, BrowserFrame */
/* exported FxaModuleSigning */

'use strict';

var AccountModuleForgotPassword = (function () {
  let Module = Object.create(FxaModule);
  let checkFunctions = {
    _checkEmail: function() {
      if (Module.accountIdType !== 'email') {
        return '';
      }

      let emailEl = $('account-reset-email-input');
      let email = emailEl.value;

      if (email && AccountTypeValidator.isEmailValid(emailEl)) {
        emailEl.errorstate = false;
        return '';
      } else {
        emailEl.errorstate = true;
        return 'ERROR_INVALID_EMAIL';
      }
    },
    _checkPhoneNumber: function() {
      if (Module.accountIdType !== 'phone') {
        return '';
      }

      const regionObj = $('account-reset-region').dataset;
      const phoneNumber = $('account-reset-phone-input').value;
      const fullPhoneNumber = regionObj.prefix + phoneNumber;

      loadPhoneUtils(fullPhoneNumber).then(result => {
        if (result) {
          return '';
        } else {
          return 'ERROR_INVALID_PHONE_NUMBER';
        }
      });
    }
  };

  Module.init = function init(options) {
    this.importElements(
      'account-reset-phone',
      'account-reset-phone-slot',
      'account-reset-region',
      'account-reset-phone-input',
      'account-reset-email',
      'account-reset-email-slot',
      'account-reset-email-input',
      'account-reset-pwd-btn'
    );

    this.options = options || {};
    // Hide all buttons
    FxaModuleUI.setButtonsVisible('00');
    FxaModuleUI.setHeaderMenu();
    // To fix the position issue while keyboard popups.
    this.setResetButtonPosition();

    // Check Internet
    this.onLine = navigator.onLine;
    this.accountResetPwdBtn.disabled = !this.onLine;
    if (!this.onLine) {
      this.showToastMessage('ERROR_NO_INTERNET');
    }

    // Initialize the component text with l10n
    this.initL10n();
    this.phoneDisabled = false;
    this.emailDisabled = false;

    if (options.email) {
      // Fill in the email if exists.
      this.accountResetEmailInput.value = options.email;
      this.accountResetPhone.isExtandabled = false;
      this.accountResetEmail.isExtandabled = true;
      this.setPhoneVisible(false);
      this.setEmailVisible(true);
    } else {
      // Default to collapse the separators
      // XXX: we should make sure it works well after bug-69317 is fixed.
      this.accountResetPhone.isExtandabled = false;
      this.accountResetEmail.isExtandabled = false;
      this.setPhoneVisible(false);
      this.setEmailVisible(false);
    }

    if (this.initialized) {
      return;
    }

    // Event listeners
    this.createListeners();
    this.initialized = true;
  };

  Module.initL10n = function initL10n() {
    this.accountResetPhone.label = lget('account-phone');
    this.accountResetRegion.text = lget('account-region');
    this.accountResetRegion.subtext = lget('account-select');
    this.accountResetPhoneInput.label = lget('account-phone-number');
    this.accountResetEmail.label = lget('account-email');
    this.accountResetEmailInput.label = lget('account-email');
    this.accountResetEmailInput.errormessage = lget('error-invalid-email');
    this.accountResetPwdBtn.text = lget('account-reset-pwd');
  };

  Module.createListeners = function createListeners() {
    this.accountResetRegion.addEventListener('change', this);
    this.accountResetRegion.addEventListener('click', this);
    this.accountResetPhone.addEventListener('click', this);
    this.accountResetPhoneInput.addEventListener('change', this);
    this.accountResetEmail.addEventListener('click', this);
    this.accountResetEmailInput.addEventListener('change', this);
    this.accountResetPwdBtn.addEventListener('click', this);
    this.accountResetEmailInput.addEventListener('input', () => {
      if (!this.accountResetEmailInput.value) {
        this.phoneDisabled = false;
      }
    });
    this.accountResetPhoneInput.addEventListener('input', () => {
      if (!this.accountResetPhoneInput.value) {
        this.emailDisabled = false;
      }
    });
  };

  Module.handleClickEvent = function handleClickEvent(evt) {
    const target = evt.target;

    switch(target) {
      case this.accountResetRegion:
        regionSelector.open(target);
        break;
      case this.accountResetPhone:
        this.setPhoneVisible(target.isExtandabled);
        break;
      case this.accountResetPhoneSlot:
        this.setPhoneVisible(target.parentNode.isExtandabled);
        break;
      case this.accountResetEmail:
        this.setEmailVisible(target.isExtandabled);
        break;
      case this.accountResetEmailSlot:
        this.setEmailVisible(target.parentNode.isExtandabled);
        break;
      case this.accountResetPwdBtn:
        const email = this.accountResetEmailInput.value;
        const regionObj = this.accountResetRegion.dataset;
        const phoneNumber = this.accountResetPhoneInput.value;
        const fullPhoneNumber = regionObj.prefix + phoneNumber;
        let error = validateType(checkFunctions);

        if (error) {
          this.showToastMessage(error);
          return;
        }

        // Check account ID and get reset mothods
        this.isUnverifiedEmail = false;
        this.getResetPasswordMethods(fullPhoneNumber, email).then(
          () => FxaModuleNavigation.next(),
          err => {
            if (err.error === 'UNVERIFIED_ACCOUNT') {
              this.isUnverifiedEmail = true;
              FxaModuleManager.setParam('email', email);
              FxaModuleNavigation.next();
            } else {
              this.showToastMessage('ERROR_SERVER_ERROR');
            }
            console.error(err);
          }
        );
        break;
    }
  };

  Module.handleChangeEvent = function handleChangeEvent(evt) {
    const target = evt.target;

    switch (target) {
      case this.accountResetRegion:
        regionSelector.setListItemValue(regionSelector.selected);
        break;
      case this.accountResetPhoneInput:
        this.emailDisabled = false;
        this.switchMode();
        break;
      case this.accountResetEmailInput:
        this.phoneDisabled = false;
        this.switchMode();
        break;
      default:
        break;
    }
  };

  Module.onNext = function onNext(gotoNextStepCallback) {
    if (this.isUnverifiedEmail) {
      gotoNextStepCallback(FxaModuleStates.VERIFY_EMAIL);
      return;
    }

    if (this.options.toEmail) {
      this.sendToEmail(this.options.toEmail, gotoNextStepCallback);
    } else if (this.options.toAltPhone) {
      this.sendToAltPhone(this.options.toAltPhone, gotoNextStepCallback);
    }
  };

  Module.getResetPasswordMethods = function getResetPasswordMethods(
    phone, email
  ) {
    AccountLoader.mask();
    return new Promise((resolve, reject) => {
      let accountId = phone || email;

      FxModuleServerRequest.resetPasswordInit(accountId,
        methods => {
          if(methods.length === 0) {
            this.showToastMessage('ERROR_UNABLE_TO_RESET_PASSWORD');
            AccountLoader.unmask();
            reject();
          }

          methods.forEach(method => {
            if (method.indexOf('@') > -1) {
              FxaModuleManager.setParam('toEmail', method);
            } else {
              FxaModuleManager.setParam('toAltPhone', method);
            }
          });
          AccountLoader.unmask();
          resolve();
        },
        err => {
          AccountLoader.unmask();
          reject(err);
        }
      );
    });
  };

  Module.sendToEmail = function sendToEmail(email, callback) {
    // Make request to reset to email
    FxModuleServerRequest.resetPasswordMethodApply(email,
      () => {
        let dialogMsg = [
          lget('account-reset-pwd'),
          lget('account-reset-pwd-succcess-content'),
          lget('account-dialog-ok'),
          ''
        ];
        FxaModuleNavigation.showDialog(...dialogMsg);
        FxaModuleNavigation.back();
      },
      err => {
        console.error(err);
        this.showToastMessage(err.error);
      }
    );
  };

  Module.sendToAltPhone = function sendToAltPhone(phone, gotoNextStepCallback) {
    // Make request to reset to altPhone
    FxaModuleManager.setParam('phoneForgot', true);
    FxModuleServerRequest.resetPasswordMethodApply(phone,
      () => {
        gotoNextStepCallback(FxaModuleStates.ENTER_PHONE_OTP);
      },
      err => {
        console.error(err);
      }
    );
  }

  Module.setEmailVisible = function setEmailVisible(isVisible) {
    if (this.emailDisabled) {
      return;
    }
    if (isVisible) {
      this.accountResetEmailInput.classList.remove('hidden');
    } else {
      this.accountResetEmailInput.value = '';
      this.accountResetEmailInput.classList.add('hidden');
    }
  };

  Module.setPhoneVisible = function setPhoneVisible(isVisible) {
    if (this.phoneDisabled) {
      return;
    }
    if (isVisible) {
      this.accountResetRegion.classList.remove('hidden');
      this.accountResetPhoneInput.classList.remove('hidden');
    } else {
      this.accountResetRegion.classList.add('hidden');
      this.accountResetPhoneInput.value = '';
      this.accountResetPhoneInput.classList.add('hidden');
    }
  };

  Module.setResetButtonPosition = function setResetButtonPosition() {
    const bodyHeight = document.body.clientHeight;
    this.accountResetPwdBtn.style.top = `calc(${bodyHeight}px - 16rem)`;
  };

  Module.switchMode = function switchMode() {
    if (this.accountResetPhoneInput.value) {
      this.accountIdType = 'phone';
      this.setPhoneVisible(true);
      this.setEmailVisible(false);
      this.accountResetPhone.isExtandabled = true;
      this.accountResetEmail.isExtandabled = false;
      this.phoneDisabled = false;
      this.emailDisabled = true;
    } else if (this.accountResetEmailInput.value) {
      this.accountIdType = 'email';
      this.setEmailVisible(true);
      this.setPhoneVisible(false);
      this.accountResetEmail.isExtandabled = true;
      this.accountResetPhone.isExtandabled = false;
      this.emailDisabled = false;
      this.phoneDisabled = true;
    }
  };

  return Module;
}());
