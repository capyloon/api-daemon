﻿/* -*- Mode: Java; tab-width: 2; indent-tabs-mode: nil; c-basic-offset: 2 -*- /
/* vim: set shiftwidth=2 tabstop=2 autoindent cindent expandtab: */

/* global FxaModuleStates, FxaModuleUI, FxaModule, FxaModuleNavigation,
   FxModuleServerRequest, FxaModuleOverlay, FxaModuleManager, BrowserFrame */
/* exported FxaModuleSigning */

'use strict';

/**
 * This module checks the validity of an email address, and if valid,
 * determines which screen to go next.
 */

var AccountModuleEntry = (function() {
  let onLine = true;
  let Module = Object.create(FxaModule);

  Module.init = function init(options) {
    this.withHeader = false;
    FxaModuleNavigation.stepCount = 1;
    window.focus();

    // Cache DOM elements
    this.importElements(
      'account-entry-create',
      'account-entry-phone-login',
      'account-entry-email-login'
    );

    // check the internet
    onLine = navigator.onLine;
    this.accountEntryCreate.disabled = !onLine;
    this.accountEntryPhoneLogin.disabled = !onLine;
    this.accountEntryEmailLogin.disabled = !onLine;

    if(!onLine) {
      this.showToastMessage('ERROR_NO_INTERNET');
    }

    if (this.initialized) {
      return;
    }

    // l10n
    this.accountEntryCreate.text = lget('account-sign-up');
    this.accountEntryPhoneLogin.text = lget('account-sign-in-with-phone');
    this.accountEntryEmailLogin.text = lget('account-sign-in-with-email');
    // event listeners
    this.accountEntryCreate.addEventListener('click', this);
    this.accountEntryPhoneLogin.addEventListener('click', this);
    this.accountEntryEmailLogin.addEventListener('click', this);

    this.initialized = true;
  };

  Module.handleClickEvent = function handleClickEvent(evt) {
    const target = evt.target;
    switch(target) {
      case this.accountEntryCreate:
        this.entryPoint = AccountModuleFlows.CREATE_ACCOUNT;
        break;
      case this.accountEntryPhoneLogin:
        this.entryPoint = AccountModuleFlows.PHONE_SIGN_IN;
        break;
      case this.accountEntryEmailLogin:
        this.entryPoint = AccountModuleFlows.EMAIL_SIGN_IN;
        break;
    }
    FxaModuleNavigation.next();
  };
  Module.onNext = function onNext(gotoNextStepCallback) {
    let state = null;

    FxaModuleManager.setParam('flow', this.entryPoint);
    switch(this.entryPoint) {
      case AccountModuleFlows.CREATE_ACCOUNT:
        state = FxaModuleStates.ABOUT;
        break;
      case AccountModuleFlows.PHONE_SIGN_IN:
      case AccountModuleFlows.EMAIL_SIGN_IN:
        state = FxaModuleStates.SIGNIN;
        break;
    }

    NavigationMap.currentActivatedLength = 0;
    state && gotoNextStepCallback(state);
  };

  return Module;
}());
