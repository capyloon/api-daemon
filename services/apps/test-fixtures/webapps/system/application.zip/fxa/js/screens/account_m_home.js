'use strict';

var AccountModuleHome = (function() {
  let Module = Object.create(FxaModule);

  Module.init = function init(options) {
    this.importElements(
      'account-home-status',
      'account-home-service-separator',
      'account-home-service-wallet',
      'account-home-service-payment',
      'account-home-service-antitheft',
      'account-home-other-separator',
      'account-home-other-accounts-container',
      'account-home-add-other-button'
    );

    this.options = options || {};
    this.login = false;
    this.action = null;

    // Hide all buttons
    FxaModuleUI.setButtonsVisible('00');
    FxaModuleUI.setHeaderMenu();

    this.setAccountInfo();

    if (this.initialized) {
      return;
    }
    this.initL10n();
    this.createListeners();
    this.initialized = true;
  };

  Module.initL10n = function initL10n() {
    this.accountHomeStatus.text = lget('account-kaios');
    this.accountHomeServiceSeparator.label = lget('account-home-kaios-service');
    this.accountHomeServiceWallet.text = lget('account-wallet');
    this.accountHomeServicePayment.text = lget('account-payment');
    this.accountHomeServiceAntitheft.text = lget('account-antitheft');
    this.accountHomeOtherSeparator.label = lget('account-home-other-accounts');
    this.accountHomeAddOtherButton.text = lget('account-home-add-other-account');
  };

  Module.createListeners = function createListeners() {
    this.accountHomeStatus.addEventListener('click', this);
    this.accountHomeAddOtherButton.addEventListener('click', this);
  };

  Module.setAccountInfo = function setAccountInfo() {
    /**
     * XXX: Use Gecko API to get account info.
     */
    this.accountHomeStatus.subtext = lget('account-not-signed-in');
    this.accountHomeServiceWallet.subtext = lget('account-service-disabled');
    this.accountHomeServicePayment.subtext = lget('account-service-disabled');
    this.accountHomeServiceAntitheft.subtext = lget('account-service-off');
  };

  Module.handleClickEvent = function handleClickEvent(evt) {
    const target = evt.target;

    switch(target) {
      case this.accountHomeStatus:
        if (this.login) {
          this.nextPage = FxaModuleStates.ACCOUNT_INFO;
        } else {
          this.nextPage = FxaModuleStates.ENTRY;
        }
        FxaModuleNavigation.next();
        break;
    }
  };

  Module.onNext = function onNext(gotoNextStepCallback) {
    gotoNextStepCallback(this.nextPage);
  };

  return Module;
}());
