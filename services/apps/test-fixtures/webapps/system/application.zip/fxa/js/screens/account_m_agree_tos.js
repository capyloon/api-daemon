'use strict';

var AccountModuleAgreeToS = (function() {
  let Module = Object.create(FxaModule);

  Module.init = function init(options) {
    this.nextPage = 'PHONE_VERIFICATION';
    this.importElements(
      'account-agree-tos-button',
      'account-agree-tos-agree',
      'account-agree-tos-agree-checkbox'
    );
    this.options = options || {};

    // Show the buttons: Cancel & Next
    FxaModuleUI.setButtonsVisible('11');
    FxaModuleUI.setHeaderMenu();

    if (this.initialized) {
      return;
    }

    this.accountAgreeTosButton.text = lget('account-tos');
    this.accountAgreeTosAgree.text = lget('account-agree-tos');

    this.accountAgreeTosButton.addEventListener('click', () => {
      this.nextPage = 'VIEW_TOS';
      FxaModuleNavigation.next();
    });

    this.initialized = true;
  };

  Module.dialogPrimaryBtnHandler = function dialogPrimaryBtnHandler() {
    FxaModuleNavigation.goBackByStepIndex(1);
  };

  Module.onCancel = function onCancel(showDialog) {
    showDialog(...this.options['signup_leave_msg']);
  };

  Module.onNext = function onNext(gotoNextStepCallback) {
    let state = null;

    switch(this.nextPage) {
      case 'VIEW_TOS':
        state = FxaModuleStates.TOS;
        break;
      default:
        state = FxaModuleStates.ENTER_PHONE_OTP;
        if (!this.accountAgreeTosAgreeCheckbox.checked) {
          this.showToastMessage('ERROR_AGREE_TOS');
          return;
        }
        break;
    }
    gotoNextStepCallback(state);
  };

  return Module;
}());
