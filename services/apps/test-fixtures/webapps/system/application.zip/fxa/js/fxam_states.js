/* -*- Mode: Java; tab-width: 2; indent-tabs-mode: nil; c-basic-offset: 2 -*- /
/* vim: set shiftwidth=2 tabstop=2 autoindent cindent expandtab: */

/* global FxaModuleNavigation */
/* exported FxaModuleStates */

'use strict';

/*
 * Define the states of the firefox accounts signup/signin flow.
 * The object key defines the state name, the value is the
 * URL hash of the screen to show. done is a special state that has no
 * corresponding screen.
 */

var FxaModuleStates = (function() {
  return {
    HOME: {
      id: 'account-home',
      module: 'AccountModuleHome'
    },
    ENTRY: {
      id: 'account-entry',
      module: 'AccountModuleEntry'
    },
    ABOUT: {
      id: 'account-about',
      module: 'AccountModuleAbout'
    },
    REGISTER: {
      id: 'account-register',
      module: 'AccountModuleRegister'
    },
    ENTER_ACCOUNT_INFO: {
      id: 'account-enter-info',
      module: 'AccountModuleEnterAccountInfo'
    },
    PASSWORD_RETRIEVAL: {
      id: 'account-password-retrieval',
      module: 'AccountModulePasswordRetrieval'
    },
    AGREE_TOS: {
      id: 'account-agree-tos',
      module: 'AccountModuleAgreeToS'
    },
    TOS: {
      id: 'account-tos',
      module: 'AccountModuleToS'
    },
    ENTER_PHONE_OTP: {
      id: 'account-enter-otp',
      module: 'AccountModuleEnterOTP'
    },
    SIGNUP_SUCCESS: {
      id: 'account-signup-success',
      module: 'AccountModuleSignupSuccess'
    },
    SIGNIN: {
      id: 'account-sign-in',
      module: 'AccountModuleSignIn'
    },
    ACCOUNT_INFO: {
      id: 'account-info',
      module: 'AccountModuleInfo'
    },
    FORGOT_PASSWORD: {
      id: 'account-forgot-password',
      module: 'AccountModuleForgotPassword'
    },
    VERIFY_EMAIL: {
      id: 'account-verify-email',
      module: 'AccountModuleVerifyEmail'
    },
    CHANGE_PASSWORD: {
      id: 'account-change-password',
      module: 'AccountModuleChangePassword'
    },
    CHECK_PASSWORD: {
      id: 'account-check-password',
      module: 'AccountModuleCheckPassword'
    },
    EDIT_INFO: {
      id: 'account-edit-info',
      module: 'AccountModuleEditInfo'
    },
    DELETE: {
      id: 'account-delete',
      module: 'AccountModuleDelete'
    },
    SIGN_OUT: {
      id: 'account-sign-out',
      module: 'AccountModuleSignOut'
    },
    ANTI_THEFT_RECONFIRM: {
      id: 'account-antitheft-reconfirm',
      module: 'AccountModuleAntitheftReconfirm'
    },
    ANTI_THEFT_DISABLE: {
      id: 'account-antitheft-disable',
      module: 'AccountAntitheftDisable'
    },
    ACCOUNT_PRIVACY_POLICY: {
      id: 'account-privacy-policy',
      module: 'AccountModulePrivacy',
    },
    DONE: null,

    back: function() {
      FxaModuleNavigation.back();
    },

    setState: function setState(state) {
      if (!(state in this) || typeof state === 'function') {
        return;
      }
      document.location.hash = state.id;
    }
  };
})();
