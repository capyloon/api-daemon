/* -*- Mode: Java; tab-width: 2; indent-tabs-mode: nil; c-basic-offset: 2 -*- /
/* vim: set shiftwidth=2 tabstop=2 autoindent cindent expandtab: */

/* global FxaModule, FxaModuleManager, $, ViewManager, NavigationMap,
          FxModuleServerRequest, FxaModuleOverlay */
/* exported AccountModuleChangePassword */

'use strict';

/**
 * This module checks the validity of password given phone number or
 * email address, and if valid, determine which screen to change password.
 */

var AccountModuleChangePassword = (function() {
  const oldPasswordEl = $('account-chgpwd-old');
  const newPasswordEl = $('account-chgpwd-new');
  const confirmPasswordEl = $('account-chgpwd-confirm');
  const showPasswordEl = $('account-chgpwd-show-checkbox');

  let Module = Object.create(FxaModule);
  let checkFunctions = {
    _checkPassword: function() {
      const newPassword = newPasswordEl.value;
      const confirmPassword = confirmPasswordEl.value;

      oldPasswordEl.errorstate = false;
      newPasswordEl.errorstate = false;
      confirmPasswordEl.errorstate = false;

      if (!newPassword || newPassword.length < 8) {
        newPasswordEl.errorstate = true;
        return 'ERROR_PASSWORD_LESS';
      }
      if (newPassword.length > 20) {
        newPasswordEl.errorstate = true;
        return 'ERROR_PASSWORD_MORE';
      }
      if (newPassword !== confirmPassword) {
        newPasswordEl.errorstate = true;
        confirmPasswordEl.errorstate = true;
        return 'ERROR_PASSWORD_DONT_MATCH';
      }
      if (!/^(?![^a-zA-Z]+$)(?!\D+$).{8,20}$/.test(newPassword)) {
        newPasswordEl.errorstate = true;
        return 'ERROR_INVALID_PASSWORD';
      }
      return '';
    }
  };

  function _clearFrom() {
    oldPasswordEl.value = '';
    newPasswordEl.value = '';
    confirmPasswordEl.value = '';
    showPasswordEl.checked = false;
  }

  Module.init = function init(options) {
    this.options = options || {};
    this.action = AccountModuleFlows.CHANGE_PWD;

    if (!this.initialized) {
      // Cache DOM elements
      this.importElements(
        'account-chgpwd-old',
        'account-chgpwd-new',
        'account-chgpwd-new-tips',
        'account-chgpwd-confirm',
        'account-chgpwd-show',
        'account-chgpwd-show-checkbox',
        'account-chgpwd-forgot-pwd-link'
      );

      // Create listeners
      this.createListeners();
      // Avoid repeated initialization
      this.initialized = true;
    }

    this.initL10n();
    FxaModuleUI.setButtonsVisible('11');
    FxaModuleUI.setHeaderMenu();
    FxaModuleUI.setNextText(lget('account-next'));
    _clearFrom();
  };

  Module.initL10n = function initL10n() {
    this.accountChgpwdOld.label = lget('account-password');
    this.accountChgpwdNew.label = lget('account-change-password-new-pwd');
    this.accountChgpwdConfirm.label =
      lget('account-change-password-confirm-pwd');
    this.accountChgpwdShow.text = lget('account-show-password');
  };

  Module.createListeners = function createListeners() {
    this.accountChgpwdShowCheckbox.addEventListener('click', this);
    this.accountChgpwdForgotPwdLink.addEventListener('click', this);
    this.accountChgpwdNew.addEventListener('focus', this);
    this.accountChgpwdNew.addEventListener('blur', this);
  };

  Module.handleClickEvent = function handleClickEvent(evt) {
    const target = evt.target;

    switch (target) {
      case this.accountChgpwdShowCheckbox:
        let inputType = target.checked ? 'text' : 'password';

        this.accountChgpwdOld.type = inputType;
        this.accountChgpwdNew.type = inputType;
        this.accountChgpwdConfirm.type = inputType;
        break;
      case this.accountChgpwdForgotPwdLink:
        this.action = AccountModuleFlows.FORGOT_PWD;
        FxaModuleNavigation.next();
        break;
    }
  };

  Module.handleFocusEvent = function handleFocusEvent(evt) {
    const target = evt.target;

    switch (target) {
      case this.accountChgpwdNew:
        this.accountChgpwdNewTips.classList.add('focusInput');
        break;
    }
  };

  Module.handleBlurEvent = function handleBlurEvent(evt) {
    const target = evt.target;

    switch (target) {
      case this.accountChgpwdNew:
        this.accountChgpwdNewTips.classList.remove('focusInput');
        break;
    }
  };

  Module.onCancel = function onCancel(showDialog) {
    FxaModuleNavigation.back();
  };

  Module.onNext = function onNext(gotoNextStepCallback) {
    switch (this.action) {
      case AccountModuleFlows.CHANGE_PWD:
        const oldPassword = this.accountChgpwdOld.value;
        const newPassword = this.accountChgpwdNew.value;
        let error = validateType(checkFunctions);

        if (error) {
          this.showToastMessage(error);
          return;
        }
        // Change password via Gecko API, and handle wrong time interval here
        this.changePassword(oldPassword, newPassword, gotoNextStepCallback);
        break;
      case AccountModuleFlows.FORGOT_PWD:
        gotoNextStepCallback(FxaModuleStates.FORGOT_PASSWORD);
        break;
      default:
        break;
    }
  };

  Module.changePassword = function changePassword(oldPwd, newPwd, callback) {
    // Enable loading mask
    AccountLoader.mask();
    // Reset error status
    this.accountChgpwdOld.errorstate = false;
    this.accountChgpwdNew.errorstate = false;
    this.accountChgpwdConfirm.errorstate = false;
    // Change password
    FxModuleServerRequest.changePassword(oldPwd, newPwd,
      () => {
        AccountLoader.unmask();
        InvalidPasswordHelper.resetWrongTimes();
        this.showToastMessage('NOTIFY_CHANGE_PASSWORD_SUCCESS');
        callback && callback(FxaModuleStates.ACCOUNT_INFO);
      },
      err => {
        AccountLoader.unmask();
        switch (err.error) {
          case 'INVALID_PASSWORD':
            InvalidPasswordHelper.setWrongTimes();
            this.accountChgpwdOld.errorstate = true;
            this.showToastMessage('ERROR_PASSWORD_INCORRECT');
            break;
          default:
            console.error('[Account] Checking password error.', err);
            this.showToastMessage('ERROR_SERVER_ERROR');
            break;
        }
      }
    );
  };

  return Module;
})();
