/* -*- Mode: Java; tab-width: 2; indent-tabs-mode: nil; c-basic-offset: 2 -*- /
/* vim: set shiftwidth=2 tabstop=2 autoindent cindent expandtab: */

/* global SettingsHelper, FxaModuleManager, MozActivity, NavigationMap */

'use strict';

/*
 * FxModuleServerRequest wraps the functionality exposed by the server,
 * letting our code to be shielded against changes in the API of FxA.
 */

(function(exports) {
  var pref = 'identity.fxaccounts.reset-password.url';
  var fxaSettingsHelper = SettingsHelper(pref);
  var fxaURL;

  fxaSettingsHelper.get(function on_fxa_get_settings(url) {
    fxaURL = url;
  });

  var hostKey = 'identity.kaiaccounts.api.uri';
  var host = 'https://api.kaiostech.com';

  var resetPasswordInfo = {};

  SettingsHelper(hostKey).get(function(url) {
    if (!url) {
      return;
    }
    host = url;
  });

  function _setAccountDetails(response) {
    if (
      response && response.user &&
      (response.user.email || response.user.phoneNumber)
    ) {
      FxaModuleManager.setParam('verified', response.user.verified);
      FxaModuleManager.setParam('done', true);
    }
  }

  function _ensureFxaClient(callback) {
    window.parent.LazyLoader.load('../js/fxa_client.js', function() {
      callback && callback();
    });
  }

  var verifyRestPwdRsp = function verifyRestPwdRsp (resp) {
    if (
      !resp || !resp.id || !resp.contact ||
      !Array.isArray(resp.methods) || resp.methods.length === 0
    ) {
      return false;
    }
    /*
    {
      "id": "K57aMTe79g5T-wxQexpd9w_6em9zermlSH34EmE-",
      "contact": "+19495069988",
      "methods": [
        "jo**.***th@exmaple.com",
        "+1******4321"
      ]
    }
    */
    resetPasswordInfo = resp;
    return true;
  };

  var FxModuleServerRequest = {
    getAccounts: function(onsuccess, onerror, fromServer = false) {
      _ensureFxaClient(function() {
        window.parent.FxAccountsClient
          .getAccounts(onsuccess, onerror, fromServer);
      });
    },
    // Request OTP
    requestPhoneVerification: function(phone, altPhone, onsuccess, onerror) {
      _ensureFxaClient(function() {
        window.parent.FxAccountsClient
          .requestPhoneVerification(phone, altPhone, onsuccess, onerror);
      });
    },

    // OTP Verification
    resolvePhoneVerification: function(
      phone, altPhone, verificationId, code, onsuccess, onerror
    ) {
      _ensureFxaClient(function() {
        window.parent.FxAccountsClient.resolvePhoneVerification(
          phone, altPhone, verificationId, code, onsuccess, onerror
        );
      });
    },

    // Send the verificaition email
    requestEmailVerification: function(email, altEmail, onsuccess, onerror) {
      _ensureFxaClient(function() {
        window.parent.FxAccountsClient
          .requestEmailVerification(email, altEmail, onsuccess, onerror);
      });
    },

    // Check the email exists or not
    checkEmailExistence: function fxmsr_checkEmailExistence(
      email, onsuccess, onerror
    ) {
      _ensureFxaClient(function() {
        window.parent.FxAccountsClient
          .checkEmailExistence(email, onsuccess, onerror);
      });
    },

    // Check the phone number exists or not
    checkPhoneExistence: function fxmsr_checkPhoneExistence(
      phone, onsuccess, onerror
    ) {
      _ensureFxaClient(function() {
        window.parent.FxAccountsClient
          .checkPhoneExistence(phone, onsuccess, onerror);
      });
    },

    // Sign in with accountId (phone or email) and password
    signIn: function fxmsr_signIn(accountId, password, onsuccess, onerror) {
      let successHandler = response => {
        let authenticated =
          (response && response.user && (response.user.verified ||
          response.user.phoneVerified || response.user.emailVerified)) || false;

        _setAccountDetails(response);
        onsuccess && onsuccess({ authenticated: authenticated });
      };
      let errorHandler = response => {
        onerror && onerror(response);
      };

      _ensureFxaClient(function signIn() {
        window.parent.FxAccountsClient
          .signIn(accountId, password, successHandler, errorHandler);
      });
    },

    // Delete KaiOS account (sign-in required)
    deleteAccount: function fxmsr_deleteAccount(onsuccess, onerror) {
      _ensureFxaClient(function() {
        window.parent.FxAccountsClient.deleteAccount(onsuccess, onerror);
      });
    },

    // Logout KaiOS account (sign-in required)
    logout: function fxmsr_logout(onsuccess, onerror) {
      _ensureFxaClient(function() {
        window.parent.FxAccountsClient.logout(onsuccess, onerror);
      });
    },

    // Update account infomation (sign-in required)
    // Note: altPhone, altEmail, yob, birthday, gender are set into info object.
    updateAccount: function fxmsr_updateAccount(
      phone, email, password, info, onsuccess, onerror
    ) {
      let successHandler = response => {
        _setAccountDetails(response);
        onsuccess && onsuccess(response);
      };

      NavigationMap.currentActivatedLength = 1;
      _ensureFxaClient(function updateAccount() {
        window.parent.FxAccountsClient
          .updateAccount(phone, email, password, info, successHandler, onerror);
      });
    },

    // Create a KaiOS account
    // Note: altPhone, altEmail, yob, birthday, gender are set into info object.
    signUp: function fxmsr_signUp(
      phone, email, password, info, onsuccess, onerror
    ) {
      let successHandler = response => {
        _setAccountDetails(response);
        onsuccess && onsuccess(response);
      };

      _ensureFxaClient(function signUp() {
        window.parent.FxAccountsClient
          .signUp(phone, email, password, info, successHandler, onerror);
      });
    },

    requestPasswordReset: function fxmsr_requestPasswordReset(
      email, onsuccess, onerror
    ) {
      var url = email ? fxaURL + '?email=' + email : fxaURL;
      var activity = new MozActivity({
        name: 'view',
        data: {
          type: 'url',
          url: url
        }
      });
      activity.onsuccess = function on_reset_success() {
        // XXX: When the browser loads, it is *behind* the system app. So we
        // need to dismiss this app in order to let the user reset their
        // password.
        onsuccess && onsuccess();
        FxaModuleManager.close();
      };
      activity.onerror = function on_reset_error(err) {
        console.error(err);
        onerror && onerror(err);
      };
    },

    resetPasswordInit: function fxmsr_resetPasswordInit(
      accountId, onsuccess, onerror
    ) {
      var extraParams = {
        contact: accountId,
        step: 1
      };
      var reqMethod = 'POST';
      FxModuleServerRequest.resetPassword(extraParams, reqMethod,
        resp => {
          if(!verifyRestPwdRsp(resp)) {
            onerror && onerror({ error: 'UNKNOWN' });
            return;
          }
          onsuccess && onsuccess(resp.methods);
        },
        onerror
      );
    },

    resetPasswordMethodApply: function fxmsr_resetPasswordMethodApply(
      method, onsuccess, onerror
    ) {
      if (
        !resetPasswordInfo.id || !method ||
        !Array.isArray(resetPasswordInfo.methods) ||
        resetPasswordInfo.methods.length === 0
      ) {
        onerror && onerror({ error: 'UNKNOWN' });
        return;
      }

      var extraParams = {};
      var reqMethod = 'PUT';

      extraParams.id = resetPasswordInfo.id;
      extraParams.method = method;
      extraParams.contact = resetPasswordInfo.contact;
      extraParams.step = 2;
      resetPasswordInfo.method = method;

      FxModuleServerRequest.resetPassword(
        extraParams, reqMethod, onsuccess, onerror
      );
    },

    resetPasswordPhoneValidate: function fxmsr_resetPasswordPhoneValidate(
      code, onsuccess, onerror
    ) {
      if (
        !resetPasswordInfo.id || !resetPasswordInfo.method || !code ||
        !Array.isArray(resetPasswordInfo.methods) ||
        resetPasswordInfo.methods.length === 0
      ) {
        onerror && onerror({ error: 'UNKNOWN' });
        return;
      }

      var extraParams = {};
      var reqMethod = 'PUT';

      extraParams.id = resetPasswordInfo.id;
      extraParams.method = resetPasswordInfo.method;
      extraParams.contact = resetPasswordInfo.contact;
      extraParams.code = code;
      extraParams.step = 3;

      FxModuleServerRequest.resetPassword(
        extraParams, reqMethod,
        resp => {
          if (!resp || (resp && !resp.link)) {
            onerror && onerror({ error: 'UNKNOWN' });
            return;
          }
          onsuccess && onsuccess(resp.link);
        },
        onerror
      );
    },

    resetPassword: function fxmsr_resetpassword(
      extraParams, reqMethod, onsuccess, onerror
    ) {
      if (!navigator.onLine) {
        onerror && onerror({ error: 'OFFLINE' });
        return;
      }
      if (extraParams && !extraParams.contact) {
        onerror && onerror({ error: 'UNKNOWN' });
        return;
      }

      var id = '';
      var step = 1;
      var params = {
        contact: extraParams.contact,
      };

      if (extraParams && extraParams.id) {
        params.id = extraParams.id;
        id = '/' + params.id;
      }
      if (extraParams && extraParams.method) {
        params.method = extraParams.method;
      }
      if (extraParams && extraParams.code) {
        params.code = extraParams.code;
      }
      if (extraParams && extraParams.step) {
        step = extraParams.step;
      }

      var api = '/core/v1.0/accounts/password_reset' + id;
      var method = reqMethod;
      var url = host + api;
      var xhr = new XMLHttpRequest({ mozSystem: true });

      xhr.open(method, url);
      xhr.timeout = 30000;
      xhr.setRequestHeader('Content-Type', 'application/json');
      xhr.onload = function fmdr_xhr_onload() {
        // We have 2 or 3 steps to do password reset.
        // Differentiate error messages based on the step number
        if (xhr.status >= 200 && xhr.status < 300) {
          var obj = null;
          try {
            obj = JSON.parse(xhr.response);
          } catch (e) {}
          onsuccess && onsuccess(obj);
        } else if (xhr.status == 404) {
          if (step === 1) {
            onerror && onerror({ error: 'ACCOUNT_DOES_NOT_EXIST' });
          } else if (step === 3) {
            onerror && onerror({ error: 'VERIFICATION_FAILED' });
          } else {
            xhr.onerror();
          }
        } else if (xhr.status == 400) {
          if (step === 1) {
            onerror && onerror({ error: 'NO_RETRIEVALE_METHOD' });
          } else {
            xhr.onerror();
          }
        } else if (xhr.status == 424) {
          onerror && onerror({ error: 'UNVERIFIED_ACCOUNT' });
        } else {
          xhr.onerror();
        }
      };
      xhr.onerror = function fmd_xhr_onerror() {
        onerror && onerror({ error: 'UNKNOWN' });
      };
      xhr.ontimeout = function fmd_xhr_ontimeout() {
        xhr.onerror();
      };
      xhr.send(JSON.stringify(params));
    },

    // Change Password
    changePassword: function fxmsr_changePassword(
      oldPassword, newPassword, onsuccess, onerror
    ) {
      let successHandler = response => {
        _setAccountDetails(response);
        onsuccess && onsuccess(response);
      };

      NavigationMap.currentActivatedLength = 1;
      _ensureFxaClient(function changePassword() {
        window.parent.FxAccountsClient
          .changePassword(oldPassword, newPassword, successHandler, onerror);
      });
    }
  };
  exports.FxModuleServerRequest = FxModuleServerRequest;
})(window);
