/* -*- Mode: Java; tab-width: 2; indent-tabs-mode: nil; c-basic-offset: 2 -*- /
/* vim: set shiftwidth=2 tabstop=2 autoindent cindent expandtab: */

/* global HtmlHelper, FxaModuleOverlay, LazyLoader, FxaModuleErrors,
   FxaModuleErrorOverlay */
/* exported FxaModule */

'use strict';

var FxaModule = (function() {

  var Module = {
    initialized: false,
    withHeader: true,
    init: function fxam_init() {
      // override this to do initialization
      // l10n note: this method is called after mozL10n.once has fired. It is
      // safe to assume strings have loaded and mozL10n.readyState is 'complete'
      // inside this function and other Module functions.
    },

    handleEvent: function fxam_handleEvent(evt) {
      const type = evt.type;

      switch(type) {
        case 'click':
          this.handleClickEvent(evt);
          break;
        case 'change':
          this.handleChangeEvent(evt);
          break;
        case 'focus':
          this.handleFocusEvent(evt);
          break;
        case 'blur':
          this.handleBlurEvent(evt);
          break;
      }
    },

    handleClickEvent: function fxam_handleClickEvent(evt) {
      // handle click event here
    },

    handleChangeEvent: function fxam_handleChangeEvent(evt) {
      // handle change event here
    },

    handleFocusEvent: function fxam_handleFocusEvent(evt) {
      // handle focus event here
    },

    handleBlurEvent: function fxam_handleBlurEvent(evt) {
      // handle blur event here
    },

    dialogPrimaryBtnHandler: function fxam_dialogPrimaryBtnHandler() {
      // handle the primary button on the dialog
    },

    dialogSecondaryBtnHandler: function fxam_dialogSecondaryBtnHandler() {
      // handle the secondary button on the dialog
    },

    onCancel: function fxam_onNext(showLeaveDailog) {
      // handle "cancel" button presses.
    },

    onNext: function fxam_onNext(gotoNextStepCallback) {
      // override this to take care of when the user clicks on the "next"
      // button. Validate any inputs, talk with the backend, do processing.
      // When complete, call gotoNextStepCallback with the next state from
      // fxam_states.js
    },

    onBack: function fxam_onBack(gotoBackStepCallback) {
      // handle "back" button presses.
    },

    onDone: function fxam_onDone(doneCallback) {
      doneCallback();
    },

    importElements: function fxam_importElements() {
      var args = [].slice.call(arguments);
      // context to import into is the first argument to importElements
      args.unshift(this);
      HtmlHelper.importElements.apply(null, args);
    },

    showToastMessage: function fxam_showToastMessage(msg, translated=false) {
      // XXX TODO: Modify here if system app supports the toast.
      if(!translated) {
        msg = lget(msg.toLowerCase().replace(/_/g, '-'));
      }
      AccountToaster.showToast(msg);
    }
  };

  return Module;

}());

