/* -*- Mode: Java; tab-width: 2; indent-tabs-mode: nil; c-basic-offset: 2 -*- /
/* vim: set shiftwidth=2 tabstop=2 autoindent cindent expandtab: */

/* global FxaModule, FxaModuleNavigation, FxModuleServerRequest,
          FxaModuleManager, ViewManager, NavigationMap, $ */
/* exported FxaModuleEnterOTP */

'use strict';

/**
 * This module wait the OTP of a phone number. Once it get the OTP,
 * sign in the account with the phone number, OTP.
 * Then, determines which screen to go next according to receive OTP
 * or not, server response.
 */

var AccountModuleEnterOTP = (function() {
  var endTime;
  var countdownTimer = null;
  var COUNTDOWN_TIME = 2 * 60 * 1000;
  var COUNTDOWN_INTERVAL_TIME = 1000;
  var DEBUG = false;

  function _debug(msg) {
    if (DEBUG) {
      console.log(msg);
    }
  }

  function _fillInCode(otp, containerEl) {
    let spanAry = containerEl.querySelectorAll('.digital');

    if (otp === '') {
      spanAry.forEach(el => {
        el.classList = 'digital';
        el.setAttribute('data-icon', '');
      });
    } else {
      if (typeof otp === 'string' && otp.length <= 4) {
        spanAry.forEach((el, idx) => {
          el.classList.add('fillin');
          el.setAttribute(
            'data-icon',
            'numeric_' + otp[idx] + '_rounded_semibold'
          );
        });
      } else {
        _debug(otp);
      }
    }
  }

  function _getTimeRemaining(endTime) {
    var t = Date.parse(endTime) - Date.parse(new Date());
    var seconds = Math.floor((t / 1000) % 60);
    var minutes = Math.floor((t / 1000 / 60) % 60);
    return {
      total: t,
      minutes: minutes,
      seconds: seconds
    };
  }

  var Module = Object.create(FxaModule);
  Module.init = function init(options) {
    // Cache static HTML elements
    this.importElements(
      'account-sms-fill-mode',
      'account-sms-resend-mode',
      'account-time-remaining',
      'account-otp-container',
      'account-resend-sms',
      'account-invisible-input'
    );

    FxaModuleUI.setButtonsVisible('10');
    FxaModuleUI.setCancelButtonLevel();
    FxaModuleUI.setHeaderMenu();
    // To fix the position issue while keyboard popups.
    this.setResendButtonPosition();

    this.startCountdownRemaningTime();
    this.options = options || {};
    this.flow = this.options.flow;
    this.switchToResend(false);

    // set the different infomation text by flow
    let msgEl = this.accountSmsFillMode.querySelector('.fine-print');
    let failMsgEl = this.accountSmsResendMode.querySelector('.fine-print');
    let l10nId = '';
    let failL10nId = '';

    if (this.options.phoneForgot) {
      l10nId = 'account-enter-passcode';
      failL10nId = 'account-sms-verification-failed1';
      this.resetOtp();
    } else {
      switch (this.flow) {
        case AccountModuleFlows.CREATE_ACCOUNT:
          l10nId = 'account-signup-sms-has-been-sent';
          failL10nId = 'account-sms-verification-failed';
          break;
        case AccountModuleFlows.PHONE_SIGN_IN:
          l10nId = 'account-signin-sms-has-been-sent';
          failL10nId = 'account-sms-verification-failed';
          break;
        case AccountModuleFlows.VERIFY_ALT_PHONE:
        case AccountModuleFlows.EDIT_ALT_PHONE:
          l10nId = 'account-verify-sms-has-been-sent';
          failL10nId = 'account-sms-verification-failed1';
          this.resetOtp();
          break;
        default:
          break;
      }
    }

    msgEl.setAttribute('data-l10n-id', l10nId);
    failMsgEl.setAttribute('data-l10n-id', failL10nId);

    this.accountResendSms.text = lget('account-resend-sms');
    _fillInCode('', this.accountOtpContainer);

    if (this.initialized) {
      return;
    }

    // event listener
    this.accountResendSms.addEventListener('click', this);
    this.accountOtpContainer.addEventListener('click', this);
    this.accountInvisibleInput.addEventListener('input', this.inputChangeHandler.bind(this));
    this.initialized = true;
  };

  Module.handleClickEvent = function handleClickEvent(evt) {
    const target = evt.target;

    switch (target) {
      case this.accountResendSms:
        if (this.options.phoneForgot) {
          this.requestPhoneVerification(this.options.toAltPhone);
        } else {
          this.requestPhoneVerification(this.options.phone);
        }
        break;
      case this.accountOtpContainer:
        if (
          this.flow === AccountModuleFlows.EDIT_ALT_PHONE ||
          this.flow === AccountModuleFlows.VERIFY_ALT_PHONE
        ) {
          this.accountInvisibleInput.focus();
        }
        break;
      default:
        break;
    }
  };

  Module.inputChangeHandler = function inputChangeHandler(evt) {
    // XXX: Due to catch two input event here which are fired by the input
    // element and web-component, so we need to eliminate one of them to
    // avoid executing twice.
    if (evt.isComposing) {
      const str = evt.target.value;
      const len = str.length;

      if (len > 0) {
        let char = str.slice(len - 1, len);
        // To check the character is digital or not.
        if (char >= '0' && char <= '9') {
          this.manualOtp += char;
        }
        this.manualOtp = this.manualOtp.slice(0, 4);
        _fillInCode(this.manualOtp, this.accountOtpContainer);
        if (this.manualOtp.length === 4) {
          this.accountInvisibleInput.blur();
          setTimeout(() => {
            this.resolvePhoneVerification(this.manualOtp, true);
          }, 500);
        }
      }
    }
  };

  Module.startCountdownRemaningTime = function() {
    this.stopCountdownRemaningTime();
    // Create deadline 2 minutes from now.
    var currentTime = Date.parse(new Date());
    endTime = new Date(currentTime + COUNTDOWN_TIME);
    // Set interval timer to refresh remaining time.
    countdownTimer = setInterval(() => {
      this.updateRemainingTime();
    }, COUNTDOWN_INTERVAL_TIME);
  };

  Module.stopCountdownRemaningTime = function() {
    if (countdownTimer) {
      clearInterval(countdownTimer);
      endTime = null;
    }
  };

  Module.updateRemainingTime = function() {
    var currentTimeRemaining = _getTimeRemaining(endTime);
    this.accountTimeRemaining.textContent =
      currentTimeRemaining.minutes +
      ':' +
      ('0' + currentTimeRemaining.seconds).slice(-2);

    if (currentTimeRemaining.total <= 0 && countdownTimer) {
      // Timeout: User might have to resend message.
      this.stopCountdownRemaningTime();
      this.switchToResend(true);
    }
  };

  Module.requestPhoneVerification = function requestPhoneVerification(phone) {
    if (this.options.phoneForgot) {
      FxModuleServerRequest.resetPasswordMethodApply(phone,
        () => {
          this.startCountdownRemaningTime();
          this.switchToResend(false);
          this.resetOtp();
        },
        err => {
          console.error('[Account] Request OTP error.', err);
          this.stopCountdownRemaningTime();
          this.switchToResend(true);
          this.showToastMessage('ERROR_SERVER_ERROR');
        }
      );
    } else {
      switch (this.flow) {
        case AccountModuleFlows.VERIFY_ALT_PHONE:
        case AccountModuleFlows.EDIT_ALT_PHONE:
          const accountPhone = this.options.user.phone;
          const altPhone = phone;

          FxModuleServerRequest.requestPhoneVerification(
            accountPhone, altPhone,
            response => {
              if (!response || (response && !response.verificationId)) {
                console.error(
                  '[Account] Request OTP: response without verificationId.'
                );
                return;
              }
              FxaModuleManager.paramsRetrieved.verificationId =
                response.verificationId;
              this.startCountdownRemaningTime();
              this.switchToResend(false);
              this.resetOtp();
            },
            err => {
              console.error('[Account] Request OTP error.', err);
              this.stopCountdownRemaningTime();
              this.switchToResend(true);
              this.showToastMessage('ERROR_SERVER_ERROR');
            }
          );
          break;
        default:
          FxModuleServerRequest.requestPhoneVerification(
            phone, '',
            response => {
              if (!response || (response && !response.verificationId)) {
                console.error(
                  '[Account] Request OTP: response without verificationId.'
                );
                return;
              }
              FxaModuleManager.paramsRetrieved.verificationId =
                response.verificationId;
              this.startCountdownRemaningTime();
              this.switchToResend(false);
            },
            err => {
              console.error('[Account] Request OTP error.', err);
              this.stopCountdownRemaningTime();
              this.switchToResend(true);
              this.showToastMessage('ERROR_SERVER_ERROR');
            }
          );
          break;
      }
    }
  };

  Module.resolvePhoneVerification = function resolvePhoneVerification(
    otp, isManual = false
  ) {
    if (this.options.phoneForgot) {
      console.log(otp);
      FxModuleServerRequest.resetPasswordPhoneValidate(otp,
        link => {
          window.parent.FxAccountsUI.showUrl(link);
          window.parent.FxAccountsUI.done();
        },
        err => {
          this.resetOtp();
          // XXX: Error code here may be INCORRECT_CODE. But server-side
          // only return SERVER_ERROR for now. Wait for backend
          // to modify it.
          this.showToastMessage('ERROR_INCORRECT_PASSCODE');
          console.error(err);
        }
      );
    } else {
      const phone = this.options.phone;
      const verificationId = this.options.verificationId;

      switch (this.flow) {
        case AccountModuleFlows.CREATE_ACCOUNT:
        case AccountModuleFlows.EDIT_PHONE:
          FxModuleServerRequest.resolvePhoneVerification(
            phone, '', verificationId, otp,
            () => {
              delete FxaModuleManager.paramsRetrieved.phone;
              FxaModuleNavigation.next();
            },
            err => {
              console.error('[Account] Resolve OTP error.', err);
              if (isManual) {
                this.resetOtp();
                this.showToastMessage('ERROR_SERVER_ERROR');
              } else {
                this.stopCountdownRemaningTime();
                this.switchToResend(true);
                this.showToastMessage('ERROR_SERVER_ERROR');
              }
            }
          );
          break;
        case AccountModuleFlows.VERIFY_ALT_PHONE:
        case AccountModuleFlows.EDIT_ALT_PHONE:
          const accountPhone = this.options.user.phone;

          FxModuleServerRequest.resolvePhoneVerification(
            accountPhone, phone, verificationId, otp,
            () => {
              delete FxaModuleManager.paramsRetrieved.phone;
              FxaModuleNavigation.next();
            },
            err => {
              console.error('[Account] Resolve OTP error.', err);
              if (isManual) {
                this.resetOtp();
                // XXX: Error code here may be INCORRECT_CODE. But server-side
                // only return SERVER_ERROR for now. Wait for backend
                // to modify it.
                this.showToastMessage('ERROR_INCORRECT_PASSCODE');
              } else {
                this.stopCountdownRemaningTime();
                this.switchToResend(true);
                this.showToastMessage('ERROR_SERVER_ERROR');
              }
            }
          );
          break;
        default:
          break;
      }
    }
  };

  // Get the verify code from notification and fill in automatically.
  Module.onOTPReceived = function(otp) {
    _fillInCode(otp, this.accountOtpContainer);
    // To display the verify code to users, so delay 500 ms here.
    setTimeout(() => {
      this.resolvePhoneVerification(otp);
    }, 500);
  };

  // Use to switch this page to the different mode. (fill or resend)
  Module.switchToResend = function switchToResend(isResendMode) {
    if (isResendMode) {
      this.mode = 'resend';
      this.accountSmsFillMode.classList.add('hidden');
      this.accountSmsResendMode.classList.remove('hidden');
    } else {
      this.mode = 'fill';
      this.accountSmsFillMode.classList.remove('hidden');
      this.accountSmsResendMode.classList.add('hidden');
    }
  };

  Module.resetOtp = function resetOtp() {
    _fillInCode('', this.accountOtpContainer);
    this.manualOtp = '';
    this.accountInvisibleInput.value = '';
    setTimeout(() => this.accountInvisibleInput.focus(), 100);
  };

  Module.dialogPrimaryBtnHandler = function dialogPrimaryBtnHandler() {
    FxaModuleNavigation.goBackByStepIndex(1);
  };

  Module.onCancel = function onCancel(showDialog) {
    switch (this.flow) {
      case AccountModuleFlows.PHONE_SIGN_IN:
        // Go to Sign In page with region selected and phone filled in.
        FxaModuleNavigation.goBackByStepIndex(2);
        break;
      case AccountModuleFlows.VERIFY_ALT_PHONE:
        FxaModuleNavigation.back();
        break;
      case AccountModuleFlows.EDIT_PHONE:
      case AccountModuleFlows.EDIT_ALT_PHONE:
        // Go to Account Info page with region selected and phone filled in.
        FxaModuleNavigation.goBackByStepIndex(3);
        break;
      case AccountModuleFlows.CREATE_ACCOUNT:
        // Show the dialog with message.
        showDialog(...this.options['signup_leave_msg']);
        break;
      default:
        break;
    }
  };

  Module.onNext = function onNext(gotoNextStepCallback) {
    this.stopCountdownRemaningTime();

    switch (this.flow) {
      case AccountModuleFlows.CREATE_ACCOUNT:
        gotoNextStepCallback(FxaModuleStates.SIGNUP_SUCCESS);
        break;
      case AccountModuleFlows.PHONE_SIGN_IN:
        gotoNextStepCallback(FxaModuleStates.ACCOUNT_INFO);
        break;
      case AccountModuleFlows.EDIT_PHONE:
        const dialogMsg = [
          lget('account-dialog-confirm'),
          lget('account-change-phone-success-message'),
          lget('account-dialog-ok'),
          ''
        ];
        FxaModuleNavigation.showDialog(...dialogMsg);
        FxaModuleNavigation.goBackByStepIndex(1);
        break;
      case AccountModuleFlows.VERIFY_ALT_PHONE:
      case AccountModuleFlows.EDIT_ALT_PHONE:
        gotoNextStepCallback(FxaModuleStates.ACCOUNT_INFO);
        break;
      default:
        break;
    }
  };

  Module.setResendButtonPosition = function setResendButtonPosition() {
    const bodyHeight = document.body.clientHeight;
    this.accountResendSms.style.top = `calc(${bodyHeight}px - 16rem)`;
  };

  Module.onBack = function onBack() {
    this.stopCountdownRemaningTime();
  };

  return Module;
})();
