'use strict';

const RETRY_INTERVAL = {
  6: 1 * 60 * 1000,
  7: 5 * 60 * 1000,
  8: 15 * 60 * 1000,
  9: 60 * 60 * 1000,
  10: 4 * 60 * 60 * 1000
};

var InvalidPasswordHelper = {
  storageKey: {
    RETRY: 'checkpassword.retrycount',
    ENABLE: 'checkpassword.enabletime'
  },

  setWrongTimes: function() {
    const keyRetry = this.storageKey.RETRY;
    const keyEnable = this.storageKey.ENABLE;

    window.parent.asyncStorage.getItem(keyRetry, value => {
      let count = value || 0;
      count += 1;
      window.parent.asyncStorage.setItem(keyRetry, count);
      if (count >= 6) {
        if (count >= 10) {
          count = 10;
        }
        let inverval = RETRY_INTERVAL[count];
        let enableTime = (new Date()).getTime() + inverval;
        window.parent.asyncStorage.setItem(keyEnable, enableTime);
      }
    });
  },

  resetWrongTimes: function() {
    const keyRetry = this.storageKey.RETRY;
    const keyEnable = this.storageKey.ENABLE;

    window.parent.asyncStorage.setItem(keyRetry, 0);
    window.parent.asyncStorage.setItem(keyEnable, 0);
  },

  checkEnableDateTime: function() {
    const keyRetry = this.storageKey.RETRY;
    const keyEnable = this.storageKey.ENABLE;

    return new Promise((resolve, reject) => {
      window.parent.asyncStorage.getItem(keyRetry, retryValue => {
        // Set the dialog message
        const dialogContent = replaceText(
          lget('error-multiple-wrong-password-message'),
          {
            time: (retryValue < 10) ? (RETRY_INTERVAL[retryValue]/60000) : (RETRY_INTERVAL[10]/60000),
          }
        );
        const dialogMsg = [
          lget('account-dialog-confirm'),
          dialogContent,
          lget('account-dialog-ok'),
          ''
        ];

        window.parent.asyncStorage.getItem(keyEnable, enableTime => {
          if (enableTime) {
            var currentTime = (new Date()).getTime();
            if (currentTime < enableTime) {
              // Show the wrong password multiple times dialog
              FxaModuleNavigation.showDialog(...dialogMsg);
              reject();
            }
          }
          resolve();
        });
      });
    });
  }
};
