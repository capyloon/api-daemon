'use strict';

var AccountModuleDelete = (function() {
  let Module = Object.create(FxaModule);

  Module.init = function init(options) {
    this.importElements('account-delete-button');
    this.options = options || {};

    // Show the Cancel button
    FxaModuleUI.setButtonsVisible('10');
    FxaModuleUI.setCancelButtonLevel();
    FxaModuleUI.setHeaderMenu();

    if (this.initialized) {
      return;
    }
    this.initL10n();
    this.accountDeleteButton.addEventListener('click', this);
    this.initialized = true;
  };

  Module.initL10n = function initL10n() {
    this.accountDeleteButton.text = lget('account-delete');
  };

  Module.handleClickEvent = function handleClickEvent(evt) {
    const target = evt.target;

    switch (target) {
      case this.accountDeleteButton:
        FxaModuleNavigation.next();
        break;
      default:
        break;
    }
  };

  Module.onCancel = function onCancel(showDialog) {
    // Back to the page: Your Account, and nothing change.
    FxaModuleNavigation.goBackByStepIndex(1);
  };

  Module.onNext = function onNext(gotoNextStepCallback) {
    AccountLoader.mask();
    FxModuleServerRequest.deleteAccount(
      () => {
        FxModuleServerRequest.logout();
        AccountLoader.unmask();
        window.parent.FxAccountsUI.done({
          success: true
        });
      },
      err => {
        AccountLoader.unmask();
        console.error('[Account] Delete account error.', err);
        this.showToastMessage('ERROR_SERVER_ERROR');
      }
    );
  };

  return Module;
})();
