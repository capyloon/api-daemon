'use strict';

var AccountModuleAntitheftReconfirm = (function () {
  let Module = Object.create(FxaModule);

  Module.init = function init(options) {
    // Cache static HTML elements
    this.importElements(
      'antitheft-reconfirm-email',
      'antitheft-reconfirm-pwd',
      'antitheft-reconfirm-pwd-show',
      'antitheft-reconfirm-pwd-show-checkbox',
      'antitheft-reconfirm-next-btn'
    );

    FxaModuleUI.setButtonsVisible('00');
    FxaModuleUI.setHeaderMenu();

    this.initL10n();
    this.antitheftReconfirmEmail.value = options.email;

    if (this.initialized) {
      return;
    }
    this.createListeners();
    this.initialized = true;
  };

  Module.initL10n = function initL10n() {
    this.antitheftReconfirmEmail.label = lget('account-email');
    this.antitheftReconfirmPwd.label = lget('account-password');
    this.antitheftReconfirmPwdShow.text = lget('account-show-password');
    this.antitheftReconfirmNextBtn.text = lget('account-next');
  };

  Module.createListeners = function createListeners() {
    this.antitheftReconfirmNextBtn.addEventListener('click', this);
    this.antitheftReconfirmPwdShow.addEventListener('click', this);
  };
  Module.handleClickEvent = function handleClickEvent(evt) {
    const target = evt.target;

    switch(target) {
      case this.antitheftReconfirmPwdShow:
        let inputType = target.checked ? 'text' : 'password';
        this.antitheftReconfirmPwd.type = inputType;
        break;
      case this.antitheftReconfirmNextBtn:
        InvalidPasswordHelper.checkEnableDateTime().then(
          () => {
            // Enabled
            FxaModuleNavigation.next();
          },
          () => {
            // Disabled: show the wrong password multiple times dialog
          }
        );
        break;
    }
  };

  Module.onNext = function onNext(gotoNextStepCallback) {
    FxaModuleManager.setParam('email', this.antitheftReconfirmEmail.value);
    FxaModuleManager.setParam('password', this.antitheftReconfirmPwd.value);
    gotoNextStepCallback(FxaModuleStates.SIGN_OUT);
  };

  return Module;
}());
