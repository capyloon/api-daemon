/* -*- Mode: Java; tab-width: 2; indent-tabs-mode: nil; c-basic-offset: 2 -*- /
/* vim: set shiftwidth=2 tabstop=2 autoindent cindent expandtab: */

/* global FxaModuleStates, FxaModuleUI, FxaModule, FxaModuleNavigation,
   FxModuleServerRequest, FxaModuleManager */
/* exported AccountModuleCheckPassword */

'use strict';

/**
 * This module checks the validity of account password, and if valid,
 * determines which screen to go next.
 *
 * When password is incorrect, show the toast "ERROR_PASSWORD_INCORRECT",
 * and record the retry count to the async storage.
 *
 * Error Retry Interval:
 * Retry count = 6, users need to wait for 1 min to try it again.
 * Retry count = 7, users need to wait for 5 min to try it again.
 * Retry count = 8, users need to wait for 15 min to try it again.
 * Retry count = 9, users need to wait for 60 min to try it again.
 * Retry count >= 10, users need to wait for 240 min to try it again.
 */
var AccountModuleCheckPassword = (function() {
  const passwordEl = $('account-check-pwd');
  const showPasswordEl = $('account-check-pwd-show-checkbox');

  let Module = Object.create(FxaModule);
  let checkFunctions = {
    _checkPasswordFormat: function() {
      if (passwordEl.value === '') {
        passwordEl.errorstate = true;
        return 'ERROR_EMPTY_PASSWORD';
      }
      passwordEl.errorstate = false;
      return '';
    }
  };

  function _clearFrom() {
    passwordEl.value = '';
    showPasswordEl.checked = false;
  }

  Module.init = function init(options) {
    // Cache static HTML elements
    this.importElements(
      'account-check-pwd-msg',
      'account-check-pwd',
      'account-check-pwd-show',
      'account-check-pwd-show-checkbox',
      'account-check-pwd-forgot-pwd-link'
    );

    _clearFrom();

    this.options = options || {};
    this.action = this.options.flow;
    this.initL10n();
    FxaModuleUI.setButtonsVisible('11');
    FxaModuleUI.setCancelButtonLevel('secondary');
    FxaModuleUI.setHeaderMenu();
    FxaModuleUI.setNextText(lget('account-next'));

    if (this.initialized) {
      return;
    }

    this.accountCheckPwdShowCheckbox.addEventListener('click', this);
    this.accountCheckPwdForgotPwdLink.addEventListener('click', this);
    this.initialized = true;
  };

  Module.initL10n = function initL10n() {
    switch (this.action) {
      case AccountModuleFlows.DELETE_ACCOUNT:
        this.accountCheckPwdMsg
          .setAttribute('data-l10n-id','account-enter-password-to-delete');
        break;
      case AccountModuleFlows.EDIT_PHONE:
      case AccountModuleFlows.EDIT_EMAIL:
        this.accountCheckPwdMsg
          .setAttribute('data-l10n-id','account-enter-password-to-edit-info');
        break;
      default:
        break;
    }
    this.accountCheckPwd.label = lget('account-password');
    this.accountCheckPwdShow.text = lget('account-show-password');
  };

  Module.handleClickEvent = function handleClickEvent(evt) {
    const target = evt.target;

    switch (target) {
      case this.accountCheckPwdShowCheckbox:
        let inputType = target.checked ? 'text' : 'password';
        this.accountCheckPwd.type = inputType;
        break;
      case this.accountCheckPwdForgotPwdLink:
        this.action = AccountModuleFlows.FORGOT_PWD;
        FxaModuleNavigation.next();
        break;
      default:
        break;
    }
  };

  Module.onCancel = function onCancel(showDialog) {
    FxaModuleNavigation.back();
  };

  Module.onNext = function onNext(gotoNextStepCallback) {
    const { accountId } = FxaModuleManager.paramsRetrieved.user;
    const password = this.accountCheckPwd.value;

    if (this.action === AccountModuleFlows.FORGOT_PWD) {
      gotoNextStepCallback(FxaModuleStates.FORGOT_PASSWORD);
    } else {
      // Check the wrong time interval
      InvalidPasswordHelper.checkEnableDateTime().then(() => {
        // Check the password
        let error = validateType(checkFunctions);
        if (error) {
          this.showToastMessage(error);
          return;
        }
        // Use Gecko API to check password is correct or not.
        this.checkPassword(accountId, password).then(() => {
          switch (this.action) {
            case AccountModuleFlows.DELETE_ACCOUNT:
              gotoNextStepCallback(FxaModuleStates.DELETE);
              break;
            case AccountModuleFlows.EDIT_PHONE:
            case AccountModuleFlows.EDIT_EMAIL:
            case AccountModuleFlows.EDIT_ALT_PHONE:
              FxaModuleManager.setParam('password', password);
              gotoNextStepCallback(FxaModuleStates.EDIT_INFO);
              break;
            default:
              break;
          }
        });
      });
    }
  };

  Module.checkPassword = function checkPassword(accountId, password) {
    return new Promise((resolve, reject) => {
      // Loading mask
      AccountLoader.mask();
      // Use sign in method to check password
      FxModuleServerRequest.signIn(accountId, password,
        () => {
          AccountLoader.unmask();
          InvalidPasswordHelper.resetWrongTimes();
          resolve();
        },
        err => {
          AccountLoader.unmask();
          switch (err.error) {
            case 'UNVERIFIED_ACCOUNT':
            case 'ACCOUNT_DOES_NOT_EXIST':
              this.showToastMessage('ERROR_ACCOUNT_DOES_NOT_EXIST');
              break;
            case 'INVALID_PASSWORD':
              InvalidPasswordHelper.setWrongTimes();
              this.showToastMessage('ERROR_PASSWORD_INCORRECT');
              break;
            default:
              console.error('[Account] Checking password error.', err);
              this.showToastMessage('ERROR_SERVER_ERROR');
              break;
          }
          reject(err);
        }
      );
    });
  };

  return Module;
})();
