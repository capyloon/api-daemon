/* global ViewManager, inputHandler, regionSelector */

'use strict';

var NavigationMap = {
  currentActivatedLength: 0,
  dialogId: null,
  focusedElement: null,
  focusedMenuElement: null,
  focusedDialogElement: null,
  focusedControls: [],
  navType: null,

  init: function() {
    ViewManager.init();
    this.start();
  },

  start: function() {
    var self = this;

    var observer = new MutationObserver(this.mutationsHandler.bind(this));

    observer.observe(document.body, {
      childList: false,
      attributes: true,
      subtree: true,
      attributeOldValue: true,
      attributeFilter: [ 'class' ]
    });

    window.addEventListener('keydown', this.keydownHandler);

    document.addEventListener('focusChanged', (event) => {
      self.focusChanged.call(self, event.detail.focusedElement);
    });
    window.addEventListener('windowLoaded', () => {
      self.reset(2);
    });
    if ('undefined' != typeof inputHandler) {
      inputHandler.init();
    }
  },

  // -----------------------------------
  // Mutations Handler
  // -----------------------------------
  mutationsHandler: function(mutations) {
    var self = this;
    mutations.forEach((mutation) => {
      self.navType = null;
      var target = mutation.target;
      var classes = target.classList;

      if (
        'dialog' === target.getAttribute('role') &&
        'menu' !== target.dataset.subtype
      ) {
        if (mutation.oldValue.indexOf('hidden') > -1) {
          self.navType = 0;
          self.dialogId = target.id;
        } else {
          self.navType = 2;
        }
        NavigationMap.reset(self.navType);
      } else if (self.popupMenu(target)) {
      } else if (
        target.tagName === 'SECTION' &&
        target.parentNode.id != 'toast'
      ) {
        self.navType = 2;
        // the first screen will not dispatch windowLoaded event, so we must reset manually
        if (
          target.id === 'account-entry' ||
          target.id === 'account-sign-in' ||
          target.id === 'account-sign-out' ||
          target.id === 'account-check-password'
        )
          NavigationMap.reset(self.navType);
      }
    });
  },

  reset: function(navType) {
    var self = NavigationMap;
    if (self.currentActivatedLength) {
      return;
    }
    switch (navType) {
      case null:
        self.focusedMenuElement = NavigationHelper.resetMenu();
        break;
      case 0:
        self.focusedDialogElement = NavigationHelper.reset(
          VerticalNavigator,
          self.dialogControls,
          self.getDialogFocusIndex,
          'dialog'
        );
        break;
      case 2:
        self.focusedElement = NavigationHelper.reset(
          ViewManager.navigator,
          ViewManager.controls,
          ViewManager.focus,
          ViewManager.curViewId
        );

        if (self.focusedElement) {
          self.focusChanged(self.focusedElement);
        }
        break;
    }
  },

  handleClick: function(event) {
    if (event.target.click) {
      event.target.click();
      if (event.target.type === 'checkbox') {
        event.preventDefault();
        return;
      }
      var input =
        event.target.querySelector('input') ||
        (event.target.tagName.toLowerCase() === 'input' && event.target);
      if (input) {
        if (input.type === 'checkbox') {
          input.click();
        } else {
          input.focus();
        }
      }
    } else {
      var children = event.target.children;
      for (var i = 0; i < children.length; i++) {
        if (children[i].click) children[i].click();
      }
    }
  },

  focusChanged: function(element) {
    var input = element.querySelector('input');
    if (
      input &&
      [ 'text', 'password', 'email', 'tel', 'number', 'checkbox' ].indexOf(
        input.type
      ) > -1
    ) {
      input.focus();
      input.setSelectionRange(input.value.length, input.value.length);
    }

    if (element.getAttribute('scroll-into-view') === 'top') {
      element.scrollIntoView(true);
    } else if (element.getAttribute('scroll-into-view') === 'bottom') {
      element.scrollIntoView(false);
    }
  },

  getDefaultFocusIndex: function() {
    var focusId = 0;
    if (ViewHelper.curViewId) {
      focusId = NavigationMap.focusedControls[ViewHelper.curViewId];
      if (isNaN(focusId)) focusId = ViewHelper.defaultFocusIndex;
      if (
        isNaN(focusId) ||
        focusId < 0 ||
        focusId >= NavigationHelper.controls.length
      ) {
        focusId = 0;
      }
    }
    return focusId;
  },

  getDialogFocusIndex: function() {
    return 0;
  },

  deleteFocus: function(viewId) {
    if (undefined === viewId) viewId = ViewHelper.curViewId;
    delete NavigationMap.focusedControls[viewId];
  },

  dialogControls: function() {
    var dialogForm = $(NavigationMap.dialogId);
    return dialogForm ? dialogForm.querySelectorAll('ol > li') : null;
  },

  popupMenu: function(target) {
    var classes = target.classList;
    return (
      classes && classes.contains('group-menu') && classes.contains('visible')
    );
  },

  // -----------------------------------
  // Keydown Handler
  // -----------------------------------
  keydownHandler: function(e) {
    switch (e.key) {
      case 'BrowserBack':
        if (regionSelector.enabled) {
          regionSelector.hide();
          return;
        } else if (!NavigationMap.currentActivatedLength) {
          ViewManager.backKeyHandler();
        }
        break;
      case 'Backspace':
        e.preventDefault();
        e.stopPropagation();
        if (window.parent.FxAccountsUI.isClosing) {
          return;
        }
        if (regionSelector.enabled) {
          regionSelector.hide();
        } else if (numberPicker.enabled) {
          numberPicker.hide();
        } else {
          ViewManager.backKeyHandler();
        }
        break;
      case 'ContextMenu':
        // If user click home button end fxaccount flow.
        FxaModuleNavigation.done();
        break;
      default:
        break;
    }
  }
};
