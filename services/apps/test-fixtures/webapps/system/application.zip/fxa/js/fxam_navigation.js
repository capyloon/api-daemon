/* -*- Mode: Java; tab-width: 2; indent-tabs-mode: nil; c-basic-offset: 2 -*- /
/* vim: set shiftwidth=2 tabstop=2 autoindent cindent expandtab: */

/* global LazyLoader, FxaModuleUI, View, FxaModuleManager, FxaModuleStates */
/* exported FxaModuleNavigation */

'use strict';

/*
 * This code controls the navigation between modules. When tapping on
 * next/back, we load the next/previous module, loading resources and
 * updating the UI. Transitions are based on hash change.
 */

var FxaModuleNavigation = {
  stepCount: 0,
  currentModule: null,
  dialog: $('account-dialog'),

  init: function fxam_nav_init(flow) {
    let viewPath = `view/view_${flow}.js`;

    // Add Event Listeners
    this.initEventListeners();
    // Load view
    LazyLoader.load(viewPath, function loaded() {
      FxaModuleUI.setMaxSteps(View.length);
      window.location.hash = View.start.id;
    }.bind(this));
  },

  initEventListeners: function fxam_nav_initEventListeners() {
    // Listen on hash changes for panel changes
    window.addEventListener(
      'hashchange',
      this.hashchangeHandler.bind(this),
      false
    );
    // Listen on the dialog's primary button event
    window.addEventListener(
      'dialogPrimaryBtnClick',
      () => {
        this.dialog.open = false;
        this.currentModule.dialogPrimaryBtnHandler();
      }
    );
    // Listen on the dialog's secondary button event
    window.addEventListener(
      'dialogSecondaryBtnClick',
      () => {
        this.dialog.open = false;
        this.currentModule.dialogSecondaryBtnHandler();
      }
    );
  },

  hashchangeHandler: function fxam_nav_hashchangeHandler() {
    if (!location.hash) {
      return;
    }

    var panel = document.querySelector(location.hash);
    if (!panel || !panel.classList.contains('screen')) {
      return;
    }

    if (this.backAnim) {
      this.stepCount--;
      this.loadStep(panel, true);
    } else {
      this.stepCount++;
      this.loadStep(panel);
    }
  },

  loadStep: function fxam_nav_loadStep(panel, back) {
    if (!panel) {
      return;
    }

    FxaModuleUI.loadScreen({
      panel: panel,
      count: this.stepCount,
      back: this.backAnim,
      onload: function() {
        this.currentModule = window[this.moduleById(panel.id)];
        this.currentModule.init &&
          this.currentModule.init(FxaModuleManager.paramsRetrieved);
        FxaModuleUI.setHeaderVisible(this.currentModule.withHeader);
      }.bind(this),
      onanimate: function() {
        this.backAnim = false;
        this.updatingStep = false;
        window.dispatchEvent(new CustomEvent('windowLoaded'));
      }.bind(this)
    });
  },

  back: function fxam_nav_back(isSoftBack) {
    // Avoid multiple taps on 'back' if screen transition is not over.
    if (this.updatingStep) {
      return;
    }
    this.updatingStep = true;
    // Execute module back (if is defined)
    this.currentModule.onBack && this.currentModule.onBack(this.loadNextStep.bind(this));
    if (!isSoftBack) {
      // Go to previous step
      this.backAnim = true;

      window.history.back();
    }
  },

  cancel: function fxam_nav_cancel() {
    this.currentModule.onCancel && this.currentModule.onCancel(this.showDialog.bind(this));
  },

  showDialog: function fxam_nav_showDialog(title, message, pButtonText, sButtonText) {
    this.dialog.title = title;
    this.dialog.message = message;
    this.dialog.primarybtntext = pButtonText;
    this.dialog.secondarybtntext = sButtonText;
    this.dialog.open = true;
  },

  goBackByStepIndex: function fxam_nav_goBackByStepIndex(index, toastMsg = null) {
    let backCount = index - this.stepCount;

    if(backCount) {
      this.backAnim = true;
      window.history.go(backCount);

      // After execute history.go, set the step counter to current step number.
      setTimeout(() => {
        this.stepCount = index;
        toastMsg && this.currentModule.showToastMessage(toastMsg);
      }, 100);
    } else {
      console.error(`backCount=${backCount}, it will cause to restart the phone.`);
    }
  },

  loadNextStep: function fxam_loadNextStep(nextStep) {
    if (!nextStep || !nextStep.id) {
      return;
    }

    location.hash = nextStep.id;
  },

  next: function fxam_nav_next() {
    this.currentModule.onNext(this.loadNextStep.bind(this));
  },

  moduleById: function fxam_nav_moduleById(id) {
    ViewManager.switchSection(id);
    var moduleKey = Object.keys(FxaModuleStates).filter(function(module) {
      return FxaModuleStates[module] &&
        FxaModuleStates[module].id &&
        FxaModuleStates[module].id === id;
    }).pop();
    if (moduleKey) {
      return FxaModuleStates[moduleKey].module;
    }
  },

  done: function fxam_nav_done() {
    this.currentModule.onDone(FxaModuleManager.done);
  }
};
