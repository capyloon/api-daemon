'use strict';

var View = {
  length: 1,
  start: FxaModuleStates.ACCOUNT_INFO
};
