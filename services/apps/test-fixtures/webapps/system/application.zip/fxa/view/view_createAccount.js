var View = {
  length: 5,
  start: FxaModuleStates.ABOUT
};
