/* global Service */
'use strict';

import BaseModule from 'base-module';
import SettingsManager from 'settings-manager';
import Voicemail from './voicemail';

class NotificationStore extends BaseModule {
  name = 'NotificationStore';

  EVENT_PREFIX = 'notification-';

  SILENT_APPLICATIONS = [
    window.location.origin.replace('system.', 'network-alerts.') +
      '/manifest.webapp'
  ];

  ICON_MAP = {
    'Call Log': 'call',
    'Voicemail': 'voicemail-32px',
    'Messages': 'messages',
    'Calendar': 'calendar',
    'E-Mail': 'email',
    'System': 'notification-32px'
  };

  MAX_SIZE = 99;

  // XXX: Move to lockscreen?
  lockscreenPreview = false;

  start() {
    window.addEventListener('mozChromeNotificationEvent', this);
    window.addEventListener('applicationenabledstatechange', evt => {
      let app = evt.detail.application;
      if (app) {
        let manifest = app.manifest ? app.manifest : app.updateManifest;
        if (
          !app.enabled ||
          manifest.role === 'invisible' ||
          app.role === 'invisible'
        ) {
          this.removeDisabledAppNotice(app.manifestURL);
        }
      }
    });
    this.notificationMap = new Map();
    this.newComingCountMap = new Map();
    this._resendStoredNotifications();
    Service.register('add', this);
    Service.register('remove', this);
    Service.registerState('getAll', this);
    Service.registerState('isResending', this);
    Service.registerState('unreadCount', this);
    SettingsManager.addObserver(
      'lockscreen.notifications-preview.enabled',
      this
    );

    this.resetNewComingCount();
  }

  removeDisabledAppNotice(manifestURL) {
    this.notificationMap.forEach((detail, id) => {
      if (detail.manifestURL === manifestURL) {
        this.remove(id, true);
      }
    });
    this.emit('deleted');
    this.emit('changed');
  }

  unreadCount() {
    return this.notificationMap.size;
  }

  getAll() {
    return this.notificationMap;
  }

  '_observe_lockscreen.notifications-preview.enabled'(value) {
    this.lockscreenPreview = value;
  }

  handleEvent(evt) {
    var detail = evt.detail;
    switch (detail.type) {
      case 'desktop-notification':
        this.add(detail);

        this._resendExpecting = Math.max(this._resendExpecting - 1, 0);
        this.isResending = !!this._resendExpecting;
        break;
      case 'desktop-notification-close':
        this.remove(detail.id);
        break;
    }
  }

  /**
   * Increase new coming notice count
   * @param {object} detail detail.appName should be in ICON_MAP
   */
  addNewComingCount(detail) {
    let targetAppName = detail.appName;
    if (!this.ICON_MAP[detail.appName]) {
      targetAppName = 'System';
    }

    // if is voicemail notification
    if (detail.appName == 'System' && detail.icon == Voicemail.icon) {
      targetAppName = 'Voicemail';
    }

    this.newComingCountMap.set(
      targetAppName,
      this.newComingCountMap.get(targetAppName) + 1
    );
  }

  resetNewComingCount() {
    Object.keys(this.ICON_MAP).forEach(appName => {
      this.newComingCountMap.set(appName, 0);
    });
  }

  add(detail) {
    /* If dir "auto" was specified by the notification,
     * use document direction instead because dir="auto"
     * does not align the notification node according to
     * the system language direction but instead it aligns
     * every child element according to its own language
     * which creates a UI mess we can't control by changing
     * the system language.
     */
    if (
      detail['id'] &&
      detail['id'].indexOf('app://system.gaiamobile.org') !== -1
    ) {
      var perm = window.navigator.mozPermissionSettings.get(
        'desktop-notification',
        'app://system.gaiamobile.org/manifest.webapp',
        'app://system.gaiamobile.org',
        false
      );
      if (perm === 'deny') {
        return;
      }
    }

    var manifestURL = detail.manifestURL || '';
    let app = applications.getByManifestURL(manifestURL);
    if (app) {
      let manifest = app.manifest ? app.manifest : app.updateManifest;
      if (
        !app.enabled ||
        manifest.role === 'invisible' ||
        app.role === 'invisible'
      ) {
        return;
      }
    }

    var dir =
      detail.dir === 'auto' || typeof detail.dir === 'undefined'
        ? document.documentElement.dir
        : detail.dir;
    var type = detail.type || 'desktop-notification';

    var behavior = detail.mozbehavior || {};
    if (detail.dismissable === undefined) {
      detail.dismissable = true;
    }
    if (behavior && behavior.noclear) {
      detail.dismissable = false;
    }
    if (detail.timestamp === undefined) {
      detail.timestamp = new Date().getTime();
    }

    if (!detail.isDownload && !detail.type.startsWith('bluetooth')) {
      this.publish(
        'mozContentNotificationEvent',
        {
          type: 'desktop-notification-show',
          id: detail.id
        },
        true
      );
    }

    // check notification count limit before adding a new one
    if (
      this.notificationMap.size >= this.MAX_SIZE &&
      !this.notificationMap.has(detail.id)
    ) {
      var id = this.notificationMap.entries().next().value[0];
      this.remove(id, true);
    }
    this.notificationMap.set(detail.id, detail);

    var notify =
      !('noNotify' in detail) &&
      // don't notify for network-alerts notifications
      this.SILENT_APPLICATIONS.indexOf(detail.manifestURL) === -1;

    if (notify && !this.isResending) {
      if (detail.requireInteraction) {
        Service.request('NotificationDialogView:show', detail);
      } else {
        Service.request('NotificationDialogView:maybeHide', detail);
        Service.request('StandaloneNotification:show', detail);
      }

      // pump new notice together with the toaster
      if (Service.query('locked') && this.lockscreenPreview) {
        this.addNewComingCount(detail);
        this.publish('add-to-lockscreen', detail);
      }
    }

    this.emit('added');
    this.emit('changed');
  }

  click(id) {
    const detail = this.notificationMap.get(id);

    if (detail && detail.callback) {
      detail.callback();
      return;
    }

    if (detail.requireInteraction) {
      Service.request('NotificationDialogView:show', detail, true);
    } else {
      const event = new CustomEvent('mozContentNotificationEvent', {
        detail: {
          type: 'desktop-notification-click',
          id: id
        }
      });
      window.dispatchEvent(event);
    }
  }

  removeAll() {
    this.notificationMap.forEach(function(detail, id) {
      if (detail.type === 'download-notification-downloading') {
        return;
      }
      if (detail.dismissable === false) {
        return;
      }
      this.remove(id, true);
    }, this);
    this.emit('deleted');
    this.emit('changed');
  }

  remove(id, ignoreChange) {
    // console.warn(id, ignoreChange);
    this.notificationMap.delete(id);
    var event = new CustomEvent('mozContentNotificationEvent', {
      detail: {
        type: 'desktop-notification-close',
        id: id
      }
    });
    window.dispatchEvent(event);
    if (!ignoreChange) {
      this.emit('deleted', id);
      this.emit('changed');
    }
  }

  _resendStoredNotifications() {
    if ('mozSettings' in navigator && navigator.mozSettings) {
      var key = 'notifications.resend';
      var req = navigator.mozSettings.createLock().get(key);
      var self = this;
      req.onsuccess = req.onerror = function onsuccess() {
        var resendEnabled = req.result[key] || false;
        if (!resendEnabled) {
          return;
        }

        var resendCallback = function(number) {
          self._resendExpecting = number;
          window.dispatchEvent(
            new CustomEvent('desktop-notification-resend', {
              detail: { number: number }
            })
          );
        }.bind(this);

        if ('mozChromeNotifications' in navigator) {
          navigator.mozChromeNotifications.mozResendAllNotifications(
            resendCallback
          );
        }
      };
    }
  }
}

var notificationStore = new NotificationStore();
notificationStore.start();

export default notificationStore;
