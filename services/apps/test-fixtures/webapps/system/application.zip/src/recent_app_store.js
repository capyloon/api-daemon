'use strict';

import BaseModule from 'base-module';

const STORE_NAME = 'recent_apps';
const RECORD_ID = 'in_time_order';
let instance;

/**
 * RecentAppStore adopts DataStore to record recently launched apps
 * in specific odrer.
 */
class RecentAppStore extends BaseModule {
  name = 'RecentAppStore';

  // stores recently opened apps in order
  _recentApps = [];

  // refers to the `recent_apps` datastore
  _recentAppStore = null;

  // stores the callbacks that would be performed after data synchronization
  _callbacks = [];

  constructor() {
    super();

    navigator.getDataStores(STORE_NAME).then(stores => {
      this._recentAppStore = stores[0];
      this._recentAppStore.onchange = () => {
        this.sync();
      }
      this.sync();

      window.Service.register('watch', this);
      window.Service.register('reorder', this);
      window.Service.register('unwatch', this);
    });
  }

  /**
   * Sort the launched applications by their latest launched time.
   * @param {object} currentApp
   */
  reorder(currentApp) {
    const index = this._recentApps
      .map(app => app.origin)
      .indexOf(currentApp.origin);

    if (index === 0) {
      this._recentApps[0].lastLaunched = Date.now();
    } else {
      if (index > 0) {
        const removed = this._recentApps.splice(index, 1);
        removed.lastLaunched = Date.now();
        this._recentApps = [...removed, ...this._recentApps];
      } else {
        const {
          name, origin, url, manifestURL
        } = currentApp;

        this._recentApps = [{
          // DON'T store icons! They might be changed in someday.
          name,
          origin,
          url,
          manifestURL,
          lastLaunched: Date.now(),
        }, ...this._recentApps];
      }
    }

    this._recentAppStore.put(this._recentApps, RECORD_ID);
  }

  /**
   * Retrive the latest `_recentApps` and
   * trigger all the registered callback handlers.
   */
  sync() {
    this._recentAppStore.get(RECORD_ID).then(apps => {
      this._recentApps = apps || [];
      const len = this._callbacks.length;
      for (let i = 0; i < len; i++) {
        this._callbacks[i](this._recentApps);
      }
    });
  }

  /**
   * Register a handler to process the data after `_recentApps` is updated.
   * @param {function} cb
   */
  watch(cb) {
    if (typeof cb === 'function') {
      this._callbacks.push(cb);
    }
    this.sync();
  }

  /**
   * Remove the handler registered before.
   * @param {function} cb
   */
  unwatch(cb) {
    const len = this._callbacks.length;
    for (let i = 0; i < len; i++) {
      if (this._callbacks[i] === cb) {
        this._callbacks.splice(i, 1);
        break;
      }
    }
  }
}

if (!instance) {
  instance = new RecentAppStore();
}

export default instance;
