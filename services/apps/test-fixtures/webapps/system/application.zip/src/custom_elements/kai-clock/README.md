# Clock

A digital-clock component built with lit-element.

## Example

```
<kai-clock></kai-clock>
```
