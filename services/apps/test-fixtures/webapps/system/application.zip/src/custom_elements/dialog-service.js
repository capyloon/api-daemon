/* global Service */
import { LitElement, html, css } from 'lit-element';

class DialogService extends LitElement {
  name = 'DialogService';

  static get is() {
    return 'dialog-service';
  }

  static get properties() {
    return {
      pendingDialogs: { type: Array },
      currentDialog: { type: Object },
    };
  }

  static get styles() {
    return css`
      :host {
        width: 100%;
        height: calc(100% - var(--infogation-bar-height));
        z-index: var(--z-index-attention);
        display: flex;
        flex-direction: column;
        align-items: center;
        position: absolute;
        top: 0;
        left: 0;
      }
      :host(.hide) {
        display: none;
      }
      .extra-text {
        width: 100%;
        color: var(--color-gs100);
        position: absolute;
        height: 3.8rem;
        display: flex;
        align-items: center;
        /*
          this is hack, because kai-dialog height is 100%,
          and the z-index (100) insided is higher than default.
          set higher z-index for extra-text div.
         */
        z-index: 101;
      }
      @media screen and (orientation: portrait) {
        .extra-text {
          justify-content: center;
          bottom: 2.5rem;
          left: 0;
        }
      }
      @media screen and (orientation: landscape) {
        .extra-text {
          justify-content: flex-end;
          bottom: 2rem;
          right: 2rem;
        }
      }
    `;
  }

  constructor() {
    super();
    this.pendingDialogs = [];
    this.currentDialog = {};
    Service.register('show', this);
    Service.register('hide', this);
  }

  firstUpdated() {
    this.addEventListener('dialogPrimaryBtnClick', () =>
      this.currentDialog.onDialogPrimaryBtnClick()
    );
    this.addEventListener('dialogSecondaryBtnClick', () =>
      this.currentDialog.onDialogSecondaryBtnClick()
    );
  }

  updated(changedProperties) {
    if (changedProperties.has('currentDialog')) {
      if (this.currentDialog.id) {
        this.classList.remove('hide');
      } else {
        this.classList.add('hide');
      }
    }
  }

  show(config) {
    if (config && config.id) {
      const id = config.id;
      if (!this.currentDialog.id) {
        // there is no dialog displayed
        this.currentDialog = config;
      } else {
        if (this.currentDialog.id === id) {
          console.warn('dialog with this id already exists');
        } else {
          this.pendingDialogs.push(config);
        }
      }
    } else {
      console.warn('"config" is null or "id" is null');
    }
  }

  hide(id) {
    if (!id || this.currentDialog.id === id) {
      this.currentDialog = {};
      if (this.pendingDialogs.length > 0) {
        this.currentDialog = this.pendingDialogs.shift();
      }
    } else {
      this.pendingDialogs = this.pendingDialogs.filter(
        dialog => dialog.id !== id
      );
    }
  }

  _onExtraTextClick() {
    this.currentDialog.onDialogExtraTextClick();
  }

  _preventFocus(evt) {
    evt.preventDefault();
  }

  render() {
    return html`
      <div @mousedown="${this._preventFocus}">
        ${this.currentDialog.id
          ? html`
              <kai-dialog
                .title=${this.currentDialog.title}
                .message=${this.currentDialog.message}
                .primarybtntext=${this.currentDialog.primarybtntext}
                .secondarybtntext=${this.currentDialog.secondarybtntext}
                open
              >
                <slot name="custom-view"></slot>
              </kai-dialog>
              ${this.currentDialog.extratext
                ? html`
                    <div
                      class="h4 extra-text"
                      @click="${this._onExtraTextClick}"
                    >
                      ${this.currentDialog.extratext}
                    </div>
                  `
                : ''}
            `
          : ''}
      </div>
    `;
  }
}

customElements.define(DialogService.is, DialogService);
