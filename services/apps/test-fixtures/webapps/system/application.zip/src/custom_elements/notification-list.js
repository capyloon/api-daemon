/* global GestureDetector, Service, ScreenManager */
import { LitElement, html, css } from 'lit-element';
import './kai-notification';
import mozL10n from '../app_umd/l10n.js';
import logger from '../util/logger.js';
import { getMozAppIcon } from '../util/utils.js';
import NotificationStore from '../notification_store';

const log = logger('notification-list');
const _ = mozL10n.get;

const EVENT_ACTION = {
  EXPAND: 'group',
  COLLAPSE: 'collapse',
  CLEAR: 'clear',
  OPEN: 'open'
};

class NotificationList extends LitElement {

  TIMEOUT = 300;

  static get properties() {
    const internalProps = {
      expandedApps: Array
    };

    return {
      notificationDx: {
        type: Number
      },
      header: { type: String },
      items: {
        type: Array,
        hasChanged: (newVal, oldVal = []) => newVal._count !== oldVal._count
      },
      ...internalProps
    };
  }

  static get styles() {
    const host = css`
      :host {
        display: flex;
        flex-direction: column;
        height: 100%;
        overflow: scroll;
      }

      .list-header {
        display: flex;
        justify-content: space-between;
        color: var(--color-gs100);
        font-size: 2rem;
        font-weight: bold;
        text-transform: uppercase;
      }

      .list-header [data-icon] {
        font-size: 2.4rem;
        width: 2.4rem;
        height: 2.4rem;
        background-color: var(--color-gs60);
        border-radius: 100%;
        line-height: 100%;
        color: var(--color-gs00);
        margin-bottom: 2rem;
      }

      .empty-element {
        display: flex;
        justify-content: center;
        margin-top: 10rem;
      }
    `;
    const group = css`
      .group {
        position: relative;
        display: flex;
        flex-direction: column;
      }

      .group__header {
        display: flex;
        justify-content: space-between;
        margin-bottom: 1rem;
        color: var(--color-gs100);
        transition: opacity 0.25s linear;
        opacity: 0;
        visibility: collapse;
      }

      .group--expanded .group__header {
        opacity: 1;
        visibility: visible;
      }

      .group__header [data-icon] {
        font-size: 2.4rem;
        width: 2.4rem;
        height: 2.4rem;
        background-color: var(--color-gs60);
        border-radius: 100%;
        line-height: 100%;
        color: var(--color-gs00);
      }

      .hide {
        display: none;
      }

      .show {
        display: block;
      }
    `;
    return [host, group];
  }

  constructor() {
    super();
    this.expandedApps = [];
    this.items = [];
    this.header = '';
    this.clickCount = 0;
    this.tempID = '';
    this.lockDx = 0;
    this.notificationPanHandler = this.notificationPanHandler.bind(this);
    this.notificationSwipeHandler = this.notificationSwipeHandler.bind(this);
  }

  async performUpdate() {
    await new Promise(resolve => {
      requestAnimationFrame(() => {
        if (this.notification) {
          this.notification.style.transform = `translate(${this.notificationDx}px)`;
        }
        resolve();
      });
    });
    super.performUpdate();
  }

  notificationPanHandler(e) {
    e.stopPropagation();
    const { dx } = e.detail.absolute;
    this.notificationDx = dx;
  }

  firstUpdated() {
    const rootNotification = this.root;
    this._notificationGesture = new GestureDetector(rootNotification);
    this._notificationGesture.startDetecting();
    rootNotification.addEventListener('pan', this.notificationPanHandler);
    rootNotification.addEventListener('swipe', this.notificationSwipeHandler);

    NotificationStore.on('changed', () => {
      this.items = this.getNotification();
    });
  }

  getNotification() {
    const notificationMap = NotificationStore.getAll();
    const notificationArray = Array.from(notificationMap.entries()).reverse();

    const notifications = [];
    for (let i = 0; i < notificationArray.length; i++) {
      const obj = notificationArray[i][1];
      notifications.push(obj);
    }

    // count to know which appName should be grouped
    const countByApp = {};
    notifications.forEach(item => {
      countByApp[item.appName] = countByApp[item.appName] || 0;
      countByApp[item.appName]++;
    });

    // extract group name according to the criteria from SPEC
    const groups = Object.entries(countByApp)
      .filter(([, count]) => count >= 3)
      .map(([appName]) => appName);

    const itemsMap = {};
    notifications.forEach(item => {
      if (groups.includes(item.appName)) {
        itemsMap[item.appName] = itemsMap[item.appName] || {
          isGroup: true,
          children: [],
          appName: item.appName
        };
        itemsMap[item.appName].children.push(item);
      } else {
        itemsMap[item.id] = item;
      }
    });

    const items = Object.values(itemsMap);
    // handy for checking prop changed or not
    items._count = notifications.length;

    return items;
  }

  get root() {
    return this.shadowRoot.querySelector('.root');
  }

  get notification() {
    return this.shadowRoot.querySelector('kai-notification');
  }

  notificationSwipeHandler = e => {
    e.stopPropagation();
    const { end } = e.detail;
    let elmntLength = e.target.getBoundingClientRect().width;

    // When the swipe distance is over 2/3 of the notification length
    if (
      e.detail.direction === 'right' &&
      end.screenX >= elmntLength * (2 / 3)
    ) {
      if (e.target.id === 'group') {
        this.dismissGroup(e.target.appname);
      } else {
        NotificationStore.remove(e.target.id);
      }
    }
  };

  // To avoid too many event listeners, we delegate all click events to one listener
  // XXX: consider swipe event
  _onClick = evt => {
    const element = evt.target;
    const inInstantPanel = this.header ? true : false;
    log('_onClick:', element.dataset.eventAction);
    switch (element.dataset.eventAction) {
      case EVENT_ACTION.EXPAND:
        this.expandedApps = [...this.expandedApps, element.appname];
        break;
      case EVENT_ACTION.COLLAPSE:
        this.expandedApps = this.expandedApps.filter(
          appName => appName !== element.dataset.appName
        );
        break;
      case EVENT_ACTION.CLEAR:
        NotificationStore.removeAll();
        break;
      case EVENT_ACTION.OPEN:
        // For Instant Panel: single tap on the notificaiton.
        if (inInstantPanel) {
          // Hide instant panel after opening a notification.
          Service.request('InfogationBar:toggleInstantPanel');
          NotificationStore.click(element.id);
          NotificationStore.remove(element.id);
        } else {
          this.clickCount++;
          if (this.clickCount === 1) {
            this.tempID = element.id;
            this.singleClickTimer = setTimeout(() => {
              this.clickCount = 0;
            }, this.TIMEOUT);
          } else if (this.clickCount === 2) {
            if (element.id === this.tempID) {
              // For Lock Screen: double tap on the notificaiton.
              clearTimeout(this.singleClickTimer);
              this.clickCount = 0;
              NotificationStore.click(element.id);
              NotificationStore.remove(element.id);
            } else {
              this.tempID = '';
              this.clickCount = 0;
            }
          }
        }
        break;
      default:
        return;
    }
    evt.preventDefault();
    evt.stopPropagation();
  };

  _itemToHtml = item => {
    getMozAppIcon(item.appName)
      .then(iconUrl => {
        item.appIcon = iconUrl;
      })
      .catch(err => console.error(err));

    if (item.isGroup) {
      const isExpanded = this.expandedApps.includes(item.appName);
      return html`
        <div class="group ${isExpanded ? 'group--expanded' : ''}">
          <div class="group__header">
            <div class="subtilte-1">${item.appName}</div>
            <div
              data-icon="arrow-up"
              data-event-action="${EVENT_ACTION.COLLAPSE}"
              data-app-name="${item.appName}"
            ></div>
          </div>
          <div class="group__children">
            ${isExpanded
              ? item.children.map(this._itemToElement)
              : this._itemToElement(item)}
          </div>
        </div>
      `;
    } else {
      return this._itemToElement(item);
    }
  };

  // item could be a single notice or group of notices
  _itemToElement = item => {
    const {
      appName,
      appIcon,
      title,
      text,
      timestamp = item.timestamp
    } = item.isGroup ? item.children[0] : item;

    const timestampLabel = new mozL10n.DateTimeFormat().fromNow(timestamp);
    return html`
      <kai-notification
        id="${item.isGroup ? 'group' : item.id}"
        icon="${appIcon}"
        appname="${appName}"
        noticetitle="${title}"
        bodytext="${text}"
        timestamp="${timestampLabel}"
        .isgroup=${!!item.isGroup}
        data-event-action="${item.isGroup
          ? EVENT_ACTION.EXPAND
          : EVENT_ACTION.OPEN}"
        }
      >
      </kai-notification>
    `;
  };

  render() {
    const itemsHtml = this.items.map(this._itemToHtml);
    const emptyHtml = html`
      ${this.header
        ? html`
            <div class="empty-element body-1">${_('notification-empty')}</div>
          `
        : html``}
    `;

    return html`
      <div class="root" @click=${this._onClick}>
      <link rel="stylesheet" type="text/css" href="https://shared.local/style/gaia-icons-embedded.css">
        ${this.header
          ? html`
              <div class="list-header">
                <div>${this.header}</div>
                <div
                  data-icon="cancel"
                  data-event-action="${EVENT_ACTION.CLEAR}"
                  class="${this.items.length === 0 ? 'hide' : 'show'}"
                ></div>
              </div>
            `
          : html``}
        ${this.items.length === 0 ? emptyHtml : itemsHtml}
      </div>
    `;
  }
}

mozL10n.once(() => {
  customElements.define('notification-list', NotificationList);
  log('custom element defined');
});
