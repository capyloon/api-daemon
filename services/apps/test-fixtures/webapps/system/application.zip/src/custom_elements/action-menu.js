import { LitElement, html, css } from 'lit-element';

class ActionMenu extends LitElement {
  static get properties() {
    return {
      detail: { type: Object }
    };
  }

  static get styles() {
    return css`
      .container {
        width: 100%;
        height: calc(100% - var(--infogation-bar-height));
        background-color: var(--popup-background-color);
        display: flex;
        flex-direction: column-reverse;
        justify-content: center;
        align-items: center;
        z-index: var(--z-index-data-operation);
        position: fixed;
        top: 0;
        left: 0;
      }
      .container.bottom {
        justify-content: flex-start;
      }
      .popup {
        width: 30rem;
        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: center;
      }
      .container.bottom > .popup {
        width: 32rem;
        margin-bottom: 2rem;
      }
      .title {
        width: 30rem;
        height: 3.2rem;
        padding: 0 2rem;
        box-sizing: border-box;
        color: var(--color-gs100);
        text-align: center;
        overflow: hidden;
        white-space: nowrap;
        text-overflow: ellipsis;
      }
      .options {
        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: center;
        width: 100%;
        color: var(--color-gs100);
        margin-top: 1.2rem;
        border-radius: 3rem;
        border: solid 0.2rem var(--color-gs80);
        padding: 1rem 0;
        padding-right: 0.5rem;
        overflow-y: auto;
        box-sizing: border-box;
        background-color: var(--color-gs00);
      }
      .list {
        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: stretch;
        width: 100%;
      }
      .list-image {
        width: 4rem;
        height: auto;
      }
      .line {
        box-sizing: border-box;
        width: calc(100% - 4rem);
        height: 0.2rem;
        border-bottom: solid 0.2rem var(--color-gs80);
        border-radius: 0.2rem;
        margin: 1rem 2rem 0 2rem;
      }
      .grid {
        width: 100%;
        display: flex;
        flex-direction: row;
        flex-wrap: wrap;
        align-items: center;
      }
      .grid-item {
        flex-basis: calc(100%/3);
        margin: 2rem 0;
        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: center;
      }
      .grid-item-image {
        width: 5.6rem;
        height: auto;
      }
      .grid-item-name {
        font-size: 1.4rem;
        font-weight: 600;
      }
      .hide {
        display: none;
      }
    `;
  }

  constructor() {
    super();
    window.addEventListener('mozChromeEvent', this._mozChromeEvent.bind(this));
    this.detail = {};
  }

  _mozChromeEvent(event) {
    this.detail = event.detail;

    if ('activity-choice' === this.detail.type) {
      this._chooseActivity();
    }
  }

  _isShare() {
    return this.detail && this.detail.name === 'share';
  }

  _chooseActivity() {
    let choices = this.detail.choices;
    this._publish('activityrequesting', this.detail);
    if (choices.length === 1 && !this._isShare()) {
      this._choose(0);
    } else {
      this._publish('activitymenuwillopen', this.detail);
      setTimeout(() => {
        this._open();
      });
    }
  }

  _publish(eventName, detail) {
    let event = new CustomEvent(eventName, { detail: detail });
    window.dispatchEvent(event);
  }

  _choose(choice) {
    let returnedChoice = {
      id: this.detail.id,
      type: 'activity-choice',
      value: choice
    };

    this._sendEvent(returnedChoice);
    this._close();
  }

  _cancel() {
    let returnedChoice = {
      id: this.detail.id,
      type: 'activity-choice',
      value: -1
    };

    this._sendEvent(returnedChoice);
  }

  _sendEvent(value) {
    var event = document.createEvent('CustomEvent');
    event.initCustomEvent('mozContentEvent', true, true, value);
    window.dispatchEvent(event);
  }

  _preventFocus = evt => {
    evt.preventDefault();
    if (evt.target === this.container) {
      this._close();
      this._cancel();
    }
  }

  _onClick = evt => {
    evt.preventDefault();
    this._choose(parseInt(evt.target.dataset.index, 10));
  }

  get container() {
    return this.shadowRoot.querySelector('#container');
  }

  _open() {
    this.container.classList.remove('hide');
  }

  _close() {
    this.container.classList.add('hide');
    this.detail = {};
  }

  _getAppIcon(choice) {
    return choice.icon;
  }

  _getAppName(choice) {
    let app = applications.getByManifestURL(choice.manifest);
    if (!app) {
      return '';
    }

    let manifest = app.manifest;
    return new ManifestHelper(manifest).name;
  }

  _getListApp(id) {
    const _ = navigator.mozL10n;
    const prefix = 'activity-share-';
    const listApps = {
      'app://bluetooth.gaiamobile.org/manifest.webapp': {
        get text() { return _.get(prefix + 'bluetooth') },
        'icon': 'bluetooth'
      },
      'app://wallpaper.gaiamobile.org/manifest.webapp': {
        get text() { return _.get(prefix + 'wallpaper') },
        'icon': 'mobile-phone'
      },
      'app://ringtones.gaiamobile.org/manifest.webapp': {
        get text() { return _.get(prefix + 'ringtones') },
        'icon': 'reminder'
      },
      'app://contacts.gaiamobile.org/manifest.webapp': {
        get text() { return _.get(prefix + 'contacts') },
        'icon': 'mobile-phone'
      }
    }

    return listApps[id];
  }

  _renderListOptions() {
    let choices = (this.detail && this.detail.choices) ? this.detail.choices : [];

    if (this._isShare()) {
      this.detail.choices.map((choice, index) => {
        let app = this._getListApp(choice.manifest);
        if (app) {
          app.index = index;
          choices.push(app);
        }
      });

      return html`
        ${choices.map((choice) =>
          html`
            <kai-1line-listitem text="${choice.text}" data-index="${choice.index}" @click="${this._onClick}">
              <i slot="listitem-left-slot" data-icon="${choice.icon}"></i>
            </kai-1line-listitem>
          `
        )}
        <div class="${choices.length > 0 ? 'line' : 'hide'}"></div>
      `;
    } else {
      return html`
        ${choices.map((choice, index) =>
          html`
            <kai-1line-listitem text="${this._getAppName(choice)}" data-index="${index}" @click="${this._onClick}">
              <img class="list-image" slot="listitem-left-slot" src="${this._getAppIcon(choice)}">
            </kai-1line-listitem>
          `
        )}
      `;
    }
  }

  _renderGridOptions() {
    let choices = [];
    this.detail.choices.map((choice) => {
      if (!this._getListApp(choice.manifest)) {
        choices.push(choice);
      }
    });

    return html`
      ${choices.map((choice, index) =>
          html`
            <div class="grid-item" @click="${this._onClick}">
              <img class="grid-item-image" data-index="${index}" src="${this._getAppIcon(choice)}">
              <span class="grid-item-name" data-index="${index}">${this._getAppName(choice)}</span>
            </div>
          `
      )}
    `;
  }

  render(){
    const _ = navigator.mozL10n;
    const title = this.detail && this.detail.name ? _.get('activity-' + this.detail.name) : 'Actions';
    const style = this._isShare() ? 'container bottom hide' : 'container hide';

    return html`
      <div class="${style}" id="container" @mousedown="${this._preventFocus}">
        <link rel="stylesheet" type="text/css" href="https://shared.local/style/gaia-icons-embedded.css">
        <div class="popup">
          <div class="options">
            ${this._isShare()
              ? html`
                  <div class="list">${this._renderListOptions()}</div>
                  <div class="grid">${this._renderGridOptions()}</div>
                `
              : html`
                  <div class="list">${this._renderListOptions()}</div>
                `}
          </div>
        </div>
        ${!this._isShare() ? html`<div class="h3 title">${title}</div>` : ''}
      </div>
    `;
  }
}

customElements.define('action-menu', ActionMenu);
