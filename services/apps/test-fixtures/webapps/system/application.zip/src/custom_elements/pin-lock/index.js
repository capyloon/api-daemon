import { LitElement, html, css } from 'lit-element';
import * as utils from '../../util/utils';

export const EVENT_TYPES = {
  INPUT_AREA: 'input_area',
  DELETE: 'delete',
  KEYPAD: 'keypad',
  BOTTOM_TEXT: 'bottom_text',
};

export function isDigitId(id) {
  return ['1', '2', '3', '4', '5', '6', '7', '8', '9', '0'].includes(id);
}

class PINLock extends LitElement {
  static get is() {
    return 'pin-lock';
  }

  static get properties() {
    return {
      header: { type: String },
      description: { type: String },
      inputAreas: { type: Array },
      inputs: { type: Object },
      hints: { type: Object },
      activeInputId: { type: String },
      smallkeypad: { type: Boolean },
      submittable: { type: Boolean },
      bottomtext: { type: String },
    };
  }

  static get styles() {
    return css`
      :host {
        width: 100%;
        height: 100%;
        background-color: rgba(0, 0, 0, 0.9);
        display: flex;
        flex-direction: column;
        align-items: center;
        padding: 0 4rem;
        box-sizing: border-box;
        text-align: center;
      }

      .header {
        width: 100%;
        color: var(--color-gs100);
        margin-top: 2.4rem;
        height: 6.2rem;
        display: flex;
        justify-content: center;
        align-items: center;
      }

      .description {
        width: 100%;
        color: var(--color-gs80);
        height: 3rem;
        display: flex;
        justify-content: center;
        align-items: center;
      }

      /*
        the inputfield's height is flexible.
        because the :host height is 100%,
        set height: flex-grow: 1 to inputfield is not working.
        caculate the inputfield height by minus keypad's height
        and the margin with bottom-text.
      */
      .has-smallkeypad > .inputfield {
        height: calc(100% - 25rem - 1rem);
      }

      .inputfield {
        width: 100%;
        height: calc(100% - 31rem - 2rem);
        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: center;
      }
      .inputfield > .area {
        width: 100%;
        min-height: 7.6rem;
      }
      .area > .label {
        color: var(--color-gs60);
        text-transform: none;
      }
      .area > .input-area {
        width: 100%;
        display: flex;
        align-items: center;
        color: var(--color-gs100);
      }
      .input-area > .inputbox {
        flex-grow: 1;
        height: 2.4rem; /* TODO: check height */
        background-color: transparent;
        display: flex;
        align-items: center;
        justify-content: center;
        /*
          set this padding to make dots looks like center aligned.
        */
        padding-left: 0.2rem;
      }
      .input-area > .inputbox::first-child {
        margin-left: 0;
      }
      .input-area > .inputbox > .half-dot {
        color: var(--color-gs100);
        width: 0.4rem;
        height: 0.8rem;
        background-color: var(--color-gs100);
        border-radius: 0 0.4rem 0.4rem 0;
        display: inline-block;
      }
      .input-area > .inputbox > .dot {
        color: var(--color-gs100);
        width: 0.8rem;
        height: 0.8rem;
        margin-left: 1.5rem;
        background-color: var(--color-gs100);
        border-radius: 50%;
        display: inline-block;
      }
      .input-area > .inputbox > .cursor {
        width: 0.1rem;
        height: 2.4rem; /* TODO: check height */
        background-color: var(--color-gs100);
        margin-left: 0.6rem;
      }
      .input-area > .delete {
        /* TODO: check size */
        font-size: 1.9rem; /* to align the inputbox height */
      }
      .input-area > .delete.disabled {
        pointer-events: none;
        color: var(--color-gs60);
      }
      .area > .line {
        width: 100%;
        height: 0.2rem;
        background-color: var(--theme-color);
        box-sizing: border-box;
        border-radius: 0.1rem;
        margin-top: 0.4rem;
      }
      .area > .line.disabled {
        pointer-events: none;
        background-color: var(--color-gs20);
      }
      .area > .hint {
        color: var(--color-error);
        margin-top: 0.2rem;
      }

      .keypad {
        width: 100%;
        height: 31rem;
        display: flex;
        flex-wrap: wrap;
        align-items: center;
        justify-content: space-between;
        margin: 2rem 0;
      }
      .keypad.small {
        height: 25rem;
        margin: 1rem 0;
      }
      .keypad > .item {
        display: flex;
        justify-content: center;
        align-items: center;
        color: var(--color-gs100);
        width: 8rem;
        height: 6rem;
      }
      .keypad.small > .item {
        width: 7rem;
        height: 5rem;
      }
      .keypad > .digit {
        border-radius: 3rem;
        border: solid 0.2rem var(--color-gs80);
        background-color: var(--color-gs00);
      }
      .keypad > .ok {
        border-radius: 3rem;
        background-color: var(--theme-color);
      }
      .keypad > .ok.disabled {
        pointer-events: none;
        background-color: var(--color-gs20);
      }

      .bottom-text {
        width: 100%;
        color: var(--color-gs100);
        position: absolute;
        left: 0;
        bottom: 2.5rem;
        height: 3.8rem;
        display: flex;
        justify-content: center;
        align-items: center;
      }

      @media screen and (orientation: landscape) {
        :host {
          display: block;
          padding: 0;
        }

        .header {
          position: fixed;
          left: 0;
          top: 2rem;
          width: 50%;
          height: 4rem;
          padding: 0 3.5rem;
          margin: 0;
          box-sizing: border-box;
        }

        .description {
          position: fixed;
          left: 0;
          top: calc(2rem + 4rem); /* header's margin-top and height */
          width: 50%;
          height: 3rem;
          padding: 0 3.5rem;
          box-sizing: border-box;
        }

        .has-smallkeypad > .inputfield {
          top: calc(2rem + 4rem); /* header's margin-top and height */
          height: calc(
            100% - 2rem - 4rem - 3.8rem - 3rem - var(--infogation-bar-height)
          );
        }

        .has-description > .inputfield {
          /* header's margin-top, height, description's height */
          top: calc(2rem + 4rem + 3rem);
          height: calc(
            100% - 2rem - 4rem - 3rem - 3.8rem - 3rem -
              var(--infogation-bar-height)
          );
        }

        .inputfield {
          position: fixed;
          left: 0;
          top: calc(2rem + 4rem); /* header's margin-top and height */
          width: 50%;
          /*
            header's margin-top, height, description's height, bottom's height
            and padding-bottom
           */
          height: calc(
            100% - 2rem - 4rem - 3.8rem - 3rem - var(--infogation-bar-height)
          );
          padding: 0 3.5rem;
          box-sizing: border-box;
        }

        .keypad.small {
          height: calc(100% - var(--infogation-bar-height));
          margin: 0;
        }

        .keypad {
          position: fixed;
          right: 0;
          width: 50%;
          height: calc(100% - var(--infogation-bar-height));
          margin: 0;
          padding: 4.4rem 10.6rem;
          box-sizing: border-box;
        }

        .keypad > .item {
          width: 7rem;
          height: 5rem;
        }

        .bottom-text {
          position: fixed;
          left: 0;
          width: 50%;
          height: 3.8rem;
          bottom: calc(3rem + var(--infogation-bar-height));
          padding: 0 3.5rem;
          box-sizing: border-box;
        }
      }

      .hide {
        display: none;
      }
    `;
  }

  constructor() {
    super();
    this.header = '';
    this.description = '';
    this.inputAreas = [];
    this.inputs = {};
    this.hints = {};
    this.activeInputId = '';
    this.smallkeypad = false;
    this.submittable = false;
    this.bottomtext = '';
  }

  _fireCustomEvent(detail) {
    const event = new CustomEvent('pinlock-click', {
      detail,
      bubbles: true,
      composed: true,
    });
    this.dispatchEvent(event);
  }

  _renderHeader() {
    if (this.header) {
      return html`
        <div class="h3 header">${this.header}</div>
      `;
    }
  }

  _renderDescription() {
    if (this.description) {
      return html`
        <div class="body-2 description">
          ${this.description}
        </div>
      `;
    }
  }

  _onClickInput(evt) {
    this._fireCustomEvent({
      type: EVENT_TYPES.INPUT_AREA,
      activeInputId: evt.currentTarget.id,
    });
  }

  _onDelete(evt) {
    evt.stopPropagation();
    if (this.activeInputId) {
      this._fireCustomEvent({
        type: EVENT_TYPES.DELETE,
        activeInputId: this.activeInputId,
      });
    }
  }

  _rederInputArea(area) {
    /*
     if input length over 10, there is a half-dot on inputbox left side.
     this is a workaround to prevent inputbox contents overflow.
    */
    return html`
      <div class="area">
        <div class="h5 label">${area.label}</div>
        <div class="input-area" id=${area.id} @click="${this._onClickInput}">
          <div class="subtitle-1 inputbox">
            ${this.inputs[area.id].length > 10
              ? html`
                  <span class="half-dot"></span>
                `
              : ''}
            ${this.inputs[area.id].slice(0, 10).map(
              () =>
                html`
                  <span class="dot"></span>
                `
            )}
            <span
              class="cursor ${this.activeInputId === area.id ? '' : 'hide'}"
            ></span>
          </div>
          <div
            class="delete ${this.inputs[area.id].length === 0 ||
            this.activeInputId !== area.id
              ? 'disabled'
              : ''}"
            data-icon="ime-delete"
            @click="${this._onDelete}"
          ></div>
        </div>
        <div
          class="line ${this.activeInputId === area.id ? '' : 'disabled'}"
        ></div>
        <div class="subtitle-2 hint">
          ${this.hints[area.id]}
        </div>
      </div>
    `;
  }

  _renderInputField() {
    if (this.inputAreas.length > 0 && Object.keys(this.inputs).length > 0) {
      return html`
        <div class="inputfield">
          ${this.inputAreas.map(
            area =>
              html`
                ${this._rederInputArea(area)}
              `
          )}
        </div>
      `;
    }
  }

  _isValidId(id) {
    return ['1', '2', '3', '4', '5', '6', '7', '8', '9', '0', 'ok'].includes(
      id
    );
  }

  _onClickKeypad(e) {
    const isItem = e.target.classList.contains('item');
    const id = e.target.id;
    if (isItem && this._isValidId(id) && this.activeInputId) {
      this._fireCustomEvent({
        type: EVENT_TYPES.KEYPAD,
        id,
        activeInputId: this.activeInputId,
      });
    }
  }

  _renderKeypad() {
    return html`
      <div
        class="keypad ${this.smallkeypad ? 'small' : ''}"
        @click="${this._onClickKeypad}"
      >
        <div id="1" class="item digit h3">1</div>
        <div id="2" class="item digit h3">2</div>
        <div id="3" class="item digit h3">3</div>
        <div id="4" class="item digit h3">4</div>
        <div id="5" class="item digit h3">5</div>
        <div id="6" class="item digit h3">6</div>
        <div id="7" class="item digit h3">7</div>
        <div id="8" class="item digit h3">8</div>
        <div id="9" class="item digit h3">9</div>
        <div id="empty" class="item"></div>
        <div id="0" class="item digit h3">0</div>
        <div id="ok" class="item ok h4 ${this.submittable ? '' : 'disabled'}">
          ${utils.toL10n('ok')}
        </div>
      </div>
    `;
  }

  _onClickBottomText() {
    this._fireCustomEvent({ type: EVENT_TYPES.BOTTOM_TEXT });
  }

  _renderBottomText() {
    if (this.bottomtext) {
      return html`
        <div class="h4 bottom-text" @click="${this._onClickBottomText}">
          ${this.bottomtext}
        </div>
      `;
    }
  }

  _preventFocus(evt) {
    evt.preventDefault();
  }

  render() {
    return html`
      <div
        class="theme-kaibrand dark-fixed ${this.smallkeypad
          ? 'has-smallkeypad'
          : ''} ${this.description ? 'has-description' : ''}"
        @mousedown="${this._preventFocus}"
      >
        ${this._renderHeader()} ${this._renderDescription()}
        ${this._renderInputField()} ${this._renderKeypad()}
        ${this._renderBottomText()}
      </div>
    `;
  }
}

customElements.define(PINLock.is, PINLock);
