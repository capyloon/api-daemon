/* global Service, ScreenManager */
import { LitElement, html, css } from 'lit-element';
import { connect } from '../redux';
import './kai-notification';
import { getMozAppIcon } from '../util/utils.js';
import mozL10n from '../app_umd/l10n.js';

function delay(duration) {
  return new Promise(resolve => {
    setTimeout(() => {
      resolve();
    }, duration);
  });
}
class StandaloneNotification extends LitElement {
  static get is() {
    return 'standalone-notification';
  }

  name = 'StandaloneNotification';
  TIMEOUT = 2000;

  static get properties() {
    return {
      icon: { type: String },
      appname: { type: String },
      timestamp: { type: String },
      noticetitle: { type: String },
      bodytext: { type: String },
      _isKeyboardActivated: { type: Boolean },
      _isVisible: { type: Boolean }
    };
  }

  static get styles() {
    return css`
      .popup {
        position: absolute;
        left: 0;
        right: 0;
        margin: 0 auto;
        z-index: var(--z-index-notice);
      }
      .pin-to-bottom {
        bottom: 7rem;
      }
      .pin-to-top {
        top: 2rem;
      }

      /* make keyframes that tell the start state and the end state of our
      object */
      @keyframes fadeIn {
        from {
          opacity: 0;
          transform-origin: bottom;
          transform: scaleY(0.8);
        }
        to {
          opacity: 1;
          transform: scaleY(1);
        }
      }

      @keyframes fadeInText {
        from {
          opacity: 0;
        }
        to {
          opacity: 1;
        }
      }

      @keyframes fadeOut {
        0% {
          opacity: 1;
          transform: translateX(0);
        }
        99% {
          opacity: 0.01;
          transform: translateX(-20%);
        }
        100% {
          opacity: 0;
        }
      }

      .fade-in {
        opacity: 0;
        /* make things invisible upon start */
        animation: fadeIn 1s cubic-bezier(0, 0, 0.25, 1);
        animation-fill-mode: forwards;
        /* this makes sure that after animation is done we remain at the last
        keyframe value (opacity: 1)*/
      }

      .fade-in-text {
        opacity: 0;
        animation: fadeInText 0.15s cubic-bezier(0, 0, 0.25, 1);
        animation-fill-mode: forwards;
        animation-delay: 0.25s;
      }

      .fade-out {
        animation: fadeOut 0.5s;
        animation-fill-mode: forwards;
      }
    `;
  }

  constructor() {
    super();
    this.icon = '';
    this.appname = '';
    this.timestamp = '';
    this.noticetitle = '';
    this.bodytext = '';
    this._isKeyboardActivated = false;
    this._isVisible = false;
    Service.register('show', this);
  }

  show(notification) {
    // console.warn(notification, notification.type);
    if (Service.query('remoteLockEnabled')) {
      return;
    }
    ScreenManager.turnScreenOn();
    if (notification.type === 'desktop-notification') {
      this.appname = notification.appName;
      this.noticetitle = notification.title;
      this.bodytext = notification.text;
      this.timestamp = new mozL10n.DateTimeFormat().fromNow(
        notification.timestamp
      );
      getMozAppIcon(notification.appName)
        .then(iconUrl => {
          this.icon = iconUrl;
        })
        .catch(err => console.error(err));
      this._showStandaloneNotification();
    }
  }

  get notification() {
    return this.shadowRoot.querySelector('kai-notification');
  }

  firstUpdated() {
    this.notification.style.display = 'none';
    this.notification.addEventListener('animationend', e => {
      if (e.animationName === 'fadeOut') {
        this.notification.style.display = 'none';
      }
    });
  }

  _clickFadeOut() {
    this._isVisible = false;
  }

  _showStandaloneNotification() {
    this._isVisible = true;
    this.notification.style.display = 'block';

    delay(this.TIMEOUT)
      .then(() => {
        this._isVisible = false;
      })
      .catch(error => {
        console.warn(error);
      });
  }

  _preventFocus = evt => {
    evt.preventDefault();
  };

  render() {
    return html`
      <kai-notification
        class="popup ${this._isKeyboardActivated
          ? 'pin-to-top'
          : 'pin-to-bottom'}
          ${this._isVisible ? 'fade-in' : 'fade-out'}"
        @mousedown="${this._preventFocus}"
        @click="${this._clickFadeOut}"
        .icon="${this.icon}"
        .appname="${this.appname}"
        .noticetitle="${this.noticetitle}"
        .bodytext="${this.bodytext}"
        .timestamp="${this.timestamp}"
      >
      </kai-notification>
    `;
  }
}

const mapStateToProps = state => {
  return {
    _isKeyboardActivated: state.isKeyboardActivated
  };
};

customElements.define(
  StandaloneNotification.is,
  connect(mapStateToProps)(StandaloneNotification)
);
