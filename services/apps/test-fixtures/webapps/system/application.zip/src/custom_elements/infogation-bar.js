/* global SettingsListener SIMSlotManager */

import { LitElement, html, css } from 'lit-element';
import { connect } from '../redux';
import { mode as screenlockMode } from '../constants/screenlock';
import { genHardwareKeyEvent, objHasChanged } from '../util/utils.js';
import NotificationStore from '../notification_store';

const HOMESCREEN_STATUS = {
  HOME: 'home',
  APPS_MENU: 'apps-menu'
};

const processButtonEvent = (event, key) => {
  switch (event.type) {
    case 'touchstart':
    case 'mousedown':
      genHardwareKeyEvent(key, 'keydown');
      break;
    case 'touchend':
    case 'mouseup':
      genHardwareKeyEvent(key, 'keyup');
      break;
    default:
      // only send key events on touchstart & touchend
      break;
  }
};

const leftButtonAction = {
  sendBackspaceKey: (event) => {
    processButtonEvent(event, 'Backspace');
  },
  dismissKeyboard: (event) => {
    // Dismiss keyboard on tap(touchstart/mousedown) starts.
    if ('touchstart' === event.type || 'mousedown' === event.type) {
      navigator.mozInputMethod && navigator.mozInputMethod.removeFocus();
    }
  }
};

const centerButtonAction = {
  // When keyboard is activated, sending context menu/home btn event
  // will also dismiss keyboard but slower than current app window.
  // Because input focus was not taken off, dismiss keyboard whenever
  // context button pressed makes better user experience.
  sendContextMenuKey: (event) => {
    leftButtonAction.dismissKeyboard(event);
    processButtonEvent(event, 'ContextMenu');
  },
  sendHomeKey: (event) => {
    leftButtonAction.dismissKeyboard(event);
    processButtonEvent(event, 'Home');
  },
};

class InfogationBar extends LitElement {
  name = 'InfogationBar';

  static get is() {
    return 'infogation-bar';
  }

  static get properties() {
    return {
      _isHomescreen: { type: Boolean },
      _isFullscreen: { type: Boolean },
      _isLeftButtonEnabled: { type: Boolean },
      _isKeyboardActivated: { type: Boolean },
      _homescreenUrl: { type: String },
      lockscreenMode: { type: String },
      timeLabel: { type: String },
      batteryState: {
        type: Object,
        hasChanged: objHasChanged,
      },
      wifiState: { type: Object },
      isInstantPanelShown: { type: Boolean },
      isSIMSecurityActivated: { type: Boolean },
      notificationSize: { type: Number },
      iconVisibility: { type: Object },
      simState: { type: Object },
      portals: { type: Object }
    };
  }

  static get styles() {
    const fixedWhiteColor = css`#e9e9f2`;
    const host = css`
      :host {
        z-index: var(--z-index-infogation-bar);
        color: var(--color-gs100);
      }

      .root {
        background-color: var(--infogation-bar-bgcolor);
        position: relative;
      }

      .root .bar {
        width: 100%;
        height: var(--infogation-bar-height);
        display: flex;
        align-items: center;
        padding: 0px 0.8rem;
        box-sizing: border-box;
      }

      .root .portal-line {
        position: absolute;
        bottom: 0;
        left: 0;
        width: 100%;
        height: 0.3rem;
      }
    `;

    const icon = css`
      [data-icon] {
        font-size: 2rem;
        white-space: nowrap;
      }

      [data-icon='all-apps'] {
        font-size: 1.4rem;
      }

      .icon-calling {
        color: var(--color-green);
        font-size: 3.2rem;
      }
    `;

    const column = css`
      .column {
        display: flex;
        align-items: center;
        overflow: hidden;
      }

      .column-left {
        justify-content: flex-start;
        flex-basis: 3.4rem;
      }

      .column-portal {
        justify-content: center;
        flex-basis: 32%;
      }

      .column-center {
        justify-content: center;
        position: relative;
        flex-grow: 1;
        overflow: visible;
      }

      .column-right {
        justify-content: flex-end;
        flex-basis: 41%;
      }
    `;

    const left = css`
      .left-icon {
        width: 3.2rem;
        height: 3.2rem;
        font-size: 3.2rem;
        background-color: var(--infogation-bar-left-icon-bgcolor);
        border-radius: 50%;
        display: flex;
        align-items: center;
        justify-content: center;
      }
    `;

    const portal = css`
      .portal-icon {
        width: 2.8rem;
        height: 2.8rem;
      }
    `;

    const center = css`
      .battery-charge {
        font-size: 1.8rem;
        position: absolute;
        left: -1.6rem;
        line-height: 0;
      }

      .battery-badge {
        width: 6.4rem;
        height: 2.6rem;
        border-radius: 2rem;
        border: solid 0.3rem var(--infogation-bar-battery-badge-bordercolor);
        background-color: var(--color-gs20);
        position: relative;
        overflow: hidden;
      }

      .battery-badge.full-charged,
      .battery-badge.charging {
        background-color: var(--infogation-bar-battery-badge-charging-color);
        color: ${fixedWhiteColor};
      }

      .battery-badge.low {
        background-color: var(--infogation-bar-battery-badge-low-color);
        color: ${fixedWhiteColor};
      }

      .battery-badge__level {
        width: 100%;
        height: 100%;
        background-color: var(--infogation-bar-battery-level-bgcolor);
        border-radius: 2rem 0 0 2rem;
        position: absolute;
        top: 0;
        left: 0;
      }

      .battery-badge__level.full-charged,
      .battery-badge__level.charging {
        background-color: var(--color-green);
      }

      .battery-badge__level.low {
        background-color: var(--color-pink);
      }

      .battery-badge__content {
        width: 100%;
        height: 100%;
        display: flex;
        align-items: center;
        justify-content: center;
        position: absolute;
        top: 0;
        left: 0;
      }

      .battery-level,
      time.clock {
        display: flex;
        align-items: center;
        justify-content: center;
      }

      .battery-level i.percentage {
        margin: auto;
        font-size: 1.4rem;
      }

      .battery-level i.digits,
      time.clock i.digits {
        width: unset;
        height: unset;
        font-size: 1.4rem;
        margin: auto -0.2rem;
      }

      time.clock i.colon {
        display: flex;
        flex-direction: column;
        justify-content: center;
        padding: 0 0.2rem;
      }

      time.clock i.colon:before,
      time.clock i.colon:after {
        display: block;
        content: '';
        width: 0.3rem;
        height: 0.3rem;
        margin: 0.1rem 0;
        border-radius: 50%;
        background-color: var(--color-gs100);
      }

      .battery-badge.full-charged time.clock i.colon:before,
      .battery-badge.full-charged time.clock i.colon:after,
      .battery-badge.charging time.clock i.colon:before,
      .battery-badge.charging time.clock i.colon:after,
      .battery-badge.low time.clock i.colon:after,
      .battery-badge.low time.clock i.colon:after {
        background-color: ${fixedWhiteColor};
      }
    `;

    const right = css`
      .right-icons {
        height: 3.2rem;
        padding: 0 1.2rem;
        border-radius: 1.6rem;
        background-color: var(--infogation-bar-right-icons-bgcolor);
        overflow: hidden;
        display: flex;
        align-items: center;
      }

      .right-icons > div {
        display: flex;
        align-items: center;
      }

      .right-icons > div > :not(:last-child) {
        margin-right: 0.6rem;
      }

      .right-icons > .status-icons {
        flex-grow: 1;
        justify-content: flex-end;
      }

      .status-icons > .indicator {
        width: 2rem;
        height: 2rem;
        border: solid 0.19rem var(--color-gs100);
        background: var(--infogation-bar-indicator-bgcolor);
        border-radius: 0.5rem;
        border-bottom-right-radius: 0;
        display: flex;
        align-items: center;
        justify-content: center;
        font-size: 1.25rem;
        font-weight: bold;
      }
    `;

    const dynamicIcons = css`
      .icon-sim,
      .icon-wifi {
        position: relative;
        /* aligin with data-icon font size */
        width: 2rem;
        height: 2rem;
        line-height: 100%;
      }

      .icon-wifi[data-icon='wifi-0']:before {
        opacity: 0;
      }

      .icon-sim__mask,
      .icon-wifi__mask {
        position: absolute;
        top: 0;
        opacity: 0.5;
      }

      .icon-sim [data-icon='signal-roaming'] {
        position: absolute;
        top: 0;
      }

      .icon-wifi [data-icon='wifi-permissions'] {
        position: absolute;
        top: 0;
      }

      .icon-sim--searching {
        background: url('assets/images/signal-searching.png') no-repeat 0 0 /
          2rem;
      }

      .icon-wifi--connecting {
        background: url('assets/images/wifi-connecting.png') no-repeat 0 0 /
          2rem;
      }

      .icon-sim--connecting .icon-sim__mask,
      .icon-sim--connecting[data-icon]:before,
      .icon-wifi--connecting .icon-wifi__mask,
      .icon-wifi--connecting[data-icon]:before {
        display: none;
      }
    `;

    const instantPanelShown = css`
      .root--instantPanelShown .column {
        display: flex;
        align-items: center;
      }

      .root--instantPanelShown .column-right {
        flex-grow: 1;
        margin-left: 1rem;
      }

      .root--instantPanelShown .column-right > .right-icons {
        width: 100%;
        justify-content: space-between;
      }

      .battery-info {
        margin-right: 0.6rem;
      }

      .battery-info.low {
        color: var(--color-pink);
      }

      .battery-icon {
        position: relative;
        line-height: 0;
        width: 2.4rem;
      }

      .battery-icon > i {
        position: absolute;
        font-size: 2.4rem;
        width: 2.4rem;
      }

      .battery-icon > .plugged {
        opacity: 0.5;
      }

      .battery-percent {
        font-size: 1.4rem;
        font-weight: 600;
      }
    `;

    const transparentRoot = css`
      .root--transparent {
        background-color: transparent;
        background-image: linear-gradient(
          to bottom,
          rgba(0, 0, 0, 0),
          rgba(0, 0, 0, 0.3)
        );
      }

      .root--transparent .battery-badge {
        border: solid 0.3rem rgba(0, 0, 0, 0.5);
        background-color: #004080;
        color: ${fixedWhiteColor};
      }

      .root--transparent .battery-badge.full-charged,
      .root--transparent .battery-badge.charging {
        background-color: var(--infogation-bar-battery-badge-charging-color);
      }

      .root--transparent .battery-badge.low {
        background-color: var(--infogation-bar-battery-badge-low-color);
      }

      .root--transparent .battery-badge__level {
        background-color: var(--color-blue);
      }

      .root--transparent .battery-badge__level.full-charged,
      .root--transparent .battery-badge__level.charging {
        background-color: var(--color-green);
      }

      .root--transparent .battery-badge__level.low {
        background-color: var(--color-pink);
      }

      .root--transparent .right-icons {
        background-color: rgba(0, 0, 0, 0.5);
        color: ${fixedWhiteColor};
      }
      .root--transparent .battery-charge {
        color: ${fixedWhiteColor};
      }
    `;

    const fullscreen = css`
      :host.fullscreen {
        position: absolute;
        width: 100%;
        left: 0;
        bottom: 0;
      }

      :host.fullscreen .column-left,
      :host.fullscreen .column-right {
        visibility: hidden;
        pointer-events: none;
      }

      :host.fullscreen .column-center {
        align-self: flex-end;
        margin-bottom: 1.4rem;
      }

      :host.fullscreen .root--transparent .battery-badge,
      :host.fullscreen .root--transparent .battery-badge.full-charged,
      :host.fullscreen .root--transparent .battery-badge.charging,
      :host.fullscreen .root--transparent .battery-badge.low {
        height: 0.6rem;
        border: solid 0.2rem rgba(0, 0, 0, 0.3);
        background-color: var(--color-gs40);
      }

      :host.fullscreen .root--transparent .battery-badge__level,
      :host.fullscreen .root--transparent .battery-badge__level.full-charged,
      :host.fullscreen .root--transparent .battery-badge__level.charging,
      :host.fullscreen .root--transparent .battery-badge__level.low {
        background-color: ${fixedWhiteColor};
      }

      :host.fullscreen .battery-badge__content,
      :host.fullscreen .battery-charge {
        visibility: hidden;
      }
    `;

    const landscape = css`
      @media screen and (orientation: landscape) {
        .column-portal {
          flex-basis: 38%;
        }

        .battery-charge {
          left: 20%;
        }
      }
    `;

    return [
      host,
      icon,
      column,
      left,
      portal,
      center,
      right,
      dynamicIcons,
      instantPanelShown,
      transparentRoot,
      fullscreen,
      landscape,
    ];
  }

  // Left to Right (Priority: Low to High)
  PRIORITY = ['signals', 'connections', 'wifi', 'airplane'];

  SETTINGS = {
    'airplaneMode.status': { default: 'disabled', icon: 'airplane' },
    'wifi.enabled': { default: false, icon: 'wifi' },
    'ril.data.enabled': { default: false, icon: 'connections' },
  };

  /* A mapping table between technology names
     we would get from API v.s. the icon we want to show. */
  MOBILE_DATA_ICON_TYPES = {
    lte: 'lte', // 4G LTE
    ehrpd: '4g', // 4G CDMA
    'hspa+': 'hspa-plus', // 3.5G HSPA+
    hsdpa: 'hspa',
    hsupa: 'hspa',
    hspa: 'hspa', // 3.5G HSDPA
    evdo0: 'ev',
    evdoa: 'ev',
    evdob: 'ev', // 3G CDMA
    umts: '3g', // 3G
    tdscdma: '3g', // TDS-CDMA
    edge: 'edge', // EDGE
    gprs: '2g',
    '1xrtt': '1x',
    is95a: '1x',
    is95b: '1x', // 2G CDMA
  };

  constructor() {
    super();
    this._isFullscreen = false;
    this._isLeftButtonEnabled = true;
    this._homescreenlocationchangeHandler =
      this._homescreenlocationchangeHandler.bind(this);
    this._lockscreenModechangeHandler =
      this._lockscreenModechangeHandler.bind(this);
    this.lockscreenMode = screenlockMode.UNLOCKED;
    this.portals = {
      calling: '',
      recording: '',
      hotspot: '',
      geolocation: ''
    };
    this.notificationSize = 0;
    this.iconVisibility = { signals: true };
    this.simState = { data: {}, voice: {}, isAbsent: true };
    this.wifiState = {
      connecting: false,
      connected: false,
      signalLevel: 0,
      hasInternet: false,
    };
    window.Service.register('toggleInstantPanel', this);
  }

  firstUpdated() {
    // setup the notification store event
    NotificationStore.on('changed', () => {
      this.notificationSize = NotificationStore.unreadCount();
    });

    // add settings event listeners
    Object.keys(this.SETTINGS).forEach(settingKey => {
      this._addSettingsListener(settingKey);
    });

    this._initWifiListeners();

    this._initMobileConnectionListeners();
  }

  _addSettingsListener(settingKey) {
    SettingsListener.observe(
      settingKey, // name
      this.SETTINGS[settingKey].default, // defaultValue
      status => {
        // callback
        this._verifyIconVisibility(this.SETTINGS[settingKey].icon, status);
      },
      {
        //options
        forceClose: true,
      }
    );
  }

  _initWifiListeners() {
    const wifiManager = navigator.mozWifiManager;
    if (wifiManager) {
      wifiManager.addEventListener('statuschange', this);
      wifiManager.addEventListener('connectioninfoupdate', this);
      wifiManager.addEventListener('wifihasinternet', this);
    }
  }

  _initMobileConnectionListeners() {
    const conns = navigator.mozMobileConnections;
    if (conns) {
      Array.from(conns).forEach(conn => {
        conn.addEventListener('datachange', this);
        conn.addEventListener('voicechange', this);
        conn.addEventListener('signalstrengthchange', this);
      });
    }
  }

  handleEvent(event) {
    const type = event.type;
    switch (type) {
      case 'statuschange':
      case 'connectioninfoupdate':
      case 'wifihasinternet':
        this._updateWiFiState(event);
        break;
      case 'datachange':
      case 'voicechange':
      case 'signalstrengthchange':
        this._updateSIMState(type);
        break;
      default:
        break;
    }
  }

  _updateWiFiState(event) {
    const type = event.type;
    const wifiManager = navigator.mozWifiManager;
    if (type === 'statuschange') {
      const status = event.status;
      switch (status) {
        case 'disconnected':
        case 'dhcpfailed':
        case 'authenticationfailed':
        case 'associationreject':
          this.wifiState = {
            ...this.wifiState,
            connecting: false,
            connected: false,
          };
          break;
        case 'connecting':
        case 'associated':
          this.wifiState = {
            ...this.wifiState,
            connecting: true,
            connected: false,
          };
          break;
        case 'connected':
          this.wifiState = {
            ...this.wifiState,
            connecting: false,
            connected: true,
            hasInternet: wifiManager.hasInternet,
          };
          break;
        default:
          break;
      }
    }
    if (type === 'connectioninfoupdate') {
      const signalLevel = Math.min(
        Math.floor(wifiManager.connectionInformation.relSignalStrength / 20),
        4
      );
      this.wifiState = {
        ...this.wifiState,
        signalLevel,
      };
    }
    if (type === 'wifihasinternet') {
      this.wifiState = {
        ...this.wifiState,
        hasInternet: event.hasInternet,
      };
    }
  }

  _hasActiveCall() {
    const telephony = navigator.mozTelephony;
    // will return true as soon as we begin dialing
    return !!(telephony && telephony.active);
  }

  _updateSIMState(type) {
    const simSlots = SIMSlotManager.getSlots();
    const hasActiveCall = this._hasActiveCall();
    // TODO: multiple SIMs
    // const isMultiSIM = SIMSlotManager.isMultiSIM();
    const slotIdx = 0;
    const simslot = simSlots[slotIdx];
    const conn = simslot.conn;
    const isAbsent = !conn.iccId;
    const data = conn.data;
    const voice = conn.voice;
    const dataConnected = data && data.connected;
    const voiceConnected = voice && voice.connected;

    let roaming = false;
    let connInfo = data;
    if (dataConnected && data.type && data.type.startsWith('evdo')) {
      // "Carrier" / "Carrier (Roaming)" (EVDO)
      // Show signal strength of data call as EVDO only supports data call.
      connInfo = data;
      roaming = connInfo.roaming;
    } else if (
      conn.radioState &&
      (voiceConnected ||
        (data && data.state === 'registered') ||
        (hasActiveCall && navigator.mozTelephony.active.serviceId === slotIdx))
    ) {
      // "Carrier" / "Carrier (Roaming)"
      // If voice.connected is false but there is an active call, we should
      // check whether the service id of that call equals the current index
      // of the target sim card. If yes, that means the user is making an
      // emergency call using the target sim card. In such case we should
      // also display the signal bar as the normal cases.
      connInfo = voiceConnected || hasActiveCall ? voice : data;
      roaming = connInfo.roaming;
    }

    const signalStrength = conn.signalStrength;
    let level = -1;
    if (signalStrength) {
      // signalStrength.level range: 0-4 as normal case
      // -1 is a special case for out-of-serivce.
      // signal icon range: 1-5
      level = signalStrength.level + 1;
    } else {
      level = Math.ceil(connInfo.relSignalStrength / 20); // 0-5
    }

    switch (type) {
      case 'datachange':
        this.simState = {
          ...this.simState,
          data,
          isAbsent,
          roaming,
        };
        break;
      case 'voicechange':
        this.simState = {
          ...this.simState,
          voice,
          isAbsent,
          roaming,
        };
        break;
      case 'signalstrengthchange':
        this.simState = {
          ...this.simState,
          level,
          isAbsent,
          roaming,
        };
        break;
      default:
        break;
    }
  }

  _updateIconVisibility(icon, show) {
    this.iconVisibility = {
      ...this.iconVisibility,
      [icon]: show,
    };
  }

  _verifyIconVisibility(icon, status) {
    switch (icon) {
      case 'airplane':
        if (status === 'enabled') {
          this._updateIconVisibility('airplane', true);
        } else if (status === 'disabled') {
          // Hidden when Airplane mode is off.
          this._updateIconVisibility('airplane', false);
        }
        break;
      case 'wifi':
        // Hidden when Wi-Fi is off.
        this._updateIconVisibility('wifi', status);
        break;
      case 'connections':
        this._updateIconVisibility('connections', status);
        break;
      default:
        break;
    }
  }

  // Retrieve the homescreen status via its hashname.
  // Note that we only take whitelisted hashes,
  // apart from that would be null.
  get homescreenStatus() {
    if (this._isHomescreen &&
      this._homescreenUrl && this._homescreenUrl.indexOf('#') >= 0) {
      const hash = this._homescreenUrl.split('#')[1];
      if (Object.values(HOMESCREEN_STATUS).indexOf(hash) >= 0) {
        return hash;
      }
    }
    return null;
  }

  // The event handler is used for prevent from stealing focus
  // from other places.
  _preventFocus(evt) {
    evt.preventDefault();
  }

  _homescreenlocationchangeHandler(evt) {
    const homescreenAppWindow = evt.detail;
    this._homescreenUrl = homescreenAppWindow.browser.element.dataset.url;
  }

  _windowchangeHandler = () => {
    this._isLeftButtonEnabled = this.isLeftButtonEnabled();
  }

  _fullscreenchangeHandler = evt => {
    this._isFullscreen = document.mozFullScreen;
    this.shadowRoot.host.classList.toggle('fullscreen', this._isFullscreen);
  }

  _lockscreenModechangeHandler({ detail }) {
    this.lockscreenMode = detail.mode;
  }

  _updatePortals(option, value) {
    this.portals[option] = value;
    this.portals = Object.assign({}, this.portals);
  }

  _callscreenchangeHandler = evt => {
    if (!Service.query('onCall')) {
      this._updatePortals('calling', '');
      return;
    }

    if (evt.detail && evt.detail.isCallscreenWindow) {
      if ('attentionopened' === evt.type) {
        this._updatePortals('calling', '');
      }

      if ('attentionclosed' === evt.type) {
        if (Service.query('onCall')) {
          this._updatePortals('calling', 'incoming');
        } else {
          this._updatePortals('calling', '');
        }
      }
    }
  }

  isLeftButtonEnabled() {
    const topMostWindow = window.Service.query('getTopMostWindow');
    const ftuManifestURL = 'app://ftu.gaiamobile.org/manifest.webapp';
    return (
      this._isKeyboardActivated ||
      window.Service.query('SecureWindowManager.isActive') ||
      this.lockscreenMode === screenlockMode.PASSCODE ||
      !(
        window.Service.query('LockscreenView.locked') ||
        this.isSIMSecurityActivated ||
        (
          this._isHomescreen &&
          this.homescreenStatus === HOMESCREEN_STATUS.HOME
        ) ||
        (
          ftuManifestURL === topMostWindow.manifestURL
          // Add other blacklist apps in the future(if any).
        )
      )
    );
  }

  showCallscreen() {
    Service.request('showCallscreen');
  }

  connectedCallback() {
    super.connectedCallback();
    window.addEventListener('homescreenlocationchange',
      this._homescreenlocationchangeHandler);
    window.addEventListener('hierarchytopmostwindowchanged',
      this._windowchangeHandler);
    window.addEventListener('fullscreenchange',
      this._fullscreenchangeHandler);
    window.addEventListener('lockmode-change',
      this._lockscreenModechangeHandler);
    window.addEventListener('attentionopened',
      this._callscreenchangeHandler);
    window.addEventListener('attentionclosed',
      this._callscreenchangeHandler);
    navigator.mozTelephony.addEventListener('callschanged',
      this._callscreenchangeHandler);
  }

  updated(changedProperties) {
    if (
      changedProperties.has('_isKeyboardActivated') ||
      changedProperties.has('_isHomescreen') ||
      changedProperties.has('_homescreenUrl') ||
      changedProperties.has('lockscreenMode') ||
      changedProperties.has('isSIMSecurityActivated')
    ) {
      this._isLeftButtonEnabled = this.isLeftButtonEnabled();
    }
  }

  disconnectedCallback() {
    window.removeEventListener('homescreenlocationchange',
      this._homescreenlocationchangeHandler);
    window.removeEventListener('hierarchytopmostwindowchanged',
      this._windowchangeHandler);
    window.removeEventListener('fullscreenchange',
      this._fullscreenchangeHandler);
    window.removeEventListener('lockmode-change',
      this._lockscreenModechangeHandler);
    window.removeEventListener('attentionopened',
      this._callscreenchangeHandler);
    window.removeEventListener('attentionclosed',
      this._callscreenchangeHandler);
    navigator.mozTelephony.removeEventListener('callschanged',
      this._callscreenchangeHandler);
    super.disconnectedCallback();
  }

  _renderLeftColumn() {
    const leftButton = {};
    if (this.isInstantPanelShown) {
      leftButton.icon = 'arrow-down';
      leftButton.action = this.toggleInstantPanel;
    } else if (this._isLeftButtonEnabled) {
      if (this._isKeyboardActivated) {
        leftButton.icon = 'arrow-down';
        leftButton.action = leftButtonAction.dismissKeyboard;
      } else {
        leftButton.icon = 'back';
        leftButton.action = leftButtonAction.sendBackspaceKey;
      }
    } else {
      leftButton.icon = '';
      leftButton.action = null;
    }
    return html`
      <div
        class="${leftButton.icon ? 'left-icon' : ''}"
        data-icon="${leftButton.icon}"
        @touchstart="${leftButton.action}"
        @touchend="${leftButton.action}"
        @mousedown="${leftButton.action}"
        @mouseup="${leftButton.action}"
      ></div>
    `;
  }

  _renderPortalColumn() {
    /*
      Portal Icon
      In-call: Tap to go to in-call screen
      Recording: Tap to go to recording app
      Hotspot connected: Tap to go to Settings > Internet Sharing
      Navigating: Tap to go to navigating app
      show only one icon according to the priority.
    */
    if (this.portals.calling) {
      return html`
        <div
          class="icon icon-calling"
          data-icon="call-incoming"
          @touchstart="${this.showCallscreen}"
        >
        </div>
      `;
    } else {
      return html``;
    }
    // TODO: we will add more portals icons here.
  }

  _renderCenterColumn() {
    let batteryChargeIcon = '';
    let batteryBadgeClass = '';
    const isBatteryLow = this.batteryState.level < 0.15;
    if (this.batteryState.plugged && this.batteryState.level === 1) {
      batteryChargeIcon = 'plug';
      batteryBadgeClass = 'full-charged';
    } else if (this.batteryState.charging) {
      batteryChargeIcon = 'lightening';
      batteryBadgeClass = 'charging';
    } else if (isBatteryLow) {
      batteryBadgeClass = 'low';
    }
    // In order to make homescreen app has customized response to
    // the software `Home` button, we will send a 'ContextMenu' key
    // to the homescreen app while it's in the foreground;
    // Otherwise, the `Home` button will behave as usual, that is,
    // send a 'Home' key (and the system app will take care of the rest).
    let centerButton = {};
    if (
      this.isSIMSecurityActivated || // sim lock security activated
      window.Service.query('RemoteLock.isActive') || // remote lock activated
      window.Service.query('LockscreenView.locked') // lockscreen activated
    ) {
      centerButton.action = null;
    } else if (this._isHomescreen) {
      centerButton.action = centerButtonAction.sendContextMenuKey;
    } else {
      centerButton.action = centerButtonAction.sendHomeKey;
    }
    // Why using `toFixed()` ?
    // JavaScript has floating number precision issue.
    // See: https://floating-point-gui.de
    const batteryPercent = `${(this.batteryState.level * 100).toFixed()}`;
    let batteryBadgeContent = null;

    if (
      window.Service.query('RemoteLock.isActive') ||
      window.Service.query('LockscreenView.locked')
    ) {
      // Show the battery level on Lockscreen.
      batteryBadgeContent = html`
        <div class="battery-level">
          ${[...batteryPercent].map(
            digit => html`
              <i class="digits" data-icon="numeric_${digit}_rounded_bold"></i>
            `
          )}
          <i class="percentage" data-icon="percentage"></i>
        </div>
      `;
    } else if (
      this._isHomescreen &&
      this.homescreenStatus === HOMESCREEN_STATUS.HOME &&
      !this.isSIMSecurityActivated // sim lock security
    ) {
      batteryBadgeContent = html`
        <i data-icon="all-apps"></i>
      `;
    } else {
      const [hh, mm] = this.timeLabel.split(':');
      batteryBadgeContent = html`
        <time class="clock">
          <i class="digits" data-icon="numeric_${hh[0]}_rounded_bold"></i>
          <i class="digits" data-icon="numeric_${hh[1]}_rounded_bold"></i>
          <i class="colon"></i>
          <i class="digits" data-icon="numeric_${mm[0]}_rounded_bold"></i>
          <i class="digits" data-icon="numeric_${mm[1]}_rounded_bold"></i>
        </time>
      `;
    }
    return html`
      ${batteryChargeIcon
        ? html`
            <div class="battery-charge" data-icon="${batteryChargeIcon}"></div>
          `
        : ''}
      <div
        class="battery-badge ${batteryBadgeClass}"
        @touchstart="${centerButton.action}"
        @touchend="${centerButton.action}"
        @mousedown="${centerButton.action}"
        @mouseup="${centerButton.action}"
      >
        <span
          class="battery-badge__level ${batteryBadgeClass}"
          style="width: ${batteryPercent}%"
        ></span>
        <span class="battery-badge__content">
          ${batteryBadgeContent}
        </span>
      </div>
    `;
  }

  _renderNotifications() {
    // Hidden when there is no notification. Maximum number is 99.
    const indicatorNumber = this.notificationSize;
    return html`
      ${indicatorNumber > 0
        ? html`
            <div class="indicator">
              ${Math.min(indicatorNumber, 99)}
            </div>
          `
        : ''}
    `;
  }

  _renderSIMSignal() {
    // Hidden when airplane mode is on, or SIM PIN/PUK not passed.
    if (!(this.iconVisibility.airplane || this.isSIMSecurityActivated)) {
      const voice = this.simState.voice;
      const searching = voice && voice.state === 'searching';
      if (this.simState.isAbsent) {
        // Show SIM missing icon when no SIM card in SIM slot.
        return html`
          <div data-icon="no-sim"></div>
        `;
      } else {
        return html`
          <div
            class="icon-sim ${searching ? 'icon-sim--searching' : ''}"
            data-icon="signal-${this.simState.level}"
          >
            ${this.simState.roaming
              ? html`
                  <div data-icon="signal-roaming"></div>
                `
              : ''}
            <div class="icon-sim__mask" data-icon="signal-5"></div>
          </div>
        `;
      }
    } else {
      return html``;
    }
  }

  _renderCellularDataType() {
    const dataConnected = this.simState.data && this.simState.data.connected;
    const dataType = this.simState.data && this.simState.data.type;
    const dataIcon = this.MOBILE_DATA_ICON_TYPES[dataType];
    // Hidden when Wi-Fi is connected, or cellular data is not connected,
    // or airplane mode is on
    if (
      !this.wifiState.connected &&
      dataConnected &&
      !this.iconVisibility.airplane
    ) {
      return html`
        <div data-icon=${dataIcon}></div>
      `;
    } else {
      return html``;
    }
  }

  _renderWiFi() {
    // Hidden when Wi-Fi is not connected.
    if (this.wifiState.connected || this.wifiState.connecting) {
      return html`
        <div
          class="icon-wifi ${this.wifiState.connecting
            ? 'icon-wifi--connecting'
            : ''}"
          data-icon="wifi-${this.wifiState.signalLevel}"
        >
          ${!this.wifiState.hasInternet && this.wifiState.connected
            ? html`
                <div data-icon="wifi-permissions"></div>
              `
            : ''}
          <div class="icon-wifi__mask" data-icon="wifi-4"></div>
        </div>
      `;
    } else {
      return html``;
    }
  }

  _renderGeneralIcons(item) {
    if (this.iconVisibility[item]) {
      switch (item) {
        case 'signals':
          return html`
            ${this._renderSIMSignal()}
          `;
        case 'connections':
          return html`
            ${this._renderCellularDataType()}
          `;
        case 'wifi':
          return html`
            ${this._renderWiFi()}
          `;
        case 'airplane':
          return html`
            <div data-icon=${item}></div>
          `;
        default:
          return html``;
      }
    } else {
      return html``;
    }
  }

  _renderRightColumn() {
    const batteryPercent = `${(this.batteryState.level * 100).toFixed()}`;
    const isBatteryLow = this.batteryState.level < 0.15;
    /*
      0%-5%: icon0; 5%-15%: icon1; ...; 85%-95%: icon9; 95%-100%: icon10.
      Icon should be primarily red when battery level is < 15%.
      Attach a subicon when charging.
      Attach a subicon when fully charged.

      batteryPercent is String, change to Int.
    */
    const level = parseInt((+batteryPercent + 5) / 10);
    const batteryIcon = `battery-${level}`;

    const isBatteryPlugged = this.batteryState.plugged;
    let batteryChargeIcon = '';
    if (isBatteryPlugged && this.batteryState.level === 1) {
      batteryChargeIcon = 'battery-plugged-ac';
    } else if (this.batteryState.charging) {
      batteryChargeIcon = 'battery-charging';
    }

    let toggleInstantPanelAction = this.toggleInstantPanel;
    if (
      this.isSIMSecurityActivated ||
      window.Service.query('RemoteLock.isActive')
    ) {
      toggleInstantPanelAction = null;
    }

    if (this.isInstantPanelShown) {
      return html`
        <div class="right-icons">
          <div class="battery-info">
            <div class="battery-icon ${isBatteryLow ? 'low' : ''}">
              ${isBatteryPlugged
                ? ''
                : html`
                    <i data-icon="battery-0"></i>
                  `}
              ${level > 0
                ? html`
                    <i
                      class="${isBatteryPlugged ? 'plugged' : ''}"
                      data-icon=${batteryIcon}
                    ></i>
                  `
                : ''}
              ${isBatteryPlugged
                ? html`
                    <i data-icon=${batteryChargeIcon}></i>
                  `
                : ''}
            </div>
            <div class="battery-percent">${batteryPercent}%</div>
          </div>
          <div class="status-icons">
            ${this.PRIORITY.map(
              item =>
                html`
                  ${this._renderGeneralIcons(item)}
                `
            )}
          </div>
        </div>
      `;
    } else {
      return html`
        <div
          class="right-icons"
          @touchstart="${toggleInstantPanelAction}"
          @mousedown="${toggleInstantPanelAction}"
        >
          <div class="status-icons">
            ${this._renderNotifications()}
            ${this.PRIORITY.map(
              item =>
                html`
                  ${this._renderGeneralIcons(item)}
                `
            )}
          </div>
        </div>
      `;
    }
  }

  render() {
    // Why use `touchstart`:
    // if we attach `_leftButtonHandler` to `click` event,
    // somehow the generated key events(in app side) cannot be captured by
    // `preventDefault` and `stopPropagation` correctly.
    const transparentRoot =
      !this.isInstantPanelShown &&
      !this.isSIMSecurityActivated &&
      ((this._isHomescreen &&
        this.homescreenStatus === HOMESCREEN_STATUS.HOME) ||
        window.Service.query('LockscreenView.locked') ||
        this._isFullscreen);
    return html`
      <div
        class="root
      ${this.isInstantPanelShown ? 'root--instantPanelShown' : ''}
      ${transparentRoot ? 'root--transparent' : ''}"
        @touchstart="${this._preventFocus}"
        @mousedown="${this._preventFocus}"
      >
        <link rel="stylesheet" type="text/css" href="https://shared.local/style/gaia-icons-embedded.css">
        <div class="bar">
          <div class="column column-left">
            ${this._renderLeftColumn()}
          </div>

          ${!this.isInstantPanelShown
            ? html`
                <div class="column column-portal">
                  ${this._renderPortalColumn()}
                </div>
                <div class="column column-center">
                  ${this._renderCenterColumn()}
                </div>
              `
            : ''}

          <div class="column column-right">
            ${this._renderRightColumn()}
          </div>
        </div>
        <div class="portal-line"></div>
      </div>
    `;
  }
}

const mapStateToProps = (state) => {
  const isHomescreen = state.activeApp.isHomescreen;
  return {
    _isHomescreen: isHomescreen,
    _isKeyboardActivated: state.isKeyboardActivated,
    timeLabel: state.date.toTimeString().slice(0, 5),
    batteryState: state.battery,
    isInstantPanelShown: state.isInstantPanelShown,
    isSIMSecurityActivated: state.isSIMSecurityActivated,
  };
};

const mapDispatchToProps = {
  toggleInstantPanel: () => ({ type: 'TOGGLE_INSTANT_PANEL' }),
};

customElements.define(InfogationBar.is, connect(mapStateToProps, mapDispatchToProps)(InfogationBar));
