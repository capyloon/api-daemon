/* global AudioChannelController, BrowserFrame */

import { LitElement, html, css } from 'lit-element';
import { connect } from '../redux';
import logger from '../util/logger.js';

const log = logger('keyboard-app');

/**
 * This file is aimed to replace the functionalities of `js/input_window.js`(deleted).
 * Use `git log -p --summary -- js/input_window.js` to check original history.
 */

const origin = 'https://keyboard.local/';
const url = origin + '/index.html';
const manifestURL = 'https://keyboard.local/manifest.webapp';
const IGNORED_INPUT_TYPES = [
  'blur',
  'select-one',
  'select-multiple',
  'date',
  'time',
  'datetime',
  'datetime-local',
];

class KeyboardApp extends LitElement {
  static get properties() {
    return {
      isKeyboardActivated: Boolean,
      isScreenLocked: Boolean,
      keyboardHeight: Number,
    };
  }

  static get styles() {
    return css`
    web-view {
      border: none;
      position: absolute;
      width: 100%;
      height: 100%;
      bottom: 0rem;
      pointer-events: none;
      z-index: var(--z-index-keyboard-app);
    }
    `;
  }

  constructor() {
    super();
    this.isKeyboardActivated = false;
    this.isScreenLocked = false;
    this.keyboardHeight = 0;
    this.audioChannels = null;
  }

  registerAudioChannels(cAppFrame) {
    const browser = new BrowserFrame({
      name: 'Keyboard',
      oop: true,
      manifestURL: manifestURL,
      isInputMethod: true,
      url: url,
      origin: origin
    }, cAppFrame);
    const audioChannels = browser.element.allowedAudioChannels;
    this.audioChannels = new Map();
    audioChannels && audioChannels.forEach((audioChannel) => {
      this.audioChannels.set(
        audioChannel.name,
        new AudioChannelController(cAppFrame, audioChannel)
      );
    });
  }

  firstUpdated() {
    const appFrame = this.shadowRoot.querySelector('web-view');
    // set instanceID & debug for AudioChannelController usage
    appFrame.instanceID = appFrame.id;
    appFrame.debug = log;
    this.registerAudioChannels(appFrame);
    this.registerKbHeightEvent(appFrame);
    // appFrame.setInputMethodActive(true);
    this.registerWindowEvent();
  }

  updated() {
    if (
      this.isKeyboardActivated &&
      window.Service.query('RemoteLock.isActive')
    ) {
      this.style.opacity = 1;
    } else if (this.isKeyboardActivated && !this.isScreenLocked) {
      this.style.opacity = 1;
    } else {
      this.style.opacity = 0;
    }
  }

  publish(type, height){
    const eventInitDict = {
      bubbles: true,
      cancelable: true,
      detail: {
        height: height
      }
    };
    // We dispatch the events at the body level so we are able to intercept
    // them and prevent page resizing where desired.
    var evt = new CustomEvent(type, eventInitDict);
    document.body.dispatchEvent(evt);
  }

  _mozbrowserresize(evt) {
    this.keyboardHeight = evt.detail.height;
    if (this.keyboardHeight > 0) {
      this.publish('keyboardchange', this.keyboardHeight);
    } else {
      this.publish('keyboardhide', 0);
    }
  }

  registerKbHeightEvent(appFrame) {
    appFrame.addEventListener('mozbrowserresize', this._mozbrowserresize.bind(this));
  }

  registerWindowEvent() {
    window.addEventListener('mozChromeEvent', this._mozChromeEvent.bind(this));
    window.addEventListener('lockscreen-appopened', this._lockScreenEvent.bind(this));
    window.addEventListener('lockscreen-appclosed', this._lockScreenEvent.bind(this));
  }

  _delayingFlag = false;
  _mozChromeEvent = (evt) => {
    if (evt.detail.type === 'inputmethod-contextchange') {
      // If multiple events happened in a short period,
      // only the last one will be executed.
      // E.g. switching from an input field to another text input field
      // will invoke `text` event immediately after `blur` event.
      if (this._delayingFlag) {
        window.clearTimeout(this._delayingFlag);
      }
      this._delayingFlag =  window.setTimeout(() => {
        const type = evt.detail.inputType;
        log('be going to activate/deactivate keyboard: inputType:', type);
        if (!type || IGNORED_INPUT_TYPES.includes(type)) {
          this.deactivateKeyboard();
        } else {
          this.activateKeyboard();
        }
      }, 100);
    }
  }

  _lockScreenEvent(evt) {
    switch (evt.type) {
      case 'lockscreen-appopened':
        this.isScreenLocked = true;
        break;
      case 'lockscreen-appclosed':
        this.isScreenLocked = false;
        break;
    }
  }

  render() {
    return html`
    <web-view
      remote='true'
      mozapptype='inputmethod'
      mozpasspointerevents='true'
      ignoreuserfocus='true'
      src='${origin}/index.html#en'
      mozapp='${manifestURL}'
    >
    </web-view>
    `;
  }
}

const mapStateToProps = (state) => {
  return {
    isKeyboardActivated: state.isKeyboardActivated,
  };
};

const mapDispatchToProps = {
  activateKeyboard: () => ({ type: 'ACTIVATE_KEYBOARD' }),
  deactivateKeyboard: () => ({ type: 'DEACTIVATE_KEYBOARD' }),
};

customElements.define('keyboard-app', connect(mapStateToProps, mapDispatchToProps)(KeyboardApp));
log('custom element defined');
