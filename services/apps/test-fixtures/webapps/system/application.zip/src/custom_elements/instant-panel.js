/* global GestureDetector, SIMSlotManager */
import { LitElement, html, css } from 'lit-element';
import './notification-list.js';
import './playback-control.js';
import IpSettingsStore from './instant-panel-store';
import { connect } from '../redux';
import mozL10n from '../app_umd/l10n.js';
import logger from '../util/logger.js';

const log = logger('instant-panel');

class InstantPanel extends LitElement {
  name = 'InstantPanel';

  static get properties() {
    const internalProps = {
      isFullNotifications: Boolean,
      isSpherePage: Boolean,
      sphereFunction: String,
      sphereRadius: Object
    };
    return {
      isShown: Boolean,
      // hour and minute
      hmLabel: String,
      // AM or PM
      ampmLabel: String,
      dateLabel: String,
      settings: {
        type: Object,
      },
      ...internalProps,
    };
  }

  static get styles() {
    const root = css`
    .root, .root--lockscreen {
      z-index: var(--z-index-instant-panel);
      position: absolute;
      top: 0;
      overflow: hidden;
      width: calc(100% - 4rem);
      padding: 1rem 2rem 0;
      transition: opacity 0.15s, visibility 0.15s;
      transition-timing-function: linear;
      visibility: collapse;
      opacity: 0;
      display: flex;
      flex-direction: column;
    }
    .root {
      background-image: var(--instant-panel-bg);
      height: calc(100% - 1rem - var(--infogation-bar-height));
      color: var(--color-gs100);
    }
    .root--lockscreen {
      background-image: linear-gradient(to bottom, var(--color-gs100), rgba(233, 233, 242, 0.95));
      color: var(--color-gs10);
    }

    .root--shown {
      visibility: visible;
      opacity: 1;
    }
    `;

    const header = css`
    .header {
      display: flex;
      justify-content: space-between;
      transition: opacity 0.2s linear;
      opacity: 0;
    }

    .root--shown .header {
      opacity: 1;
    }

    .header__operator {
      font-size: 18px;
      font-weight: 600;
      height: 3.6rem;
      line-height: 3.6rem;
      display: flex;
      justify-content: flex-start;
      flex-direction: column;
    }

    .header__time {
      text-align: right;
      height: 3.6rem;
      line-height: 3.6rem;
    }

    .header__hm {
      font-size: 26px;
    }

    .header__ampm {
      font-size: 14px;
    }

    .header__date {
      font-size: 14px;
      font-weight: 600;
      line-height: 1.8rem;
      height: 1.8rem;
    }
    `;

    const section = css`
      .section {
        transition: transform 0.3s cubic-bezier(0, 0, 0, 1), opacity 0.15s linear;
        transform: translateY(100%);
        opacity: 0;
        display: flex;
        flex-direction: column;
        flex: 1;
      }

      .root--shown .section {
        transform: translateY(0);
        opacity: 1;
        transition-timing-function: cubic-bezier(0.75, 0, 1, 1), linear;
      }
    `;
    const quickSettings = css`
      .quick-settings {
        display: grid;
        grid-template-columns: repeat(4, 1fr);
        grid-gap: 2.4rem;
        margin: 2rem 0;
      }

      .quick-settings__item {
        text-align: center;
        border-radius: 50%;
        width: 6rem;
        height: 6rem;
        margin: auto;
        display: flex;
      }
      .root .quick-settings__item {
        border: solid 1px;
      }
      .root--lockscreen .quick-settings__item {
        border: solid 2px;
      }

      .quick-settings__item--on {
        background-color: var(--color-purple);
        border-color: var(--color-purple);
        color: var(--instant-panel-color-on);
      }

      .quick-settings__item [data-icon] {
        font-size: 3.6rem;
        width: 3.6rem;
        height: 3.6rem;
        line-height: 100%;
        margin: auto;
      }
    `;

    const notification = css`
      .root--full-notifications .section {
        /* by calculating height of '.header' */
        max-height: calc(100% - 5.6rem);
      }

      .root--full-notifications .switch {
        opacity: 1;
        pointer-events: auto;
      }

      .root--full-notifications .header {
        opacity: 0;
      }

      .root--full-notifications #section__control {
        opacity: 0;
      }

      .root--full-notifications .section__notifications {
        min-height: calc(100% + 2.2rem);
      }

      .section__playback {
        padding: 0 0 2rem;
      }

      .section__settings,
      .section__playback {
        transition: transform 0.3s cubic-bezier(0, 0, 1, 1), opacity 0.15s linear;
        opacity: 1;
      }

      .section__notifications {
        transition: transform 0.4s cubic-bezier(0, 0, 0, 1);
        transform: translateY(0);
        flex: 1;
      }

      .switch {
        position: absolute;
        left: calc(50% - 1.2rem);
        z-index: 1;
        font-size: 2.4rem;
        width: 2.4rem;
        height: 2.4rem;
        line-height: 100%;
        color: var(--color-gs60);
        transition: opacity 0.15s linear;
        opacity: 0;
        pointer-events: auto;
      }
    `;

    const lockScreen = css`
      .root.lockScreen {
        height: auto;
      }
      .header.lockScreen {
        display: none;
      }
      .section__notifications.lockScreen {
        display: none;
      }
    `;

    const adjusting = css`
      .volume_control {
        z-index: var(--z-index-volumn-panel);
        position: absolute;
        left: 0;
        top: 0;
        width: 100%;
        height: 100%;
        opacity: 0;
        pointer-events: none;
        background-image: var(--instant-panel-bg);
      }
      .volume_control.adjusting {
        opacity: 1;
        pointer-events: auto;
      }
      .sphere_container {
        width: 120vw;
        height: 120vw;
        display: flex;
        align-items: center;
        justify-content: center;
        position: relative;
        transform: translate(-10vw, 0);
      }
      .sphere {
        width: 100vw;
        height: 100vw;
        background-color: var(--color-purple);
        border-radius: 50vw;
      }
      .sphereVal {
        font-size: 4.8rem;
        position: absolute;
        display: flex;
        align-items: center;
        justify-content: center;
        width: 100%;
        height: 100%;
        left: 0;
        top: 0;
      }
      .vibrate_container {
        font-size: 2rem;
        display: flex;
        align-items: center;
        justify-content: center;
        flex-direction: column;
      }
      .vibrate_container.hide {
        display: none;
      }
      .vibrate_btn {
        border-color: var(--color-gs00);
        color: var(--color-gs100);
      }
    `;

    const orientation = css`
      @media screen and (orientation: landscape) {
        .section {
          flex-direction: row;
        }
        #section__control {
          flex: 4;
          display: flex;
          flex-direction: column;
          justify-content: center;
        }
        .section__notifications {
          flex: 5;
        }
        .hideOnLandscape {
          display: none;
        }
        .header__operator {
          flex: 1 1 0%;
          flex-direction: row;
          font-size: 1.4rem;
        }
        .header__time {
          text-align: center;
          font-size: 1.6rem;
        }
        .header__date {
          font-size: 1.4rem;
          text-align: right;
          height: 3.6rem;
          line-height: 3.6rem;
        }
        .header__time.hideOnPortrait,
        .header__date.hideOnPortrait {
          flex: 1 1 0%;
        }
        .root--full-notifications.instant-panel .header {
          opacity: 1;
        }
        .root--full-notifications.instant-panel .switch {
          opacity: 0;
          pointer-events: auto;
        }
        .root--full-notifications #section__control {
          opacity: 1;
        }
        .sphere_container {
          width: calc(100vh - var(--infogation-bar-height));
          height: calc(100vh - var(--infogation-bar-height));
          transform: translate(calc(50vw - 50vh + var(--infogation-bar-height) / 2), 0);
        }
        .sphere {
          width: calc(100vh - var(--infogation-bar-height));
          height: calc(100vh - var(--infogation-bar-height));
          border-radius: calc(50vh - var(--infogation-bar-height) / 2);
        }
        #volume_sphere_container{
          position: absolute;
          top: 0;
        }
        .vibrate_container {
          position: absolute;
          right: 10rem;
          bottom: 4.5rem;
        }
        .header__operator > .operator:nth-child(n+2) {
          margin-left: 1.5rem;
        }
      }

      @media screen and (orientation: portrait) {
        .hideOnPortrait {
          display: none;
        }
        .header__operator > .operator:nth-child(n+2) {
          height: 1.4rem;
          line-height: 1.4rem;
        }
      }
    `;
    return [
      root,
      header,
      section,
      quickSettings,
      notification,
      lockScreen,
      adjusting,
      orientation,
    ];
  }

  constructor() {
    super();
    this.isFullNotifications = false;
    this.isSpherePage = false;
    this.sphereFunction = 'volume';
    this.sphereRadius = {
      'volume': null,
      'brightness': null
    };
    this._lockScreenGesture = new GestureDetector(this);
    this._lockScreenGesture.startDetecting();
    this.addEventListener('swipe', this);
    window.Service.registerState('isActive', this);
    this._ipStore = IpSettingsStore;
    this.updateSettings();
  }

  firstUpdated() {
    this._ipStore.on('change', this.updateSettings.bind(this));
    this._ipStore.toggleAllObservers(true);
  }

  updateSettings(newSettings = this._ipStore.getSettingsInArray()) {
    this.settings = newSettings;
    ['volume', 'brightness'].forEach((item) => {
      this.sphereRadius[item] = this.getSetting(item).valueByPercent() * 100;
    });
  }

  getSetting(item) {
    return this.settings.find(obj => {
      return obj.name === item;
    });
  }

  handleEvent(evt) {
    switch (evt.type) {
      case 'swipe':
        this.swipeNotifications(evt);
        break;
    }
  }

  _onSettingsClick = (evt) => {
    const item = evt.target.dataset.item;
    const settingIndex = parseInt(evt.target.dataset.index, 10);
    switch (item) {
      case 'brightness':
        this.sphereFunction = 'brightness';
        this._toggleSpherePage();
        break;
      case 'volume':
        this.sphereFunction = 'volume';
        this._toggleSpherePage();
        break;
      default:
        this.settings[settingIndex].click();
        break;
    }
  }

  _toggleFullNotifications = () => {
    this.isFullNotifications = !this.isFullNotifications;
  }

  _toggleSpherePage = () => {
    this.isSpherePage = !this.isSpherePage;
  }

  // The event handler is used for prevent from stealing focus
  // from other places.
  _preventFocus(evt) {
    evt.preventDefault();
  }

  swipeNotifications(evt) {
    if (this.isSpherePage ||
        window.Service.query('LockscreenView.locked') ||
        screen.orientation.type.startsWith('landscape')) {
      return;
    }
    evt.stopPropagation();
    const {direction} = evt.detail;
    if (this.isFullNotifications) {
      if (direction === 'down' &&
          this.notificationContainer.scrollTop === 0) {
        this.isFullNotifications = false;
      }
    } else {
      if (direction === 'up') {
        this.isFullNotifications = true;
      }
    }
  }

  _handleSphereEvent(evt) {
    if (!this.isSpherePage || !evt) {
      return;
    }
    switch (evt.type) {
      case 'touchstart' :
        this.startPoint = [
          evt.changedTouches[0].clientX - this.sphereCenter[0],
          evt.changedTouches[0].clientY - this.sphereCenter[1]
        ];
        this.startingVal = this.sphereRadius[this.sphereFunction];
        break;
      case 'touchmove':
        this.updateSphere(
          evt.changedTouches[0].clientX,
          evt.changedTouches[0].clientY
        );
        break;
      case 'touchend':
        break;
    }
  }

  updateSphere(cX, cY) {
    // decide sphere size & value changed
    // the sphere size is beteeen 0.2(20vw) to 1.2(120vw) time than
    // window width
    const touchmovedVec = [
      cX - this.sphereCenter[0] - this.startPoint[0],
      cY - this.sphereCenter[1] - this.startPoint[1]
    ];
    const startPointDist = Math.hypot(this.startPoint[0], this.startPoint[1]);
    const changedProj = [
      touchmovedVec[0] * this.startPoint[0] / startPointDist,
      touchmovedVec[1] * this.startPoint[1] / startPointDist
    ];
    const changedDist = Math.hypot(
      changedProj[0],
      changedProj[1],
    );
    const changedSphereRadius = Math.floor(
      (changedDist / this.spherePage.clientWidth) * 100
    );
    const isIncreasing = this.startPoint[0] * touchmovedVec[0]
                        + this.startPoint[1] * touchmovedVec[1];
    let newval = isIncreasing > 0
      ? this.startingVal + changedSphereRadius
      : this.startingVal - changedSphereRadius;
    if (newval >= 100) {newval = 100;}
    if (newval < 0) {newval = 0;}
    this.getSetting(this.sphereFunction).click(newval);
  }

  _toggleVibration (evt) {
    evt.preventDefault();
    evt.stopPropagation();
    this.getSetting('volume').toggleVibration();
  }

  get controlContainer () {
    return this.shadowRoot.getElementById('section__control');
  }

  get getFullNotificationOffset () {
    // dynamic calculating height of settings & playback control
    if (this.isFullNotifications) {
      return 0 - this.controlContainer.clientHeight;
    }
    return 0;
  }

  get spherePage() {
    return this.shadowRoot.getElementById('volume_control');
  }

  get volumeSphereContainer() {
    return this.shadowRoot.getElementById('volume_sphere_container');
  }

  get _operatorListHTML() {
    // if airplane mode, display airplane
    if (this.getSetting('airplaneMode').value) {
      return html`<div class='operator'>${mozL10n.get('airplane-mode')}</div>`;
    }
    // else display all providers......
    const conns = navigator.mozMobileConnections;
    if (!conns) {
      return html`<div class='operator'>${mozL10n.get('noService')}</div>`;
    }
    return Array.from(conns).map( (conn, index) => {
      if (!SIMSlotManager.isSIMCardAbsent(index)) {
        return html`<div class='operator'>${conn.voice.network.longName}</div>` ||
            html`<div class='operator'>${mozL10n.get('noService')}</div>`;
      } else {
        return html`<div class='operator'>${mozL10n.get('noSimCard')}</div>`;
      }
    });
  }

  get notificationContainer () {
    return this.shadowRoot.getElementById('notification-list');
  }

  get sphereCenter () {
    const sphereTop = this.volumeSphereContainer.offsetTop;
    return [
      this.spherePage.clientWidth / 2,
      sphereTop + this.volumeSphereContainer.clientHeight/2
    ];
  }

  render() {
    this.isFullNotifications = this.isShown ? this.isFullNotifications : false;
    this.isSpherePage = this.isShown ? this.isSpherePage : false;
    const settingsHtml = this.settings.map((item, index) => html`
    <div class='quick-settings__item ${item.value === true ? 'quick-settings__item--on' : ''}'>
      <div data-icon='${item.icon()}' data-item='${item.name}' data-index='${index}'></div>
    </div>`);
    const rootShownModifier = this.isShown ? 'root--shown' : '';
    const rootFullNotificationsModifer = this.isFullNotifications ? 'root--full-notifications' : '';
    const lockScreenModifier = window.Service.query('LockscreenView.locked') ? 'lockScreen' : '';
    const adjustingMenuModifier = this.isSpherePage ? 'adjusting' : '';
    const scaleConst = screen.orientation.type.startsWith('landscape') ? 0 : 0.2;
    const sphereScale = (this.sphereRadius[this.sphereFunction] / 100 + scaleConst).toFixed(2);
    return html`
    <div
      id='instantPanelRoot'
      class='${lockScreenModifier ? 'root--lockscreen' : 'root'} ${rootShownModifier} ${rootFullNotificationsModifer} ${lockScreenModifier}'
      @mousedown=${this._preventFocus}
    >
      <link rel="stylesheet" type="text/css" href="https://shared.local/style/gaia-icons-embedded.css">
      <div
        class='switch'
        data-icon='arrow-up'
        @click=${this._toggleFullNotifications}
      ></div>
      <div class='header ${lockScreenModifier}'>
        <div class='header__operator'>${this._operatorListHTML}</div>
        <div class='header__time hideOnPortrait'>
          <span class='header__hm'>${this.hmLabel}</span>
          <span
            class='header__ampm'
            style=${this.ampmLabel ? 'margin-left: 0.5rem' : ''}
          >${this.ampmLabel}</span>
        </div>
        <div class='header__date hideOnPortrait'>
          ${this.dateLabel}
        </div>
        <div class='hideOnLandscape'>
          <div class='header__time'>
            <span class='header__hm'>${this.hmLabel}</span>
            <span
              class='header__ampm'
              style=${this.ampmLabel ? 'margin-left: 0.5rem' : ''}
            >${this.ampmLabel}</span>
          </div>
          <div class='header__date'>
            ${this.dateLabel}
          </div>
        </div>
      </div>
      <div class='section'>
        <div id='section__control'>
          <div id='section__settings' class='section__settings'>
            <div class='quick-settings' @click=${this._onSettingsClick}>
              ${settingsHtml}
            </div>
          </div>
          <div id='section__playback' class='section__playback'>
            <playback-control></playback-control>
          </div>
        </div>
        <div
          class='section__notifications ${lockScreenModifier}'
          style='transform: translateY(${this.getFullNotificationOffset}px);'
        >
          <notification-list id='notification-list' header='notification'></notification-list>
        </div>
      </div>
      <div
        id='volume_control'
        @click=${this._toggleSpherePage}
        @touchstart=${this._handleSphereEvent}
        @touchmove=${this._handleSphereEvent}
        @touchend=${this._handleSphereEvent}
        class='volume_control
        ${adjustingMenuModifier}'
      >
        <kai-header
          title="${mozL10n.get(this.sphereFunction+'-title')}"
          type="large"
        >
          <kai-textbutton slot="header-right-slot" text="DONE">
        </kai-header>
        <div id='volume_sphere_container' class='sphere_container'>
          <div class='sphere'
            style='transform: scale(${sphereScale});'
          >
          </div>
          <div class='sphereVal'>
            ${Math.floor(this.getSetting(this.sphereFunction).value)}
          </div>
        </div>
        <div
          class='vibrate_container ${this.sphereFunction === 'volume' ? '' : 'hide'}'
        >
          <div @click='${this._toggleVibration}'
            class='quick-settings__item ${this.getSetting('volume').vibrationEnabled === true ? 'quick-settings__item--on' : ''} vibrate_btn'
          >
            <div data-icon='vibrate-32px'></div>
          </div>
          <div>Vibrate</div>
        </div>
      </div>
    </div>
    `;
  }
}

const mapStateToProps = (state) => {
  const localeFormat = (new mozL10n.DateTimeFormat()).localeFormat;
  const hmFormat = window.navigator.mozHour12 ? '%I:%M' : '%H:%M';
  const ampmFormat = window.navigator.mozHour12 ? '%p' : '';
  const hmLabel = localeFormat(state.date, hmFormat);
  const ampmLabel = localeFormat(state.date, ampmFormat);
  const dateLabel = localeFormat(state.date, '%A, %B %d');
  return {
    isShown: state.isInstantPanelShown,
    hmLabel,
    ampmLabel,
    dateLabel,
  };
};

const mapDispatchToProps = {
};

mozL10n.once(() => {
  customElements.define('instant-panel', connect(mapStateToProps, mapDispatchToProps)(InstantPanel));
  log('custom element defined');
});
