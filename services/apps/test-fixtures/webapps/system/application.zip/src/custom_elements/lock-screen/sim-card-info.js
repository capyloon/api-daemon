import { LitElement, html, css } from 'lit-element';

class SimCardInfo extends LitElement {
  name = 'LockscreenSimCardInfo';

  static get is() {
    return 'sim-card-info';
  }

  static get properties() {
    // The property `_simCardsName` is not reactive.

    return {
      isAirplaneMode: {
        type: Boolean,
        attribute: false,
      },
      cardInfos: {
        type: Array,
        attribute: false,
      },
    };
  }

  static get styles() {
    return css`
      :host {
        text-shadow: 0 1px 2px rgba(0, 0, 0, 0.7);
        font-family: OpenSans;
        font-size: 1.4rem;
        font-weight: 600;
        font-style: normal;
        font-stretch: normal;
        line-height: 1.33;
        letter-spacing: normal;
        text-align: center;
        color: #ffffff;
        display: flex;
        justify-content: center;
        align-items: center;
      }

      html[dir="rtl"] #simcard-info .icon.level::before,
      html[dir="rtl"] #simcard-info .icon.bg::before {
        transform: rotateY(180deg);
      }

      .airplane-mode-info {
        display: none;
      }
      [data-is-airplane-mode=true]:not([data-is-voWifi-mode=true]) .airplane-mode-info {
        display: block;
      }
      [data-is-airplane-mode=true]:not([data-is-voWifi-mode=true]) .info-row {
        display: none;
      }
      [data-is-airplane-mode=true] .info-row[data-is-voWifi-mode=false] {
        display: none;
      }

      .info-row {
        display: flex;
        align-self: flex-start;
        height: 50%;
        margin-left: 2rem;
        margin-right: 2rem;
      }
      .info-row .icon-wrapper {
        position: relative;
        width: 1.6rem;
        height: 1.6rem;
        margin-inline-end: 0.5rem;
        // line-height: 1;
      }
      .info-row .icon-wrapper .icon {
        position: absolute;
        top: 0;
        right: 0;
        bottom: 0;
        left: 0;
      }
      .info-row .icon-wrapper .icon.inactive::before {
        color: rgba(255, 255, 255, 0.3);
      }
      .info-row .icon-wrapper .icon.bg {
        opacity: 0.4;
      }
      .info-row .icon-wrapper[data-is-searching=true] .icon.level::before {
        background: url(./signal-searching-165fc9.png) no-repeat 50%;
        content: '';
        width: 100%;
        height: 100%;
      }
      .info-row .icon-wrapper[data-is-searching=true] .icon.bg {
        opacity: 0;
      }
      .info-row .carrier-name {
        display: flex;
        line-height: 1;
        font-size: 1.4rem !important;
      }
      .info-row .carrier-name .text {
        margin: auto;
      }
      .info-row .carrier-name .text.inactive {
        color: rgba(218, 218, 218, 0.3);
      }
      .level::after {
        content: attr(data-index);
        font-size: 0.9rem;
        font-weight: 700;
        line-height: 1;
        position: absolute;
        top: 0;
        left: 0;
        right: 0;
        bottom: 0;
      }
    `;
  }

  constructor() {
    super();

    this._simCardsName = {};
    this.isAirplaneMode = true;
    this.cardInfos = [];
  }

  connectedCallback() {
    super.connectedCallback();
    this.watchCustomSimcardName();
    this.watchAirplaneMode();
    this.initCardInfos();
  }

  disconnectedCallback() {
    const conns = navigator.mozMobileConnections;
    if (conns) {
      Array.from(conns).forEach((conn, index) => {
        if (!SIMSlotManager.isSIMCardAbsent(index)) {
          conn.removeEventListener('datachange', this.datachangeHandler);
          conn.removeEventListener('voicechange', this.voicechangeHandler);
          conn.removeEventListener(
            'signalstrengthchange', this.signalstrengthchangeHandler
          );
        }
      });
    }

    navigator.mozSettings.removeObserver(
      'custom.simcards.name', this.customSimcardNameObserver
    );
    navigator.mozSettings.removeObserver(
      'airplaneMode.enabled', this.airplaneModeObserver
    );

    super.disconnectedCallback();
  }

  /**
   * Assign event handlers and update cardInfos once
   */
  initCardInfos() {
    const conns = navigator.mozMobileConnections;
    if (!conns) {
      return;
    }

    if (SIMSlotManager.ready) {
      Array.from(conns).forEach((conn, index) => {
        if (!SIMSlotManager.isSIMCardAbsent(index)) {
          conn.addEventListener('datachange', this.datachangeHandler);
          conn.addEventListener('voicechange', this.voicechangeHandler);
          conn.addEventListener(
            'signalstrengthchange', this.signalstrengthchangeHandler
          );
        }
      });
    } else {
      window.addEventListener('simslotready', this.simslotreadyHandler);
    }
    this.updateCardInfos();
  }

  /**
   * Update cardInfos by looping all mozMobileConnections
   * Object structure in cardInfos:
   * {
   *  signalLevel: 1, // 1~5
   *  carrierName: 'Far EasTone'  // long name
   * }
   */
  updateCardInfos() {
    const conns = navigator.mozMobileConnections;
    if (!conns) {
      return;
    }

    const cardInfos = [];
    const simSlots = SIMSlotManager.getSlots();

    Array.from(conns).forEach( (conn, index) => {
      const isAbsent = !conn.iccId;
      const data = conn.data;
      const voice_data = conn.voice ? conn.voice : conn.data;

      // Raw signal level from MozMobileConnections is -1~4
      // we normalize it to 0~5 for data-icon convenient
      let signalLevel = 0;
      if (!isAbsent && conn.voice.connected) {
        if (conn.signalStrength) {
          signalLevel = conn.signalStrength.level + 1;
        } else {
          signalLevel = Math.ceil(conn.voice.relSignalStrength / 20);
        }
      }

      let stateL10nId;
      let carrierName;
      let network;
      if (conn.voice && conn.voice.connected) {
        network = conn.voice.network;
      } else if (data && data.state === 'registered') {
        network = conn.data.network;
      }
      if (isAbsent) {
        stateL10nId = 'noSimCard';
      } else if (simSlots[index].getCardState() !== 'ready') {
        stateL10nId = 'lockedSim';
      } else if (voice_data.state === 'searching') {
        stateL10nId = 'searching';
      } else if (voice_data.emergencyCallsOnly) {
        stateL10nId = 'noService';
      } else if (network) {
        const iccid = conn.iccId;
        const iccObj = navigator.mozIccManager.getIccById(iccid);
        const iccInfo = iccObj ? iccObj.iccInfo : null;
        let operator = network ? network.longName : null;
        if (operator && iccInfo && iccInfo.isDisplaySpnRequired && iccInfo.spn) {
          if (iccInfo.isDisplayNetworkNameRequired && operator !== iccInfo.spn) {
            operator = operator + ' ' + iccInfo.spn;
          } else {
            operator = iccInfo.spn;
          }
        }
        carrierName = this._simCardsName[conn.iccId] || operator;
      } else {
        stateL10nId = 'noService';
      }

      cardInfos.push({
        signalLevel,
        carrierName,
        stateL10nId
      });
    });

    this.cardInfos = cardInfos;
  }

  watchCustomSimcardName() {
    const { mozSettings } = navigator;
    const lock = mozSettings.createLock();
    const key = 'custom.simcards.name';
    const req = lock.get(key);

    req.onsuccess = () => {
      const res = req.result[key];
      this._simCardsName = res || {};
      this.updateCardInfos();
    }
    req.onerror = () => {
      console.error(`[SIM-CARD-INFO] Failed to get "${key}"`, req.error);
    }
    mozSettings.addObserver(key, this.customSimcardNameObserver);
  }

  watchAirplaneMode() {
    const { mozSettings } = navigator;
    const lock = mozSettings.createLock();
    const key = 'airplaneMode.enabled';
    const req = lock.get(key);

    req.onsuccess = () => {
      const res = req.result[key];
      this.isAirplaneMode = res;
    }
    req.onerror = () => {
      console.error(`[SIM-CARD-INFO] Failed to get "${key}"`, req.error);
    }
    mozSettings.addObserver(key, this.airplaneModeObserver);
  }

  customSimcardNameObserver = (event) => {
    const res = event.settingValue;
    this._simCardsName = res || {};
    this.updateCardInfos();
  }

  airplaneModeObserver = (event) => {
    const res = event.settingValue;
    this.isAirplaneMode = res;
  }

  /**
   * Handle mobile connection data change.
   * Just update all card infos.
   */
  datachangeHandler = () => {
    this.updateCardInfos();
  }

  voicechangeHandler = () => {
    this.updateCardInfos();
  }

  signalstrengthchangeHandler = () => {
    this.updateCardInfos();
  }

  simslotreadyHandler = () => {
    window.removeEventListener('simslotready', this.simslotreadyHandler);
    this.initCardInfos();
  }

  render() {
    const isMultiSIM = SIMSlotManager.isMultiSIM();

    const infoDOMs = this.cardInfos.map((info, index) => {
      const cardDOM = html`
        <div class="icon-wrapper">
          <div class="icon inactive" data-icon="${`sim-${index + 1}`}">
            <div class="icon" data-icon="signal-0"></div>
          </div>
        </div>
      `;

      const signalDOM = html`
        <div
          class="icon-wrapper"
          data-is-searching="${info.stateL10nId === 'searching'}"
        >
          <div
            class="icon level"
            data-index="${index + 1}"
            data-icon="${`signal-${info.signalLevel}`}"
          >
          </div>
          <div class="icon bg" data-icon="signal-5"></div>
        </div>
      `;

      const textClass = SIMSlotManager.isSIMCardAbsent(index)
        ? 'text inactive'
        : 'text';

      return html`
        <div class="info-row">
          ${['noSimCard', 'noService', 'lockedSim'].includes(info.stateL10nId)
            ? cardDOM
            : signalDOM
          }
          <div class="carrier-name secondary">
            ${info.stateL10nId
              ? html`
                <span class="${textClass}" data-l10n-id="${info.stateL10nId}">
                </span>
              `
              : html`<span class="${textClass}">${info.carrierName}</span>`
            }
          </div>
        </div>
      `;
    });

    return html`
      <div id="simcard-info" data-is-airplane-mode=${this.isAirplaneMode}>
        ${infoDOMs.map(el => html`${el}`)}
        ${isMultiSIM
          ? null
          : html`<div
              class="airplane-mode-info"
              data-l10n-id="airplane-mode"
            ></div>`
        }
      </div>
    `;
  }
}

customElements.define(SimCardInfo.is, SimCardInfo);
