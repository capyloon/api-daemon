/* global Service */
import { LitElement, html, css } from 'lit-element';

class AppToast extends LitElement {
  name = 'AppToast';
  TIMEOUT = 3000;

  static get properties() {
    return {
      text: { type: String }
    };
  }

  static get styles() {
    return css`
      :host {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background-color: transparent;
        display: flex;
        flex-direction: column;
        justify-content: flex-start;
        align-items: center;
        z-index: var(--z-index-notice);
        pointer-events: none;
      }
      @keyframes fade-in {
        0% { opacity: 0; transform: translate(0, 1rem); }
        50% { opacity: 1; transform: translate(0, 0); }
        100% { opacity: 1; transform: translate(0, 0); }
      }
      @keyframes fade-out {
        0% { opacity: 1; transform: translate(0, 0); }
        99% { opacity: 0; transform: translate(0, 0); }
        100% { opacity: 0; transform: translate(0, 1rem); }
      }
      kai-toast {
        margin-top: 2rem;
        opacity: 0;
        animation-name: fade-out;
        animation-duration: 120ms;
        animation-fill-mode: forwards;
        animation-timing-function: cubic-bezier(0, 0, 0.25, 1);
      }
      kai-toast.show {
        animation-name: fade-in;
        animation-duration: 300ms;
        animation-fill-mode: forwards;
        animation-timing-function: cubic-bezier(0, 0, 0.25, 1);
      }
    `;
  }

  constructor() {
    super();
    this.text = '';
    this.timer = null;
  }

  connectedCallback() {
    super.connectedCallback();
    Service.register('show', this);
    window.addEventListener('iac-systoaster', this);
  }

  disconnectedCallback() {
    super.disconnectedCallback();
    window.removeEventListener('iac-systoaster', this);
  }

  show(detail) {
    Service.request('turnScreenOn', 'toast');
    window.clearTimeout(this.timer);

    this.text = detail.message;
    this.timer = window.setTimeout(() => {
      this.text = '';
    }, this.TIMEOUT);
  }

  handleEvent(evt) {
    this.show(evt.detail);
  }

  render() {
    const style = this.text ? 'show' : '';
    return html`
      <kai-toast class="${style}" text="${this.text}"></kai-toast>
    `;
  }
}

customElements.define('app-toast', AppToast);
