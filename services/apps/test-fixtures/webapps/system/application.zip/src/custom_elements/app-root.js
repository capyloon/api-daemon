import { LitElement, html, css } from 'lit-element';
import { connect } from '../redux';
import logger from '../util/logger.js';

const log = logger('app-root');

// Minimal AppRoot that loads in gecko-dev
class AppRoot extends HTMLElement {

  constructor() {
    super();
    this._touchstartXY = [0, 0];
    this._touchendXY = [0, 0];
    this.ready = false;
  }

  static get properties() {
    return {
      isKeyboardActivated: false,
      isAirDeckShown: Boolean,
    };
  }

  connectedCallback() {
    // TODO(fabrice): manage disconnection from the DOM.
    if (this.ready) {
      return;
    }

    this.appendChild(document.createElement("slot"));

    this.addEventListener('touchstart', this.touchstart);
    this.addEventListener('touchend', this.touchend);

    this.ready = true;
  }

  touchstart(evt) {
    const { screenX: x, screenY: y } = evt.changedTouches[0];
    this._touchstartXY = [x, y];
  }

  touchend(evt) {
    const { screenX: x, screenY: y } = evt.changedTouches[0];
    this._touchendXY = [x, y];

    const side = toEdgeSwipeType(this._touchstartXY, this._touchendXY);
    log('swipe detected:', side);
    if (['left', 'right'].includes(side) && !this.isKeyboardActivated) {
      // XXX: Temporarily disabled the AirDeck feature since it's still work in progress.
      // this.showAirDeckAt(side);
    }
  }
}

class AppRoot_ extends LitElement {
  static get properties() {
    return {
      isKeyboardActivated: false,
      isAirDeckShown: Boolean,
    };
  }

  static get styles() {
    return css`
      :host {
        position: absolute;
        width: 100%;
        height: 100%;
        display: flex;
        flex-direction: column;
      }
    `;
  }

  constructor() {
    super();
    this._touchstartXY = [0, 0];
    this._touchendXY = [0, 0];
  }

  firstUpdated() {
    log('firstUpdated');
    this.addEventListener('touchstart', this.touchstart);
    this.addEventListener('touchend', this.touchend);
    window.addEventListener('firstappopened', this.firstappopened);
  }

  touchstart(evt) {
    const { screenX: x, screenY: y } = evt.changedTouches[0];
    this._touchstartXY = [x, y];
  }

  touchend(evt) {
    const { screenX: x, screenY: y } = evt.changedTouches[0];
    this._touchendXY = [x, y];

    const direction = localStorage.getItem('air_deck_nav_direction') || 'ltr';
    const side = toEdgeSwipeType(this._touchstartXY, this._touchendXY);
    log('swipe detected:', side);

    const isTrigger =
      (direction === 'ltr' && side === 'left') ||
      (direction === 'rtl' && side === 'right') ||
      (direction === 'both' && ['left', 'right'].includes(side));

    if (isTrigger && !this.isKeyboardActivated) {
      const evt = new CustomEvent('edgeswiping', { detail: { side } });
      window.dispatchEvent(evt);
      this.showAirDeckAt(side);
    }
  }

  firstappopened = () => {
    this.showAirDeckAt('left');
  }

  render(){
    return html`
      <slot></slot>
    `;
  }
}

/**
 * The edge swipe is determined by two factors:
 * 1. should start from edge area
 * 2. should move in correct direction
 *
 * The edge area is a small inner border arround the screen.
 * Its size is defined by `edgeRatio` which is a ratio compared to the screen size.
 * There are four edges(left, right, top, bottom) seperated by two diagonals.
 */
function toEdgeSwipeType([startX, startY], [endX, endY]) {
  const edgeRatio = 0.1;
  const { width: w, height: h } = window.screen;

  // normalize
  const [x1, y1] = [startX/w, startY/h];
  const [x2, y2] = [endX/w, endY/h];

  // not start from edge area, i.e. inside the rectangle surrounded by edge area
  if (x1 > edgeRatio && x1 < 1 - edgeRatio &&
    y1 > edgeRatio && y1 < 1 - edgeRatio) {
    return '';
  }

  if (x1 < y1 && x1 < 1 - y1 && x1 < x2) {
    return 'left';
  }

  if (x1 > y1 && x1 > 1 - y1 && x1 > x2) {
    return 'right';
  }

  if (x1 > y1 && x1 < 1 - y1 && y1 < y2) {
    return 'top';
  }

  if (x1 < y1 && x1 > 1 - y1 && y1 > y2) {
    return 'bottom';
  }

  // start from edge area but not move in expected direction
  return '';
}

const mapStateToProps = (state) => {
  const { isShown } = state.airDeckDisplay;
  return {
    isKeyboardActivated: state.isKeyboardActivated,
    isAirDeckShown: isShown,
  };
};

const mapDispatchToProps = {
  showAirDeckAt: (side) => ({ type: 'UPDATE_AIR_DECK', at: side, isShown: true }),
};

customElements.define('app-root', connect(mapStateToProps, mapDispatchToProps)(AppRoot));
log('custom element defined');
