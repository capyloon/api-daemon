import { LitElement, html, css } from 'lit-element';

class KaiClock extends LitElement {
  static get properties() {
    return {
      clockStyle: {
        type: String,
        attribute: 'clock-style',
      },
      time: { type: Date },
      ticker: { type: Function }
    };
  }

  static get styles() {
    return css`
      :host {
        display: block;
        height: 15rem;
      }
      .clock-widget {
        display: flex;
        flex-direction: column;
        justify-content: center;
        height: 100%;
      }
      .time {
        display: flex;
        justify-content: center;
        align-items: center;
        margin-bottom: 1.5rem;
        height: 6.6rem;
      }
      .digit {
        position: relative;
        font-size: 6.6rem;
        margin: -1rem;
        color: var(--color-gs100);
        text-shadow: 0 0.1rem 0.2rem rgba(0, 0, 0, 0.7);
      }
      .colon {
        display: inline-flex;
        flex-direction: column;
        margin-left: 1em;
        margin-right: 1em;
        font-size: 0.6rem;
      }
      .colon::before, .colon::after {
        content: '';
        background: var(--color-gs100);
        width: 0.7rem;
        height: 0.7rem;
        margin-top: 0.6rem;
        margin-bottom: 0.6rem;
        box-shadow: 0 0.1rem 0.2rem rgba(0, 0, 0, 0.7);
      }
      .period {
        position: absolute;
        top: 0.8rem;
        right: -1.8rem;
        font-size: 1.6rem;
        text-align: right;
        font-weight: 600;
        color: var(--color-gs100);
        text-shadow: 0 0.1rem 0.2rem rgba(0, 0, 0, 0.7);
      }
      .date-container {
        text-align: center;
      }
      .weekday {
        font-size: 1.6rem;
        font-weight: 300;
        text-align: right;
        padding-right: 0.5rem;
        color: var(--color-gs100);
        text-shadow: 0 0.1rem 0.2rem rgba(0, 0, 0, 0.7);
      }
      .date {
        font-size: 1.6rem;
        text-align: right;
        font-weight: 600;
        color: var(--color-gs100);
        text-shadow: 0 0.1rem 0.2rem rgba(0, 0, 0, 0.7);
      }
    `;
  }

  static getWeekdayString(weekday) {
    if (!Number.isInteger(weekday) || weekday < 0 || weekday > 6) {
      return '';
    }

    return [
      'Sunday',
      'Monday',
      'Tuesday',
      'Wednesday',
      'Thursday',
      'Friday',
      'Saturday'
    ][weekday];
  };

  static getMonthString(month) {
    if (!Number.isInteger(month) || month < 0 || month > 11) {
      return '';
    }

    return [
      'January',
      'February',
      'March',
      'April',
      'May',
      'June',
      'July',
      'August',
      'September',
      'October',
      'November',
      'December'
    ][month];
  };

  constructor() {
    super();
    this.time = new Date;
  }

  connectedCallback() {
    super.connectedCallback();
    this.ticker = setInterval(() => this.time = new Date, 1000);
  }

  disconnectedCallback() {
    clearInterval(this.ticker);
    super.disconnectedCallback();
  }

  render() {
    const time = this.time;

    const period = time.getHours() >= 12 ? 'PM' : 'AM';

    const hh = `0${time.getHours() % 12 || 12}`.slice(-2);
    const hoursFirstDigit = hh[0] === '0' ? null : hh[0];
    const hoursSecondDigit = hh[1];

    const mm = `0${time.getMinutes()}`.slice(-2);
    const minutesFirstDigit = mm[0];
    const minutesSecondDigit = mm[1];

    const weekday = KaiClock.getWeekdayString(time.getDay()).toUpperCase();
    const month = KaiClock.getMonthString(time.getMonth()).toUpperCase();
    // Looks like .toLocaleString() will cause memory bloating.
    // const weekday = time.toLocaleString('en-us', { weekday: 'long' }).toUpperCase();
    // const month = time.toLocaleString('en-us', { month: 'long' }).toUpperCase();
    const day = time.getDate();

    const fontWeight = this.clockStyle === 'bold'
      ? 'rounded_semibold'
      : 'light';

    return html`
      <div class="clock-widget">
        <link rel="stylesheet" type="text/css" href="https://shared.local/style/gaia-icons-embedded.css">
        <span class="time">
          ${hoursFirstDigit &&
            html`<span class="digit" data-icon="numeric_${hoursFirstDigit}_${fontWeight}"></span>`
          }
          <span class="digit" data-icon="numeric_${hoursSecondDigit}_${fontWeight}"></span>
          <span class="colon"></span>
          <span class="digit" data-icon="numeric_${minutesFirstDigit}_${fontWeight}"></span>
          <span class="digit" data-icon="numeric_${minutesSecondDigit}_${fontWeight}">
            <span class="period">${period}</span>
          </span>
        </span>
        <span class="date-container">
          <span class="weekday">${weekday}</span>
          <span class="date">
            ${month} ${day}
          </span>
        </span>
      </div>
    `;
  }
}

customElements.define('kai-clock', KaiClock);
