/* global Service */
import { LitElement, html, css } from 'lit-element';
import { connect } from '../redux';
import * as utils from '../util/utils';
import { EVENT_TYPES, isDigitId } from '../custom_elements/pin-lock';
import SimLockStore from '../sim_lock_manager';

class SIMSecurity extends LitElement {
  name = 'SIMSecurity';

  LOCK_TYPES = {
    pinRequired: 'pin',
    pukRequired: 'puk',
    permanentBlocked: 'blocked',
    networkLocked: 'nck', //  CARD_LOCK_TYPE_NCK = 4;
    networkSubsetLocked: 'nsck', //  CARD_LOCK_TYPE_NSCK = 5;
    network1Locked: 'nck1', //  CARD_LOCK_TYPE_NCK1 = 6;
    network2Locked: 'nck2', //  CARD_LOCK_TYPE_NCK2 = 7;
    hrpdNetworkLocked: 'hnck', //  CARD_LOCK_TYPE_HNCK = 8;
    corporateLocked: 'cck', //  CARD_LOCK_TYPE_CCK = 9;
    serviceProviderLocked: 'spck', //  CARD_LOCK_TYPE_SPCK = 10;
    simPersonalizationLocked: 'pck', //  CARD_LOCK_TYPE_PCK = 11;
    ruimCorporateLocked: 'rcck', //  CARD_LOCK_TYPE_RCCK = 12;
    ruimServiceProviderLocked: 'rspck', //  CARD_LOCK_TYPE_RSPCK = 13;
    networkPukRequired: 'nck-puk',
    networkSubsetPukRequired: 'nsck-puk',
    network1PukRequired: 'nck1-puk',
    network2PukRequired: 'nck2-puk',
    hrpdNetworkPukRequired: 'hnck-puk',
    corporatePukRequired: 'cck-puk',
    serviceProviderPukRequired: 'spck-puk',
    simPersonalizationPukRequired: 'pck-puk',
    ruimCorporatePukRequired: 'rcck-puk',
    ruimServiceProviderPukRequired: 'rspck-puk',
  };

  ACTIVE_INPUTS = {
    UNLOCK: 'unlock',
    NEW: 'new',
    CONFIRM: 'confirm',
  };

  static get is() {
    return 'sim-security';
  }

  static get properties() {
    return {
      currentSlot: { type: Object },
      lockType: { type: String },
      retryCount: { type: Number },
      incorrectInput: { type: Boolean },
      resetPIN: { type: Boolean },
      currentPUK: { type: String },
      dismatchPIN: { type: Boolean },

      header: { type: String },
      description: { type: String },
      inputAreas: { type: Array },
      inputs: { type: Object },
      hints: { type: Object },
      activeInputId: { type: String },
      smallkeypad: { type: Boolean },
      submittable: { type: Boolean },
    };
  }

  static get styles() {
    return css`
      .container {
        width: 100%;
        height: calc(100% - var(--infogation-bar-height));
        z-index: var(--z-index-sim-lock-panel);
        position: fixed;
        top: 0;
        left: 0;
      }

      .hide {
        display: none;
      }
    `;
  }

  _reset() {
    this.currentSlot = {};
    this.lockType = '';
    this.retryCount = -1;
    this.incorrectInput = false;
    this.resetPIN = false;
    this.currentPUK = '';
    this.dismatchPIN = false;

    this.header = '';
    this.description = '';
    this.inputAreas = [];
    this.inputs = {};
    this.hints = {};
    this.activeInputId = '';
    this.smallkeypad = false;
    this.submittable = false;
  }

  constructor() {
    super();
    this._reset();
  }

  firstUpdated() {
    if (SimLockStore) {
      SimLockStore.on('changed', () => {
        this._reset();
        const slStore = SimLockStore.state;
        // TODO: aligin feature phone, only support slot 1 SIM security check
        const slot1 = slStore.slots[0];
        if (slStore.active && slot1) {
          this.currentSlot = slot1;
          this.lockType = this.LOCK_TYPES[this.currentSlot.getCardState()];
          if (
            this.lockType === 'puk' ||
            this.lockType === 'blocked' ||
            (slStore.showAttentionInNck && this.lockType === 'nck') ||
            this.lockType.includes('-puk')
          ) {
            this._showSIMLockedDialog();
          } else {
            this._show();
          }
        } else {
          this._hide();
          this._hideSIMLockedDialog();
        }
      });
    }
  }

  get container() {
    return this.shadowRoot.querySelector('.container');
  }

  _show() {
    let lockType = this.lockType;
    let isXckPuk = false;
    if (lockType.includes('-puk')) {
      lockType = lockType.replace('-puk', '');
      isXckPuk = true;
    }
    if (lockType !== 'blocked' && !isXckPuk) {
      this.currentSlot.getCardLockRetryCount(lockType).then(e => {
        if (this.lockType !== lockType) {
          return;
        }
        this.retryCount = e.retryCount;
        this._setHints(this.ACTIVE_INPUTS.UNLOCK);
      });
    }
    this._updateUI();
    this.container.classList.remove('hide');
    this.activateSIMSecurity();
  }

  _hide() {
    this._reset();
    this.container.classList.add('hide');
    this.deactivateSIMSecurity();
  }

  _isSubmittable() {
    switch (this.lockType) {
      case 'pin': {
        const unlockInput = this.inputs[this.ACTIVE_INPUTS.UNLOCK];
        return unlockInput.length >= 4 && unlockInput.length <= 8;
      }
      case 'puk': {
        if (this.resetPIN) {
          const newPINInput = this.inputs[this.ACTIVE_INPUTS.NEW];
          const confirmPINInput = this.inputs[this.ACTIVE_INPUTS.CONFIRM];
          return (
            newPINInput.length >= 4 &&
            newPINInput.length <= 8 &&
            confirmPINInput.length >= 4 &&
            confirmPINInput.length <= 8
          );
        } else {
          const unlockInput = this.inputs[this.ACTIVE_INPUTS.UNLOCK];
          return unlockInput.length >= 4 && unlockInput.length <= 8;
        }
      }
      case 'pck': {
        const unlockInput = this.inputs[this.ACTIVE_INPUTS.UNLOCK];
        return unlockInput.length >= 6;
      }
      default: {
        const unlockInput = this.inputs[this.ACTIVE_INPUTS.UNLOCK];
        return unlockInput.length >= 8;
      }
    }
  }

  _preventFocus(evt) {
    evt.preventDefault();
  }

  _onDelete(activeInputId) {
    let activeInput = this.inputs[activeInputId];
    activeInput.pop();
    this.inputs = {
      ...this.inputs,
      [activeInputId]: activeInput,
    };
    this.submittable = this._isSubmittable();
  }

  _getInputLabel(textid) {
    switch (this.lockType) {
      case 'pin':
        return utils.toL10n('simPin');
      case 'puk':
        return this.resetPIN && textid
          ? utils.toL10n(textid)
          : utils.toL10n('pukCode');
      default:
        return utils.toL10n('xckCode', { type: this.lockType.toUpperCase() });
    }
  }

  _getHintText() {
    switch (this.lockType) {
      case 'pin':
        return this.incorrectInput
          ? `${utils.toL10n('pinErrorMsg')} ${utils.toL10n(
              'inputCodeAttemptsLeft',
              {
                n: this.retryCount,
              }
            )}`
          : `${utils.toL10n('inputCodeAttemptsLeft', {
              n: this.retryCount,
            })}`;
      case 'puk':
        if (this.resetPIN && this.dismatchPIN) {
          return utils.toL10n('newPinErrorMsg');
        } else {
          return `${utils.toL10n('inputCodeAttemptsLeft', {
            n: this.retryCount,
          })}`;
        }
      default:
        return this.incorrectInput
          ? `${utils.toL10n('nxkErrorMsg')} ${utils.toL10n(
              'inputCodeAttemptsLeft',
              {
                n: this.retryCount,
              }
            )}`
          : `${utils.toL10n('inputCodeAttemptsLeft', {
              n: this.retryCount,
            })}`;
    }
  }

  _checkMaxLength(activeInputId) {
    // TODO: any method to get this max length value?
    const activeInput = this.inputs[activeInputId];
    switch (this.lockType) {
      case 'pin':
      case 'puk': {
        const inputMaxlength = 8; // Input maxlength for PIN/PUK is 8.
        return activeInput.length < inputMaxlength;
      }
      default: {
        const inputMaxlength = 16; // Input maxlength for XCK is 16.
        return activeInput.length < inputMaxlength;
      }
    }
  }

  _onClickKeypad(id, activeInputId) {
    if (isDigitId(id) && this._checkMaxLength(activeInputId)) {
      this.inputs = {
        ...this.inputs,
        [activeInputId]: [...this.inputs[activeInputId], id],
      };
      this.submittable = this._isSubmittable();
    } else if (id === 'ok' && this.retryCount > 0) {
      this.submittable = false;
      if (this.resetPIN) {
        const newPINInput = this.inputs[this.ACTIVE_INPUTS.NEW];
        const confirmPINInput = this.inputs[this.ACTIVE_INPUTS.CONFIRM];
        const dismatchPIN = newPINInput.join('') !== confirmPINInput.join('');
        if (dismatchPIN) {
          this.dismatchPIN = true;
          this._setHints(this.ACTIVE_INPUTS.CONFIRM);
          setTimeout(() => {
            this.inputs = {
              [this.ACTIVE_INPUTS.NEW]: [],
              [this.ACTIVE_INPUTS.CONFIRM]: [],
            };
            this.activeInputId = this.ACTIVE_INPUTS.NEW;
            this.dismatchPIN = false;
            this._setHints(this.ACTIVE_INPUTS.CONFIRM);
          }, 2000); // Auto clear both input fields.
        } else {
          this._unlock();
        }
      } else {
        this._unlock();
      }
    }
  }

  _unlock() {
    const config = {
      lockType: this.lockType,
    };
    switch (this.lockType) {
      case 'pin':
        {
          const unlockInput = this.inputs[this.ACTIVE_INPUTS.UNLOCK];
          config.pin = unlockInput.join('');
        }
        break;
      case 'puk':
        if (this.resetPIN) {
          config.puk = this.currentPUK;
          this.currentPUK = '';
          const newPINInput = this.inputs[this.ACTIVE_INPUTS.NEW];
          config.newPin = newPINInput.join('');
        } else {
          const unlockInput = this.inputs[this.ACTIVE_INPUTS.UNLOCK];
          this.currentPUK = unlockInput.join('');
          this.resetPIN = true;
          this._updateUI();
          return;
        }
        break;
      // network locks
      default:
        {
          const unlockInput = this.inputs[this.ACTIVE_INPUTS.UNLOCK];
          config.pin = unlockInput.join('');
        }
        break;
    }
    this.currentSlot.unlockCardLock(config).then(
      () => {
        // SimLockStore will get cardstatechange if locked successfully
        this._hide();
      },
      e => {
        this.submittable = false;
        this.retryCount = e.retryCount;
        this.incorrectInput = true;
        if (this.resetPIN) {
          this._setHints(this.ACTIVE_INPUTS.CONFIRM);
        } else {
          this.inputs = {
            [this.ACTIVE_INPUTS.UNLOCK]: [],
          };
          this._setHints(this.ACTIVE_INPUTS.UNLOCK);
        }
        if (this.retryCount === 0) {
          this._hide();
        } else if (this.lockType === 'puk') {
          this._showSIMLockedDialog();
        }
      }
    );
  }

  _hideSIMLockedDialog() {
    const id = 'sim-locked-dialog';
    Service.request('DialogService:hide', id);
  }

  _showSIMLockedDialog() {
    const id = 'sim-locked-dialog';
    let config = {
      id,
      title: utils.toL10n('sim-attention-header'),
    };
    switch (this.lockType) {
      case 'puk':
        if (this.incorrectInput) {
          config = {
            ...config,
            title: 'PUK',
            message: `${utils.toL10n(
              'sim-puk-incorrect-message'
            )} ${utils.toL10n('inputCodeAttemptsLeft', {
              n: this.retryCount,
            })}`,
            primarybtntext: utils.toL10n('ok'),
            onDialogPrimaryBtnClick: () => {
              this.resetPIN = false;
              this._updateUI();
              this._hideSIMLockedDialog();
              this.container.classList.remove('hide');
            },
          };
          // do not use 'this._hide() or all the properties will be reset.'
          this.container.classList.add('hide');
        } else {
          config = {
            ...config,
            message: utils.toL10n('sim-pin-lock-message'),
            extratext: utils.toL10n('emergency-call-button'),
            primarybtntext: utils.toL10n('enter-puk-rsk'),
            onDialogPrimaryBtnClick: () => {
              this._hideSIMLockedDialog();
              this._show();
            },
            onDialogExtraTextClick: () => {
              this._launchEmergencyCall();
            },
          };
        }
        break;
      case 'blocked':
        // The dialog should be shown until the locked SIM card is removed.
        config = {
          ...config,
          message: utils.toL10n('sim-permanently-lock-message'),
          primarybtntext: utils.toL10n('emergency-call-button'),
          onDialogPrimaryBtnClick: () => {
            this._launchEmergencyCall();
          },
        };
        break;
      default:
        config = {
          ...config,
          message: utils.toL10n('xcklockContent', {
            type: this.lockType.toUpperCase(),
          }),
          primarybtntext: utils.toL10n('emergency-call-button'),
          onDialogPrimaryBtnClick: () => {
            this._launchEmergencyCall();
          },
        };
    }
    Service.request('DialogService:show', config);
  }

  _launchEmergencyCall() {
    const name = 'emergency-call';
    let url = window.parent.location.href.replace('system', name);
    const manifestUrl = url.replace(
      /(\/)*(index.html#?)*$/,
      '/manifest.webapp'
    );

    url += '#secure';
    window.dispatchEvent(
      new window.CustomEvent('secure-launchapp', {
        detail: {
          appURL: url,
          appManifestURL: manifestUrl,
        },
      })
    );
  }

  _updateUI() {
    this._setHeaderText();
    this._setDescriptionText();
    this._setInputAreas();
    this._setSmallKeypad();
  }

  _setHeaderText() {
    switch (this.lockType) {
      case 'pin':
        this.header = utils.toL10n('pinTitle');
        break;
      case 'puk':
        this.header = this.resetPIN
          ? utils.toL10n('sim-pin-reset')
          : utils.toL10n('sim-attention-header');
        break;
      default:
        this.header = utils.toL10n('xckTitle', {
          type: this.lockType.toUpperCase(),
        });
        break;
    }
  }

  _setDescriptionText() {
    if (this.lockType === 'puk' && !this.resetPIN) {
      this.description = utils.toL10n('sim-pin-lock-description');
    } else {
      this.description = '';
    }
  }

  _setInputAreas() {
    if (this.resetPIN) {
      const newInput = {
        label: this._getInputLabel('newSimPinMsg'),
        id: this.ACTIVE_INPUTS.NEW,
      };
      const confirmInput = {
        label: this._getInputLabel('confirmNewSimPinMsg'),
        id: this.ACTIVE_INPUTS.CONFIRM,
      };
      this._setHints(this.ACTIVE_INPUTS.CONFIRM);
      this.inputAreas = [newInput, confirmInput];
      this.inputs = {
        [this.ACTIVE_INPUTS.NEW]: [],
        [this.ACTIVE_INPUTS.CONFIRM]: [],
      };
      this.activeInputId = this.ACTIVE_INPUTS.NEW;
    } else {
      const unlockInput = {
        label: this._getInputLabel(),
        id: this.ACTIVE_INPUTS.UNLOCK,
      };
      this._setHints(this.ACTIVE_INPUTS.UNLOCK);
      this.inputAreas = [unlockInput];
      this.inputs = {
        [this.ACTIVE_INPUTS.UNLOCK]: [],
      };
      this.activeInputId = this.ACTIVE_INPUTS.UNLOCK;
    }
  }

  _setHints(id) {
    this.hints = {
      ...this.hints,
      [id]: id === this.ACTIVE_INPUTS.NEW ? '' : this._getHintText(),
    };
  }

  _setSmallKeypad() {
    if (this.lockType === 'puk') {
      this.smallkeypad = true;
    } else {
      this.smallkeypad = false;
    }
  }

  _clickHandler(e) {
    const type = e.detail.type;
    const detail = e.detail;
    switch (type) {
      case EVENT_TYPES.INPUT_AREA:
        this.activeInputId = detail.activeInputId;
        break;
      case EVENT_TYPES.DELETE:
        {
          const activeInputId = detail.activeInputId;
          this._onDelete(activeInputId);
        }
        break;
      case EVENT_TYPES.KEYPAD:
        {
          const id = detail.id;
          const activeInputId = detail.activeInputId;
          this._onClickKeypad(id, activeInputId);
        }
        break;
      case EVENT_TYPES.BOTTOM_TEXT:
        this._launchEmergencyCall();
        break;
      default:
        break;
    }
  }

  render() {
    return html`
      <div
        class="theme-kaibrand dark-fixed container hide"
        @mousedown="${this._preventFocus}"
        @pinlock-click=${this._clickHandler}
      >
        <pin-lock
          .header=${this.header}
          .description=${this.description}
          .inputAreas=${this.inputAreas}
          .inputs=${this.inputs}
          .hints=${this.hints}
          .activeInputId=${this.activeInputId}
          ?smallkeypad=${this.smallkeypad}
          ?submittable=${this.submittable}
          .bottomtext=${utils.toL10n('emergency-call-button')}
        >
        </pin-lock>
      </div>
    `;
  }
}

const mapDispatchToProps = {
  activateSIMSecurity: () => ({ type: 'ACTIVATE_SIM_SECURITY' }),
  deactivateSIMSecurity: () => ({ type: 'DEACTIVATE_SIM_SECURITY' }),
};

customElements.define(SIMSecurity.is, connect(null, mapDispatchToProps)(SIMSecurity));
