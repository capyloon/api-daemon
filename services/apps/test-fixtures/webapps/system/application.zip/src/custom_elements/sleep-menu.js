/* global Service, LogoLoader, CustomLogoPath */
import { LitElement, html, css } from 'lit-element';
import { classMap } from 'lit-html/directives/class-map.js';

class SleepMenu extends LitElement {
  static get properties() {
    return {
      isShuttingDown: { type: Boolean },
      isActive: { type: Boolean }
    };
  }

  static get styles() {
    return css`
      #container {
        position: fixed;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        background-color: var(--color-gs00);
        display: none;
        flex-direction: column;
        justify-content: center;
        align-items: center;
        z-index: var(--z-index-sleep-menu);
      }
      #container.show {
        display: flex;
      }
      .option {
        margin: 1.5rem 0;
      }
      #cancel {
        position: absolute;
        left: 0;
        bottom: 4rem;
        width: 100%;
        font-size: 1.6rem;
        font-weight: bold;
        text-transform: uppercase;
        text-align: center;
        color: var(--color-gs100);
      }
      #splash {
        position: absolute;
        top: 0;
        left: 0;
        width: 100%;
        height: 100%;
        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: center;
        pointer-events: none;
        background-color: transparent;
        transition: background-color 300ms ease-in-out;
        z-index: var(--z-index-power-splash);
      }
      #splash.show {
        background-color: black;
        pointer-events: auto;
      }
      #splash video,
      #splash img {
        width: 100%;
        height: auto;
      }
      @keyframes fade-in-out {
        0% { opacity: 0 }
        50% { opacity: 1 }
        100% { opacity: 0}
      }
      #splash img {
        opacity: 0;
      }
      #splash img.play {
        animation: fade-in-out 1500ms ease-in-out forwards;
      }
    `;
  }

  constructor() {
    super();
    window.addEventListener('holdsleep', this);
    window.addEventListener('batteryshutdown', this);
    Service.register('powerOff', this);
    Service.register('restart', this);
    Service.registerState('isShuttingDown', this);
    this.isShuttingDown = false;
    this.isActive = false;
  }

  get splash() {
    return this.shadowRoot.querySelector('#splash');
  }

  _publish(eventName, detail) {
    let event = new CustomEvent(eventName, { detail: detail });
    window.dispatchEvent(event);
  }

  _preventFocus = evt => {
    evt.preventDefault();
  }

  _onClick = evt => {
    evt.preventDefault();
    switch (evt.target.id) {
      case 'power-off':
        this.powerOff();
        break;
      case 'restart':
        this.restart();
        break;
      case 'cancel':
        this._close();
        break;
      default:
        // TODO: other cases.
        break;
    }
  }

  handleEvent(evt) {
    switch (evt.type) {
      case 'holdsleep':
        this._open();
        break;
      case 'batteryshutdown':
        this.powerOff();
        break;
      default:
        // TODO: other cases.
    }
  }

  _open() {
    this.isActive = true;
  }

  _close() {
    this.isActive = false;
  }

  _playMedia() {
    return new Promise((resolve, reject) => {
      Service.request('turnScreenOn');
      this._publish('will-shutdown');
      this.isShuttingDown = true;

      let logoLoader = new LogoLoader(CustomLogoPath.poweroff);
      logoLoader.onload = (element) => {
        this.splash.appendChild(element);

        if ('video' == element.tagName.toLowerCase()) {
          // Video
          element.onended = resolve;
          element.play();
        } else {
          // Image
          element.addEventListener('animationend', resolve);
          element.classList.add('play');
        }
      }

      logoLoader.onnotfound = reject;
    });
  }

  async powerOff() {
    try {
      await this._playMedia();
    } catch (e) {
      console.warn('No media content found!');
    }
    navigator.mozPower && navigator.mozPower.powerOff();
  }

  async restart() {
    try {
      await this._playMedia();
    } catch (e) {
      console.warn('No media content found!');
    }
    navigator.mozPower && navigator.mozPower.reboot();
  }

  render() {
    const _ = navigator.mozL10n;
    const classes = {
      'dark-fixed': true,
      'show': this.isActive || this.isShuttingDown
    };
    const visibility = {
      'show': this.isShuttingDown
    };

    return html`
      <div class="${classMap(classes)}" id="container" @mousedown="${this._preventFocus}">
        <kai-pillbutton
          id="power-off"
          class="option theme-kaibrand"
          text="${_.get('power')}"
          @click="${this._onClick}"
        ></kai-pillbutton>
        <kai-pillbutton
          id="restart"
          class="option"
          text="${_.get('restart')}"
          level="secondary"
          @click="${this._onClick}"
        ></kai-pillbutton>
        <div id="cancel" @click="${this._onClick}">${_.get('cancel')}</div>
        <div id="splash" class="${classMap(visibility)}"></div>
      </div>
    `;
  }
}

customElements.define('sleep-menu', SleepMenu);
