import { LitElement, html, css } from 'lit-element';

class NotificationElement extends LitElement {
  static get is() {
    return 'kai-notification';
  }

  static get properties() {
    return {
      icon: { type: String },
      appname: { type: String },
      timestamp: { type: String },
      noticetitle: { type: String },
      bodytext: { type: String },
      isgroup: { type: Boolean },
      primarybtntext: { type: String },
      secondarybtntext: { type: String },
      primarybtnicon: { type: String },
      secondarybtnicon: { type: String }
    };
  }

  static get styles() {
    return [
      css`
        :host {
          color: var(--color-gs00);
        }

        .root {
          display: block;
          margin-bottom: 1rem;
          position: relative;
        }

        .root--group {
          margin-bottom: 2rem;
          width: var(--notification-width, 32rem);
        }

        .root--group:before,
        .root--group:after {
          content: '';
          box-shadow: 0 0.5rem 1.5rem 0 rgba(0, 0, 0, 0.3);
          background-color: var(--color-gs100);
          border-bottom-left-radius: 3rem;
          opacity: 0.4;
          position: absolute;
          right: 0;
          height: 3rem;
        }

        .root--group:before {
          bottom: -0.5rem;
          width: calc(100% - 0.5rem);
          z-index: 1;
        }

        .root--group:after {
          bottom: -1rem;
          width: calc(100% - 1rem);
          z-index: 0;
        }

        .popup {
          display: flex;
          flex-direction: column;
          width: var(--notification-width, 32rem);
          padding: 1.5rem 2.5rem;
          margin: 0 auto;
          box-sizing: border-box;
          box-shadow: 0 0.5rem 1.5rem 0 rgba(0, 0, 0, 0.3);
          background-color: var(--color-gs100);
          border-radius: 3rem;
          border-bottom-right-radius: 0.2rem;
        }

        .header {
          display: flex;
          justify-content: space-between;
          align-items: center;
          margin-bottom: 0.4rem;
        }

        .long-and-truncated {
          flex: 1;
          white-space: nowrap;
          overflow: hidden;
          text-overflow: ellipsis;
        }

        /* resize icon images */
        img {
          width: 2.4rem;
          height: 2.4rem;
          vertical-align: middle;
        }

        span {
          margin-left: 0.4rem;
          margin-right: 1.5rem;
          vertical-align: middle;
        }

        .time-stamp {
          vertical-align: middle;
        }

        .short-and-fixed {
          white-space: nowrap;
        }

        .notice-text {
          color: var(--color-gs00);
        }

        .body-text {
          color: var(--color-gs10);
          margin-top: 0.2rem;
        }

        .buttons {
          margin-top: 1rem;
          width: 100%;
          display: flex;
          align-content: center;
          justify-content: space-between;
        }

        .buttons > :only-child {
          --pillbutton-width: 27rem;
        }

        kai-pillbutton {
          --pillbutton-width: 12.5rem;
          --pillbutton-height: 4.8rem;
        }

        .content ::slotted([slot='thumbnail']) {
          width: 4rem;
          height: 4rem;
          border: solid 0.2rem #ffffff;
          border-radius: 50%;
          float: left;
          margin-right: 1rem;
        }
      `
    ];
  }

  constructor() {
    super();
    this.icon = '';
    this.appname = '';
    this.timestamp = '';
    this.noticetitle = '';
    this.bodytext = '';
    this.primarybtntext = '';
    this.secondarybtntext = '';
    this.primarybtnicon = '';
    this.secondarybtnicon = '';
  }

  _clickHandler(e) {
    switch (e.target.id) {
      case 'secondarybtntext':
      case 'secondarybtnicon':
        {
          const event = new CustomEvent('notificationSecondaryBtnClick', {
            bubbles: true,
            composed: true
          });
          this.dispatchEvent(event);
        }
        break;
      case 'primarybtntext':
      case 'primarybtnicon':
        {
          const event = new CustomEvent('notificationPrimaryBtnClick', {
            bubbles: true,
            composed: true
          });
          this.dispatchEvent(event);
        }
        break;
      default:
        break;
    }
  }

  render() {
    const buttonsHtml = html`
      <div
        class="${this.primarybtnicon === '' &&
        this.secondarybtnicon === '' &&
        this.primarybtntext === '' &&
        this.secondarybtntext === ''
          ? ''
          : 'buttons'}"
      >
        ${this.secondarybtntext
          ? html`
              <kai-pillbutton
                id="secondarybtntext"
                text=${this.secondarybtntext}
                level="secondary"
                apply="notification"
                @click="${this._clickHandler}"
              ></kai-pillbutton>
            `
          : ''}
        ${this.primarybtntext
          ? html`
              <kai-pillbutton
                id="primarybtntext"
                text=${this.primarybtntext}
                apply="notification"
                @click="${this._clickHandler}"
              ></kai-pillbutton>
            `
          : ''}
        ${this.secondarybtnicon
          ? html`
              <kai-pillbutton
                id="secondarybtnicon"
                level="secondary"
                @click="${this._clickHandler}"
                icon="${this.secondarybtnicon}"
              >
              </kai-pillbutton>
            `
          : ''}
        ${this.primarybtnicon
          ? html`
              <kai-pillbutton
                id="primarybtnicon"
                @click="${this._clickHandler}"
                icon="${this.primarybtnicon}"
              >
              </kai-pillbutton>
            `
          : ''}
      </div>
    `;
    return html`
      <div class="root ${this.isgroup ? 'root--group' : ''}">
        <div class="popup">
          <div class="header">
            <div class="subtitle-2 long-and-truncated">
              <img src="${this.icon}" />
              <span>${this.appname}</span>
            </div>
            <div
              class="time-stamp subtitle-2
          short-and-fixed"
            >
              ${this.timestamp}
            </div>
          </div>

          <div class="content">
            <slot name="thumbnail"></slot>
            <div class="notice-text subtitle-1">${this.noticetitle}</div>
            <div class="${this.bodytext === null ? '' : 'body-text'} body-2">
              ${this.bodytext}
            </div>
          </div>

          ${buttonsHtml}
        </div>
      </div>
    `;
  }
}

customElements.define(NotificationElement.is, NotificationElement);
