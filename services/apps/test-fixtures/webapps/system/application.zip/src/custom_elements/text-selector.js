import { LitElement, html, css } from 'lit-element';

const copycutTimeoutPeriod = 15000;
const copyCmds = ['copy', 'cut'];
const pasteCmds = ['paste'];
class TextSelector extends LitElement {
  static get is() {
    return 'text-selector';
  }

  static get properties() {
    return {
      // detail is internal property
      detail: { type: Object }
    };
  }

  static get styles() {
    return css`
      .textSelector {
        display: flex;
        justify-content: center;
        align-items: center;
        z-index: var(--z-index-data-operation);
        position: absolute;
        top: 0;
        left: 0;
      }
      .cmdBtn {
        display: none;
        flex-direction: column;
        justify-content: center;
        align-items: center;
        height: 5rem;
        padding: 0 0.8rem;
        background-color: var(--color-gs100);
        border-radius: 2rem;
      }
      .textSelector.canCut > #cut.cmdBtn,
      .textSelector.canCopy > #copy.cmdBtn,
      .textSelector.canPaste > #paste.cmdBtn,
      .textSelector.canSelectAll > #selectall.cmdBtn {
        display: flex;
      }
      // [cut][copy][paste][selectdall]
      .textSelector.canCut > #copy.cmdBtn,
      .textSelector.canCut > #paste.cmdBtn,
      .textSelector.canCut > #selectall.cmdBtn,
      .textSelector.canCopy > #paste.cmdBtn,
      .textSelector.canCopy > #selectall.cmdBtn,
      .textSelector.canPaste > #selectall.cmdBtn, {
        border-top-left-radius: 0;
        border-bottom-left-radius: 0;
      }
      .textSelector.canPaste > #paste.cmdBtn {
        padding: 0 1.6rem;
      }
      .textSelector.canCopy.canSelectAll > #copy.cmdBtn {
        border-top-right-radius: 0;
        border-bottom-right-radius: 0;
        padding-left: 1.6rem;
      }
      .textSelector.canPaste.canSelectAll > #paste.cmdBtn {
        border-top-right-radius: 0;
        border-bottom-right-radius: 0;
        padding-left: 1.6rem;
        padding-right: 0.8rem;
      }
      .textSelector.canCopy.canSelectAll > #selectall.cmdBtn,
      .textSelector.canPaste.canSelectAll > #selectall.cmdBtn {
        border-top-left-radius: 0;
        border-bottom-left-radius: 0;
        padding-right: 1.6rem;
      }
      .textSelector.canCut.canCopy.canSelectAll > #cut.cmdBtn {
        border-top-right-radius: 0;
        border-bottom-right-radius: 0;
        padding: 0 0.8rem 0 1.6rem;
      }
      .textSelector.canCut.canCopy.canSelectAll > #copy.cmdBtn {
        border-radius: 0;
        padding: 0 0.8rem;
      }
      .textSelector.canCut.canCopy.canPaste.canSelectAll > #copy.cmdBtn,
      .textSelector.canCut.canCopy.canPaste.canSelectAll > #paste.cmdBtn,
      .textSelector.canCut.canCopy.canPaste.canSelectAll > #selectall.cmdBtn {
        border-top-left-radius: 0;
        border-bottom-left-radius: 0;
      }
      .textSelector.canCut.canCopy.canPaste.canSelectAll > #cut.cmdBtn,
      .textSelector.canCut.canCopy.canPaste.canSelectAll > #copy.cmdBtn,
      .textSelector.canCut.canCopy.canPaste.canSelectAll > #paste.cmdBtn {
        border-top-right-radius: 0;
        border-bottom-right-radius: 0;
      }
      .textSelector.canCut.canCopy.canPaste.canSelectAll > #paste.cmdBtn {
        padding: 0 0.8rem;
      }
      .title {
        font-size: 1.6rem;
        font-weight: 600;
        box-sizing: border-box;
        color: var(--color-gs00);
        text-align: center;
        pointer-events: none;
      }
      .hide {
        opacity: 0;
        pointer-events: none;
      }
    `;
  }

  constructor() {
    super();
    window.addEventListener('mozbrowsercaretstatechanged', this);
    window.addEventListener('mozChromeEvent', this);
    this.detail = {};
    this.copycutTimer = null;
    this.hasPastedAfterCopied = false;
  }

  handleEvent = evt => {
    switch (evt.type) {
      case 'mozbrowsercaretstatechanged':
        evt.preventDefault();
        evt.stopPropagation();
        this._handleCaretStateChanged(evt.detail);
        break;
      case 'mozChromeEvent':
        switch (evt.detail.type) {
          case 'caretstatechanged':
            evt.preventDefault();
            evt.stopPropagation();
            this._handleCaretStateChanged(evt.detail.detail);
            break;
        }
        break;
    }
  };

  _handleCaretStateChanged(detail) {
    if (!detail) {
      return;
    }
    if (detail.reason === 'visibilitychange' && !detail.caretVisible) {
      this._close();
      return;
    }
    if (detail.reason === 'scroll') {
      this._close();
      return;
    }
    if (detail.reason === 'presscaret') {
      this._close();
      return;
    }
    if (!detail.selectionVisible) {
      this._close();
      return;
    }
    if (detail.collapsed) {
      this._onCollapsedMode(detail);
    } else {
      this._onSelectionMode(detail);
    }
  }

  _onSelectionMode(detail) {
    // make sure cut command option is only shown on editable element
    detail.commands.canCut = detail.commands.canCut &&
                               detail.selectionEditable;
    this._open(detail);
  }

  _onCollapsedMode(detail) {
    let showDialog = false;
    switch (detail.reason) {
      case 'taponcaret':
      case 'longpressonemptycontent':
      case 'releasecaret':
        // Always allow, do nothing here.
        showDialog = true;
        break;
      case 'updateposition':
        if (this.copycutTimer && !this.hasPastedAfterCopied) {
          showDialog = true;
        }
        break;
      default:
        // Other state are not allow
        break;
    }
    if (showDialog) {
      detail.commands.canCut = false;
      detail.commands.canCopy = false;
      this._open(detail);
    } else {
      this._close();
    }
  }

  get container() {
    return this.shadowRoot.getElementById('textSelector');
  }

  get containerWidth () {
    return this.container.clientWidth || 0;
  }

  get containerHeight () {
    return this.container.clientHeight || 0;
  }

  _open(detail) {
    this.detail = detail;
    this.container.classList.remove('hide');
  }

  _close() {
    this.container.classList.add('hide');
  }

  _preventFocus = evt => {
    evt.preventDefault();
  }

  _onClick(evt){
    evt.preventDefault();
    if (this.detail && this.detail.sendDoCommandMsg) {
      const cmd = evt.target.getAttribute('data-cmd');
      this.detail.sendDoCommandMsg(cmd);
      if (copyCmds.indexOf(cmd) > -1) {
        this.hasPastedAfterCopied = false;
        this.copycutTimer = window.setTimeout(() => {
          this.copycutTimer = null;
        }, copycutTimeoutPeriod);
      }
      if (pasteCmds.indexOf(cmd) > -1){
        this.hasPastedAfterCopied = true;
        window.clearTimeout(this.copycutTimer);
        this.copycutTimer = null;
      }
    }
    this._close();
  }

  calculateDialogPosition(){
    // *** vetical position
    // if top availble. dialog on top on selection
    // if not, on bottom
    // if both, on center of window
    const visibleHeight = window.innerHeight -
        document.querySelector('infogation-bar').clientHeight;
    const caretReservedHeight = 30;
    const rectTop = this.detail.rect.top * this.detail.zoomFactor
                    - caretReservedHeight
                    + document.activeElement.offsetTop;
    const rectBtm = this.detail.rect.bottom * this.detail.zoomFactor
                    + caretReservedHeight
                    + document.activeElement.offsetTop;
    const bottomSpaceHeight = visibleHeight - rectBtm;
    const y = rectTop > this.containerHeight
      ? rectTop - this.containerHeight
      : bottomSpaceHeight > this.containerHeight
        ? rectBtm
        : visibleHeight / 2 - this.containerHeight;

    // *** horizontal
    // if center on selection rectangle area, make it center
    // if no way to center, on left or right depends
    // on center position of rectangle
    const visibleWidth = window.innerWidth;
    const rectCenter = (this.detail.rect.left + this.detail.rect.right)
                      * this.detail.zoomFactor / 2;
    const containerRadius = this.containerWidth / 2;
    const x = (rectCenter + containerRadius) <= visibleWidth
      && (rectCenter - containerRadius) >= 0
      ? rectCenter - containerRadius
      : rectCenter <= visibleWidth / 2
        ? 0
        : visibleWidth - this.containerWidth;
    this.container.style.transform = `translate(${x}px, ${y}px)`;
  }

  updated() {
    if (this.detail && this.detail.commands) {
      Object.keys(this.detail.commands).forEach(key =>{
        if (this.detail.commands[key]){
          this.container.classList.add(key);
        } else {
          this.container.classList.remove(key);
        }
      });
    }
    this.calculateDialogPosition();
  }

  render() {
    return html`
      <div
        @mousedown="${this._preventFocus}"
        class="textSelector hide"
        id="textSelector"
      >
        <div id="cut" class="cmdBtn" data-cmd="cut"
          @click="${this._onClick}"
        >
          <div class="title">Cut</div>
        </div>
        <div id="copy" class="cmdBtn" data-cmd="copy"
          @click="${this._onClick}"
        >
          <div class="title">Copy</div>
        </div>
        <div id="paste" class="cmdBtn" data-cmd="paste"
          @click="${this._onClick}"
        >
          <div class="title">Paste</div>
        </div>
        <div id="selectall" class="cmdBtn" data-cmd="selectall"
          @click="${this._onClick}"
        >
          <div class="title">Select All</div>
        </div>
      </div>
    `;
  }
}

customElements.define(TextSelector.is, TextSelector);
