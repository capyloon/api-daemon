import { LitElement, html, css } from "lit-element";
import * as utils from "../util/utils";
import { PASSCODE_LIMIT } from '../constants/remotelock';

const eventPrefix = 'remote-lock-screen';

class RemoteLock extends LitElement {
  name = 'RemoteLock';
  EVENT_PREFIX = eventPrefix; // for hierarchy_manager

  static get is() {
    return 'remote-lock';
  }

  static get properties() {
    return {
      hidden: {
        type: Boolean,
        reflect: true,
        hasChanged(newVal, oldVal) {
          if (newVal !== oldVal) {
            window.dispatchEvent(new CustomEvent(
              `${eventPrefix}${newVal ? '-deactivating' : '-activating'}`
            ));
            return true;
          }
          return false;
        }
      },
      lockInfo: {
        type: Object,
        reflect: true
      },
      inputVal: {
        type: String,
        reflect: true
      },
      inputErr: {
        type: String,
        reflect: true
      }
    };
  }

  static get styles() {
    return css`
      :host {
        position: absolute;
        z-index: var(--z-index-remote-lock);
        left: 0;
        right: 0;
        top: 0;
        bottom: 0;
        background: var(--color-gs00);
        color: var(--color-gs100);
      }

      :host[hidden] {
        display: none;
      }

      p,
      strong {
        font-size: 1.8rem;
      }

      .invalid {
        border-color: var(--color-error) !important;
      }

      .invalid-msg {
        color: var(--color-error) !important;
      }

      .remote-lock-container {
        display: flex;
        height: calc(100% - var(--infogation-bar-height));
        flex-direction: column;
      }

      .remote-lock-header {
        flex: 0 1 8rem;
      }

      .remote-lock-content {
        flex-grow: 1;
        padding: 0 2rem;
      }

      .remote-lock-passcode-input {
        margin-top: 3rem;
        width: 100%;
        font-size: 5rem;
        letter-spacing: 2rem;
        background: transparent;
        border: 0;
        border-bottom: 1px solid var(--color-gs100);
      }

      .remote-lock-btns {
        padding: 0 2rem 3rem;
        text-align: center;
      }

      .remote-lock-text-btn {
        height: var(--pillbutton-height, 6rem);
        outline: none;
        border: 0;
        background: transparent;
        font-size: 1.6rem;
        font-weight: bold;
        text-transform: uppercase;
        color: var(--color-gs100);
      }
    `;
  }

  constructor() {
    super();

    this.hidden = true;
    this.lockInfo = {
      message: '',
      passcode: ''
    };
    this.inputVal = '';
    this.inputErr = '';

    window.Service.registerState('isActive', this);
    this._watchRemoteLock();
  }

  firstUpdated() {
    window.Service.request('registerHierarchy', this);
  }

  isActive() {
    return !this.hidden;
  }

  setHierarchy(value) {
    if (value) {
      this.focus();
    }
  }

  focus() {
    this.shadowRoot.querySelector('.remote-lock-container').focus();
  }

  _watchRemoteLock() {
    const { mozSettings } = navigator;

    mozSettings.addObserver('lockscreen.remote-lock', evt => {
      if (
        evt.settingValue &&
        evt.settingValue[0] !== '' &&
        evt.settingValue[1] !== ''
      ) {
        this._remoteLockSwitch({
          isActivate: true,
          remoteInfo: {
            message: evt.settingValue[0],
            passcode: evt.settingValue[1]
          }
        });
      } else {
        this._remoteLockSwitch({
          isActivate: false,
          remoteInfo: { message: '', passcode: '' }
        });
      }
    });
  }

  _remoteLockSwitch = ({ isActivate, remoteInfo }) => {
    this.lockInfo = {
      ...this.lockInfo,
      ...remoteInfo
    };

    if (isActivate) {
      this.hidden = false;
    } else {
      // Initialize component states after unlock.
      this.hidden = true;
      this.inputVal = '';
      this.inputErr = '';
    }
  };

  _invokeSecureApp(name) {
    const url = window.parent.location.href.replace('system', name);
    const manifestUrl = url.replace(
      /(\/)*(index.html#?)*$/,
      '/manifest.webapp'
    );
    window.dispatchEvent(
      new window.CustomEvent('secure-launchapp', {
        detail: {
          appURL: url + '#secure',
          appManifestURL: manifestUrl
        }
      })
    );
  }

  _handleUnlockBtnClick() {
    if (
      this.inputVal.length === PASSCODE_LIMIT &&
      this.lockInfo.passcode === this.inputVal
    ) {
      const { mozSettings } = navigator;

      this.inputErr = '';
      mozSettings.createLock().set({
        'lockscreen.remote-lock': ['', '']
      });
    } else {
      window.navigator.vibrate(50);
      this.inputErr = utils.toL10n('passcodeErrorMsg', { n: 0 });
    }
  }

  _isUnlockBtnDisabled() {
    return this.inputVal.length < PASSCODE_LIMIT;
  }

  _handleEmergencyBtnClick() {
    this._invokeSecureApp('emergency-call');
  }

  _handleChange(e) {
    this._limitInputText(e, PASSCODE_LIMIT);
  }

  _handleInput(e) {
    this._limitInputText(e, PASSCODE_LIMIT);
  }

  _limitInputText(e, limit) {
    if (e.target.value.length > limit) {
      const limitedValue = e.target.value.slice(0, limit);

      this.inputVal = limitedValue;
      e.target.value = limitedValue; // controlled input https://github.com/Polymer/lit-html/issues/998.
    } else {
      this.inputVal = e.target.value;
      if (this.inputErr !== '') {
        // Remove error message when user still typing.
        this.inputErr = '';
      }
    }
  }

  render() {
    return html`
      <div class="remote-lock-container">
        <kai-header
          class="remote-lock-header"
          title="Device Locked"
          type="small"
        >
        </kai-header>
        <div class="remote-lock-content">
          <p>${this.lockInfo.message}</p>
          <strong>Enter the 6-digit code to unlock</strong>
          <input
            id="remote-lock-passcode-input"
            class="remote-lock-passcode-input ${this.inputErr !== ''
              ? 'invalid'
              : ''}"
            type="tel"
            .value=${this.inputVal}
            @input=${this._handleInput}
            @change=${this._handleChange}
          />
          ${this.inputErr !== ''
            ? html`<p class="invalid-msg">${this.inputErr}</p>`
            : null}
        </div>
        <div class="remote-lock-btns">
          <kai-pillbutton
            level="primary"
            text="unlock"
            ?disabled=${this._isUnlockBtnDisabled()}
            @click=${this._handleUnlockBtnClick}
          >
          </kai-pillbutton>
          <button
            type="button"
            class="remote-lock-text-btn"
            @click=${this._handleEmergencyBtnClick}
          >
            ${utils.toL10n("emergency-call-button")}
          </button>
        </div>
      </div>
    `;
  }
}

customElements.define(RemoteLock.is, RemoteLock);
