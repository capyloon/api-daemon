import { LitElement, html, css } from 'lit-element';

const _im = navigator.mozInputMethod;
class ValueSelectorElement extends LitElement {
  static get is() {
    return 'value-selector';
  }

  static get properties() {
    return {
      // detail is internal property
      detail: { type: Object },
    };
  }

  static get styles() {
    return css`
      .container {
        width: 100%;
        height: calc(100% - var(--infogation-bar-height));
        background-color: var(--popup-background-color);
        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: center;
        z-index: var(--z-index-data-operation);
        position: fixed;
        top: 0;
        left: 0;
      }
      .popup {
        width: 30rem;
        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: center;
      }
      .title {
        width: 30rem;
        height: 3.2rem;
        padding: 0 2rem;
        box-sizing: border-box;
        color: var(--color-gs100);
        text-align: center;
        overflow: hidden;
        white-space: nowrap;
        text-overflow: ellipsis;
      }
      .options {
        /* max dialog height is 32rem, 3.2rem is title height,
          6rem is buttons block height, and 1.2rem is top margin */
        max-height: calc(32rem - 3.2rem - 1.2rem);
        width: 30rem;
        color: var(--color-gs100);
        margin-top: 1.2rem;
        border-radius: 3rem;
        border: solid 0.2rem var(--color-gs80);
        padding: 1rem 0;
        padding-right: 0.5rem;
        overflow-y: auto;
        box-sizing: border-box;
        background-color: var(--color-gs00);
      }
      .buttons {
        width: 100%;
        display: flex;
        align-content: center;
        justify-content: space-between;
        margin-top: 3rem;
      }
      kai-pillbutton {
        --pillbutton-width: 14rem;
      }
      .hide {
        display: none;
      }
    `;
  }

  constructor() {
    super();
    window.addEventListener('mozChromeEvent', this._mozChromeEvent);
    this.detail = {};
  }

  _isSupportedType(type) {
    const typesToHandle = ['select-one', 'select-multiple'];
    return typesToHandle.includes(type);
  }

  _mozChromeEvent = evt => {
    switch (evt.detail.type) {
      case 'inputmethod-contextchange':
        {
          const inputType = evt.detail.inputType;
          const opening = this._isSupportedType(inputType);
          if (opening) {
            this.detail = evt.detail;
            /* event might occur before component has been added to DOM */
            setTimeout(() => {
              this._open();
            }, 0);
          }
        }
        break;
      default:
        break;
    }
  };

  get container() {
    return this.shadowRoot.querySelector('#container');
  }

  get options() {
    return this.shadowRoot.querySelector('.options');
  }

  _open() {
    this._updateCheckboxState();
    this.container.classList.remove('hide');
    this._scrollToSelectedItem();
  }

  _close() {
    this.container.classList.add('hide');
    this.detail = {};
    _im.removeFocus();
  }

  _preventFocus = evt => {
    evt.preventDefault();
    if (evt.target === this.container) {
      this._onCancel();
    }
  };

  _onClick = evt => {
    evt.preventDefault();
    const inputType = this.detail.inputType;
    switch (inputType) {
      case 'select-one':
        {
          const radio = evt.currentTarget.querySelector('kai-radio');
          const disabled = radio.disabled;
          if (disabled) {
            console.warn('radio is disabled!');
            return;
          }
          _im.setSelectedOption(+radio.value);
          this._close();
        }
        break;
      case 'select-multiple':
        {
          const checkbox = evt.currentTarget.querySelector('kai-checkbox');
          const disabled = checkbox.disabled;
          if (disabled) {
            console.warn('checkbox is disabled!');
            return;
          }
          checkbox.checked = !checkbox.checked;
        }
        break;
      default:
        break;
    }
  };

  _scrollToSelectedItem() {
    const selectorChoice = JSON.parse(this.detail.choices);
    const selected = selectorChoice.choices.filter(choice => choice.selected);
    /*
      The first checked item is scrolled to as middle as possible automatically
    */
    if (selected && selected[0]) {
      const listitem = this.options.querySelector('kai-1line-listitem');
      const listitemHeight = listitem.offsetHeight;
      const optionsOffsetHeight = this.options.offsetHeight;
      const rootFontSize = getComputedStyle(
        document.documentElement
      ).getPropertyValue('font-size');
      // convert unit from rem to px here. top/bottom padding are 1 rem.
      const optionsTopAndBottomPadding = 1 * 2 * parseFloat(rootFontSize);
      const targetY = selected[0].optionIndex * listitemHeight;
      const optionsContentHeight =
        optionsOffsetHeight - optionsTopAndBottomPadding;
      const targetScrollHeight =
        targetY - optionsContentHeight / 2 + listitemHeight / 2;
      this.options.scrollTo(0, targetScrollHeight);
    }
  }

  _updateCheckboxState() {
    /*
      TODO:
      this is a workaround to set original value back when
      user is click 'cancel' button
    */
    const inputType = this.detail.inputType;
    if (inputType === 'select-multiple') {
      const selectorChoice = JSON.parse(this.detail.choices);
      const selects = this.options
        ? this.options.querySelectorAll('kai-checkbox')
        : [];
      selectorChoice.choices.forEach((choice, idx) => {
        selects[idx].checked = choice.selected;
      });
    }
  }

  _onCancel = () => {
    this._updateCheckboxState();
    this._close();
  };

  _onEnabled = () => {
    const selects = this.options.querySelectorAll('kai-checkbox');
    const optionIndices = [];
    selects.forEach(selectee => {
      if (selectee.checked) {
        optionIndices.push(+selectee.value);
      }
    });
    _im.setSelectedOptions(optionIndices);
    this._close();
  };

  _renderOptions() {
    if (!this.details || !this.details.choices) {
      console.warn(`ValueSelectorElement::_renderOptions called with no details.choices !!`);
      return;
    }

    const selectorChoice = JSON.parse(this.detail.choices);
    const inputType = this.detail.inputType;
    switch (inputType) {
      case 'select-one':
        return html`
          <kai-radio-group>
            ${selectorChoice.choices.map(
              choice =>
                html`
                  <kai-1line-listitem
                    text=${choice.text}
                    @click="${this._onClick}"
                    ?disabled="${choice.disabled}"
                  >
                    <kai-radio
                      slot="listitem-right-slot"
                      value="${choice.optionIndex}"
                      name="select-one"
                      .checked="${choice.selected}"
                      ?disabled="${choice.disabled}"
                    ></kai-radio>
                  </kai-1line-listitem>
                `
            )}
          </kai-radio-group>
        `;
      case 'select-multiple':
        return html`
          ${selectorChoice.choices.map(
            choice =>
              html`
                <kai-1line-listitem
                  text=${choice.text}
                  @click="${this._onClick}"
                  ?disabled="${choice.disabled}"
                >
                  <kai-checkbox
                    slot="listitem-right-slot"
                    value="${choice.optionIndex}"
                    .checked="${choice.selected}"
                    ?disabled="${choice.disabled}"
                  ></kai-checkbox>
                </kai-1line-listitem>
              `
          )}
        `;
    }
  }

  render() {
    const _ = navigator.mozL10n.get;
    const title = this.detail && this.detail.name ? this.detail.name : _('select');
    return html`
      <div
        class="container hide"
        id="container"
        @mousedown=${this._preventFocus}
      >
        <div class="popup">
          <div class="h3 title">${title}</div>
          <div class="options">${this._renderOptions()}</div>
          ${this.detail && this.detail.inputType === 'select-multiple'
            ? html`
                <div class="buttons">
                  <kai-pillbutton
                    text=${_('cancel')}
                    level="secondary"
                    @click="${this._onCancel}"
                  ></kai-pillbutton>
                  <kai-pillbutton
                    text=${_('done')}
                    @click="${this._onEnabled}"
                  ></kai-pillbutton>
                </div>
              `
            : ''}
        </div>
      </div>
    `;
  }
}

customElements.define(ValueSelectorElement.is, ValueSelectorElement);
