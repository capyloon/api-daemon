import { LitElement, html, css } from 'lit-element';

const _im = navigator.mozInputMethod;
const selected = 'selected';
const SYSTIME = 1970;
const months = [
  'Jan',
  'Feb',
  'Mar',
  'Apr',
  'May',
  'Jun',
  'Jul',
  'Aug',
  'Sep',
  'Oct',
  'Nov',
  'Dec'
];
const range = (start, stop) =>
  Array.from(new Array(stop > start ? stop - start : start - stop), (x, i) =>
    stop > start ? i + start : start - i
  );

// Follow feature phone date picker range
const yy = range(SYSTIME, SYSTIME + 66).map(String);

function zeropad(num, size) {
  let s = num + '';
  while (s.length < size) {
    s = `0${s}`;
  }
  return s;
}

function debounce(func, wait) {
  let timeout;
  return function(...args) {
    const context = this;
    clearTimeout(timeout);
    timeout = setTimeout(() => func.apply(context, args), wait);
  };
}

function daysInMonth(month, year) {
  return new Date(year, month, 0).getDate();
}

function check(e) {
  let monthNumber = this.months
    .querySelector('.' + selected)
    .getAttribute('value');
  let yearNumber = this.years
    .querySelector('.' + selected)
    .getAttribute('value');
  const rect = e.target.getBoundingClientRect();
  const centerCell = document.elementFromPoint(
    rect.left + e.target.getBoundingClientRect().width / 2.5,
    rect.top + e.target.getBoundingClientRect().height / 2.5
  );

  const selectedItem = e.target.querySelector('.' + selected);

  if (selectedItem !== null) {
    selectedItem.classList.remove(selected);
  }
  centerCell.classList.add(selected);

  let dayNumber = daysInMonth(monthNumber, yearNumber);
  if (parseInt(dayNumber) > 0) {
    this.dd = [...Array(dayNumber)].map((_, i) => zeropad(i + 1, 2));
  }
}
class DatePickerElement extends LitElement {
  static get is() {
    return 'date-picker';
  }

  static get properties() {
    return {
      detail: { type: Object },
      dd: { type: Array }
    };
  }

  static get styles() {
    return css`
      .modal-dialog {
        width: 100%;
        height: calc(100% - var(--infogation-bar-height));
        background-color: var(--popup-background-color);
        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: center;
        z-index: var(--z-index-data-operation);
        position: fixed;
        top: 0;
        left: 0;
      }

      .popup {
        width: 30rem;
        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: center;
      }

      .title {
        width: 30rem;
        height: 3.2rem;
        padding: 0 2rem;
        box-sizing: border-box;
        color: var(--color-gs100);
        text-align: center;
        overflow: hidden;
        white-space: nowrap;
        text-overflow: ellipsis;
      }

      .container {
        width: 30rem;
        height: 22rem;
        margin-top: 1.2rem;
        margin-bottom: 3rem;
        border-radius: 3rem;
        border: solid 0.2rem var(--color-gs80);
        background: var(--color-gs00);
        display: flex;
        flex-direction: row;
        align-items: center;
        justify-content: center;
      }

      .scrollport {
        display: flex;
        flex-direction: column;
        flex-wrap: nowrap;
        width: 9.4rem;
        height: 22rem;
        overflow: auto;
        scroll-snap-type: mandatory;
        scroll-snap-points-y: repeat(33.33%);
        scroll-snap-destination: 0 33.33%;
      }

      .scrollport:before {
        content: '';
        flex-grow: 1;
        flex-shrink: 0;
        flex-basis: 33.33%;
        display: flex;
        justify-content: center;
        align-items: center;
        color: var(--color-gs100);
      }

      .scrollport:after {
        content: '';
        flex-grow: 1;
        flex-shrink: 0;
        flex-basis: 50%;
        display: flex;
        justify-content: center;
        align-items: center;
        color: var(--color-gs100);
      }

      .cell {
        flex-grow: 1;
        flex-shrink: 0;
        flex-basis: 33.33%;
        display: flex;
        justify-content: center;
        align-items: center;
        color: var(--color-gs100);
        font-size: 1.8rem;
      }

      .buttons {
        width: 100%;
        display: flex;
        align-content: center;
        justify-content: space-between;
      }

      kai-pillbutton {
        --pillbutton-width: 14rem;
      }

      .hide {
        display: none;
      }

      .scrollport i {
        margin: 0 -0.2rem 0 -0.2rem;
      }

      .selected {
        color: var(--theme-color);
      }

      .selected i {
        font-size: 2.1rem;
      }

      span {
        font-size: 2rem;
        font-weight: bold;
      }

      .selected span {
        font-size: 2.4rem;
        font-weight: bold;
      }
    `;
  }

  constructor() {
    super();
    window.addEventListener('mozChromeEvent', this._mozChromeEvent);
    this.detail = {};
    this.dd = [...Array(31)].map((_, i) => zeropad(i + 1, 2));
  }

  _isSupportedType(type) {
    const typesToHandle = ['date'];
    return typesToHandle.includes(type);
  }

  _mozChromeEvent = evt => {
    switch (evt.detail.type) {
      case 'inputmethod-contextchange':
        {
          const inputType = evt.detail.inputType;
          const opening = this._isSupportedType(inputType);

          if (opening) {
            this.detail = evt.detail;
            /* event might occur before component has been added to DOM */
            setTimeout(() => {
              this._open();
            }, 0);
          }
        }
        break;
      default:
        break;
    }
  };

  get wrapper() {
    return this.shadowRoot.querySelector('#wrapper');
  }

  get scrollports() {
    return this.shadowRoot.querySelectorAll('.scrollport');
  }

  get years() {
    return this.shadowRoot.querySelector('#years');
  }

  get months() {
    return this.shadowRoot.querySelector('#months');
  }

  get dates() {
    return this.shadowRoot.querySelector('#dates');
  }

  _open() {
    this._updatePickerState();
    this.wrapper.classList.remove('hide');
    const debouncedFunc = debounce(check, 50);
    this.scrollports.forEach(scrollport =>
      scrollport.addEventListener('scroll', debouncedFunc.bind(this))
    );
  }

  _close() {
    this.wrapper.classList.add('hide');
    this.detail = {};
    _im.removeFocus();
  }

  _preventFocus = evt => {
    evt.preventDefault();
    if (evt.target === this.wrapper) {
      this._onCancel();
    }
  };

  _onCancel = () => {
    this._updatePickerState();
    this._close();
  };

  _updatePickerState() {
    const inputType = this.detail.inputType;
    const elmntOffsetHeight = this.shadowRoot
      .querySelector('.cell')
      .getBoundingClientRect().height;

    if (inputType === 'date') {
      const currentValue = this.detail.value;
      if (currentValue !== '') {
        const year = parseInt(currentValue.split('-')[0], 10);
        const month = parseInt(currentValue.split('-')[1], 10);
        const day = parseInt(currentValue.split('-')[2], 10);

        if (year) {
          this.years.scrollTop = (year - SYSTIME) * elmntOffsetHeight;
        }

        if (month) {
          // this.months
          //   .querySelector('#' + months[month - 1])
          //   .classList.add('selected');
          this.months.scrollTop = (month - 1) * elmntOffsetHeight;
        }

        if (day) {
          // this.dates
          //   .querySelector('#n' + currentValue.split('-')[2])
          //   .classList.add('selected');
          this.dates.scrollTop = (day - 1) * elmntOffsetHeight;
        }
      }
    }
  }

  _onEnabled() {
    const selects = this.wrapper.querySelectorAll('.' + selected);
    const dateValue = selects.map(selected => selected.getAttribute('value'));
    const month = zeropad(dateValue[0], 2);
    const date = dateValue[1];
    const year = dateValue[2];
    _im.setValue(year + '-' + month + '-' + date);
    this._close();
  }

  render() {
    const _ = navigator.mozL10n.get;
    const title =
      this.detail && this.detail.name ? this.detail.name : _('select-date');
    return html`
      <div
        id="wrapper"
        class="modal-dialog hide"
        @mousedown=${this._preventFocus}
      >
        <link rel="stylesheet" type="text/css" href="https://shared.local/style/gaia-icons-embedded.css">
        <div class="popup">
          <div class="h3 title">${title}</div>
          <div class="container">
            <div class="scrollport" id="months">
              ${months.map(
                (m, i) => html`
                  <div
                    class="cell ${i === 0 ? 'selected' : ''}"
                    value="${i + 1}"
                    id="${m}"
                  >
                    <span>${m.toUpperCase()}</span>
                  </div>
                `
              )}
            </div>
            <div class="scrollport" id="dates">
              ${this.dd.map(
                (d, i) => html`
                  <div
                    class="cell ${i === 0 ? 'selected' : ''}"
                    value="${d}"
                    id="n${d}"
                  >
                    <i
                      data-icon="numeric_${d.substring(0, 1)}_rounded_bold"
                    ></i>
                    <i
                      data-icon="numeric_${d.substring(1, 2)}_rounded_bold"
                    ></i>
                  </div>
                `
              )}
            </div>
            <div class="scrollport" id="years">
              ${yy.map(
                (y, i) => html`
                  <div
                    class="cell ${i === 0 ? 'selected' : ''}"
                    value="${y}"
                    id="n${y}"
                  >
                    <i
                      data-icon="numeric_${y.substring(0, 1)}_rounded_bold"
                    ></i>
                    <i
                      data-icon="numeric_${y.substring(1, 2)}_rounded_bold"
                    ></i>
                    <i
                      data-icon="numeric_${y.substring(2, 3)}_rounded_bold"
                    ></i>
                    <i
                      data-icon="numeric_${y.substring(3, 4)}_rounded_bold"
                    ></i>
                  </div>
                `
              )}
            </div>
          </div>
          <div class="buttons">
            <kai-pillbutton
              text=${_('cancel')}
              level="secondary"
              @click="${this._onCancel}"
            ></kai-pillbutton>
            <kai-pillbutton
              text=${_('done')}
              @click="${this._onEnabled}"
            ></kai-pillbutton>
          </div>
        </div>
      </div>
    `;
  }
}
customElements.define(DatePickerElement.is, DatePickerElement);
