# Notification

A popup notice provides user a message and optional actions, and user can interactive with it immediately or later.

## Properties

| Property 	| Type 	| Default 	|
|---	|---	|---	|
| `icon` 	| String 	| '' 	|
| `appname` 	| String 	| '' 	|
| `timestamp` 	| String 	| '' 	|
| `noticetitle` 	| String 	| '' 	|
| `bodytext` 	| String 	| '' 	|
| `primarybtntext` 	| String 	| '' 	|
| `secondarybtntext` 	| String 	| '' 	|
| `primarybtnicon` 	| String 	| '' 	|
| `secondarybtnicon` 	| String 	| '' 	|

## Custom Events

Event | Fired
---------|----------
| `notificationSecondaryTextBtnClick` | secondary text button clicked |
| `notificationPrimaryTextBtnClick` | primary text button clicked |
| `notificationSecondaryIconBtnClick` | secondary icon button clicked |
| `notificationPrimaryIconBtnClick` | primary icon button clicked |

## Slots

| Name 	| Position 	|
|---	|---	|
| `thumbnail` 	|  on the left of the middle side 	|

## Examples

### Title Only

```
<kai-notification
    icon="icon-calendar"
    appname="Calendar"
    timestamp="Yesterday,10:26 AM"
    noticetitle="The meeting will start in 15 minutes.">
</kai-notification>
```

### Title + Body

```
<kai-notification
    icon="icon-calendar"
    appname="Calendar"
    timestamp="Yesterday,10:26 AM"
    noticetitle="The meeting will start in 15 minutes."
    bodytext="Team meeting will start in 15 minutes at spectacular room.">
</kai-notification>
```

### Title + Body + 1 Button

```
<kai-notification
    icon="icon-calendar"
    appname="Calendar"
    timestamp="Yesterday,10:26 AM"
    noticetitle="The meeting will start in 15 minutes."
    bodytext="Team meeting will start in 15 minutes at spectacular room."
    primarybtntext="OK">
</kai-notification>
```

### Title + 2 Text Buttons

```
<kai-notification
    icon="icon-calendar"
    appname="Calendar"
    timestamp="Yesterday,10:26 AM"
    noticetitle="The meeting will start in 15 minutes."
    bodytext="Team meeting will start in 15 minutes at spectacular room."
    primarybtntext="OK"
    secondarybtntext="Dismiss">
</kai-notification>
```

### Title + Body + 2 Icon Buttons

```
<kai-notification
    icon="icon-calendar"
    appname="Calendar"
    timestamp="Yesterday,10:26 AM"
    noticetitle="The meeting will start in 15 minutes."
    bodytext="Team meeting will start in 15 minutes at spectacular room."
    secondarybtnicon="fa fa-times"
    primarybtnicon="fa fa-check">
</kai-notification>
```

### Thumbnail + Title + 2 Text Buttons
```
<kai-notification
    icon="icon-call"
    appname="WhatsApp"
    timestamp="Yesterday,10:26 AM"
    noticetitle="Cathy Parker"
    bodytext="Incoming call…"
    primarybtntext="OK"
    secondarybtntext="Dismiss">
    <img
        slot="thumbnail"
        src="https://www.w3schools.com/w3css/img_lights.jpg"
    />
</kai-notification>
```

### Thumbnail + Title + 2 Icon Buttons
```
<kai-notification
    icon="icon-call"
    appname="WhatsApp"
    timestamp="Yesterday,10:26 AM"
    noticetitle="Cathy Parker"
    bodytext="Incoming call…"
    secondarybtnicon="favorite-on"
    primarybtnicon="tick">
    <img
        slot="thumbnail"
        src="https://www.w3schools.com/w3css/img_lights.jpg"
    />
</kai-notification>
```