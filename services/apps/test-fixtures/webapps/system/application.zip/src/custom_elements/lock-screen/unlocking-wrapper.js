import { LitElement, html, css } from 'lit-element';

const pathUnlock = 'style/system/images/icon-unlock.svg';

class UnlockingWrapper extends LitElement {
  name = 'LockscreenUnlockingWrapper'; // for Service

  static get is() {
    return 'unlocking-wrapper';
  }

  static get properties() {
    // These properties aren't reactive:
    // ---------------------------------
    // _timer
    // _unlockIconEl
    // _flashlightManager

    return {
      isFlashlightReady: {
        type: Boolean,
        attribute: false,
      },
      isFlashlightOn: {
        type: Boolean,
        attribute: false,
      },
      unlockSize: {
        type: Number,
        attribute: false,
      },
      unlockDx: {
        type: Number,
        attribute: false,
      },
    };
  }

  static get styles() {
    return css`
      :host {
        position: reletive;
        display: block;
        height: 100%;
      }
      .cycle {
        position: absolute;
        box-sizing: border-box;
        width: 6.2rem;
        height: 6.2rem;
        border-radius: 3.1rem;
        border: 2px solid var(--color-gs80);
        background-color: var(--color-gs00);
        opacity: 0;
        left: 0;
        right: 0;
        top: 0;
        bottom: 0;
        margin: auto;
        display: flex;
        align-items: center;
        justify-content: center;
      }
      #flashlight {
        font-size: 4.7em;
      }
      #camera {
        font-size: 3.8em;
      }
      #unlock {
        opacity: 1;
        width: 9.2rem;
        height: 9.2rem;
        border-radius: 4.6rem;
      }
      #unlock img {
        width: 5rem;
      }
      @keyframes animation-flashlight {
        12.5% {
          opacity: 0;
        }
        25% {
          transform: translate(0);
          opacity: 1;
        }
        100% {
          transform: translate(0, -12rem);
          transition-timing-function: cubic-bezier(.3,0,.3,1);
          opacity: 1;
        }
      }
      @keyframes animation-camera {
        12.5% {
          opacity: 0;
        }
        25% {
          transform: translate(0);
          opacity: 1;
        }
        100% {
          transform: translate(0, 12rem);
          transition-timing-function: cubic-bezier(.3,0,.3,1);
          opacity: 1;
        }
      }
      @keyframes animation-unlock {
        0% {
          transform: scale(0.5);
        }
        100% {
          transition-timing-function: cubic-bezier(.3,0,.3,1);
        }
      }
      .animation-flashlight {
        animation: animation-flashlight 0.8s;
        animation-fill-mode: forwards;
      }
      .animation-camera {
        animation: animation-camera 0.8s;
        animation-fill-mode: forwards;
      }
      .animation-unlock {
        animation: animation-unlock 0.5s;
        animation-fill-mode: forwards;
      }
    `;
  }

  constructor() {
    super();
    this.isFlashlightReady = false;
    this.isFlashlightOn = false;
    this.unlockDx = 0;
    this.unlockSize = 1;
    this._timer = undefined;
    this.updateTimer = this.updateTimer.bind(this);
    this.touchstartHandler = this.touchstartHandler.bind(this);
    this.touchmoveHandler = this.touchmoveHandler.bind(this);
    this.touchendHandler = this.touchendHandler.bind(this);
    this.flashlightchangeHandler = this.flashlightchangeHandler.bind(this)
  }

  connectedCallback() {
    super.connectedCallback();
    window.addEventListener('securewindowmanager-deactivated', this.updateTimer);
    this.addEventListener('pointerdown', this.touchstartHandler);
    this.addEventListener('pointermove', this.touchmoveHandler);
    this.addEventListener('pointerup', this.touchendHandler);
    this.updateTimer();

    this.isFlashlightReady = false;
    if (navigator.getFlashlightManager) {
      navigator.getFlashlightManager().then((flashlightManager) => {
        flashlightManager.addEventListener(
          'flashlightchange', this.flashlightchangeHandler
        );
        this._flashlightManager = flashlightManager;
        this.isFlashlightReady = true;
        this.isFlashlightOn = flashlightManager.flashlightEnabled;
      });
    }
  }

  async performUpdate() {
    await new Promise((resolve) => {
      requestAnimationFrame(() => {
        const unlock = this.getUnlockIconEl();
        if (unlock) {
          unlock.style.transform =
            `translateX(${this.unlockDx}px) scale(${this.unlockSize})`;
        }
        resolve();
      });
    });
    super.performUpdate();
  }

  render() {
    const isFlashlightOn = this.isFlashlightReady && this.isFlashlightOn;
    const flashlightStyle = isFlashlightOn ? `
      background-color: var(--color-purple);
      border-color: var(--color-purple);
    ` : '';

    return html`
      <link rel="stylesheet" type="text/css" href="https://shared.local/style/gaia-icons-embedded.css">
      <div
        id="flashlight"
        class="cycle"
        style="${flashlightStyle}"
      >
        <i data-icon="flashlight-${isFlashlightOn ? 'on' : 'off'}"></i>
      </div>
      <div id="camera" class="cycle">
        <i data-icon="camera"></i>
      </div>
      <div id="unlock" class="cycle">
        <img src=${pathUnlock}></img>
      </div>
    `;
  }

  firstUpdated() {
    ['flashlight', 'camera', 'unlock'].forEach(el => {
      this.shadowRoot.getElementById(el).classList.add(`animation-${el}`);
    });
  }

  getUnlockIconEl() {
    if (!this._unlockIconEl) {
      this._unlockIconEl = this.shadowRoot.querySelector('#unlock');
    }
    return this._unlockIconEl;
  }

  flashlightchangeHandler(e) {
    const flashlightManager = e.target;
    this.isFlashlightOn = flashlightManager.flashlightEnabled;
  }

  touchstartHandler(e) {
    const targetSrc = e.originalTarget.getAttribute('src');
    if (pathUnlock === targetSrc) {
      this.unlockSize = 0.9;
    }
    clearTimeout(this._timer);
    this._startScreenX = e.screenX;
  }

  touchmoveHandler(e) {
    const targetSrc = e.originalTarget.getAttribute('src');
    const lastScreenX = e.screenX;
    const dx = lastScreenX - this._startScreenX;

    this._lastScreenX = lastScreenX;
    if (pathUnlock === targetSrc && dx <= 0) {
      this.unlockDx = dx;
    }
  }

  touchendHandler(e) {
    e.preventDefault();

    const targetSrc = e.originalTarget.getAttribute('src');
    const targetIcon = e.originalTarget.getAttribute('data-icon');
    const clear = () => {
      this._startScreenX = undefined;
      this._lastScreenX = undefined;
    }

    // deal with unlock icon
    if (pathUnlock === targetSrc) {
      if (
        !this._lastScreenX ||
        this._lastScreenX === this._startScreenX
      ) { // tap
        this.unlockSize = 1;
        this.dispatchEvent(
          new CustomEvent('lockscreenUnlock', {
            bubbles: true,
            composed: true,
          })
        );
      } else if (this._lastScreenX > this._startScreenX) {
        this.unlockSize = 1;
      } else {
        this.hideUnlockWrapper();
      }

      clear();
      return false;
    }

    if ([
      'flashlight-off', 'flashlight-on', 'camera'
    ].some((el) => el === targetIcon)) {
      this.updateTimer();
      clear();

      if (targetIcon === 'camera') {
        if (this._timer) {
          clearTimeout(this._timer);
        }
        window.Service.request('invokeSecureApp', 'camera');
      } else if (this._flashlightManager) {
        this._flashlightManager.flashlightEnabled =
          !this._flashlightManager.flashlightEnabled;
      }

      return false;
    }

    if ( // anywhere but icons
      !this._lastScreenX || // tap
      this._lastScreenX <= this._startScreenX // swipe left
    ) {
      this.hideUnlockWrapper();
    } else {
      this.updateTimer();
    }

    clear();
  }

  hideUnlockWrapper() {
    this.dispatchEvent(
      new CustomEvent('lockscreenHideUnlockWrapper', {
        bubbles: true,
        composed: true,
      })
    );
  }

  updateTimer() {
    if (this._timer) {
      clearTimeout(this._timer);
    }
    this._timer = setTimeout(() => {
      this.hideUnlockWrapper();
    }, 5000);
  }

  disconnectedCallback() {
    clearTimeout(this._timer);
    this.removeEventListener('touchstart', this.touchstartHandler);
    this.removeEventListener('touchmove', this.touchmoveHandler);
    this.removeEventListener('touchend', this.touchendHandler);
    if (this._flashlightManager) {
      this._flashlightManager.removeEventListener(
        'flashlightchange', this.flashlightchangeHandler
      );
    }
    super.disconnectedCallback();
  }
}

customElements.define(UnlockingWrapper.is, UnlockingWrapper);
