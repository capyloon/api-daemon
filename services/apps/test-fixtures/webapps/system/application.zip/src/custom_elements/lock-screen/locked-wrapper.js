import { LitElement, html, css } from 'lit-element';

import '../kai-clock';

class LockedWrapper extends LitElement {
  name = 'LockscreenLockedWrapper'; // for Service

  static get is() {
    return 'locked-wrapper';
  }

  static get properties() {
    // These properties aren't reactive:
    // ---------------------------------
    // _lockIconEl
    // _lockIconGesture

    return {
      isInstantPanelShown: {
        converter: value => {
          if (['false', 'null', 'undefined'].includes(value)) {
            return false;
          }
          return true;
        }
      },
      clockStyle: {
        type: String,
        attribute: 'clock-style'
      },
      lockDx: {
        type: Number,
        attribute: false
      }
    };
  }

  static get styles() {
    const sideWidth = css`3.5rem`;

    return css`
      :host {
        height: 100%;
        display: flex;
      }

      .left {
        position: relative;
        width: ${sideWidth};
      }
      i.icon-lock {
        position: absolute;
        left: 0;
        right: 0;
        top: 0;
        bottom: 0;
        margin: auto;
        font-size: 3rem;
        width: 3.5rem;
        height: 4rem;
        display: flex;
        justify-content: center;
        align-items: center;
        z-index: 4; /* Make it higher than notifications */
      }

      .right {
        position: relative;
        flex: 1;
      }
      .content {
        position: absolute;
        width: 100%;
        height: 100%;
        overflow-y: auto;
        padding-right: 5px; /* Hide the scroll bar */
        box-sizing: content-box; /* The width will be 100% + padding */
      }

      notification-list {
        --notification-width: 30rem;
      }

      .notification {
        display: block;
      }
    `;
  }

  constructor() {
    super();
    this.lockDx = 0;
    this.iconPanHandler = this.iconPanHandler.bind(this);
    this.iconSwipeHandler = this.iconSwipeHandler.bind(this);
    this.touchendHandler = this.touchendHandler.bind(this);
  }

  connectedCallback() {
    super.connectedCallback();
    this.addEventListener('pointerup', this.touchendHandler);
  }

  async performUpdate() {
    await new Promise(resolve => {
      requestAnimationFrame(() => {
        if (this.getLockIconEl()) {
          this.getLockIconEl().style.transform = `translate(${this.lockDx}px)`;
        }
        resolve();
      });
    });
    super.performUpdate();
  }

  firstUpdated() {
    const lockIcon = this.getLockIconEl();
    this._lockIconGesture = new GestureDetector(lockIcon);
    this._lockIconGesture.startDetecting();
    lockIcon.addEventListener('pan', this.iconPanHandler);
    lockIcon.addEventListener('swipe', this.iconSwipeHandler);
  }

  disconnectedCallback() {
    super.disconnectedCallback();

    const lockIcon = this.getLockIconEl();
    this._lockIconGesture.stopDetecting();
    lockIcon.removeEventListener('pan', this.iconPanHandler);
    lockIcon.removeEventListener('swipe', this.iconSwipeHandler);
    this.removeEventListener('pointerup', this.touchendHandler);
  }

  touchendHandler(e) {
    // e.preventDefault();
    if (this.isInstantPanelShown) {
      // Using setTimeout to prevent `isInstantPanelShown` being updated
      // before `screenSwipeHandler()` is called. (in lock-screen/index.js)
      setTimeout(() => {
        window.Service.request('InfogationBar:toggleInstantPanel');
      }, 0);
    }
  }

  render() {
    return html`
      <link rel="stylesheet" type="text/css" href="https://shared.local/style/gaia-icons-embedded.css">
      <div class="left">
        ${this.isInstantPanelShown
          ? null
          : html`
              <i class="icon-lock" data-icon="lock"></i>
            `}
      </div>
      <div class="right">
        <div class="content">
          <kai-clock clock-style="${this.clockStyle}"></kai-clock>
          <div class="notification">
            <notification-list id="notification-list"></notification-list>
          </div>
        </div>
      </div>
    `;
  }

  getLockIconEl() {
    if (!this._lockIconEl) {
      this._lockIconEl = this.shadowRoot.querySelector('i.icon-lock');
    }
    return this._lockIconEl;
  }

  iconPanHandler(e) {
    e.stopPropagation();
    const { dx } = e.detail.absolute;
    this.lockDx = dx;
  }

  iconSwipeHandler(e) {
    e.stopPropagation();
    const { end } = e.detail;
    if (end.screenX >= screen.width / 4) {
      this.dispatchEvent(
        new CustomEvent('lockscreenShowUnlockWrapper', {
          bubbles: true,
          composed: true
        })
      );
      this.lockDx = (screen.width - 40) / 2; // translate to center
    } else {
      this.lockDx = 0;
    }
  }
}

customElements.define(LockedWrapper.is, LockedWrapper);
