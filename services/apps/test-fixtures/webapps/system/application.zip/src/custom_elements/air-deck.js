import { LitElement, html, css } from 'lit-element';
import { classMap } from 'lit-html/directives/class-map.js';
import { styleMap } from 'lit-html/directives/style-map.js';
import { connect } from '../redux';
import * as utils from '../util/utils';
import logger from '../util/logger.js';
import '../recent_app_store';

const log = logger('air-deck');

class AirDeck extends LitElement {
  static get properties() {
    return {
      recentApps: Array,
      isShown: Boolean,
      at: String,
    };
  }

  static get styles() {
    return css`
      .mask {
        z-index: var(--z-index-air-deck);
        width: 100%;
        height: calc(100% - var(--infogation-bar-height));
        display: block;
        position: absolute;
        top: 0;
        transition: background-color 0.5s ease-in-out;
        pointer-events: none;
        background-color: rgba(var(--air-deck-mask-rgb), 0);
      }

      .mask--shown {
        pointer-events: auto;
        background-color: rgba(var(--air-deck-mask-rgb), 0.9);
      }

      .side {
        color: var(--color-gs100);
        width: 100%;
        height: 100%;
        position: absolute;
        top: 0;
        transition: transform 0.5s ease-in-out;
        text-align: center;
        overflow-y: hidden;
        display: flex;
        flex-direction: column;
        justify-content: space-between;
      }

      .side--left {
        right: 100%;
        transform: translate(0);
      }

      .side--left.side--shown {
        transform: translate(100%);
      }

      .side--right {
        left: 100%;
        transform: translate(0);
      }

      .side--right.side--shown {
        transform: translate(-100%);
      }

      .side__switch {
        font-size: 3.2rem;
      }

      .recent-apps {
        width: 100%;
        display: flex;
        overflow-x: scroll;
        padding: 2rem 0;
        margin-bottom: -0.5rem; // to hide scrollbar
      }

      .recent-apps::before, .recent-apps::after {
        content: '';
        padding: 0.5rem;
      }

      .app {
        margin: 0.5rem;
      }

      .app-name {
        margin: 0.6rem 0;
        font-size: 1.1rem;
      }

      .app-icon {
        border: 2px solid var(--color-gs40);
        border-radius: 1rem;
        background-repeat: no-repeat;
        background-position: 50% 50%;
        background-size: 56px;
      }

      .no-apps {
        display: flex;
        flex-direction: column;
        justify-content: center;
        flex: 1;
      }

      .no-apps-title {
        font-weight: 700;
        font-size: 2rem;
      }

      .no-apps-desc {
        font-size: 1.4rem;
      }

      @media screen and (orientation: portrait) {
        .app-icon {
          width: 8.5rem;
          height: 11.5rem;
        }
      }

      @media screen and (orientation: landscape) {
        .app-icon {
          width: 11.5rem;
          height: 8.5rem;
        }
      }
    `;
  }

  constructor() {
    super();
    this.recentApps = [];
    this._appIcons = {}; // nonreactive
    this._isFirstShown = true; // nonreactive
  }

  connectedCallback() {
    super.connectedCallback();
    window.addEventListener('edgeswiping', this.adjustScrollbar);
    window.Service.request('RecentAppStore:watch', this.updateRecentApps);
  }

  updated(changedProperties) {
    if (this.isShown) {
      if (this._isFirstShown || changedProperties.has('recentApps')) {
        this._isFirstShown = false;
        this.adjustScrollbar({ detail: { side: this.at } });
      }
    }
  }

  disconnectedCallback() {
    window.removeEventListener('edgeswiping', this.adjustScrollbar);
    window.Service.request('RecentAppStore:unwatch', this.updateRecentApps);
    super.disconnectedCallback();
  }

  adjustScrollbar = (evt) => {
    const { detail } = evt;
    const recentApps = this.shadowRoot.querySelector('.recent-apps');
    if (recentApps) {
      recentApps.scrollLeft
        = detail.side === 'left'
          ? recentApps.scrollWidth - recentApps.clientWidth
          : 0;
    }
  }

  changeDirection(evt) {
    const { detail } = evt;
    localStorage.setItem('air_deck_nav_direction', detail.selected)
  }

  getMozApp(appName) {
    return new Promise((resolve, reject) => {
      window.navigator.mozApps.mgmt.getAll()
        .then(apps => {
          const match = apps.filter(app => app.manifest.name === appName);
          if (match.length) {
            resolve(match[0]);
          } else {
            reject();
          }
        })
        .catch(err => {
          reject(err);
        });
    });
  }

  updateAppIcon(app, size) {
    const icons = this._appIcons[app.origin];
    if (icons[size]) {
      return Promise.resolve();
    }
    return new Promise(resolve => {
      this.getMozApp(app.name)
        .then(mozApp => {
          navigator.mozApps.mgmt.getIcon(mozApp, size)
            .then(res => {
              icons[size] = res ? URL.createObjectURL(res) : '';
              resolve();
            })
            .catch(err => {
              console.error(
                '[AirDeck::updateAppIcon::getIcon]',
                `size: ${size}, manifestURL: ${app.manifestURL}`,
                err
              );
              icons[size] = '';
              resolve(); // Intentionally use resolve() instead of reject().
            });
        })
        .catch(err => {
          console.error('[AirDeck::updateAppIcon::getMozApp]', err);
          icons[size] = '';
          resolve(); // Intentionally use resolve() instead of reject().
        });
    });
  }

  updateRecentApps = apps => {
    if (apps) {
      const promises = [];
      let len = apps.length;
      let app;
      while (len--) {
        app = apps[len];
        if (!this._appIcons[app.origin]) {
          this._appIcons[app.origin] = {};
        }
        promises.push(this.updateAppIcon(app, 112));
        promises.push(this.updateAppIcon(app, 56));
      }

      Promise.all(promises)
        .then(() => {
          this.recentApps = apps.map(a => {
            const icons = this._appIcons[a.origin];
            a.icon = icons['56'] || icons['112'];
            return a;
          });
        })
        .catch(err => {
          console.error(err);
          this.recentApps = apps.map(a => {
            a.icon = this._appIcons[a.origin];
            return a;
          });
        });
    } else {
      this.recentApps = [];
    }
  }

  launchApp(app, evt) {
    this.hide.call(this, evt);
    this.getMozApp(app.name).then(mozApp => {
      mozApp.launch();
    });
  }

  generateAppTemplate(el) {
    const appIconStyles = {
      backgroundImage: `url(${el.icon})`,
    };

    if (el.origin === Service.currentApp.origin) {
      const { manifest } = Service.currentApp;
      if (manifest && manifest.theme_color) {
        appIconStyles.borderColor = manifest.theme_color;
      }
    }

    return html`
      <div class="app">
        <div class="app-name">${el.name}</div>
        <div
          class="app-icon"
          style="${styleMap(appIconStyles)}"
          @click="${this.launchApp.bind(this, el)}"
        >
        </div>
      </div>
    `;
  }

  generateRecentAppsTemplate() {
    const apps = this.recentApps;
    const len = apps.length;
    const recentAppsTemplate = [];
    if (this.at === 'right') {
      for (let i = 0; i < len; i++) {
        recentAppsTemplate[i] = this.generateAppTemplate(apps[i]);
      }
    } else {
      /**
       * Somehow the style
       * `justify-content: flex-end` and
       * `flex-direction: row-reverse`
       * make the container of recent apps nonscrollable
       * when the Air Deck is swiped from left,
       * so we right-align and reverse apps manually.
       */
      recentAppsTemplate[0] = html`<div style="flex: 1"></div>`;
      for (let i = len - 1; i >= 0; i--) {
        recentAppsTemplate[len - i] = this.generateAppTemplate(apps[i]);
      }
    }
    return recentAppsTemplate;
  }

  render() {
    const maskClasses = {
      mask: true,
      'mask--shown': this.isShown,
    };
    const sideClasses = {
      side: true,
      [`side--${this.at}`]: true,
      'side--shown': this.isShown,
    };
    const recentAppClasses = {
      'recent-apps': true,
    };

    const direction = localStorage.getItem('air_deck_nav_direction') || 'ltr';
    const menuoptions = [];
    if (direction !== 'ltr') {
      menuoptions.push({
        label: utils.toL10n('airDeckDirectionLtr'),
        value: 'ltr', // left to right
      });
    }
    if (direction !== 'rtl') {
      menuoptions.push({
        label: utils.toL10n('airDeckDirectionRtl'),
        value: 'rtl', // right to left
      });
    }
    if (direction !== 'both') {
      menuoptions.push({
        label: utils.toL10n('airDeckDirectionBoth'),
        value: 'both',
      });
    }

    return html`
    <link rel="stylesheet" type="text/css" href="https://shared.local/style/gaia-icons-embedded.css">
    <div class="${classMap(maskClasses)}" @touchstart=${this.hide}>
      <div class="${classMap(sideClasses)}" @touchstart=${this.hide}>
        <kai-header
          menudataicon="settings"
          menuoptions="${JSON.stringify(menuoptions)}"
          @optionmenuSelect="${this.changeDirection}"
          @touchstart=${(evt) => {
            evt.stopPropagation();
          }}
        >
        </kai-header>
        ${this.recentApps.length
        ? html`
            <div
              class="${classMap(recentAppClasses)}"
              @touchstart=${(evt) => {
                evt.stopPropagation();
              }}
            >
              ${this.generateRecentAppsTemplate()}
            </div>
          `
        : html`
            <div class="no-apps">
              <div class="no-apps-title">
                ${utils.toL10n('airDeckEmptyTitle')}
              </div>
              <div class="no-apps-desc">
                ${utils.toL10n('airDeckEmptyDesc')}
              </div>
            </div>
          `
        }
      </div>
    </div>
    `;
  }
}

const mapStateToProps = (state) => {
  const { isShown, at } = state.airDeckDisplay;
  return {
    isShown,
    at,
  };
};

const mapDispatchToProps = {
  hide: (evt) => {
    evt.preventDefault();
    evt.stopPropagation();
    return { type: 'UPDATE_AIR_DECK', isShown: false };
  },
  switch: (evt) => {
    evt.preventDefault();
    evt.stopPropagation();
    return { type: 'SWITCH_AIR_DECK' };
  },
};

customElements.define('air-deck', connect(mapStateToProps, mapDispatchToProps)(AirDeck));
log('custom element defined');
