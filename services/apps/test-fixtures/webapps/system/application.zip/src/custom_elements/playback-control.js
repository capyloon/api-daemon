/* global IACHandler, appWindowManager */
import { LitElement, html, css } from 'lit-element';
import { connect } from '../redux';
import mozL10n from '../app_umd/l10n.js';
import logger from '../util/logger.js';

const log = logger('playback-control');
const appOrigin = Object.freeze({
  MUSIC: 'app://music.gaiamobile.org',
  FM: 'app://fm.gaiamobile.org',
});
const FM_FREQENCY_RANGE = Object.freeze({
  START: 87.5,
  END: 108
});
const cmds = Object.freeze({
  MUSIC: {
    PLAY: 'play',
    PAUSE: 'pause',
    NEXT: 'nexttrack',
    PREV: 'prevtrack',
  },
  FM: {
    PLAY: 'playpause',
    PAUSE: 'playpause',
    NEXT: 'nexttrack',
    PREV: 'prevtrack',
  },
});

class PlaybackControl extends LitElement {
  name = 'PlaybackControl';

  static get properties() {
    return {
      isShown: Boolean,
      isPlaying: Boolean,
      hasIcon: Boolean,
      progressPercent: Number,
      isInstantPanelShown: Boolean,
      songName: String,
      albumName: String,
      playerIconSrc: String,
    };
  }

  static get styles() {
    const root = css`
      .root {
        border: solid 0.2rem var(--color-gs80);
        border-radius: 3rem;
        padding: 1.5rem;
        display: none;
      }

      .root.playback {
        display: flex;
        justify-content: space-between;
        align-items: center;
      }

      .icon {
        display: flex;
        align-items: center;
        justify-content: center;
        width: 6rem;
      }

      .player {
        width: calc(100% - 7rem);
      }

      .control {
        display: flex;
        align-items: center;
        justify-content: space-around;
      }

      .info {
        font-size: 1.8rem;
        display: flex;
        flex-direction: column;
        align-items: left;
        justify-content: center;
        width: 40%;
      }

      .album, .song {
        overflow: hidden;
        white-space: nowrap;
        text-overflow: ellipsis;
        width: 100%;
      }

      .album {
        font-size: 1.4rem;
      }

      .navs {
        display: flex;
        font-size: 3.6rem;
        align-items: center;
        justify-content: space-around;
        width: 60%;
      }

      .navs > .change_track {
        font-size: 2.8rem;
      }

      .appIcon {
        width: 6rem;
        height: 6rem;
        border-radius: 1.6rem;
        opacity: 0;
      }

      .appIcon.hasIcon {
        opacity: 1;
      }
      .info.FM {
        text-align: center;
        font-size: 2.2rem;
      }
      .info.FM > .album {
        display: none;
      }
    `;
    return [ root ];
  }

  constructor() {
    super();
    this.playbackStatus = null;
    this.playbackApp = null;
    this.nowPlaying = null;
    this.hasIcon = false;
    this.playerIconSrc = '';
    this.songName = '';
    this.albumName = '';
    this.progressPercent = 100;
    window.addEventListener('iac-mediacomms', this._handle_mediacomms.bind(this));
    window.addEventListener('appterminated', this._handle_appterminated.bind(this));
  }

  firstUpdated() {
  }

  _handle_mediacomms (evt) {
    const detail = evt.detail;
    switch (detail.type) {
      case 'appinfo':
        this.playbackApp = detail.data;
        if (this.playbackApp && this.playbackApp.icon) {
          this.playerIconSrc = this.playbackApp.icon;
          this.hasIcon = true;
        } else {
          this.hasIcon = false;
        }
        break;
      case 'status':
        this.handlePlaybackStatus(detail.data);
        break;
      case 'nowplaying':
        this.updatePlaybackInfo(detail.data);
        break;
      case 'timeupdate':
        this.updatePlaybackProgress({
          duration: detail.data.endTime,
          position: detail.data.currentTime,
        });
        break;
      case 'mozinterruptbegin':
        this.isShown = false;
        break;
    }
  }

  _handle_appterminated(evt) {
    if (this.playbackApp &&
      evt.detail.origin === this.playbackApp.origin
    ) {
      this.isShown = false;
    }
  }

  handlePlaybackStatus(playbackData) {
    if (!playbackData) {
      return;
    }
    const pStatus = this.parseStatusByApp(playbackData);
    switch (pStatus) {
      case 'PLAYING':
        this.playbackStatus = pStatus;
        this.isPlaying = true;
        this.isShown = true;
        break;
      case 'PAUSED':
      case 'STOPPED':
        this.isPlaying = false;
        break;
      default:
        break;
    }
  }

  parseStatusByApp(data) {
    switch (this.playbackApp.origin) {
      case appOrigin.MUSIC:
        return data.playStatus;
      case appOrigin.FM:
        return data;
    }
  }

  updatePlaybackInfo(data) {
    switch (this.playbackApp.origin){
      case appOrigin.MUSIC:
        this.songName = data.title;
        this.albumName = data.album;
        if (data.picture){
          this.updatePlaybackIcon(data.picture);
        }
        break;
      case appOrigin.FM:
        this.songName = data.title;
        // FM's progress bar represents the stations length......
        this.updatePlaybackProgress({
          position: data.title - FM_FREQENCY_RANGE.START,
          duration: FM_FREQENCY_RANGE.END - FM_FREQENCY_RANGE.START,
        });
        break;
    }
  }

  updatePlaybackIcon (imgObj) {
    // in case the imgObj is a Blob obj......
    const reader = new FileReader();
    reader.addEventListener('loadend', () => {
      this.playerIconSrc = reader.result;
    });
    reader.readAsDataURL(imgObj);
  }

  onClickHandling(evt) {
    const action = evt.target.dataset.action;
    switch (action) {
      case 'play':
        this.sendCmd(this.isPlaying ? 'PAUSE' : 'PLAY');
        break;
      case 'next':
        this.sendCmd('NEXT');
        break;
      case 'prev':
        this.sendCmd('PREV');
        break;
    }
  }

  updatePlaybackProgress(data) {
    const cPosition = parseFloat(data.position);
    const cDuration = parseFloat(data.duration);

    if (!cPosition) {
      this.progressPercent = 0;
    }
    this.progressPercent = cPosition / cDuration * 100;
  }

  sendCmd(command) {
    const port = IACHandler.getPort('mediacomms');
    if (port) {
      port.postMessage({command: cmds[this.appName][command]});
    }
  }

  openMediaApp() {
    if (this.playbackApp && this.playbackApp.origin) {
      var evt = new CustomEvent('displayapp', {
        bubbles: true,
        cancelable: true,
        detail: appWindowManager.getApp(this.playbackApp.origin)
      });
      window.dispatchEvent(evt);
      // close instant panel to display app
      if (this.isInstantPanelShown) {
        this.toggleInstantPanel();
      }
    }
  }

  // The event handler is used for prevent from stealing focus
  // from other places.
  _preventFocus(evt) {
    evt.preventDefault();
  }

  get appName () {
    if (!this.playbackApp || !this.playbackApp.origin) {
      return '';
    }
    return Object.keys(appOrigin).find(appName => {
      return appOrigin[appName] === this.playbackApp.origin;
    });
  }

  render() {
    return html`
      <div
        class='root theme-kaibrand ${this.isShown ? 'playback' : ''}'
        @mousedown=${this._preventFocus}
      >
        <div @click='${this.openMediaApp}' class='icon'>
          <img
            class='appIcon ${this.hasIcon ? 'hasIcon' : ''}'
            src='${this.playerIconSrc}'
          />
        </div>
        <div class='player'>
          <div class='control'>
            <div class='info ${this.appName === 'FM' ? 'FM' : ''}'>
              <div class='song'>${this.songName}</div>
              <div class='album'>${this.albumName}</div>
            </div>
            <div class='navs'>
              <div
                @click='${this.onClickHandling}'
                data-action='prev'
                class='btn change_track'
                data-icon='media-previous'
              ></div>
              <div
                @click='${this.onClickHandling}'
                data-action='play'
                class='btn'
                data-icon='${this.isPlaying ? 'media-pause' : 'media-play'}'
              ></div>
              <div
                @click='${this.onClickHandling}'
                data-action='next'
                class='btn change_track'
                data-icon='media-next'
              ></div>
            </div>
          </div>
          <kai-progress id='progress' type='determined' percent='${this.progressPercent}'></kai-progress>
        </div>
      </div>`;
  }
}

const mapStateToProps = (state) => {
  return {
    isInstantPanelShown: state.isInstantPanelShown,
  };
};

const mapDispatchToProps = {
  toggleInstantPanel: () => ({ type: 'TOGGLE_INSTANT_PANEL' }),
};

mozL10n.once(() => {
  customElements.define(
    'playback-control',
    connect(mapStateToProps, mapDispatchToProps)(PlaybackControl)
  );
  log('custom element defined');
});
