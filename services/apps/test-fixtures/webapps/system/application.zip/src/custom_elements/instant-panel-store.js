import BaseModule from 'base-module';
import IP_airplanemode from '../webapi/ip_settings/ip_airplanemode';
import IP_bluetooth from '../webapi/ip_settings/ip_bluetooth';
import IP_brightness from '../webapi/ip_settings/ip_brightness';
import IP_flashlight from '../webapi/ip_settings/ip_flashlight';
import IP_mobiledata from '../webapi/ip_settings/ip_mobiledata';
import IP_volume from '../webapi/ip_settings/ip_volume';
import IP_wifi from '../webapi/ip_settings/ip_wifi';
import IP_orientationlock from '../webapi/ip_settings/ip_orientationlock';
import * as utils from '../util/utils';

class InstantPanelStore extends BaseModule {
  name = 'InstantPanelStore';

  modules = [
    IP_airplanemode,
    IP_bluetooth,
    IP_brightness,
    IP_flashlight,
    IP_mobiledata,
    IP_volume,
    IP_wifi,
    IP_orientationlock
  ];

  constructor() {
    super();
    this.settings = this.getSettingsInArray();
    this.modules.forEach((_module) => {
      _module.on('change', this.updateSettings.bind(this));
    }, this);
  }

  toggleAllObservers(active = true) {
    this.modules.forEach((_module) => {
      _module.off('change', this.updateSettings.bind(this));
      if (_module.toggleObserver) {
        _module.toggleObserver(active);
      }
    });
  }

  updateSettings() {
    this.emit('change', this.getSettingsInArray());
  }

  getSettingsInArray() {
    let _modules = this.modules.filter((module) => module.capability);
    return _modules.map((module) => module.config).sort(this.sortSettings);
  }

  sortSettings(a, b) {
    let dir = utils.isLandscape ? 'landscape' : 'portrait';
    return a.order[dir] - b.order[dir];
  }
}

const instantSettingsStore = new InstantPanelStore();
export default instantSettingsStore;
