import { LitElement, html, css } from 'lit-element';
import { classMap } from 'lit-html/directives/class-map.js';

import * as utils from '../../util/utils';
import { connect } from '../../redux';
import { mode as screenlockMode } from '../../constants/screenlock';
import { EVENT_TYPES as pinlockEventTypes, isDigitId } from '../pin-lock';
import './sim-card-info';
import './locked-wrapper';
import './unlocking-wrapper';

const eventPrefix = 'lockscreen-';
const attemptLimit = 5;
const waitingTimeMap = {
  '5': 30,
  '6': 60,
  '7': 180,
  '8': 300,
  '9': 600,
  // >= 10: 900
};

class LockScreen extends LitElement {
  name = 'LockscreenView'; // for hierarchy_manager
  EVENT_PREFIX = eventPrefix; // for hierarchy_manager

  static get is() {
    return 'lock-screen';
  }

  static get properties() {
    // These properties aren't reactive:
    // ---------------------------------
    // name
    // EVENT_PREFIX
    // _firstTime
    // _lockEnabled
    // _lockScreenGesture
    // _passcode
    // _isEmergencyCallActive
    // _hintsTimer

    return {
      hidden: {
        type: Boolean,
        reflect: true,
        hasChanged(newVal, oldVal) {
          if (newVal !== oldVal) {
            window.dispatchEvent(new CustomEvent(
              `${eventPrefix}${newVal ? 'appclosing' : 'appopening'}`
            ));
            return true;
          }
          return false;
        }
      },
      mode: {
        type: String,
        attribute: false,
        hasChanged(newVal, oldVal) {
          if (newVal !== oldVal) {
            window.dispatchEvent(new CustomEvent(
              'lockmode-change', // for InfogationBar, ScreenManager
              {
                detail: { mode: newVal }
              }
            ));
            return true;
          }
          return false;
        }
      },
      passcodeEnabled: {
        type: Boolean,
        attribute: false,
      },
      pincodeInput: {
        type: Object,
        attribute: false,
      },
      pincodeHint: {
        type: Object,
        attribute: false,
      },
      pincodeSubmittable: {
        type: Boolean,
        attribute: false,
      },
      attemptCount: {
        type: Number,
        attribute: false,
      },
      waitingTime: { // in seconds
        type: Number,
        attribute: false,
      },
      isInstantPanelShown: {
        type: Boolean,
        attribute: false,
      },
      clockStyle: {
        type: String,
        attribute: false
      },
      wallpaper: {
        type: String,
        attribute: false
      },
      lockWallpaper: {
        type: String,
        attribute: false
      },
    };
  }

  static get styles() {
    return css`
      :host {
        z-index: var(--z-index-lockscreen);
        background-color: var(--color-gs10);
        color: var(--color-gs100);
        position: absolute;
        left: 0;
        right: 0;
        top: 0;
        bottom: 0;
      }
      :host[hidden] {
        display: none;
      }
      .root {
        height: 100%;
        display: flex;
        flex-direction: column;
        background-size: cover;
        background-repeat: no-repeat;
        background-position: 50% 50%;
      }
      .unlocking-background {
        background-color: rgba(0, 0, 0, 0.6);
      }
      sim-card-info {
        height: 4rem;
      }
      .main {
        flex: 1;
        margin-bottom: var(--infogation-bar-height);
      }
      pin-lock {
        height: calc(100% - var(--infogation-bar-height));
        position: fixed;
        top: 0;
        left: 0;
      }
    `;
  }

  constructor() {
    super();
    // non-reactive
    this._firstTime = true;
    this._isEmergencyCallActive = false; // for the `backspace` event
    this._passcode = '';
    // reactive
    this.clockStyle = 'light';
    this.wallpaper = '';
    this.lockWallpaper = '';
    this.mode = screenlockMode.UNLOCKED;
    this.hidden = true;
    this.pincodeInput = {
      unlock: [],
    };
    this.pincodeHint = {
      unlock: '',
    };
    this.pincodeSubmittable = false;
    this.attemptCount = 0;
    this.waitingTime = 0;

    this.screenchangeHandler = this.screenchangeHandler.bind(this);
    this.backspaceHandler = this.backspaceHandler.bind(this);
    this.lockscreenUnlock = this.unlock.bind(this);
    this.lockscreenShowUnlockWrapper = this.showUnlockWrapper.bind(this, true);
    this.lockscreenHideUnlockWrapper = this.showUnlockWrapper.bind(this, false);

    this.watchLockEnabled();
    this.watchPasscodeEnabled();
    this.watchPasscode();
    this.watchLockImage();
    this.watchWallpaper();
    this.watchClockStyle();

    window.Service.register('invokeSecureApp', this);
    window.Service.registerState('locked', this);
    window.Service.registerState('mode', this);
  }

  connectedCallback() {
    super.connectedCallback();

    window.addEventListener('screenchange', this.screenchangeHandler);
    window.addEventListener('backspace', this.backspaceHandler);
    this._lockScreenGesture = new GestureDetector(this);
    this._lockScreenGesture.startDetecting();
    this.addEventListener('swipe', this.screenSwipeHandler);
  }

  async performUpdate() {
    // Need performUpdate() to restore
    // the size of unlock icon (in unlocking-wrapper.js)
    // before switching to the homescreen
    await new Promise((resolve) => {
      requestAnimationFrame(() => {
        resolve();
      });
    });
    super.performUpdate();
  }

  isActive() {
    return !this.hidden;
  }

  locked() { // for legacy
    return this.isActive();
  }

  setHierarchy(value) {
    if (value) {
      this.focus();
    }
  }

  focus() {
    this.shadowRoot.querySelector('.root').focus();
  }

  watchLockEnabled() {
    const { mozSettings } = navigator;
    const lock = mozSettings.createLock();
    const key = 'lockscreen.enabled';
    const req = lock.get(key);
    const updateLockEnabled = (val) => {
      this._lockEnabled = val;

      // 1) Don't make it take effect immediately except for the first time.
      // 2) `lockscreen.enabled` would be retrieved after screen is on.
      if (this._firstTime) {
        this._firstTime = false;
        this.hidden = !val;
      }
    }

    req.onsuccess = () => {
      updateLockEnabled(req.result[key]);
    }
    req.onerror = () => {
      console.error(`[LOCKSCREEN] Failed to get "${key}"`, req.error);
    }
    mozSettings.addObserver(key, (event) => {
      updateLockEnabled(event.settingValue);
    });
  }

  watchPasscodeEnabled() {
    const { mozSettings } = navigator;
    const lock = mozSettings.createLock();
    const key = 'lockscreen.passcode-lock.enabled';
    const req = lock.get(key);
    const updateLockEnabled = (val) => {
      this.passcodeEnabled = val;
    }

    req.onsuccess = () => {
      updateLockEnabled(req.result[key]);
    }
    req.onerror = () => {
      console.error(`[LOCKSCREEN] Failed to get "${key}"`, req.error);
    }
    mozSettings.addObserver(key, (event) => {
      updateLockEnabled(event.settingValue);
    });
  }

  watchPasscode() {
    const { mozSettings } = navigator;
    const lock = navigator.mozSettings.createLock();
    const key = 'lockscreen.passcode-lock.code';
    const req = lock.get(key);

    const updateValue = (val) => {
      this._passcode = val;
    }

    req.onsuccess = () => {
      updateValue(req.result[key]);
    }
    req.onerror = () => {
      console.error(`[LOCKSCREEN] Failed to get "${key}"`, req.error);
    }
    mozSettings.addObserver(key, (event) => {
      updateValue(event.settingValue);
    });
  }

  watchLockImage() {
    const { mozSettings } = navigator;
    const lock = navigator.mozSettings.createLock();
    const key = 'lockscreen.image';
    const req = lock.get(key);

    req.onsuccess = () => {
      const res = req.result[key]; // Blob or URL
      if (typeof res === "string") {
        this.lockWallpaper = res;
      } else {
        this.lockWallpaper = res ? URL.createObjectURL(res) : '';
      }
    }
    req.onerror = () => {
      console.error(`[LOCKSCREEN] Failed to get "${key}"`, req.error);
    }
    mozSettings.addObserver(key, (event) => {
      const res = event.settingValue;
      this.lockWallpaper = res ? URL.createObjectURL(res) : '';
    });
  }

  watchWallpaper() {
    const { mozSettings } = navigator;
    const lock = navigator.mozSettings.createLock();
    const key = 'wallpaper.image';
    const req = lock.get(key);

    req.onsuccess = () => {
      const res = req.result[key]; // Blob
      if (typeof res === "string") {
        this.wallpaper = res;
      } else {
        this.wallpaper = res ? URL.createObjectURL(res) : '';
      }
    }
    req.onerror = () => {
      console.error(`[LOCKSCREEN] Failed to get "${key}"`, req.error);
    }
    mozSettings.addObserver(key, (event) => {
      const res = event.settingValue;
      this.wallpaper = res ? URL.createObjectURL(res) : '';
    });
  }

  watchClockStyle() {
    const { mozSettings } = navigator;
    const lock = navigator.mozSettings.createLock();
    const key = 'home.clock.style';
    const req = lock.get(key);

    const updateClockStyle = (val) => {
      this.clockStyle = val || 'light';
    }

    req.onsuccess = () => {
      updateClockStyle(req.result[key]);
    }
    req.onerror = () => {
      console.error(`[LOCKSCREEN] Failed to get "${key}"`, req.error);
    }
    mozSettings.addObserver(key, (event) => {
      updateClockStyle(event.settingValue);
    });
  }

  screenchangeHandler(e) {
    const { detail } = e;
    if (this._lockEnabled) {
      this.mode = this.isInstantPanelShown
        ? screenlockMode.LOCKED_WITH_INSTANT_PANEL
        : screenlockMode.LOCKED;
    } else {
      this.mode = screenlockMode.UNLOCKED;
    }
    this.hidden = !this._lockEnabled;

    if (this._lockEnabled && detail && detail.screenEnabled) {
      window.Service.request('focus');
    }
  }

  backspaceHandler() {
    /**
     * 1. emergency call --> pin code
     * 2. pin code       --> lock screen
     */
    if (this._isEmergencyCallActive) {
      this._isEmergencyCallActive = false;

      // Since the secure APP won't be killed immediately,
      // `secure-appterminated` won't be fired then.
      // Hence, we manually fire an event to force update idle time.
      window.dispatchEvent(new CustomEvent(
        'lockmode-change', // for ScreenManager
        { detail: { mode: this.mode } }
      ));
    } else if (this.mode === screenlockMode.PASSCODE) {
      this.mode = screenlockMode.LOCKED;
    }
  }

  screenSwipeHandler(e) {
    e.stopPropagation();

    if (
      this.mode !== screenlockMode.LOCKED ||
      this.isInstantPanelShown
    ) {
      return false;
    }

    const { direction, start, end } = e.detail;
    const duration = end.timeStamp - start.timeStamp;

    // if duration >= 500ms: drag, else: swipe
    if ('right' === direction && duration < 500) {
      this.mode = screenlockMode.UNLOCKING;
    }
  }

  // Won't be performed until `this.waitingTime` hits 0.
  keypadClickHandler(id, activeInputId) {
    const maxInputLength = 4;
    const currentInput = this.pincodeInput[activeInputId];
    const currentInputLength = currentInput.length;

    if (isDigitId(id) && currentInputLength < maxInputLength) {
      this.pincodeInput = {
        [activeInputId]: [...currentInput, id],
      };
      this.pincodeHint = { unlock: '' };
      this.pincodeSubmittable = currentInputLength + 1 === maxInputLength;
    } else if (id === 'ok') {
      clearTimeout(this._hintsTimer);
      this.pincodeSubmittable = false;
      this.pincodeInput = {
        [activeInputId]: [],
      };
      const code = currentInput.join('');
      if (code === this._passcode) {
        this.updateMode(screenlockMode.UNLOCKED);
        this.attemptCount = 0;
        this.pincodeHint = { unlock: '' };
      } else { // No limitation for incorrect pin input times.
        window.navigator.vibrate(50);
        if (++this.attemptCount >= 5) {
          this.waitingTime = waitingTimeMap[this.attemptCount + ''] || 900;
          this.updateWaitingTime();
        } else {
          this.pincodeHint = {
            unlock: utils.toL10n('passcodeErrorMsg', {
              n: attemptLimit - this.attemptCount
            })
          };
          this._hintsTimer = setTimeout(() => {
            this.pincodeHint = { unlock: '' };
          }, 3000);
        }
      }
    }
  }

  pincodeBackspaceHandler(activeInputId) {
    const activeInput = this.pincodeInput[activeInputId];
    activeInput.pop();
    this.pincodeInput = { [activeInputId]: activeInput };
    this.pincodeSubmittable = false;
  }

  pinlockClickHandler(e) {
    e.stopPropagation();
    const { detail } = e;
    const { type, id, activeInputId } = detail;
    switch (type) {
      case pinlockEventTypes.BOTTOM_TEXT:
        this.invokeSecureApp('emergency-call');
        this._isEmergencyCallActive = true;
        break;
      case pinlockEventTypes.KEYPAD:
        this.waitingTime === 0 && this.keypadClickHandler(id, activeInputId);
        break;
      case pinlockEventTypes.DELETE:
        this.waitingTime === 0 && this.pincodeBackspaceHandler(activeInputId);
        break;
      default:
        break;
    }
  }

  unlock() {
    this.updateMode(
      this.passcodeEnabled
        ? screenlockMode.PASSCODE
        : screenlockMode.UNLOCKED
    );
  }

  updateMode(mode) {
    this.mode = mode;
    this.hidden = mode === screenlockMode.UNLOCKED;
  }

  updateWaitingTime() {
    if (this.waitingTime) {
      this.pincodeHint = {
        unlock: utils.toL10n('passcodeWaitToTry', {
          time: utils.timeFormatter(this.waitingTime--)
        })
      };
      setTimeout(this.updateWaitingTime.bind(this), 1000);
    } else {
      this.pincodeHint = { unlock: '' };
    }
  }

  showUnlockWrapper(isShown) {
    this.mode = isShown ? screenlockMode.UNLOCKING : screenlockMode.LOCKED;
  }

  invokeSecureApp(name) {
    const url = window.parent.location.href.replace('system', name);
    const manifestUrl = url.replace(/(\/)*(index.html#?)*$/, '/manifest.webapp');
    window.dispatchEvent(new window.CustomEvent('secure-launchapp',
      {
        'detail': {
          'appURL': url + '#secure',
          'appManifestURL': manifestUrl
        }
      }
    ));
  }

  render() {
    const classes = {
      'unlocking-background': this.mode === screenlockMode.UNLOCKING,
    };
    let main;

    switch (this.mode) {
      case screenlockMode.UNLOCKING:
        main = html`
          <unlocking-wrapper class="unlocking-background">
          </unlocking-wrapper>
        `;
        break;
      case screenlockMode.PASSCODE:
        main = html`
          <pin-lock
            header="${utils.toL10n('passcodeTitle')}"
            activeinputid="unlock"
            .hints=${this.pincodeHint}
            .inputs=${this.pincodeInput}
            .inputAreas=${[{
              label: utils.toL10n('passcode'),
              id: 'unlock',
            }]}
            .bottomtext=${utils.toL10n('emergency-call-button')}
            ?submittable=${this.pincodeSubmittable}
            @pinlock-click=${this.pinlockClickHandler}
          >
          </pin-lock>
        `;
        break;
      default:
        main = html`
          <locked-wrapper
            clock-style="${this.clockStyle}"
            isinstantpanelshown="${this.isInstantPanelShown}"
          >
          </locked-wrapper>
        `;
    }

    return html`
      <div
        role="presentation"
        tabindex="-1"
        class="root"
        style="background-image: url(${this.lockWallpaper || this.wallpaper})"
        @lockscreenUnlock="${this.lockscreenUnlock}"
      >
        <sim-card-info class="${classMap(classes)}"></sim-card-info>
        <div
          class="main"
          @lockscreenShowUnlockWrapper="${this.lockscreenShowUnlockWrapper}"
          @lockscreenHideUnlockWrapper="${this.lockscreenHideUnlockWrapper}"
        >
          ${main}
        </div>
      </div>
    `;
  }

  firstUpdated() {
    window.Service.request('registerHierarchy', this);
  }

  updated(changedProperties) {
    if (changedProperties.has('hidden')) {
      // dispatch lockscreen-appopened or lockscreen-appclosed
      window.dispatchEvent(new CustomEvent(
        `${eventPrefix}${this.hidden ? 'appclosed' : 'appopened'}`
      ));
    }

    if (changedProperties.has('isInstantPanelShown')) {
      this.mode = this.isInstantPanelShown
        ? screenlockMode.LOCKED_WITH_INSTANT_PANEL
        : screenlockMode.LOCKED;
    }

    if (changedProperties.has('mode') && this._lockEnabled) {
      navigator.mozSettings.createLock().set({
        'lockscreen.locked': this.mode !== screenlockMode.UNLOCKED
      });
    }
  }

  disconnectedCallback() {
    super.disconnectedCallback();

    this._lockScreenGesture.stopDetecting();
    this.removeEventListener('swipe', this.screenSwipeHandler);
    window.removeEventListener('screenchange', this.screenchangeHandler);
    window.removeEventListener('backspace', this.backspaceHandler);
  }
}

const mapStateToProps = (state) => {
  const { isInstantPanelShown } = state;
  return {
    isInstantPanelShown,
  };
};

customElements.define(
  LockScreen.is,
  connect(mapStateToProps)(LockScreen)
);
