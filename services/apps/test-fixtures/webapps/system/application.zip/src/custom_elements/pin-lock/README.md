**PIN LOCK**

PIN lock contains a series inputs field and a keypad.

**properties**

| property        | type    | defalut |
| --------------- | ------- | ------- |
| `header`        | String  | ''      |
| `description`   | String  | ''      |
| `inputAreas`    | Array   | []      |
| `inputs`        | Object  | {}      |
| `hints`         | Object  | {}      |
| `activeInputId` | String  | ''      |
| `smallkeypad`   | Boolean | false   |
| `submittable`   | Boolean | false   |
| `bottomtext`    | String  | ''      |

**`inputAreas` item format**

| key     | info                               |
| ------- | ---------------------------------- |
| `id`    | string, input id, should be unique |
| `label` | string, input label                |

**`inputs` format**

| key  | info                      |
| ---- | ------------------------- |
| [id] | array, the value of input |

**`hints` format**

| key  | info                             |
| ---- | -------------------------------- |
| [id] | string, the hint string of input |

**custom events**

| event           | type                                            | fired                        |
| --------------- | ----------------------------------------------- | ---------------------------- |
| `pinlock-click` | `input_area`, `delete`, `keypad`, `bottom_text` | click the pin lock component |

| type          | detail            |
| ------------- | ----------------- |
| `input_area`  | activeInputId     |
| `delete`      | activeInputId     |
| `keypad`      | id, activeInputId |
| `bottom_text` |                   |

**limitation**

the maximum inputs in inputfield is 3.
