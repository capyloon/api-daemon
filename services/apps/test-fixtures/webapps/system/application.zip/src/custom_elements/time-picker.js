import { LitElement, html, css } from 'lit-element';

const _im = navigator.mozInputMethod;
const mm = [...Array(60)].map((_, i) => zeropad(i, 2));
const ampm = ['AM', 'PM'];

function zeropad(num, size) {
  let s = num + '';
  while (s.length < size) {
    s = `0${s}`;
  }
  return s;
}

/**
 * This function will convert in both directions: 12 to 24 hour or 24 to 12 hour
 * @param {*} time
 * @param {*} onoff
 */
function tConv24(time, onoff) {
  if (onoff == undefined) {
    onoff = isNaN(time.replace(':', '')); //auto-detect format
  }
  var pm =
    time
      .toString()
      .toLowerCase()
      .indexOf('pm') > -1; //check if 'pm' exists in the time string
  time = time
    .toString()
    .toLowerCase()
    .replace(/[ap]m/, '')
    .split(':'); //convert time to an array of numbers
  time[0] = Number(time[0]);
  if (onoff) {
    //convert to 24 hour:
    if (pm && time[0] != 12) {
      time[0] += 12;
    } else if (!pm && time[0] == 12) {
      time[0] = '00'; //handle midnight
    }
    if (String(time[0]).length == 1) {
      time[0] = '0' + time[0]; //add leading zeros if needed
    }
  } else {
    //convert to 12 hour:
    pm = time[0] >= 12;
    if (!time[0]) {
      time[0] = 12; //handle midnight
    } else if (pm && time[0] != 12) {
      time[0] -= 12;
    }
  }
  return onoff ? time.join(':') : time.join(':') + (pm ? 'pm' : 'am');
}

function debounce(func, wait) {
  let timeout;
  return function(...args) {
    const context = this;
    clearTimeout(timeout);
    timeout = setTimeout(() => func.apply(context, args), wait);
  };
}

function check(e) {
  const rect = e.target.getBoundingClientRect();
  const selected = 'selected';
  const centerCell = document.elementFromPoint(
    rect.left + e.target.offsetWidth / 2.5,
    rect.top + e.target.offsetHeight / 2.5
  );

  e.target
    .querySelectorAll('.selected')
    .map(cell => cell.classList.remove(selected));
  centerCell.classList.add(selected);
}

function getHour12() {
  return navigator.mozHour12 != null ? navigator.mozHour12 : true;
}

class TimePickerElement extends LitElement {
  static get is() {
    return 'time-picker';
  }

  static get properties() {
    return {
      detail: { type: Object },
      hh: { type: Array },
      is12hFormat: { type: Boolean }
    };
  }

  static get styles() {
    return css`
      .modal-dialog {
        width: 100%;
        height: calc(100% - var(--infogation-bar-height));
        background-color: var(--popup-background-color);
        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: center;
        z-index: var(--z-index-data-operation);
        position: fixed;
        top: 0;
        left: 0;
      }

      .popup {
        width: 30rem;
        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: center;
      }

      .title {
        width: 30rem;
        height: 3.2rem;
        padding: 0 2rem;
        box-sizing: border-box;
        color: var(--color-gs100);
        text-align: center;
        overflow: hidden;
        white-space: nowrap;
        text-overflow: ellipsis;
      }

      .container {
        width: 30rem;
        height: 22rem;
        margin-top: 2.5rem;
        margin-bottom: 2.5rem;
        border-radius: 3rem;
        border: solid 0.2rem var(--color-gs80);
        background: var(--color-gs00);
        display: flex;
        flex-direction: row;
        align-items: center;
        justify-content: center;
      }

      .scrollport {
        display: flex;
        flex-direction: column;
        flex-wrap: nowrap;
        width: 9.4rem;
        height: 22rem;
        overflow: auto;
        scroll-snap-type: mandatory;
        scroll-snap-points-y: repeat(33.33%);
        scroll-snap-destination: 0 33.33%;
      }

      .scrollport:before {
        content: '';
        flex-grow: 1;
        flex-shrink: 0;
        flex-basis: 33.33%;
        display: flex;
        justify-content: center;
        align-items: center;
        color: var(--color-gs100);
      }

      .scrollport:after {
        content: '';
        flex-grow: 1;
        flex-shrink: 0;
        flex-basis: 50%;
        display: flex;
        justify-content: center;
        align-items: center;
        color: var(--color-gs100);
      }

      .cell {
        flex-grow: 1;
        flex-shrink: 0;
        flex-basis: 33.33%;
        display: flex;
        justify-content: center;
        align-items: center;
        color: var(--color-gs100);
        font-size: 1.8rem;
      }

      .buttons {
        width: 100%;
        display: flex;
        align-content: center;
        justify-content: space-between;
      }

      kai-pillbutton {
        --pillbutton-width: 14rem;
      }

      .hide {
        display: none;
      }

      .scrollport i {
        margin: 0 -0.2rem 0 -0.2rem;
      }

      .selected {
        color: var(--theme-color);
      }

      .selected i {
        font-size: 2.1rem;
      }

      .selected span {
        font-size: 2.4rem;
        font-weight: bold;
      }
    `;
  }

  constructor() {
    super();
    window.addEventListener('mozChromeEvent', this._mozChromeEvent);
    this.is12hFormat = getHour12();
    this.detail = {};
  }

  _isSupportedType(type) {
    const typesToHandle = ['time'];
    return typesToHandle.includes(type);
  }

  _mozChromeEvent = evt => {
    switch (evt.detail.type) {
      case 'inputmethod-contextchange':
        {
          const inputType = evt.detail.inputType;
          const opening = this._isSupportedType(inputType);

          if (opening) {
            this.detail = evt.detail;
            /* event might occur before component has been added to DOM */
            setTimeout(() => {
              this._open();
            }, 0);
          }
        }
        break;
      default:
        break;
    }
  };

  get wrapper() {
    return this.shadowRoot.querySelector('#wrapper');
  }

  get hour() {
    return this.shadowRoot.querySelector('#hour');
  }

  get minute() {
    return this.shadowRoot.querySelector('#minute');
  }

  get ampm() {
    return this.shadowRoot.querySelector('#ampm');
  }

  get scrollport() {
    return this.shadowRoot.querySelectorAll('.scrollport');
  }

  firstUpdated() {
    const scrollports = this.scrollport;
    const debouncedFunc = debounce(check, 50);
    scrollports.forEach(scrollport =>
      scrollport.addEventListener('scroll', debouncedFunc)
    );
  }

  _open() {
    this.is12hFormat = getHour12();
    this._updatePickerState();
    this.wrapper.classList.remove('hide');
  }

  _close() {
    this.wrapper.classList.add('hide');
    this.detail = {};
    _im.removeFocus();
  }

  _preventFocus = evt => {
    evt.preventDefault();
  };

  _updatePickerState() {
    const inputType = this.detail.inputType;

    if (inputType === 'time') {
      // const minTime = this.detail.min;
      // const maxTime = this.detail.max;
      const currentValue = this.detail.value;
      if (currentValue !== '') {
        /*
        const hour = currentValue.split(':')[0];
        const mins = currentValue.split(':')[1];
        const ts =
          tConv24(currentValue)[tConv24(currentValue).length - 2] +
          tConv24(currentValue)[tConv24(currentValue).length - 1];


        if (hour) {
          if (this.is12hFormat) {
            const initialHour = this.hour.querySelector(
              '#n' + zeropad(hour - 12, 2)
            );
            initialHour.classList.add('selected');
            this.hour.scrollTop = parseInt(hour, 10) * 100;
          } else {
            const initialHour = this.hour.querySelector(
              '#n' + zeropad(hour, 2)
            );
            initialHour.classList.add('selected');
            this.hour.scrollTop = parseInt(hour, 10) * 100;
          }
        }
        if (mins) {
          const initialMinute = this.minute.querySelector('#n' + mins);
          initialMinute.classList.add('selected');
          this.minute.scrollTop = mins * 100;
          // this.minute.scrollTop = initialMinute.offsetTop - initialMinute.scrollHeight;
        }
        if (ts) {
          const initialAMPM = this.ampm.querySelector('#' + ts.toUpperCase());
          initialAMPM.classList.add('selected');
          this.ampm.scrollTop = ts.toUpperCase() == 'PM' ? 100 : 0;
        }
        */
      }
    }
  }

  _onCancel = () => {
    this._updatePickerState();
    this._close();
  };

  _onEnabled() {
    const selects = this.wrapper.querySelectorAll('.selected');
    const timeValue = selects.map(s => s.getAttribute('value'));
    if (this.is12hFormat) {
      _im.setValue(tConv24(timeValue[0] + ':' + timeValue[1] + timeValue[2]));
    } else {
      let h = timeValue[0] === '24' ? '00' : timeValue[0];
      _im.setValue(h + ':' + timeValue[1]);
    }
    this._close();
  }

  render() {
    const _ = navigator.mozL10n.get;

    const hh = this.is12hFormat
      ? [...Array(12)].map((_, i) => zeropad(i + 1, 2))
      : [...Array(24)].map((_, i) => zeropad(i + 1, 2));

    const title =
      this.detail && this.detail.name ? this.detail.name : _('select-time');
    return html`
      <div
        id="wrapper"
        class="modal-dialog hide"
        @mousedown=${this._preventFocus}
      >
        <link rel="stylesheet" type="text/css" href="https://shared.local/style/gaia-icons-embedded.css">
        <div class="popup">
          <div class="h3 title">${title}</div>
          <div class="container">
            <div id="hour" class="scrollport">
              ${hh.map(
                h => html`
                  <div class="cell" id="n${h}" value="${h}">
                    <i
                      data-icon="numeric_${h.substring(0, 1)}_rounded_bold"
                    ></i>
                    <i
                      data-icon="numeric_${h.substring(1, 2)}_rounded_bold"
                    ></i>
                  </div>
                `
              )}
            </div>
            <div id="minute" class="scrollport">
              ${mm.map(
                m => html`
                  <div class="cell" id="n${m}" value="${m}">
                    <i
                      data-icon="numeric_${m.substring(0, 1)}_rounded_bold"
                    ></i>
                    <i
                      data-icon="numeric_${m.substring(1, 2)}_rounded_bold"
                    ></i>
                  </div>
                `
              )}
            </div>

            ${this.is12hFormat
              ? html`
                  <div id="ampm" class="scrollport">
                    ${ampm.map(
                      ampm => html`
                        <div
                          class="cell subtilte-1"
                          id="${ampm}"
                          value="${ampm}"
                        >
                          <span>${ampm}</span>
                        </div>
                      `
                    )}
                  </div>
                `
              : ''}
          </div>
          <div class="buttons">
            <kai-pillbutton
              text=${_('cancel')}
              level="secondary"
              @click="${this._onCancel}"
            ></kai-pillbutton>
            <kai-pillbutton
              text=${_('done')}
              @click="${this._onEnabled}"
            ></kai-pillbutton>
          </div>
        </div>
      </div>
    `;
  }
}

customElements.define(TimePickerElement.is, TimePickerElement);
