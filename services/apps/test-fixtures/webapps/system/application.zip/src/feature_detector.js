import BaseModule from 'base-module';

class FeatureDetector extends BaseModule {
  service = window.Service;

  STATES = ['hasEndCallKey', 'hasVolumeKey', 'isLowMemoryDevice'
    , 'supportSwitchPrimarysim', 'hasVT', 'isQwerty'];

  hasEndCallKey = true;
  hasVolumeKey = true;
  isLowMemoryDevice = false;
  supportSwitchPrimarysim = false;
  hasVT = false;
  isQwerty = false;

  DEBUG = false;

  start() {
    navigator.hasFeature('device.capability.endcall-key').then((hasEndCallKey) => {
      this.hasEndCallKey = !!hasEndCallKey;
      Service.registerState('hasEndCallKey', this);
    });

    navigator.hasFeature('device.capability.volume-key').then((hasVolumeKey) => {
      this.hasVolumeKey = !!hasVolumeKey;
      Service.registerState('hasVolumeKey', this);
    });

    navigator.hasFeature('ril.support.primarysim.switch').then((support) => {
      this.supportSwitchPrimarysim = !!support;
      Service.registerState('supportSwitchPrimarysim', this);
    });

    navigator.hasFeature('device.capability.vilte').then((hasVT) => {
      this.hasVT = !!hasVT;
      Service.registerState('hasVT', this);
    });

    navigator.hasFeature('device.capability.qwerty').then((isQwerty) => {
      this.isQwerty = !!isQwerty;
      Service.registerState('isQwerty', this);
    });

    navigator.hasFeature('device.capability.sim-hotswap').then((support) => {
      this.supportSimHotswap = !!support;
      Service.registerState('supportSimHotswap', this);
    });

    Promise.all([
      navigator.getFeature('hardware.memory'),
      this.loadMemoryConfig()
    ]).then((results) => {
      let memOnDevice = results[0];
      let memConfigProfile = results[1];
      this.isLowMemoryDevice =
        (memOnDevice <= 256) || (memConfigProfile === 'low') ? true : false;
      Service.registerState('isLowMemoryDevice', this);
    }, (reason) => {
      this.debug('--> reject with reason: ' + reason);
      Service.registerState('isLowMemoryDevice', this);
    });
  }

  loadMemoryConfig() {
    return new Promise((resolve, reject) => {
      let url = './resources/memory-profile.json';
      LazyLoader.getJSON(url).then((json) => {
        resolve(json.profile);
      }, (error) => {
        this.debug('--> Failed to fetch file: ' + url + ',' + error);
        resolve(null);
      });
    });
  }
}

const featureDetector = new FeatureDetector();
featureDetector.start();
window.fd = featureDetector;

export default featureDetector;
