/* globals dump */
'use strict';

// Note: By setting default false, we are inevitably missing logs at very beginning.
// (i.e. before we got value from mozSettings, that's an asynchronouse operation)
let debugEnabled = false;

const settings = window.navigator.mozSettings;
if (settings) {
  settings.createLock().get('debug.gaia.enabled').then((result) => {
    debugEnabled = !!result['debug.gaia.enabled'];
  });
  settings.addObserver('debug.gaia.enabled', (event) => {
    debugEnabled = !!event.settingValue;
  });
} else {
  debugEnabled = true;
  log('navigator.mozSettings falsy, force debugEnabled true');
}

// Print logs in both webIDE's console and `adb logcat`(stdout).
// Use `adb logcat *:S GeckoDump:V` to print dumpping logs.
function log(...args) {
  if (!debugEnabled) {
    return;
  }

  if (dump) {
    const text = args.map((v) => {
      if (typeof v === 'string') {
        return v;
      }
      if (v instanceof Node) {
        return v.outerHTML.slice(0, v.outerHTML.indexOf('>') + 1);
      }
      try {
        return JSON.stringify(v);
      } catch (e) {
        return v;
      }
    }).join(' ');
    dump(text);
  }
  console.log(...args);
}

const logger = (namespace) => (...args) => log(`[${namespace}]`, ...args);

export default logger;

// deprecated, used in legacy code only
export const DUMP = log;
