/* global KeyboardEventGenerator */

export function toL10n(id = '', args = {}) {
  if ('complete' !== navigator.mozL10n.readyState || !id) {
    return id;
  }
  id += '';
  return navigator.mozL10n.get(id, args) || id;
}

export function simpleClone(obj) {
  return JSON.parse(JSON.stringify(obj));
}

// === Math.min(max, Math.max(min, num))
export function clamp(num, min = 0, max = 2) {
  return (num <= min) ? min : ((num >= max) ? max : num);
}

export function rowColToIndex(rc = [0, 0], col = 3) {
  return (rc[0] * col) + rc[1];
}

export function indexToRowCol(index, col = 3) {
  return [Math.floor(index / col), index % col];
}

export const isLandscape = screen.orientation.type.startsWith('landscape');

export function isRtl() {
  return 'rtl' === document.dir;
}

export function navGrid({ currentRowCol = [0, 0], dir, col = 3, total } = {}) {
  let currentIndex = rowColToIndex(currentRowCol, col);
  let totalRows = Math.ceil(total / col);
  let totalGrid = totalRows * col;
  let lastIndex = total - 1;

  switch (dir) {
    case 'ArrowRight':
      currentIndex = (total + (currentIndex + 1)) % total;
      break;
    case 'ArrowLeft':
      currentIndex = (total + (currentIndex - 1)) % total;
      break;
    case 'ArrowUp':
      currentIndex = clamp((totalGrid + (currentIndex - col)) % totalGrid, 0, lastIndex);
      break;
    case 'ArrowDown':
      currentIndex = clamp((totalGrid + (currentIndex + col)) % totalGrid, 0, lastIndex);
      break;
    default:
      break;
  }

  return indexToRowCol(currentIndex, col);
}

export function toggleBletooth(targetState) {
  if (!navigator.mozBluetooth ||
      !navigator.mozBluetooth.defaultAdapter ||
      !navigator.mozBluetooth.defaultAdapter.state) {
    return Promise.reject('no bluetooth exist');
  }

  let currentState = navigator.mozBluetooth.defaultAdapter.state;
  let isEnabled = ('enabled' === currentState);
  targetState = targetState || (isEnabled ? 'disable' : 'enable');

  if (currentState.endsWith('ing')) {
    return Promise.reject(`bluetooth state is busy: ${currentState}`);
  }
  return navigator.mozBluetooth.defaultAdapter[targetState]();
}

/**
 * Generate hardware keyboard events programatically.
 * Valid key: Home, Backspace, EndCall, Enter, SoftLeft, SoftRight, ...
 */
export function genHardwareKeyEvent(key, eventType) {
  console.log(`genHardwareKeyEvent ${eventType} ${key}`);
  if (!window.KeyboardEventGenerator) {
    throw 'KeyboardEventGenerator falsy. Try setting the pref "dom.keyboardEventGenerator.enabled" true, or this is a unsupported device.';
  }
  const keg = new KeyboardEventGenerator();
  if (eventType) {
    keg.generate(new KeyboardEvent(eventType, { key }));
  } else {
    keg.generate(new KeyboardEvent('keydown', { key }));
    keg.generate(new KeyboardEvent('keyup', { key }));
  }
}

/**
 * Used as the `hasChanged` function of a `lit-element` property declaration.
 * Determine if an object property has changed or not.
 * See: https://lit-element.polymer-project.org/guide/properties#haschanged
 */
export function objHasChanged(newVal, oldVal) {
  return oldVal === undefined || Object.keys(newVal).some((key) => oldVal[key] !== newVal[key]);
}

/**
 * Get app icon
 * @param {*} appName
 */
export function getMozAppIcon(appName) {
  return navigator.mozApps.mgmt.getAll()
    .then(apps => {
      const targetMozApp =
        apps.find(app => app.manifest.name === appName);
      if (!targetMozApp) {
        throw new Error(`${appName} not found.`);
      }
      return navigator.mozApps.mgmt
        .getIcon(targetMozApp, 56)
        .then(blob => URL.createObjectURL(blob));
    });
}

export function isInteger(value) {
  return Math.round(value) === value;
};

/**
 * Transform the format of seconds to mm:ss
 * @param {number} seconds
 * @returns {string} The converted string
 * @example timeFormatter(179) ===> '02:59'
 */
export function timeFormatter(seconds) { // 0 <= seconds <= 3599
  if (!isInteger(seconds) || seconds > 3599 || seconds < 0) {
    return '--:--';
  }
  const min = Math.floor(seconds / 60);
  const sec = seconds % 60;
  return `${('0' + min).substr(-2)}:${('0' + sec).substr(-2)}`;
}
