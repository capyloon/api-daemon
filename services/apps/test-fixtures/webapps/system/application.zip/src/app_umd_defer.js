/**
 * Migrate the dependecies of `<script defer>` in index.html here.
 * See `app_umd.js` for more information.
 * Note: The `require` order does matter.
 */
import uuid from './uuid.js';
import { HtmlHelper, StringHelper } from './app_umd/defer/utilities.js';
import {
  NfcBuffer,
  NfcUtils,
  NDEF
} from './app_umd/defer/nfc_utils.js';

window.uuid = uuid;

window.HtmlHelper = HtmlHelper;
window.StringHelper = StringHelper;

window.NfcBuffer = NfcBuffer;
window.NfcUtils = NfcUtils;
window.NDEF = NDEF;

// Attach modules to global object.
// Do `require` looply for less code.
// These modules have clear dependencies and can be `import` or `require` in any order.
const moduleMap = {
  'event_safety': 'eventSafety',
  'settings_listener': 'SettingsListener',
  'async_storage': 'asyncStorage',
  'mobile_operator': 'MobileOperator',
  'manifest_helper': 'ManifestHelper',
  'clock': 'Clock',
  'service': 'Service',
  'browser_frame': 'BrowserFrame',
};
let properties = {};
Object.entries(moduleMap).forEach(([ filename, moduleName ]) => {
  properties[moduleName] = {
    value: require(`./app_umd/defer/${filename}.js`).default
  };
});
Object.defineProperties(window, properties);

// Lazy loading modules are put in separated folder.
// The reason is we use dynamic `require` above, that will cause all modules bundled together.
// For more information:
// https://webpack.js.org/guides/dependency-management/#require-with-expression
// https://webpack.js.org/api/module-methods/#magic-comments
window.LazyLoader = require('./app_umd/lazy/lazy_loader.js').default;

// These modules still need to be refactored to have clean dependencies
window.CustomDialog = require('./app_umd/defer/custom_dialog.js').default;
window.NotificationHelper = require('./app_umd/defer/notification_helper.js').default;
