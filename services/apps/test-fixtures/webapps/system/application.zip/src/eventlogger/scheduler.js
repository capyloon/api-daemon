import * as utils from './utils';

const MILLISECONDS_HALFDAY = 12 * 60 * 60 * 1000;    //12 hours
const MILLISECONDS_DAY = 24 * 60 * 60 * 1000;    //24 hours

const CHECK_SUMMARY_INTERVAL = MILLISECONDS_DAY;

const EVENTS = ['cell_connected', 'wifi_connected', 'summaryAlarming', 'retryAlarming'];

const LASTALARM = 'evl_last_alarm';

var cellTimer = 0;

class Scheduler {
  constructor() {
    this.event_callbacks = {};
    this.wifiManager = navigator.mozWifiManager;
    this.conns = navigator.mozMobileConnections;
    this.summaryInterval = CHECK_SUMMARY_INTERVAL;
    this.alarmTypes = ['EVLCheckSchedule', 'EVLRetry'];
    this.retry = 0;
  }

  start() {
    this.bindOnDatachange = this.onDatachange.bind(this);
    this.bindOnWifihasinternet = this.onWifihasinternet.bind(this);
    this.bindOnTimeChange = this.onTimeChange.bind(this);
    this.bindHandleAlarm = this.handleAlarm.bind(this);
    this.bindScheduleInterval = this.scheduleInterval.bind(this);
    this.bindSetRetryInterval = this.setRetryInterval.bind(this);

    for (var i = 0; i < this.conns.length; i++) {
      this.conns[i].addEventListener('datachange', this.bindOnDatachange);
    }
    this.wifiManager.addEventListener('wifihasinternet', this.bindOnWifihasinternet);

    window.addEventListener('moztimechange', this.bindOnTimeChange);
    AlarmMessageHandler.addCallback(this.bindHandleAlarm);

    this.triggerFirstEvent();
    this.newAlarm('EVLCheckSchedule', this.summaryInterval);

    window.navigator.mozSettings.addObserver('evl.schedule.interval', this.bindScheduleInterval);
    window.navigator.mozSettings.addObserver('evl.retry.interval', this.bindSetRetryInterval);
  }

  stop() {
    for (var i = 0; i < this.conns.length; i++) {
      this.conns[i].removeEventListener('datachange', this.bindOnDatachange);
    }
    this.wifiManager.removeEventListener('wifihasinternet', this.bindOnWifihasinternet);

    window.removeEventListener('moztimechange', this.bindOnTimeChange);
    this.removeSummaryAlarm();
    AlarmMessageHandler.removeCallback(this.bindHandleAlarm);

    window.navigator.mozSettings.removeObserver('evl.schedule.interval', this.bindScheduleInterval);
    window.navigator.mozSettings.removeObserver('evl.retry.interval', this.bindSetRetryInterval);
  }

  onDatachange(e) {
    if (e.target.data.connected) {
      clearTimeout(cellTimer);
      // Remove redundant datachange
      for (var i = 0; i < this.conns.length; i++) {
        if (this.conns[i].data.connected) {
          cellTimer = setTimeout(() => {
            utils.debug('datachange true');
            this.dispatchEvent('cell_connected', { 'detail': { slot: i }, 'type': 'cell_connected' });
          }, 500);
        }
      }
    }
  }

  onWifihasinternet(e) {
    if (e.hasInternet) {
      utils.debug('wifihasinternet true');
      var networkInfo = this.wifiManager.connection.network;
      // It has some gap when the wifi is really connected.
      // Delay the event dispatching
      setTimeout(() => {
        // The 'wifi_connected' means device has internet connection
        this.dispatchEvent('wifi_connected', { 'detail': networkInfo, 'type': 'wifi_connected' });
      }, 1000);
    }
  }

  scheduleInterval(interval) {
    var inter = parseInt(interval.settingValue);
    // Validate, minimum is 60 sec
    if (!isNaN(inter) && inter > 59 * 1000) {
      this.summaryInterval = inter;
      utils.debug('evl.schedule.interval is', this.summaryInterval);
      utils.debug('newAlarm');
      this.newAlarm('EVLCheckSchedule', this.summaryInterval, true);
    }
  }

  setRetryInterval(interval) {
    var inter = parseInt(interval.settingValue);
    // Validate, minimum is 10 sec
    if (!isNaN(inter) && inter > 10 * 1000) {
      this.testTimeInMilli = inter;
      utils.debug('evl.retry.interval is', this.testTimeInMilli);
      this.newAlarm('EVLRetry', this.testTimeInMilli, true);
    } else {
      this.testTimeInMilli = null;
    }
  }

  triggerFirstEvent() {
    for (var i = 0; i < this.conns.length; i++) {
      if (this.conns[i].data.connected) {
        utils.debug('datachange true' + `slot ${i}`);
        this.dispatchEvent('cell_connected', { 'detail': { slot: i }, 'type': 'cell_connected' });
      }
    }

    // Dispatch summaryAlarming if device missed old alarm.
    this.checkAlarm();
  }

  checkAlarm() {
    var lastAlarmTime = this.LASTALARM || localStorage.getItem(LASTALARM);
    var time = parseInt(lastAlarmTime);
    utils.debug('checkAlarm lastAlarmTime', time);
    utils.debug('checkAlarm', Date.now());
    if (!isNaN(time) && time < Date.now()) {
      utils.debug('checkAlarm alarming ' + time);
      this.dispatchEvent('summaryAlarming', { 'detail': new Date(time), 'type': 'summaryAlarming' });
    }
  }

  removeSummaryAlarm() {
    return new Promise((resolve, reject) => {
      var alarmRequest = navigator.mozAlarms.getAll();
      alarmRequest.onsuccess = function () {
        this.result.forEach(function (alarm) {
          if (alarm.data.EVLCheckSchedule) {
            navigator.mozAlarms.remove(alarm.id);
          }
        });
        resolve();
      };
      alarmRequest.onerror = function () {
        reject();
        utils.debug('removeExistingSummaryAlarm failed: ' + this.error);
      };
    });
  }

  addEventListener(key, callback) {
    if (EVENTS.indexOf(key) < 0) {
      return false;
    }
    if (!(key in this.event_callbacks)) {
      this.event_callbacks[key] = [];
    }
    utils.debug('addEventListener scheduler', key);
    this.event_callbacks[key].push(callback);

    return true;
  }

  removeEventListener(key, callback) {
    if (!(key in this.event_callbacks)) {
      return;
    }
    utils.debug('removeEventListener scheduler entering', key);
    var stack = this.event_callbacks[key];
    stack.forEach((element, index) => {
      if (element === callback) {
        utils.debug('removeEventListener scheduler removed', key);
        stack.splice(index, 1);
      }
    });
  }

  dispatchEvent(key, data) {
    var stack = this.event_callbacks[key];
    if (stack === undefined) {
      return;
    }
    stack.forEach((element) => {
      element.call(this, data);
    });
  }

  onTimeChange() {
    utils.debug('onTimeChange');
    clearTimeout(this.timeChangeTimer);
    this.timeChangeTimer = setTimeout(() => {
      this.newAlarm('EVLCheckSchedule', this.summaryInterval, true);
      if (this.retryRunning) {
        this.newAlarm('EVLRetry', this.getRetryInterval(this.retry), true);
      }
    }, 5000);
  }

  handleAlarm(alarm) {
    if (alarm.data.EVLCheckSchedule) {
      if ((this.lastAlarmDate && this.lastAlarmDate.getTime()) === alarm.date.getTime()) {
        utils.debug('duplicate alarm, rejected');
        return;
      }
      utils.debug('EVL alarming');
      this.lastAlarmDate = alarm.date;
      this.dispatchEvent('summaryAlarming', { 'detail': alarm.date, 'type': 'summaryAlarming' });

      //Re-schedule same alarm
      this.newAlarm('EVLCheckSchedule', this.summaryInterval);
    } else if (alarm.data.EVLRetry) {
      // User may stop the alarm after the next round has been set up.
      // Stop dsipatching here.
      if (!this.retryRunning) {
        this.retry = 0;
        return;
      }
      if ((this.lastRetryAlarmDate && this.lastRetryAlarmDate.getTime()) === alarm.date.getTime()) {
        utils.debug('duplicate alarm, rejected');
        return;
      }
      utils.debug('EVL retryAlarming alarming');
      this.lastRetryAlarmDate = alarm.date;
      if (this.retry < 6) {
        this.dispatchEvent('retryAlarming', { detail: alarm, data: this.retryData, stopped: false });

        //Re-schedule same alarm
        this.newAlarm('EVLRetry', this.getRetryInterval(this.retry));
        this.retry += 1;
      } else {
        this.dispatchEvent('retryAlarming', { detail: alarm, data: this.retryData, stopped: true });
        this.removeRetryAlarm();
      }
    }
  }

  newAlarm(type, interval, forceNew) {
    var self = this;
    var alarmRequest = navigator.mozAlarms.getAll();
    alarmRequest.onsuccess = function () {
      utils.debug('EVL newAlarm = ' + JSON.stringify(this.result));
      var alarmFound = false;
      this.result.forEach(function (alarm) {
        // Only one alarm allowed.
        if (alarm.data[type]) {
          if (forceNew || alarmFound) {
            navigator.mozAlarms.remove(alarm.id);
          } else if (alarm.date.getTime() > Date.now()) {
            alarmFound = true;
            self.nextAlarmDate = alarm.date;
          }
        }
      });
      if (!alarmFound) {
        self.addAlarm(interval, type);
      }
    };
    alarmRequest.onerror = function () {
      utils.debug('newAlarm failed: ' + this.error);
    };
  }

  newRetryAlarm(data) {
    this.newAlarm('EVLRetry', this.getRetryInterval(this.retry));
    this.retryData = data;
    this.retryRunning = true;
  }

  removeRetryAlarm() {
    this.retry = 0;
    this.retryData = null;
    this.retryRunning = false;
    var alarmRequest = navigator.mozAlarms.getAll();
    alarmRequest.onsuccess = function () {
      utils.debug('removeRetryAlarm[]=' + JSON.stringify(this.result));
      this.result.forEach(function (alarm) {
        if (alarm.data.EVLRetry) {
          navigator.mozAlarms.remove(alarm.id);
        }
      });
    };
    alarmRequest.onerror = function () {
      utils.debug('operation failed: ' + this.error);
    };
  }

  getRetryInterval(n) {
    if (this.testTimeInMilli) {
      return this.testTimeInMilli;
    }

    var ret = 60 * 60 * 1000;
    switch (n) {
      case 0:
        ret = 60 * 1000;
        break;
      case 1:
        ret = 5 * 60 * 1000;
        break;
      case 2:
        ret = 30 * 60 * 1000;
        break;
      case 3:
        ret = 60 * 60 * 1000;
        break;
    }

    return ret;
  }

  addAlarm(interval, type) {
    var self = this;
    var alarmDate = new Date(Date.now() + interval);
    var detail = {};
    detail[type] = true;
    var request = navigator.mozAlarms.add(alarmDate, 'ignoreTimezone', detail);
    request.onsuccess = function () {
      self.nextAlarmDate = alarmDate;
      utils.debug('nextAlarmDate=' + alarmDate, type);
      if (type === 'EVLCheckSchedule') {
        this.LASTALARM = alarmDate.getTime();
        localStorage.setItem(LASTALARM, this.LASTALARM);
        utils.debug('addAlarm LASTALARM set ' + this.LASTALARM);
      }
    };
    request.onerror = function () {
      utils.debug('add alarm failed: ' + this.error);
    };
  }

  hasWifiConnection() {
    if (this.wifiManager.connection.network &&
      this.wifiManager.connection.network.hasInternet) {
      return true;
    }

    return false;
  }
}

export default Scheduler;