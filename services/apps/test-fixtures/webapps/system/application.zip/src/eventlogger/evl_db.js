const DB_NAME = 'evldb';
const STORE_NAME = 'evlactions';
const DB_VERSION = 1;
const EVENT_TYPE_IDX = 'event_type';
const DB_CAPACITY = 'db_capacity';

class EVLDB {
  constructor() {
    this.db = null;
    this.QUOTA = 2000;
    this.OVERFLOW = 50;
    this.records = 0;
    this.isFull = false;
  }

  init() {
    return new Promise((resolve, reject) => {
      var req = window.indexedDB.open(DB_NAME, DB_VERSION);
      req.onupgradeneeded = this.upgradeSchema;
      req.onsuccess = (e) => {
        this.db = e.target.result;
        this._recordsCount().then(() => {
          resolve();
        });
      };
    });
  }

  upgradeSchema(e) {
    var db = e.target.result;

    console.log('onupgradeneeded');
    var objectStore = db.createObjectStore(STORE_NAME, { autoIncrement: true });
    objectStore.createIndex(EVENT_TYPE_IDX, EVENT_TYPE_IDX, { unique: false });
  }

  _recordsCount() {
    return new Promise((resolve, reject) => {
      var transaction = this.db.transaction([STORE_NAME], 'readonly');
      var objectStore = transaction.objectStore(STORE_NAME);
      var countRequest = objectStore.count();
      countRequest.onsuccess = () => {
        console.log(countRequest.result);
        this.records = countRequest.result;
        resolve(this.records);
        this.isFull = this.records >= this.QUOTA - 1;
        this.emit(DB_CAPACITY, { isFull: this.isFull });
      };
      countRequest.onerror = () => {
        console.log('countRequest _recordsCount error');
        reject();
      };
    });
  }

  add(obj, priority) {
    if (this.records > this.QUOTA - 1) {
      this.isFull = true;
      this.emit(DB_CAPACITY, { isFull: this.isFull });
    } else {
      this.isFull = false;
    }

    if (priority !== 1 && this.records > this.QUOTA - 1) {
      return Promise.reject({ reason: 'exceed limit', isFull: true });
    } else if (priority === 1 &&
      this.records > this.QUOTA + this.OVERFLOW - 1) {
      return Promise.reject({ reason: 'exceed limit', isFull: true });
    }

    return new Promise((resolve, reject) => {
      var transaction = this.db.transaction([STORE_NAME], 'readwrite');
      var req = transaction.objectStore(STORE_NAME).add(obj);

      req.onsuccess = e => {
        this.records += 1;
        if (this.records > this.QUOTA - 1) {
          this.isFull = true;
          this.emit(DB_CAPACITY, { isFull: this.isFull });
        }
        resolve(e.target.result);
        console.log('onsuccess primaryKey e.target.result ' + e.target.result);
      };
      transaction.onerror = transaction.onabort = req.onerror = (e) => {
        console.log('add transaction errror');
        reject(e);
      };
    });
  }

  delete(idx, value) {
    if (!value) {
      return;
    }
    var transaction = this.db.transaction([STORE_NAME], 'readwrite');
    var objectStore = transaction.objectStore(STORE_NAME);

    var finding = [].concat(value);
    var myIndex = objectStore.index(idx);
    var req = myIndex.openCursor(null, 'prev');
    req.onsuccess = (event) => {
      var cursor = event.target.result;
      if (cursor) {
        if (finding.indexOf(cursor.key) > -1) {
          console.log('deleting cursor');
          cursor.delete();
        }

        cursor.continue();
      } else {
        console.log('all deleted.');
        // Update records.
        this._recordsCount();
      }
    };
  }

  deleteSent(pKeys) {
    if (!pKeys) {
      return Promise.resolve();
    }

    return new Promise((resolve, reject) => {
      var transaction = this.db.transaction([STORE_NAME], 'readwrite');
      var objectStore = transaction.objectStore(STORE_NAME);

      var finding = [].concat(pKeys);
      var req = objectStore.openCursor(null, 'prev');
      req.onsuccess = (event) => {
        var cursor = event.target.result;
        if (cursor) {
          var idx = finding.indexOf(cursor.primaryKey);
          if (idx > -1) {
            console.log('deleteSent deleting cursor');
            console.log('cursor.primaryKey' + cursor.primaryKey);
            cursor.delete();
            finding.splice(idx, 1);
          }
          cursor.continue();
        } else {
          console.log('primaryKey all deleted.');
          // Update records.
          this._recordsCount().then(() => {
            resolve();
          }).catch( e => {
            resolve();
          });
        }
      };
    });
  }

  // To read a group of records
  read(idx, value) {
    return new Promise((resolve, reject) => {
      if (!value) {
        resolve([]);

        return;
      }

      var transaction = this.db.transaction([STORE_NAME], 'readonly');
      var objectStore = transaction.objectStore(STORE_NAME);
      var items = [];
      var finding = [].concat(value);
      var req = objectStore.getAll();
      req.onsuccess = (event) => {
        var arr = event.target.result;
        arr.forEach(data => {
          if (data[idx] && finding.indexOf(data[idx]) > -1) {
            items.push(data);
          }
        });
        resolve(items);
      };
      req.onerror = reject;
    });
  }

  getAll() {
    return new Promise((resolve, reject) => {
      var transaction = this.db.transaction([STORE_NAME], 'readonly');
      var objectStore = transaction.objectStore(STORE_NAME);
      var req = objectStore.getAll();
      req.onerror = reject;
      req.onsuccess = (e) => {
        resolve(e.target.result);
        console.log('getAll. length = ' + e.target.result.length);
      };
    });
  }

  clear() {
    return new Promise((resolve, reject) => {
      var transaction = this.db.transaction([STORE_NAME], 'readwrite');
      var objectStore = transaction.objectStore(STORE_NAME);
      var req = objectStore.clear();
      req.onsuccess = () => {
        this.records = 0;
        this.isFull = false;
        resolve();
      };
      req.onerror = reject;
    });
  }

  emit(type, data) {
    var evt = new CustomEvent(type, { detail: data });
    window.dispatchEvent(evt);
  }

  setQuota(qt, ovf) {
    if (qt && !isNaN(parseInt(qt))) {
      this.QUOTA = qt;
    }
    if (ovf && !isNaN(parseInt(ovf))) {
      this.OVERFLOW = ovf;
    }
  }
}

export const evldb = new EVLDB();