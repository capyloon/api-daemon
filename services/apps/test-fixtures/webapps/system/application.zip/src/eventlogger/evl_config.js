import DeviceInfoComposer from './device_info_composer';
import * as utils from './utils';

// https://eventlogger.kaiostech.com/config/?os=kaios&os_ver=2.5&curef=abcdef&mnc=0&mcc=0&network_mnc=0&network=mcc=0
const CONFIG_URL = 'https://eventlogger.kaiostech.com/config';
const CONFIG_NAME = 'eventlogger_config';
const CONFIG_SETTING = 'evl.config.url';
const CONFIG_QUOTA = 'config_quota';

const MILLISECONDS_DAY = 24 * 60 * 60 * 1000;

class EVLConfig {
  constructor() {
    this.DEFAULT_CONFIG = {
      'events': {
        'app_position': {
          'priority': 3,
          'consent_needed': 'N'
        },
        'app_open': {
          'priority': 3,
          'consent_needed': 'N'
        },
        'app_close': {
          'priority': 3,
          'consent_needed': 'N'
        },
        'app_install': {
          'priority': 3,
          'consent_needed': 'N'
        },
        'app_uninstall': {
          'priority': 3,
          'consent_needed': 'N'
        },
        'app_update': {
          'priority': 3,
          'consent_needed': 'N'
        },
        'app_pause': {
          'priorirty': 3,
          'consent_needed': 'N'
        },
        'call_start': {
          'priority': 3,
          'consent_needed': 'Y'
        },
        'call_start_in': {
          'priority': 3,
          'consent_needed': 'Y'
        },
        'call_end': {
          'priority': 3,
          'consent_needed': 'Y'
        },
        'call_reject': {
          'priority': 3,
          'consent_needed': 'Y'
        },
        'wifi_on': {
          'priority': 1,
          'consent_needed': 'N'
        },
        'wifi_off': {
          'proirity': 3,
          'consent_needed': 'N'
        },
        'wifi_connect': {
          'priority': 3,
          'consent_needed': 'N'
        },
        'sms_send': {
          'priority': 3,
          'consent_needed': 'Y'
        },
        'sms_receive': {
          'priority': 3,
          'consent_needed': 'Y'
        },
        'sms_open': {
          'priority': 3,
          'consent_needed': 'Y'
        },
        'contact_add': {
          'priority': 3,
          'consent_needed': 'N'
        },
        'app_summary': {
          'priority': 1,
          'consent_needed': 'N'
        },
        'data_summary': {
          'priority': 1,
          'consent_needed': 'N'
        },
        'buffer_summary': {
          'priority': 1,
          'consent_needed': 'N'
        },
        'telemetry_consent': {
          'priority': 1,
          'consent_needed': 'N'
        },
        'targeting_consent': {
          'priority': 1,
          'consent_needed': 'N'
        },
        'age_consent': {
          'priority': 1,
          'consent_needed': 'N'
        }
      },
      'buffer_size': 200,
      'config_id': null
    };

    this.REPORT_TIMEOUT = 30000;

    SettingsListener.observe(CONFIG_SETTING,
      CONFIG_URL,
      url => { this.baseUrl = url; });

    this.CONFIG = this.get();
    this.setPriroty(this.CONFIG);
  }

  getOnlineConfig() {
    if (!navigator.onLine) {
      utils.debug('getOnlineConfig offline, return');

      return;
    }

    var time = parseInt(this.CONFIG.last_check);
    if (!isNaN(time) &&
      (Date.now() - time) < MILLISECONDS_DAY) {
      utils.debug('getOnlineConfig too soon, return');

      return;
    }

    Promise.all([DeviceInfoComposer.getDeviceInfo(),
      DeviceInfoComposer.getStandardPackage()]).then(result => {
      var params = {
        os: result[0]['deviceinfo.software'] || 'kaios',
        os_ver: result[0]['deviceinfo.os'] || 2.5,
        curef: result[0]['deviceinfo.cu'],
        uuid: result[0]['app.update.custom'],
        mcc: result[1]['icc_mcc'] || 0,
        mnc: result[1]['icc_mnc'] || 0,
        network_mcc: result[1]['network_mcc'] || 0,
        network_mnc: result[1]['network_mnc'] || 0,
        config_id: this.CONFIG.config_id
      };

      // os=kaios&os_ver=2.5&curef=abcdef&mnc=0&mcc=0&network_mnc=0&network_mcc=0&config_id=null
      var commsParams = Object.keys(params).map(function (key) {
        return key + '=' + params[key];
      }).join('&');

      var url = this.baseUrl + '?' + commsParams;
      url = encodeURI(url);
      var requester = new Requester(this.REPORT_TIMEOUT);

      return requester.send({
        url: url,
        method: 'GET',
      });
    }).then(result => {
      utils.debug(result);
      this.persistConfig(result);
    }).catch(error => {
      this.updateCheckponit();
      utils.debug(error);
    });
  }

  updateCheckponit() {
    try {
      var last_check = Date.now();
      this.CONFIG.last_check = last_check;
      var str_config = JSON.stringify(this.CONFIG);
      localStorage.setItem(CONFIG_NAME, str_config);
    } catch (e) {
      utils.debug('not a valid JSON format');
    }
  }

  getConfigfromPersist() {
    try {
      var str_config = localStorage.getItem(CONFIG_NAME);
      return JSON.parse(str_config);
    } catch (e) {
      utils.debug('not a valid JSON format');
      return null;
    }
  }

  persistConfig(data) {
    var obj = {};
    if (typeof data === 'object') {
      obj = data;
    } else {
      try {
        obj = JSON.parse(data);
      } catch (e) {
        utils.debug('not a valid JSON format');
      }
    }
    if (!this.validate(obj)) {
      utils.debug('Invalid format from config server');
      return;
    }
    try {
      var last_check = Date.now();
      obj.last_check = last_check;
      this.makeSureEventTypes(obj);
      var str_config = JSON.stringify(obj);
      localStorage.setItem(CONFIG_NAME, str_config);
      // Update config
      this.updateConfig(obj);
      // Update quota for DB
      var evt = new CustomEvent(CONFIG_QUOTA, { detail: { buffer_size: obj.buffer_size } });
      window.dispatchEvent(evt);
    } catch (e) {
      utils.debug('not a valid JSON format');
    }
  }

  makeSureEventTypes(obj) {
    var types = ['app_summary', 'data_summary', 'buffer_summary'];
    types.forEach(type => {
      if (!obj.events[type]) {
        if (this.DEFAULT_CONFIG.events[type]) {
          obj.events[type] = this.DEFAULT_CONFIG.events[type];
        }
      }
    });
  }

  validate(config) {
    var ret = false;
    if (config &&
      config.events &&
      config.buffer_size &&
      config.config_id) {
      var inter = parseInt(config.buffer_size);
      if (!isNaN(inter)) {
        config.buffer_size = inter;
        ret = true;
      }
    }

    return ret;
  }

  get() {
    return this.getConfigfromPersist() || this.DEFAULT_CONFIG;
  }

  setPriroty(config) {
    var high = [];
    var onFull = [];
    Object.entries(config.events).forEach(([key, value]) => {
      console.log(`${key} ${value}`);
      if (value.priority == 1) {
        high.push(key);
      } else if (value.priority == 2) {
        onFull.push(key);
      }
    });

    this.PRIORITY_HIGHT = high;
    this.PRIORITY_ONFULL = onFull;
  }

  updateConfig(config) {
    this.CONFIG = config;
    this.setPriroty(config);
  }

  getPriority(type) {
    // Set low priority on default;
    var p = 3;
    if (this.CONFIG.events[type] && this.CONFIG.events[type].priority) {
      p = this.CONFIG.events[type].priority;
    }

    return p;
  }

}


export default EVLConfig;
