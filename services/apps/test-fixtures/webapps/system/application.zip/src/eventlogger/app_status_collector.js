import AppActionStore from './app_action_store';
import DeviceInfoComposer from './device_info_composer';
import SummaryStore from './summary_store';
import * as utils from './utils';

const MARKETPLACE_ORIGINS = ['app://kaios-plus.kaiostech.com'];
const EVENT_TYPES = [
  'appopened',
  'homescreenopened',
  'appclosed',
  'activitycreated',
  'lockscreen-appopened',
  'lockscreen-appclosed',
  'screenchange',
  'attentionopened',
  'attentionclosed'
];
const PAUSETIMEOUT = 1000;

class AppStatusCollector {
  constructor() {
    this.name = 'appStatusCollector';
    this.kaistoreApps = {};
    this.startTime = Date.now();
    //[{"appid": "appid", "appver": "1.2.3"}, ]
    this.downloads = [];
    this.downloadCount = 0;
    //[{"appid": "appid", "appver": "1.2.3"}, ]
    this.uninstalls = [];
    this.downloadCancels = [];

    this.appActionStore = new AppActionStore();

    var category = 'app_summary';
    var defaultData = {
      'daily_download': [], // list of apps (token) and app version downloaded today
      'daily_download_count': 0,
      'daily_uninstall': [], // list of apps (token) and app version that was uninstalled
      'daily_cancels': [],
      'current_inventory': [], // list of apps (token) and app version currently on phone
      'apps': {}
    };
    this.appSummary = new SummaryStore(category, defaultData);

    this.defaultUsage = {
      usageTime: 0,
      invocations: 0,
      openCount: 0,
      activities: {}
    };

    this.pauseTimer = 0;

    this.appOpenDuration = {};
  }

  getInstalledApps() {
    return new Promise((resolve, reject) => {
      navigator.mozApps.mgmt.getAll().then(apps => {
        var installedApps = [];
        apps.forEach(app => {
          if (MARKETPLACE_ORIGINS.indexOf(app.installOrigin) >= 0) {
            installedApps.push(app);
          }
        });
        utils.debug('getInstalledApps ' + installedApps);
        resolve(installedApps);
      }, reject);
    });
  }

  getCurrentInventory() {
    return new Promise((resolve, reject) => {
      navigator.mozApps.mgmt.getAll().then(apps => {
        var installed = [];
        apps.forEach(app => {
          if (MARKETPLACE_ORIGINS.indexOf(app.installOrigin) >= 0) {
            var obj = {};
            var manifest = app.manifest || app.updateManifest;
            obj.appid = manifest.name;
            obj.appver = manifest.version;
            installed.push(obj);
          }
        });
        utils.debug('getCurrentInventory ' + installed);
        resolve(installed);
      }, reject);
    });
  }

  start() {
    this.bindHandleInstall = this.handleInstall.bind(this);
    this.bindHandleUninstall = this.handleUninstall.bind(this);
    this.bindHandleUpdate = this.handleUpdate.bind(this);
    this.bindHandleDownloadapplied = this.handleDownloadapplied.bind(this);
    this.bindHandleDownloaderror = this.handleDownloaderror.bind(this);

    navigator.mozApps.mgmt.addEventListener('install', this.bindHandleInstall);
    navigator.mozApps.mgmt.addEventListener('uninstall', this.bindHandleUninstall);
    navigator.mozApps.mgmt.addEventListener('update', this.bindHandleUpdate);

    // Emit from AppStore
    window.addEventListener('evl-downloadapplied', this.bindHandleDownloadapplied);
    window.addEventListener('evl-downloaderror', this.bindHandleDownloaderror);

    var self = this;
    EVENT_TYPES.forEach((type) => {
      window.addEventListener(type, self);
    });
  }

  stop() {
    navigator.mozApps.mgmt.removeEventListener('install', this.bindHandleInstall);
    navigator.mozApps.mgmt.removeEventListener('uninstall', this.bindHandleUninstall);
    navigator.mozApps.mgmt.removeEventListener('update', this.bindHandleUpdate);

    window.removeEventListener('evl-downloadapplied', this.bindHandleDownloadapplied);
    window.removeEventListener('evl-downloaderror', this.bindHandleDownloaderror);

    var self = this;
    EVENT_TYPES.forEach((type) => {
      window.removeEventListener(type, self);
    });
  }

  handleEvent(e) {
    var now = performance.now();
    utils.debug('got an event: ' + e.type);

    switch (e.type) {
      case 'appopened':
        // Reset previous app duration.
        this.appOpenDuration[e.detail.manifestURL] = { duration: 0 };

        this.attentionWindows = [];
        this.currentApp = e.detail;
        this.currentAppStartTime = now;

        this.recordOpened(this.currentApp);
        break;

      case 'appclosed':
        // The user has opened an app, switched apps, or switched to the
        // homescreen. Record data about the app that was running and then
        // update the currently running app.
        this.recordInvocation(
          this.getCurrentApp(), now - this.getCurrentStartTime()
        );

        var obj = e.detail;
        var manifestURL = e.detail.manifestURL;
        var duration = (this.appOpenDuration[manifestURL] &&
          this.appOpenDuration[manifestURL].duration) || 0;
        obj.open_duration = duration;
        this.appActionStore.markAction('app_close', obj);
        utils.debug('app_close duration is ', duration);

        // Reset previous app duration.
        if (this.appOpenDuration[manifestURL]) {
          this.appOpenDuration[manifestURL] = { duration: 0 };
        }
        this.currentApp = null;
        break;

      case 'attentionopened':
        // Push the current attention screen start time onto stack, and use
        // currentApp / currentAppStartTime when the stack is empty
        this.recordInvocation(
          this.getCurrentApp(), now - this.getCurrentStartTime()
        );
        // Some apps do not have manifest info, get it from global applications
        var cachedApp = applications.getByManifestURL(e.detail.manifestURL);
        this.attentionWindows.push({
          app: cachedApp,
          startTime: now
        });
        break;

      case 'activitycreated':
        // If the current app launches an inline activity we record that
        // and maintain a count of how many times each activity (by url)
        // has been invoked by this app. This will give us interesting data
        // about which apps use which other apps. Note that we do not track
        // the amount of time the user spends in the activity handler.
        this.recordActivity(this.currentApp, e.detail.url);
        break;

      case 'lockscreen-appopened':
        // Record the time we ran the app, but keep the app the same
        // because we'll be back to it when the lockscreen is unlocked.
        // Note that if the lockscreen is disabled we won't get this event
        // and will just go straight to the screenchange event. In that
        // case we have to record the invocation when we get that event
        this.recordInvocation(
          this.getCurrentApp(), now - this.getCurrentStartTime()
        );
        this.setCurrentStartTime(now);

        // Remember that the lockscreen is active. When we wake up again
        // we need to know this to know whether the user is at the lockscreen
        // or at the current app.
        this.locked = true;

        // Fake one
        this.lockscreenApp = {
          manifestURL: 'app://lockscreen.kaiostech.org/manifest.webapp',
          installOrigin: 'app://kaios-plus.kaiostech.com'
        };

        if (this.getCurrentApp()) {
          clearTimeout(this.pauseTimer);
          this.pauseTimer = setTimeout(() => {
            this.appActionStore.markAction('app_pause', this.getCurrentApp());
          }, PAUSETIMEOUT);
        }
        break;

      case 'attentionclosed':
        // The attention window on top of the stack was closed. When there are
        // other attention windows, we reset the startTime of the top window on
        // the stack. Otherwise we reset the currentApp's start time when the
        // stack is empty.
        var attentionWindow = this.getTopAttentionWindow();
        if (attentionWindow && attentionWindow.app &&
          attentionWindow.app.manifestURL === e.detail.manifestURL) {
          this.recordInvocation(
            e.detail, now - attentionWindow.startTime
          );
          this.attentionWindows.pop();
        } else {
          debug('Unexpected attention window closed! ' + e.detail.manifestURL);
        }

        this.setCurrentStartTime(now);
        break;

      case 'lockscreen-appclosed':
        // If the lockscreen was started when the phone went to sleep, then
        // when we wake up we note the time and when we get this event, we
        // record the time spent on the lockscreen.
        if (this.locked && this.lockscreenApp) {
          this.recordInvocation(
            this.lockscreenApp, now - this.currentAppStartTime
          );

          // We left the currentApp unchanged when the phone went to sleep
          // so now that we're leaving the lock screen we will be back at whatever
          // app or homescreen we left. We just have to start timing again
          this.setCurrentStartTime(now);
        }
        this.locked = false;
        break;

      case 'screenchange':
        if (e.detail.screenOffBy === 'proximity') {
          // Ignore when the screen state changes because of the proximity sensor
          return;
        }

        if (e.detail.screenEnabled) {
          // We just woke up. Note the time. This will be used for recording
          // time on the lockscreen if we're locked or time at the old app.
          this.setCurrentStartTime(now);
        } else {
          // We're going to sleep. If the lockscreen is disabled and we went
          // directly to sleep then record the invocation of the current app.
          // Otherwise, we already recorded that when we got the locked event
          // so now we record lockscreen time. Typically there is just a
          // fraction of a second between the LOCKED and SCREENCHANGE events
          // and the data gets discarded because the time is too short. But
          // if the user wakes the phone up and never unlocks it and then
          // we time out again, we need to record lockscreen time here,
          // not current app time.
          var app = this.locked ? this.lockscreenApp : this.getCurrentApp();
          this.recordInvocation(app, now - this.getCurrentStartTime());

          if (!this.locked && this.getCurrentApp()) {
            clearTimeout(this.pauseTimer);
            this.pauseTimer = setTimeout(() => {
              this.appActionStore.markAction('app_pause', this.getCurrentApp());
            }, PAUSETIMEOUT);
          }
        }
        break;
    }
  }

  getTopAttentionWindow() {
    return this.attentionWindows ?
      this.attentionWindows[this.attentionWindows.length - 1] :
      undefined;
  }

  getCurrentApp() {
    return !this.attentionWindows || this.attentionWindows.length === 0 ?
      this.currentApp : this.getTopAttentionWindow().app;
  }

  getCurrentStartTime() {
    return !this.attentionWindows || this.attentionWindows.length === 0 ?
      this.currentAppStartTime : this.getTopAttentionWindow().startTime;
  }

  setCurrentStartTime(time) {
    if (!this.attentionWindows || this.attentionWindows.length === 0) {
      this.currentAppStartTime = time;
    } else {
      this.getTopAttentionWindow().startTime = time;
    }
  }

  recordActivity(app, url) {
    if (!this.shouldTrackApp(app)) {
      return false;
    }

    this.getAppUsage(app.manifestURL).then(usage => {
      var count = usage.activities[url] || 0;
      usage.activities[url] = ++count;
      utils.debug(app, 'invoked activity', url);

      this.appSummary.save();
    });
  }

  recordOpened(app) {
    if (!this.shouldTrackApp(app)) {
      return false;
    }

    this.getAppUsage(app.manifestURL).then(usage => {
      usage.openCount += 1;
      utils.debug(app, 'invoked recordOpened', usage.openCount);
      this.appSummary.save();

      // Send app_open action
      var obj = {};
      var manifest = app.manifest || app.updateManifest;
      var manifestURL = app.manifestURL;
      obj.manifestURL = manifestURL;
      obj.manifest = manifest;
      var count = 0;
      if (this.appSummary.data.apps[manifestURL] &&
        this.appSummary.data.apps[manifestURL].openCount) {
        count = this.appSummary.data.apps[manifestURL].openCount;
      }
      obj.open_count = count;

      this.appActionStore.markAction('app_open', obj);
      utils.debug('app_open', count);
    });
  }

  shouldTrackApp(app) {
    if (!app) {
      return false;
    }

    // Gecko and the app window state machine do not send certain app properties
    // along in webapp-launch or appopened events, causing marketplace app usage
    // to not be properly recorded. We fall back on the system app's application
    // cache in these situations. See Bug 1137063
    var cachedApp = applications.getByManifestURL(app.manifestURL);
    var manifest = app.manifest || app.updateManifest;
    if (!manifest && cachedApp) {
      manifest = cachedApp.manifest || cachedApp.updateManifest;
    }

    var installOrigin = app.installOrigin;
    if (!installOrigin && cachedApp) {
      installOrigin = cachedApp.installOrigin;
    }

    var type = manifest ? manifest.type : 'unknown';
    if (type === 'certified') {
      return true;
    }

    if (MARKETPLACE_ORIGINS.indexOf(installOrigin) >= 0) {
      return true;
    }

    try {
      var url = new URL(app.manifestURL);
      return url.hostname.indexOf('gaiamobile.org') >= 0;
    } catch (e) {
      return false;
    }
  }

  recordInvocation(app, time) {
    if (!this.shouldTrackApp(app)) {
      return false;
    }

    // Convert time to seconds and round to the nearest second.  If 0,
    // don't record anything. (This can happen when we go to the
    // lockscreen right before sleeping, for example.)
    time = Math.round(time / 1000);
    if (time > 0) {
      this.getAppUsage(app.manifestURL).then(usage => {
        usage.invocations++;
        usage.usageTime += time;
        utils.debug(app, 'ran for', time);

        // Save to persistent storage
        this.appSummary.save();
      });

      if (!this.locked && this.appOpenDuration[app.manifestURL]) {
        this.appOpenDuration[app.manifestURL].duration += time;
        utils.debug('appOpenDuration', this.appOpenDuration[app.manifestURL].duration);
      }
    }
  }

  getAppUsage(manifestURL) {
    return new Promise((resolve, reject) => {
      this.appSummary.init().then(() => {
        var usage = this.appSummary.data.apps[manifestURL];
        if (!usage) {
          usage = JSON.parse(JSON.stringify(this.defaultUsage));
          this.appSummary.data.apps[manifestURL] = usage;
        }

        resolve(usage);
      });
    });
  }

  handleDownloadapplied(evt) {
    var app = evt.detail;
    var obj = {};
    var manifest = app.manifest || app.updateManifest;
    obj.appid = manifest.name;
    obj.appver = manifest.version;

    this.accumulateSummary('daily_download', obj);
    this.appActionStore.markAction('installed', app);
    utils.debug('installed ' + JSON.stringify(obj));
  }

  handleDownloaderror(evt) {
    var app = evt.detail;
    if (app.downloadError.name === 'DOWNLOAD_CANCELED') {
      var obj = {};
      var manifest = app.manifest || app.updateManifest;
      obj.appid = manifest.name;
      obj.appver = manifest.version;

      this.accumulateSummary('daily_cancels', obj);
    }

    this.appActionStore.markAction('installfailed', app);
  }

  handleInstall(evt) {
    // We add download Count by one as long as install event comes.
    // We do not care download failure or installation failure here
    this.accumulateSummary('daily_download_count');

    // None packaged app should mare download action here
    if (evt.application.downloadSize == 0) {
      var e = evt.application;
      this.handleDownloadapplied({ detail: e });
    }
  }

  handleUninstall(evt) {
    utils.debug(evt.application);
    var manifest = evt.application.manifest || evt.application.updateManifest;
    var manifestURL = evt.application.manifestURL;

    // DOMApplication object will be reclaimed soon.
    // Save data for later use
    var app = {
      'manifest': {
        'name': manifest.name,
        'version': manifest.version
      },
      'manifestURL': manifestURL
    };
    var obj = {};
    obj.appid = app.manifest.name;
    obj.appver = app.manifest.version;

    this.accumulateSummary('daily_uninstall', obj);
    this.getAppUsage(app.manifestURL).then(usage => {
      app.open_count = usage.openCount;
      this.appActionStore.markAction('uninstall', app);
      utils.debug('uninstall markAction' + JSON.stringify(app));
    });
  }

  handleUpdate(evt) {
    var app = evt.application;
    utils.debug('handleUpdate oldversion');
    utils.debug(app.oldVersion);

    // Skip INSTALL event
    if (app.updateTime === 0) {
      return;
    }
    var manifest = app.manifest || app.updateManifest;
    var manifestURL = app.manifestURL;
    var appObj = {
      'manifest': {
        'name': manifest.name,
        'version_new': manifest.version,
        'version': app.oldVersion || manifest.version
      },
      'manifestURL': manifestURL
    };
    this.getAppUsage(manifestURL).then(usage => {
      appObj.open_count = usage.openCount;
      this.appActionStore.markAction('update', appObj);
    });
  }

  accumulateSummary(type, action) {
    this.appSummary.init().then(() => {
      switch (type) {
        case 'daily_download':
        case 'daily_uninstall':
        case 'daily_cancels':
          this.appSummary.data[type].push(action);
          break;
        case 'daily_download_count':
          this.appSummary.data[type] += 1;
          break;
      }
      utils.debug('AppStatusSummary save storage', type, action);

      this.appSummary.save();
    });
  }

  packSummary() {
    return Promise.all([this.getCurrentInventory(),
      DeviceInfoComposer.getStandardPackage()])
      .then(results => {
        this.appSummary.data['current_inventory'] = results[0];
        var standardPackage = results[1];
        standardPackage['event_type'] = 'app_summary';
        var data = JSON.parse(JSON.stringify(this.appSummary.data));
        standardPackage['data'] = data;
        this.reset();

        return Promise.resolve(standardPackage);
      }).catch(e => {
        utils.debug('packSummary exception');
        return Promise.reject();
      });
  }

  reset() {
    // Ready to collect new summary
    this.appSummary.reset();
  }
}

export default AppStatusCollector;