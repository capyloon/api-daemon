import ActionStore from './action_store';

const KEY = 'EVL_WIFISSID';

class NetworkActionStore extends ActionStore {
  constructor() {
    super('evl_network');
    this.isCallStartManuTimer = 0;
    this.isCallStartManuWait = 1000;
  }

  markAction(type, action) {
    var obj = {};
    switch (type) {
      case 'wifi_on':
        this.save(type, obj);
        break;
      case 'wifi_off':
        this.save(type, obj);
        break;
      case 'wifi_connect':
        if (action) {
          var is_public = action.password === null ||
            action.security.length === 0;
          obj.network_uid = action.ssid;
          obj.is_public = is_public;
          obj.wifi_count = this.setWifiSsidConnected(obj.network_uid);
          this.save(type, obj);
        }
        break;
      case 'call_start':
        if (action) {
          obj.is_contact = action.is_contact;
          obj.call_method = action.call_method;
          this.save(type, obj);
        }
        break;
      case 'call_start_in':
        if (action) {
          obj.is_contact = action.is_contact;
          this.save(type, obj);
        }
        break;
      case 'call_end':
        if (action) {
          obj.is_contact = action.is_contact;
          // TODO
          obj.call_duration = action.call_duration;
          this.save(type, obj);
        }
        break;
      case 'call_reject':
        if (action) {
          obj.is_contact = action.is_contact;
          obj.caller_number = action.caller_number;
          this.save(type, obj);
        }
        break;
      default:
        break;
    }
  }

  setWifiSsidConnected(ssid) {
    var value = localStorage.getItem(KEY);
    var wifiInfo = {};
    var ret = 1;
    try {
      if (value) {
        wifiInfo = JSON.parse(value);
      }
    } catch (e) {
    }
    if (wifiInfo[ssid]) {
      wifiInfo[ssid] += 1;
    } else {
      wifiInfo[ssid] = 1;
    }
    ret = wifiInfo[ssid];
    localStorage.setItem(KEY, JSON.stringify(wifiInfo));

    return ret;
  }

  reset() {
    localStorage.removeItem(KEY);
  }

}

export default NetworkActionStore;