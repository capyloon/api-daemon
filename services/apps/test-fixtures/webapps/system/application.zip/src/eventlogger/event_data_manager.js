import AppStatusCollector from './app_status_collector';
import NetWorkTrafficCollector from './network_traffic_collector';
import DataBufferSummary from './data_buffer_summary';
import * as utils from './utils';

class EventDataManager {
  constructor() {
    this.dataSource = {};
    var collectors = [AppStatusCollector, NetWorkTrafficCollector];
    collectors.forEach((collector) => {
      var cltor = new collector();
      this[cltor.name] = cltor;
      this[cltor.name].start();
      this.dataSource[cltor.name] = this[cltor.name];
    });
  }

  packSummary(from) {
    var p = [];
    Object.entries(this.dataSource).forEach(([name, collector]) => {
      utils.debug('Packing ' + name);
      p.push(collector.packSummary(from));
    });

    p.push(DataBufferSummary.packSummary());

    return Promise.all(p).then(results => {
      var data = [];
      for (var i = 0; i < results.length; i++) {
        data.push(results[i]);
      }
      return Promise.resolve(data);
    }).catch(e => {
      utils.debug('event_data_manager packSummary exception');
      return Promise.reject(e);
    });
  }

  stop() {
    Object.entries(this.dataSource).forEach(([name, collector]) => {
      utils.debug('stop ' + name);
      collector.stop && collector.stop();
    });
  }
}
export default EventDataManager;

