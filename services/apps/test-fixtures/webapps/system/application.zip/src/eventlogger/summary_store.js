import * as utils from './utils';

const POSTPONDTIME = 5 * 1000;

class SummaryStore {
  constructor(category, defaultData) {
    this.category = category;
    this.defaultData = JSON.parse(JSON.stringify(defaultData));
    this.data = JSON.parse(JSON.stringify(defaultData));
    this.timer = 0;
    this.init();
  }

  init() {
    if (this.initPromise) {
      return this.initPromise;
    }

    this.initPromise = new Promise((resolve, reject) => {
      this.load(this.category).then(data => {
        if (data) {
          this.data = data;
        }
        utils.debug('storage init' + JSON.stringify(this.data));
        resolve(this.data);
      });
    });

    return this.initPromise;
  }

  save(isPostpond = true) {
    utils.debug('save storage ', this.category);
    clearTimeout(this.timer);
    if (isPostpond) {
      this.timer = setTimeout(() => {
        try {
          asyncStorage.setItem(this.category, this.data);
        } catch (e) {
          utils.debug('Summary asyncStorage error');
          console.error('Summary asyncStorage error');
        }
      }, POSTPONDTIME);
    } else {
      try {
        asyncStorage.setItem(this.category, this.data);
      } catch (e) {
        utils.debug('Summary asyncStorage error');
        console.error('Summary asyncStorage error');
      }
    }
  }

  reset() {
    asyncStorage.removeItem(this.category);
    this.data = JSON.parse(JSON.stringify(this.defaultData));
  }

  load(category) {
    return new Promise((resolve, reject) => {
      asyncStorage.getItem(category, data => {
        resolve(data);
      });
    });
  }

}

export default SummaryStore;