import EventDataManager from './event_data_manager';
import Scheduler from './scheduler';
import * as utils from './utils';
import { evldb } from './evl_db';
import AppSystemDatastore from './app_system_datastore';
import DeviceInfoComposer from './device_info_composer';
import EVLConfig from './evl_config';

/*
* Simple constants used in this module.
*/
const IDLE = 'idle';
const ACTIVE = 'active';
const IACMETRICS = 'iac-app-metrics';
const ACTION = 'evl_action';
const DSADDED = 'added';
const DB_CAPACITY = 'db_capacity';
const CONFIG_QUOTA = 'config_quota';
const BUFFER_SENT_SUCCESS = 'buffer_sent_success';
const TOKEN_EXPIRATION_TIME_SHIFT_IN_MS = 60 * 60 * 1000;
const TOKEN_EXPIRATION_10_MIN_IN_MS = 10 * 60 * 1000;
const CONSENT_SENT_KEY = 'consent_sent';

// This is the list of event types we register handlers for
const EVENT_TYPES = [
  IACMETRICS,
  ACTION,
  DB_CAPACITY,
  CONFIG_QUOTA
];

class EventLoggerManager {
  constructor() {
  }

  // What setting do we listen to to get user conset to send data
  // to our server.
  TELEMETRY_CONSENT_KEY = 'eventlogger.telemetry.consent';
  // Observe the change and send user consent to server.
  TARGETING_CONSENT_KEY = 'eventlogger.targeting.consent';
  // For age consent.
  AGE_CONSENT_KEY = 'eventlogger.age.consent';

  // 3 minutes
  REPORT_TIMEOUT = 180000;
  // Server for sending data reports
  // Can be overridden with apps.serviceCenterUrl setting.
  REPORT_SERVER = 'https://api.kaiostech.com/v3.0';
  // Server endpoint for sending data reports
  REPORT_ENDPOINT = '/apps/metrics';

  // How much user idle time (in seconds, not ms) do we wait for before
  // persisting our data to asyncStorage or trying to transmit it.
  IDLE_TIME = 15; // seconds

  // Telemetry payload version
  TELEMETRY_VERSION = 2;

  // App name (static for Telemetry)
  TELEMETRY_APP_NAME = 'eventlogger';

  DEVICE_INFO = null;

  // testing purpose
  DB = evldb;

  userConsentTimer = {};

  //
  // The EventLoggerManager constructor does no initialization of any sort.
  // By system app convention, the initialization code is in this start()
  // instance method instead. Note that this is not the same as the
  // startCollecting() method which is only called if the user has actually
  // opted in to telemetry.
  //
  start() {
    this.reset(); // initialize our state variables
    // We start collecting and do not need consent.
    // But we can send summaries only when user does not consent.
    this.startCollecting();
  }

  // This method shuts everything down and is only exposed for unit testing.
  // Note that this is not the same as the stopCollecting() method which is
  // used to stop data collection but keep the module running.
  stop() {
    this.stopCollecting();
    SettingsListener.unobserve(this.TELEMETRY_ENABLED_KEY,
      this.isConsentEnabled.bind(this));
  }

  // Reset (or initialize) the EventLoggerManager instance variables
  reset() {
    // Are we collecting data? This is set to true by startCollecting()
    // and set to false by stopCollecting()
    this.collecting = false;

    // Is the user idle? Updated in handleEvent() based on an idle observer
    this.idle = false;

    // This is object is used to record the device info reading from settings
    this.DEVICE_INFO = null;

    // This is the server URL of receiving metrics data
    this.url = null;
  }

  // Start collecting app usage data. This function is only called if the
  // appropriate setting is turned on. The done callback is called when
  // setup is complete, but this feature is only needed for tests.
  startCollecting(done) {
    var self = this;

    utils.debug('starting app usage metrics collection');

    // If we're already running there is nothing to start
    if (this.collecting) {
      return;
    }
    this.collecting = true;

    SettingsListener.observe(this.TELEMETRY_CONSENT_KEY, false,
      this.isConsentEnabled.bind(this));
    SettingsListener.observe(this.TARGETING_CONSENT_KEY, false,
      this.isTargetingEnabled.bind(this));
    SettingsListener.observe(this.AGE_CONSENT_KEY, false,
      this.isAgeEnabled.bind(this));

    // retry listener.
    this.bindRetryTransmit = this.retryTransmit.bind(this);

    getConfigurationSettings();

    // allowing values in the settings database to override the defaults.
    function getConfigurationSettings() {
      // Settings to query, mapped to default values
      var query = {
        'apps.serviceCenterUrl': self.REPORT_SERVER,
        'deviceinfo.cu': '',
        'app.update.custom': '',
        'deviceinfo.platform_build_id': '',
        'deviceinfo.build_number': ''
      };

      function getSettingsAndRun() {
        utils.getSettings(query, function (result) {
          if (result['apps.serviceCenterUrl'] === "") {
            return;
          }

          self.url = result['apps.serviceCenterUrl'] + self.REPORT_ENDPOINT;
          self.allGet = Object.keys(query).every(key => {
            return (result[key] && result[key] !== '');
          });
          if (self.allGet) {
            utils.debug('All settings get');
            utils.debug(result['deviceinfo.cu']);
            utils.debug(result['app.update.custom']);
            utils.debug(result['apps.serviceCenterUrl']);
            // Move on to the next step in the startup process
            self.DEVICE_INFO = result;
            // Move on to the next step in the startup process
            registerHandlers();
          } else {
            utils.debug('try again');
            utils.debug('self.allGet ' + self.allGet);
            // In order to get non-empty values, we should retry to get values.
            self.timer = setTimeout(getSettingsAndRun, 5000);
          }
        });
      }

      clearTimeout(self.timer);
      getSettingsAndRun();
    }

    function registerHandlers() {
      // Basic event handlers
      EVENT_TYPES.forEach(function (type) {
        window.addEventListener(type, self);
      });

      self.idleObserver = {
        time: self.IDLE_TIME,
        onidle: function () {
          self.handleEvent(new CustomEvent(IDLE));
        },
        onactive: function () {
          self.handleEvent(new CustomEvent(ACTIVE));
        }
      };

      self.eventDataManager = new EventDataManager();
      self.scheduler = new Scheduler();
      self.evlConfig = new EVLConfig();
      var quota = self.evlConfig.CONFIG.buffer_size;
      evldb.setQuota(quota);
      // DB init
      evldb.init().then(() => {
        // testing ONLY
        window.scheduler = self.scheduler;

        // Register for idle events
        navigator.addIdleObserver(self.idleObserver);
        // Recieve events from datastore, only care about added event.
        AppSystemDatastore.addEventListener(DSADDED, self);

        self.startScheduler();

        self.checkAndGenConsent();

        if (done) {
          done();
        }
      });
    }
  }

  // Stop collecting app usage data and discard any we have already collected.
  // This is called if the setting is turned off.
  stopCollecting() {
    utils.debug('stopping app usage data collection and deleting stored data');

    clearInterval(this.timer);

    // If we're not already running there is nothing to stop
    if (!this.collecting) {
      return;
    }
    this.collecting = false;

    // Stop listening to all events
    navigator.removeIdleObserver(this.idleObserver);
    this.idleObserver = null;

    var self = this;
    EVENT_TYPES.forEach(function (type) {
      window.removeEventListener(type, self);
    });
    AppSystemDatastore.removeEventListener(DSADDED, self);

    self.removeSchduler();
    this.eventDataManager.stop();
    this.eventDataManager = null;
    this.evlConfig = null;

    // Reset our state, discarding local copies of metrics and deviceID
    this.reset();
  }

  //
  // This is the heart of this module. It listens to the various events and
  // 1) records app usage data
  // 2) persists app usage data at appropriate times
  // 3) transmits app usage data at appropriate times
  //
  handleEvent(e) {
    var now = performance.now();

    utils.debug('got an event: ', e.type);
    switch (e.type) {

      case IDLE:
        this.idle = true;
        this.evlConfig.getOnlineConfig();
        break;
      case ACTIVE:
        this.idle = false;
        break;
      case IACMETRICS:
        break;
      case ACTION:
        var data = e.detail;
        utils.debug('action event');
        utils.debug(e);
        this.sendOrSave(data);
        break;
      case DSADDED:
        var data = e.target;
        utils.debug('datastore event');
        utils.debug(e);
        // We can save the event_type which is not in the config list.
        // The priority will be 3 on default.
        // The config list can be updated later with connection.
        // Then this event_type can be handled correctly(priority wise).
        if (data && data.event_type) {
          DeviceInfoComposer.getStandardPackage().then(p => {
            // Align the data format
            p['event_type'] = data.event_type;
            delete data.event_type;
            p['data'] = data.data || data;
            this.sendOrSave(p);
          });
        }
        appSystemDatastore.remove(e.id);
        break;
      case DB_CAPACITY:
        if (e.detail.isFull && navigator.onLine) {
          this.transmitOnFull();
        }
        break;
      case CONFIG_QUOTA:
        var quota = parseInt(e.detail.buffer_size);
        if (!isNaN(quota)) {
          evldb.setQuota(quota);
        }
        break;
    }
  }

  startScheduler() {
    this.scheduler.addEventListener('summaryAlarming', e => {
      this.stopRetry();
      // Send from date, to see data consumption till now.
      this.transmitSummary(e.detail);
      // Check and update config
      this.evlConfig.getOnlineConfig();
    });
    this.scheduler.addEventListener('wifi_connected', e => {
      this.evlConfig.getOnlineConfig();
      this.stopRetry();
      this.checkAndSendActions();
    });
    this.scheduler.addEventListener('cell_connected', e => {
      this.stopRetry();
      this.transmitPriorityHigh();
      if (evldb.isFull) {
        this.transmitOnFull();
      }
      this.evlConfig.getOnlineConfig();
    });
    // Call start last to make sure receiving first event
    this.scheduler.start();
  }

  removeSchduler() {
    this.scheduler.stop();
    this.scheduler.event_callbacks = null;
    this.scheduler.event_callbacks = {};
    this.scheduler = null;
  }

  isSending() {
    return this.sending || (this.scheduler && this.scheduler.retryRunning);
  }

  stopRetry() {
    utils.debug('stopRetry');
    this.scheduler.removeEventListener('retryAlarming', this.bindRetryTransmit);
    this.scheduler.removeRetryAlarm();
    this.pKeysSending = null;
  }

  sendOrSave(action) {
    if (!action || (Array.isArray(action) && action.length === 0)) {
      return;
    }

    if (this.isSending() || !navigator.onLine) {
      this.addToDb(action);

      return;
    }

    var dataSave = [];
    var dataSend = [];
    var tmp = [].concat(action);

    tmp.forEach(item => {
      if (this.checkSend(item.event_type)) {
        dataSend.push(item);
      } else {
        dataSave.push(item);
      }
    });

    if (dataSave.length > 0) {
      this.addToDb(dataSave);
    }
    if (dataSend.length > 0) {
      this.sending = true;
      //Save the data in case device power off.
      //Delete them when sent success.
      this.addToDb(dataSend).then(pKeys => {
        this.pKeysSending = pKeys;

        this.send(dataSend).then(r => {
          this.sending = false;
          this.DB.deleteSent(this.pKeysSending);
          this.pKeysSending = null;
          utils.debug('sendOrSave  sent!!!');
          // We are good here, Maybe we should send all prioriy 1 in buffer
        }, e => {
          utils.debug('sendOrSave retrying');
          this.sending = false;
          this.scheduler.addEventListener('retryAlarming', this.bindRetryTransmit);
          this.scheduler.newRetryAlarm(action);
        });
      }).catch(() => {
        //Something wrong to save DB, or it's full.
        //We are still sending it.
        this.send(dataSend).then(r => {
          this.sending = false;
          this.DB.deleteSent(this.pKeysSending);
          this.pKeysSending = null;
          utils.debug('sendOrSave  sent!!!');
          // We are good here, Maybe we should send all prioriy 1 in buffer
        }, e => {
          utils.debug('sendOrSave retrying');
          this.sending = false;
          this.scheduler.addEventListener('retryAlarming', this.bindRetryTransmit);
          this.scheduler.newRetryAlarm(action);
        });
      });
    }
  }

  checkSend(type) {
    var eventType = this.evlConfig.CONFIG.events[type];
    // Send low priority in wifi mode only when consent
    return (eventType && eventType.priority == 1) ||
      (eventType && this.scheduler.hasWifiConnection() && this.consentEnabled);
  }

  addToDb(action) {
    if (!action) {
      return Promise.reject();
    }
    var arrData = [].concat(action);
    var p = [];
    arrData.forEach(data => {
      var pirority = this.evlConfig.getPriority(data.event_type);
      p.push(this.addObj(data, pirority));
    });

    return Promise.all(p).then(results => {
      return Promise.resolve(results);
    }).catch(e => {
      utils.debug('addToDb exception');
      return Promise.reject(e);
    });
  }

  addObj(obj, pirority) {
    return evldb.add(obj, pirority);
  }

  retryTransmit(e) {
    if (e.data && !e.stopped && navigator.onLine) {
      utils.debug('sendRetry');
      this.send(e.data).then(result => {
        utils.debug('Event Logger retry transmission Summary success: ', result);
        this.DB.deleteSent(this.pKeysSending).then(() => {
          // We have good connection, tries to send data with high pirority.
          this.transmitPriorityHigh();
        });
        this.stopRetry();
      }, e => {
        // No thing to do here, wait for next alarm
        utils.debug('Event Logger retry transmission Summary failure:', e);
      });
    } else if (e.data && !e.stopped && !navigator.onLine) {
      utils.debug('connection failed during retry, save data to db');
      this.stopRetry();
    } else if (e.stopped) {
      // Scheduler stopped because retry exceeded
      utils.debug('Retry failed, add data to db');
      this.stopRetry();
    }
  }

  checkAndSendActions() {
    if (this.consentEnabled) {
      if (this.bTransmitAll) {
        utils.debug(`checkAndSendActions ${this.bTransmitAll} clearTimeout and return`);
        return;
      }
      // We wait all the other network actions stop
      clearTimeout(this.transmitAllTimer);
      if (this.scheduler.hasWifiConnection()) {
        this.transmitAllTimer = setTimeout(this.transmitAll.bind(this), 10000);
      } else {
        // We wait all the other network actions stop
        clearTimeout(this.transmitPrioHighTimer);
        this.transmitPrioHighTimer = setTimeout(this.transmitPriorityHigh.bind(this), 10000);
      }
    } else {
      // We wait all the other network actions stop
      clearTimeout(this.transmitPrioHighTimer);
      this.transmitPrioHighTimer = setTimeout(this.transmitPriorityHigh.bind(this), 10000);
    }
  }

  transmitAll() {
    utils.debug('transmitAll');
    this.bTransmitAll = true;
    evldb.getAll().then(data => {
      if (Array.isArray(data) && data.length === 0) {
        this.bTransmitAll = false;
        return;
      }
      this.send(data).then(result => {
        utils.debug(' send All');
        this.flushEvlDb().then(() => {
          this.bTransmitAll = false;
        }).catch(() => {
          this.bTransmitAll = false;
        });
        // For data buffer summary
        asyncStorage.setItem(BUFFER_SENT_SUCCESS, Date.now());
      }, e => {
        this.bTransmitAll = false;
        // No thing to do here, wait for next alarm
        utils.debug('Event Logger retry transmission Summary failure:', e);
      });
    });
  }

  transmitPriorityHigh() {
    utils.debug('transmitPriorityHigh');
    this.readAndSend(this.evlConfig.PRIORITY_HIGHT);
  }

  transmitOnFull() {
    // Do not send without user consent
    if (!this.consentEnabled) {
      utils.debug('user does not consent, stop transmitOnFull');
      return;
    }

    utils.debug('transmitOnFull');
    this.readAndSend(this.evlConfig.PRIORITY_ONFULL);
  }

  readAndSend(types) {
    evldb.read('event_type', types).then(data => {
      if (Array.isArray(data) && data.length === 0) {
        return;
      }
      this.send(data).then(result => {
        if (this.testKeepData) {
          return;
        }
        utils.debug(' send transmitPriority success clearing DB');
        evldb.delete('event_type', types);
      }, e => {
        utils.debug('Event Logger readAndSend failure: ' + types[0], e);
      });
    });
  }

  transmitSummary(fromDate) {
    return new Promise((resolve, reject) => {
      utils.debug('transmitSummary date is ' + fromDate);
      this.eventDataManager.packSummary(fromDate).then(data => {
        this.sendOrSave(data);
      }, e => {
        //reject({ reason: 'no data' });
        utils.debug('No data available');
      });
    });
  }

  send(data) {
    return new Promise((resolve, reject) => {
      var params = {
        did: this.DEVICE_INFO['app.update.custom'],
        curef: this.DEVICE_INFO['deviceinfo.cu'],
        version: this.TELEMETRY_VERSION,
        data: window.btoa(JSON.stringify([].concat(data)))
      };
      utils.debug('sending data ');
      utils.debug(data);

      this.getRestrictedToken().then(token => {
        var requester = new Requester(this.REPORT_TIMEOUT);
        requester.setDeviceInfo({
          ct: DeviceInfoComposer.connectionType(),
          utc: DeviceInfoComposer.getTimeStamp(),
          utcOff: DeviceInfoComposer.getTimeZoneOffset(),
          buildID: this.DEVICE_INFO['deviceinfo.platform_build_id'],
          buildNumber: this.DEVICE_INFO['deviceinfo.build_number']
        });
        requester.setHawkCredentials(token.kid, token.macKey);
        return requester.send({
          url: this.url,
          method: 'POST',
          params: params
        });
      }).then(result => {
        resolve(result);
        // If in Wifi mode, we try to send all the actions in DB.
        // Until DB is empty.
        this.checkAndSendActions();
      }).catch(error => {
        // Invalid token to get a new one
        if (error && error.status == 401) {
          this.cachedRestrictedToken = null;
          this.tokenExpirationDate = 0;
        }
        console.error('[ELM] Error sending ' + error.status);
        console.error('[ELM] Error sending ' + error.responseText);
        reject(error);
      });
    });
  }

  getRestrictedToken() {
    return new Promise((resolve, reject) => {
      if (this.cachedRestrictedToken && this.tokenExpirationDate > Date.now()) {
        // use cached token
        resolve(this.cachedRestrictedToken);

        return;
      }
      // fetch restricted token
      navigator.kaiAuth.getRestrictedToken('metrics')
        .then((credential) => {
          var expires_in = 0;
          if ('expiresInSeconds' in credential) {
            expires_in = credential.expiresInSeconds * 1000;
            expires_in -= TOKEN_EXPIRATION_TIME_SHIFT_IN_MS;
          } else {
            expires_in = TOKEN_EXPIRATION_10_MIN_IN_MS;
          }
          this.cachedRestrictedToken = credential;
          this.tokenExpirationDate = expires_in + Date.now();
          resolve(this.cachedRestrictedToken);
        }).catch((e) => {
          utils.debug('getRestrictedToken failed with status: ' + e);
          this.cachedRestrictedToken = null;
          this.tokenExpirationDate = 0;
          reject();
        });
    });
  }

  flushEvlDb() {
    if (this.testKeepData) {
      return;
    }
    utils.debug('db clear');

    return evldb.clear();
  }

  saveUerConsent(type, isConsent) {
    // Avoid generating duplicate actions,
    // When user keeps cheking and un-checking.
    clearTimeout(this.userConsentTimer[type]);
    this.userConsentTimer[type] = setTimeout(() => {
      DeviceInfoComposer.getStandardPackage().then(p => {
        utils.debug('saveUerConsent', type, isConsent);
        p['event_type'] = type;
        p['data'] = { consent: isConsent };

        this.sendOrSave(p);
      });
    }, 10000);
  }

  checkAndGenConsent() {
    if (!FtuLauncher.isFtuRunning() && !this.checkFirstConsentSent()) {
      // When User finishes FTU quickly
      this.sendFirstConsent();
      utils.debug('!FtuLauncher.isFtuRunning() && !this.checkFirstConsentSent()');
    } else if (FtuLauncher.isFtuRunning() && !this.checkFirstConsentSent()) {
      // Normal case when User finish FTU
      utils.debug('FtuLauncher.isFtuRunning() && !this.checkFirstConsentSent()');
      // Check and Generate consent once at FTU
      window.addEventListener('ftudone', () => {
        this.sendFirstConsent();
      });
      window.addEventListener('ftuskip', () => {
        this.sendFirstConsent();
      });
    } else {
      // Do nothing for normal bootup
      utils.debug('Do nothing for normal bootup, consentChecked true');
      this.consentChecked = true;
    }
  }

  sendFirstConsent() {
    var composeConsent = function (base, type, isConsent) {
      var packData = JSON.parse(JSON.stringify(base));
      packData['event_type'] = type;
      packData['data'] = { consent: isConsent };

      return packData;
    };

    DeviceInfoComposer.getStandardPackage().then(p => {
      utils.debug('sendFirstConsent');
      var all = [];
      all.push(composeConsent(p, 'telemetry_consent', this.consentEnabled));
      all.push(composeConsent(p, 'targeting_consent', this.targetingConsent));
      all.push(composeConsent(p, 'age_consent', this.ageConsent));
      this.sendOrSave(all);
    });

    localStorage.setItem(CONSENT_SENT_KEY, 1);
    this.consentChecked = true;
  }

  checkFirstConsentSent() {
    return localStorage.getItem(CONSENT_SENT_KEY) == 1;
  }

  isConsentEnabled(value) {
    utils.debug('telemetry_consent', value);
    this.consentEnabled = value;
    // Send consent after FTU and every bootup check
    if (this.consentChecked) {
      this.saveUerConsent('telemetry_consent', value);
    }
  }

  isTargetingEnabled(value) {
    this.targetingConsent = value;
    utils.debug('targeting_consent', value);
    // Send consent after FTU
    if (this.consentChecked) {
      this.saveUerConsent('targeting_consent', value);
    }
  }

  isAgeEnabled(value) {
    this.ageConsent = value;
    utils.debug('age_consent', value);
    // Send consent after FTU
    if (this.consentChecked) {
      this.saveUerConsent('age_consent', value);
    }
  }
}

const instance = new EventLoggerManager();
instance.start();
window.evlm = instance;