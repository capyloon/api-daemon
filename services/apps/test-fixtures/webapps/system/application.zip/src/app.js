/* global Service */

import './custom_elements/pin-lock';
import './custom_elements/air-deck.js';
import './custom_elements/app-root.js';
import './custom_elements/lock-screen';
import './custom_elements/infogation-bar.js';
import './custom_elements/instant-panel.js';
import './custom_elements/keyboard-app.js';
import './custom_elements/text-selector.js';
import './custom_elements/value-selector.js';
import './custom_elements/time-picker.js';
import './custom_elements/date-picker.js';
import './custom_elements/action-menu.js';
import './custom_elements/sleep-menu.js';
import './custom_elements/standalone-notification.js';
import './custom_elements/dialog-service.js';
import './custom_elements/sim-security.js';
import './custom_elements/app-toast.js';
import './custom_elements/remote-lock.js';

import Requester from 'hawk-requester';

import KeypadBacklightManager from './keypad_backlight_manager';
import Voicemail from './voicemail';
import TemperatureMonitor from './temperature_monitor';
import MediaStorageMonitor from './media_storage_monitor';
import OtpFetcher from './otp_fetcher';
import ApplicationData from './application_data_clean';
import DeviceStorageWatcher from './storage_watcher';
import GoogleVoiceAssistant from './google_voice_assistant.js';

import './app_store';
import './eventlogger/eventlogger_manager';
import './sim_config';
import './feature_detector';
import '../scss/app.scss';

window.Requester = Requester;
