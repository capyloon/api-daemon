export const mode = Object.freeze({
  // There are 4 modes in SFP: none, pocket, passcode, remotePasscode
  // The following are new modes for TP:
  LOCKED: 'locked',
  LOCKED_WITH_INSTANT_PANEL: 'instant',
  PASSCODE: 'passcode',
  UNLOCKING: 'unlocking',
  UNLOCKED: 'none',
});
