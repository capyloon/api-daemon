export const PASSCODE_LIMIT = 6;
