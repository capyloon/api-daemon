import BaseModule from 'base-module';

class KeypadBacklightManager extends BaseModule {

  name = 'KeypadBacklightManager';

  TURN_OFF_TIME = 60000;
  DECREASE_BRIGHTNESS_TIME = 10000;

  _turnOffTimer = null;
  _decreaseBrightnessTimer = null;

  DEBUG = false;

  start() {
    Service.register('turnKeypadBacklightOn', this);
    window.addEventListener('screenchange', this);
  }

  turnKeypadBacklightOn() {
    if (this._turnOffTimer) {
      this.clearTimer();
    }
    this.turnOn();
    this.createTimer();
  }

  turnKeypadBacklightOff() {
    this.clearTimer();
    this.turnOff();
  }

  turnOn() {
    window.navigator.mozPower.keyLightEnabled = true;
    window.navigator.mozPower.keyLightBrightness = 0.5;
    this.debug('set keyLightEnabled = true, keyLightBrightness = 0.5');
  }

  turnOff() {
    window.navigator.mozPower.keyLightEnabled = false;
    this.debug('set keyLightEnabled = false');
  }

  createTimer() {
    this._turnOffTimer = setTimeout(() => {
      window.navigator.mozPower.keyLightEnabled = false;
      this.debug('set keyLightEnabled = false');
    }, this.TURN_OFF_TIME);

    this._decreaseBrightnessTimer = setTimeout(() => {
      window.navigator.mozPower.keyLightBrightness = 0.1;
      this.debug('set keyLightBrightness = 0.1');
    }, this.DECREASE_BRIGHTNESS_TIME);
  }

  clearTimer() {
    clearTimeout(this._turnOffTimer);
    clearTimeout(this._decreaseBrightnessTimer);
  }

  _handle_screenchange(evt) {
    if (evt.detail.screenEnabled) {
      this.turnKeypadBacklightOn();
    } else {
      this.turnKeypadBacklightOff();
    }
  }
}

var instance = new KeypadBacklightManager();
instance.start();

export default instance;
