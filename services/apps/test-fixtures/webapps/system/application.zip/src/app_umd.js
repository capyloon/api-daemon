/**
 * Migrate the dependecies of `<script>` in index.html here.
 * For `<script defer>`, use `app_umd_defer.js`.
 *
 * The general steps would be:
 *   - find the most top `<script>`
 *   - move `shared/js/{name}.js` or `js/{name}.js` to `src/app_umd/{name}.js`
 *   - load the file by adding `require('./app_umd/{name}.js')`
 *   (optional)
 *   - refactor `{name}.js`
 *     - remove IIFE
 *     - identify global dependencies and replace with es6 `import` if possible
 *     - deprecate adding variable to `window`
 *     - use es6 `export`
 *
 * Why `require` not `import`?
 *   - because `import` executed asynchronously
 *   - and we cannot guarantee the modules are loaded as the order of origin `<script>` tags
 *   - see https://stackoverflow.com/questions/35551366/what-is-the-defined-execution-order-of-es6-imports
 */
import './app_umd/theme.js';
import mozL10n from './app_umd/l10n.js';
import {
  setIdleTimeout,
  clearIdleTimeout
} from './app_umd/idletimer.js';
import { DUMP } from './util/logger.js';

navigator.mozL10n = mozL10n;
window.setIdleTimeout = setIdleTimeout;
window.clearIdleTimeout = clearIdleTimeout;

window.DUMP = DUMP;

// Attach modules to global object.
// Do `require` looply for less code.
// These modules have clear dependencies and can be `import` or `require` in any order.
const moduleMap = {
  'settings_helper': 'SettingsHelper',
  'applications': 'applications',
  'logo_loader': 'LogoLoader',
  'init_logo_handler': 'CustomLogoPath',
};
let properties = {};
Object.entries(moduleMap).forEach(([ filename, moduleName ]) => {
  properties[moduleName] = {
    value: require(`./app_umd/${filename}.js`).default
  };
});
Object.defineProperties(window, properties);

// if (!window.MozMobileConnection.prototype.getSupportedNetworkTypes) {
//   window.MozMobileConnection.prototype.getSupportedNetworkTypes = () => Promise.resolve([]);
// }
if (!navigator.usb) {
  navigator.usb = {
    deviceAttached: false,
    deviceConfigured: false,
    onusbstatuschange: () => {}
  };
}
