import BaseModule from 'base-module';

/**
 * DeviceStorageWatcher listens for nsIDOMDeviceStorage.onchange events
 * notifying about low device storage situations (see Bug 861921). When a
 * 'onchange' event containing a 'low-disk-space' reason is received, we show a
 * banner for a few seconds and pin a notification in the notifications center.
 * When the reason of the 'onchange' event is 'available-disk-space', we remove
 * the pinned notification, if one exists.
*/

class DeviceStorageWatcher extends BaseModule {
  name = 'DeviceStorageWatcher';

  LOW_DISK_NOTIF_ID = 'low-disk-space';

  CHECK_INTERVAL = 10000;

  start() {
    this._ = navigator.mozL10n.get;
    this._intervalHandler = null;
    this._appStorage = navigator.getDeviceStorage('apps');
    this._appStorage.addEventListener('change', this);
    this._firstCheck = true;
    this._firstShow = true;
    window.addEventListener('homescreenopened', this);
    window.addEventListener('mozChrome-almost-low-disk-space', this);
    this.startStorageMonitor();
  }

  startStorageMonitor() {
    this.stopStorageMonitor();
    this._intervalHandler = window.setInterval(this.storageCheck.bind(this),
      this.CHECK_INTERVAL);
  }
  stopStorageMonitor() {
    this._intervalHandler && window.clearInterval(this._intervalHandler);
    this._intervalHandler = null;
  }

  storageCheck() {
    this.getFreeSpaceSize().then(space => {
      // 50M
      if (space > 0x3200000) {
        this.stopStorageMonitor();
        this.hideNotification();
      } else {
        if (this._firstCheck) {
          this.showAlmostNotification();
        }
      }
      this._firstCheck = false;
    });
  }

  hideNotification() {
    this.notification && this.notification.close();
    this.notification = null;
  }

  getFreeSpaceSize() {
    let promise = new Promise(resolve => {
      let req = this._appStorage.freeSpace();
      req.onsuccess = () => resolve(req.result);
      req.onerror = () => resolve();
    });
    return promise;
  }

  launchSettings() {
    let activity = new window.MozActivity({
      name: 'configure',
      data: {
        section: 'mediaStorage'
      }
    });
    activity.onsuccess = () => {
      this.showStorageFullDialog();
    };
    activity.onerror = () => {
      this.showStorageFullDialog();
    };
  }

  showAlmostNotification() {
    this.notification = new Notification(this._('storage-alert'), {
      body: this._('phone-almost-full'),
      tag: 'phone-almost-full',
      mozbehavior: {
        showOnlyOnce: true
      }
    });
    this.notification.onclick = () => {
      this.notification.close();
      const id = 'low-storage-1-warning-dialog';
      const config = {
        id,
        title: this._('storage-full-level-1-title'),
        message: this._('delete-to-get-space'),
        primarybtntext: this._('settings'),
        secondarybtntext: this._('cancel'),
        onDialogPrimaryBtnClick: () => {
          this.launchSettings();
          Service.request('DialogService:hide', id);
        },
        onDialogSecondaryBtnClick: () => {
          Service.request('DialogService:hide', id);
        },
      };
      Service.request('DialogService:show', config);
    };
  }

  showStorageFullDialog() {
    let topMostWindow = Service.query('getTopMostWindow');
    if (topMostWindow && topMostWindow.isHomescreen) {
      if (this._hitLowestLevel) {
        const id = 'low-storage-2-warning-dialog';
        const config = {
          id,
          title: this._('storage-full-level-2-title'),
          message: this._('delete-to-get-space-level-2'),
          primarybtntext: this._('settings'),
          secondarybtntext: this._('cancel'),
          onDialogPrimaryBtnClick: () => {
            this._firstShow = false;
            this.launchSettings();
            Service.request('DialogService:hide', id);
          },
          onDialogSecondaryBtnClick: () => {
            this._firstShow = false;
            Service.request('DialogService:hide', id);
          },
        };
        Service.request('DialogService:show', config);
      }
    }
  }

  hideStorageFullDialog() {
    const id = 'low-storage-2-warning-dialog';
    Service.request('DialogService:hide', id);
  }

  _handle_homescreenopened(evt) {
    if (evt.detail.isHomescreen) {
      this.showStorageFullDialog();
    }
  }

  '_handle_mozChrome-almost-low-disk-space'() {
    this.startStorageMonitor();
    this.showAlmostNotification();
  }

  _handle_change(evt) {
    switch (evt.reason) {
      // We get 'onchange' events with a 'low-disk-space' reason when a
      // modification of a file is identified while the device is in a low
      // storage situation. When we get the first notification, we have to
      // show a system banner and pin a notification in the notifications
      // center, containing the remaining free space. Consecutive events with
      // a 'low-disk-space' reason will only update the remaining free space.
      case 'low-disk-space':
        this._hitLowestLevel = true;
        this.stopStorageMonitor();
        if (this._firstCheck) {
          this._firstCheck = false;
        }
        if (this._firstShow) {
          this.showStorageFullDialog();
        }
        break;
      case 'available-disk-space':
        this.hideStorageFullDialog();
        this._hitLowestLevel = false;
        this._firstShow = false;
        this.startStorageMonitor();
        break;
    }
  }
}

const instance = new DeviceStorageWatcher();
instance.start();
window.dsw = instance;

export default instance;
