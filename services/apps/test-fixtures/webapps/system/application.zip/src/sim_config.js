import BaseModule from 'base-module';

class SimConfig extends BaseModule {
  name = 'SimConfig';
  type = '';
  ftuReady = false;
  simcardReady = false;
  lastApplyIccId = '';
  lastIccId = '';
  iccId = '';
  configEnabled = false;
  start() {
    Service.register('showConfigMessage', this);
    let lock = navigator.mozSettings.createLock();
    let req = lock.get('sim.base.customization.enabled');
    req.onsuccess = () => {
      this.configEnabled = !!req.result['sim.base.customization.enabled'] ||
        req.result['sim.base.customization.enabled'] === undefined;
      this.checkSimConfig();
    };
    // TODO(fabrice): FIXME
    // this.lastApplyIccId = localStorage.getItem('sim.config.apply.iccid');
    // this.lastIccId = localStorage.getItem('sim.config.check.iccid');

    this.EVENTS.forEach((evt) => {
      window.addEventListener(evt, this);
    });
  }

  EVENTS = [
    'iac-ftucomms',
    'ftuskip',
    'simslot-iccinfochange',
    'simslot-cardstatechange'
  ];

  '_handle_simslot-cardstatechange'() {
    this.checkSimCardState();
  }

  '_handle_simslot-iccinfochange'() {
    this.checkSimCardState();
  }

  checkSimCardState() {
    this.iccId = navigator.mozMobileConnections[0].iccId;
    if (this.iccId && this.lastIccId !== this.iccId &&
      this.lastApplyIccId !== this.iccId) {
      let iccManager = window.navigator.mozIccManager;
      let iccCard = iccManager.getIccById(this.iccId);
      if (iccCard.cardState === 'ready') {
        this.simcardReady = true;
        this.checkSimConfig();
      }
    }
  }

  _handle_ftuskip() {
    this.ftuReady = true;
    this.checkSimCardState();
  }

  '_handle_iac-ftucomms'(evt) {
    if (evt.detail.type === 'step' && evt.detail.hash !== '#languages' &&
      evt.detail.hash !== '#input-method') {
      this.ftuReady = true;
      this.checkSimCardState();
    }
  }

  checkSimConfig() {
    console.log('sim-config ' +
      this.ftuReady + this.configEnabled + this.simcardReady);
    if (this.ftuReady && this.simcardReady && this.configEnabled) {
      this.configEnabled = false;
      if (!this.lastApplyIccId) {
        this.showConfigMessage('init');
      } else {
        this.showConfigMessage('change');
      }
    }
  }

  getCarrierName(cardIndex) {
    let conn = navigator.mozMobileConnections[cardIndex];
    let name = conn.voice && conn.voice.network && conn.voice.network.longName;
    let _ = navigator.mozL10n.get;
    if (!name) {
      name = window.navigator.mozIccManager.getIccById(this.iccId).iccInfo.spn;
      name = name || _('simLabel', { id: cardIndex + 1 });
    }
    return name;
  }

  showConfigMessage(type) {
    let buttonMsg;
    let _ = navigator.mozL10n.get;
    let msgContent = '';
    switch (type) {
      case 'init':
        buttonMsg = 'sim-config-button-begin';
        msgContent = _('sim-config-content-init', {
          carrier: this.getCarrierName(0)
        });
        break;
      case 'change':
        buttonMsg = 'yes';
        msgContent = _('sim-config-content-change', {
          carrier: this.getCarrierName(0)
        });
        break;
      case 'restart':
        buttonMsg = 'sim-config-button-restart';
        msgContent = _('sim-config-content-line1') + '\n' +
          _('sim-config-content-restart');
        break;
      case 'finish':
        buttonMsg = 'ok';
        msgContent = _('sim-config-content-line1') + '\n' +
          _('sim-config-content-finish');
        break;
      case 'failed':
        buttonMsg = 'ok';
        msgContent = _('sim-config-content-failed', {
          carrier: this.getCarrierName(0)
        });
        break;
      default:
        return;
    }
    this.type = type;
    const id = 'sim-config-dialog';
    const config = {
      id,
      title: _('sim-config-title'),
      message: msgContent,
      primarybtntext: _(buttonMsg),
      secondarybtntext: type === 'change' ? _('no') : '',
      onDialogPrimaryBtnClick: () => {
        if (this.type === 'init' || this.type === 'change') {
          let matchInfo = { clientId: '0' };
          localStorage.setItem('sim.config.check.iccid', this.iccId);
          this.lastIccId = this.iccId;
          navigator.customization.applyVariant(matchInfo).then(
            result => {
              localStorage.setItem('sim.config.apply.iccid', this.iccId);
              this.lastApplyIccId = this.iccId;
              if (result.shouldReboot === true) {
                this.showConfigMessage('restart');
              } else {
                this.showConfigMessage('finish');
              }
            },
            reason => {
              this.showConfigMessage('failed');
            }
          );
        } else if (this.type === 'restart') {
          Service.request('restart');
        }
        Service.request('DialogService:hide', id);
      },
      onDialogSecondaryBtnClick: () => {
        localStorage.setItem('sim.config.check.iccid', this.iccId);
        this.lastIccId = this.iccId;
        Service.request('DialogService:hide', id);
      },
    };
    Service.request('DialogService:show', config);
  }
}
var instance = new SimConfig();
instance.start();
window.simConfig = instance;
export default instance;
