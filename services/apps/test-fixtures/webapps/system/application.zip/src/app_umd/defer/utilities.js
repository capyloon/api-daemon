// Taken (and modified) from /apps/sms/js/searchUtils.js
// and /apps/sms/js/utils.js
const HtmlHelper = {
  createHighlightHTML: function ut_createHighlightHTML(text, searchRegExp) {
    if (!searchRegExp) {
      return this.escapeHTML(text);
    }
    searchRegExp = new RegExp(searchRegExp, 'gi');
    var sliceStrs = text.split(searchRegExp);
    var patterns = text.match(searchRegExp);
    if (!patterns) {
      return this.escapeHTML(text);
    }
    var str = '';
    for (var i = 0; i < patterns.length; i++) {
      str = str +
        this.escapeHTML(sliceStrs[i]) + '<span class="highlight">' +
        this.escapeHTML(patterns[i]) + '</span>';
    }
    str += this.escapeHTML(sliceStrs.pop());
    return str;
  },

  escapeHTML: function ut_escapeHTML(str, escapeQuotes) {
    var span = document.createElement('span');
    span.textContent = str;

    // Escape space for displaying multiple space in message.
    span.innerHTML = span.innerHTML.replace(/\s/g, '&nbsp;');

    if (escapeQuotes)
    {return span.innerHTML.replace(/"/g, '&quot;').replace(/'/g, '&#x27;');} //"
    return span.innerHTML;
  },

  // Import elements into context. The first argument
  // is the context to import into, each subsequent
  // argument is the id of an element to import.
  // Elements can be accessed using the camelCased id
  importElements: function importElements(context) {
    var ids = [].slice.call(arguments, 1);
    ids.forEach(function(id) {
      context[StringHelper.camelCase(id)] = document.getElementById(id);
    });
  }

};

const StringHelper = {
  fromUTF8: function ut_fromUTF8(str) {
    var buf = new Uint8Array(str.length);
    for (var i = 0; i < str.length; i++) {
      buf[i] = str.charCodeAt(i);
    }
    return buf;
  },

  camelCase: function ut_camelCase(str) {
    var rdashes = /-(.)/g;
    return str.replace(rdashes, function replacer(str, p1) {
      return p1.toUpperCase();
    });
  }
};

export {
  HtmlHelper,
  StringHelper
};
