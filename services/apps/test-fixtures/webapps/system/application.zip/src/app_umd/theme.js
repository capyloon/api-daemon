import SettingsManager from 'settings-manager';
import logger from '../util/logger.js';

const log = logger('app_umd/theme.js');

// we will change href dynamically when theme.selected changed
let localThemeElement = document.createElement('link');
localThemeElement.rel = 'stylesheet';
localThemeElement.type = 'text/css';
localThemeElement.href = '';

// append localThemeElement just after the themeElement
const themeElement = document.querySelector('link[href$="theme.css"]');
themeElement.parentNode.insertBefore(localThemeElement, themeElement.nextSibling);

SettingsManager.addObserver('theme.selected', (value) => {
  if (!value) {
    console.warn('invalid theme.selected was set:', value, ', use darktheme');
    value = 'app://darktheme.gaiamobile.org/manifest.webapp';
  }
  // e.g.
  // value == http://darktheme.local/manifest.webapp
  // themeName == darktheme
  const themeName = value.replace('https://', '').split('.')[0];
  localThemeElement.href = `style/${themeName}.css`;
  log('theme changed and update local theme:', value, localThemeElement);
});
