import Service from './defer/service.js';
import LogoLoader from './logo_loader.js';

const CustomLogoPath = (function() {

  const DEFAULT_RESOURCES = {
    poweron: {
      video: 'resources/power/carrier_power_on.mp4',
      image: 'resources/power/carrier_power_on.png'
    },
    poweroff: {
      video: 'resources/power/carrier_power_off.mp4',
      image: 'resources/power/carrier_power_off.png'
    },
    oslogo: {
      video: null,
      image: 'https://gaia.local/shared/resources/branding/official/initlogo.png'
    },
    cleanup: {
      video: 'resources/power/clean_up_memory.mp4',
      image: null
    }
  };

  var _poweron = {};
  var _poweroff = {};
  var _oslogo = {};
  var _cleanup = {};

  function setDefaultValues() {
    _poweron.video = DEFAULT_RESOURCES.poweron.video;
    _poweron.image = DEFAULT_RESOURCES.poweron.image;
    _poweroff.video = DEFAULT_RESOURCES.poweroff.video;
    _poweroff.image = DEFAULT_RESOURCES.poweroff.image;
    _cleanup.video = DEFAULT_RESOURCES.cleanup.video;
    _cleanup.image = DEFAULT_RESOURCES.cleanup.image;
    _oslogo.image = DEFAULT_RESOURCES.oslogo.image;
  }

  function init(aNext) {
    setDefaultValues();
    aNext && aNext();
  }

  return {
    get poweron() {
      return _poweron;
    },
    get poweroff() {
      return _poweroff;
    },
    get oslogo() {
      return _oslogo;
    },
    get cleanup() {
      return _cleanup;
    },
    init: init
  };
})();

// Function to animate init starting logo
var InitLogoHandler = {
  name: 'InitLogoHandler',
  ready: false,
  animated: false,
  readyCallBack: null,
  logoLoader: null,
  EVENT_PREFIX: 'initlogo',
  publish: function(evtName) {
    window.dispatchEvent(new CustomEvent(this.EVENT_PREFIX + evtName, {
      detail: this
    }));
  },

  get carrierLogo() {
    delete this.carrierLogo;
    return (this.carrierLogo = document.getElementById('carrier-logo'));
  },

  get osLogo() {
    delete this.osLogo;
    return (this.osLogo = document.getElementById('os-logo'));
  },

  cleanupMemory() {
    if (!this.cleanDOM) {
      this.cleanDOM = document.getElementById('cleanup');
      const transCleanup = () => {
        this.cleanDOM.removeEventListener('transitionend', transCleanup);
        this.cleanDOM.innerHTML = '';
        this.cleanDOM.classList.remove('fadeOut');
        this.cleanDOM.classList.remove('active');
      };
      this.cleanDOM.addEventListener('transitionend', transCleanup);
    }
    this.cleanDOM.classList.add('active');
    this.loader = new LogoLoader(CustomLogoPath.cleanup);
    this.loader.onload = () => {
      this.cleanDOM.appendChild(this.loader.element);
      this.loader.element.onended = () => {
        this.loader = null;
        navigator.minimizeMemoryUsage && navigator.minimizeMemoryUsage();
        window.requestAnimationFrame(() => {
          this.cleanDOM.classList.add('fadeOut');
        });
      };
      this.loader.element.play();
    };
  },

  init: function ilh_init(logoLoader) {
    var self = this;

    window.addEventListener('ftuopen', this);
    window.addEventListener('ftuskip', this);
    this.logoLoader = logoLoader;
    logoLoader.onnotfound = function() {
      self._removeCarrierPowerOn();
      self._playDefaultPowerOnSound();
    };
    this.oslogoLoader = new LogoLoader(CustomLogoPath.oslogo);
    this.oslogoLoader.onload = () => {
      if (this.osLogo) {
        this._appendOsLogo();
      } else {
        document.addEventListener('DOMContentLoaded',
          this._appendOsLogo.bind(this));
      }
    };

    logoLoader.onload = () => {
      if (this.carrierLogo) {
        this._appendCarrierPowerOn();
      } else {
        document.addEventListener('DOMContentLoaded',
          this._appendCarrierPowerOn.bind(this));
      }
    };

    if (window.Service) {
      Service.request('registerHierarchy', this);
      Service.register('cleanMemory', this);
    }
  },

  _playDefaultPowerOnSound: function() {
    var self = this;

    window.addEventListener('mozChromeEvent', function startOsLogoSound(e) {
      if (e.detail.type !== 'system-first-paint') {
        return;
      }

      var deletePowerOnAudio = function() {
        self.osLogoSoundElement.remove();
        delete self.osLogoSoundElement;
      };

      self.osLogoSoundElement = document.createElement('audio');
      self.osLogoSoundElement.src = '/resources/sounds/poweron-sound.ogg';
      self.osLogoSoundElement.preload = 'auto';
      self.osLogoSoundElement.mozAudioChannelType = 'publicnotification';

      self.osLogoSoundElement.addEventListener('ended', deletePowerOnAudio);
      self.osLogoSoundElement.addEventListener('error', deletePowerOnAudio);
      self.osLogoSoundElement.addEventListener('canplaythrough', function() {
        self.osLogoSoundElement.play();
      }, false);

      self.osLogo.appendChild(self.osLogoSoundElement);
    });
  },

  respondToHierarchyEvent: function(evt) {
    if (this['_handle_' + evt.type]) {
      return this['_handle_' + evt.type](evt);
    } else {
      return true;
    }
  },

  _handle_home: function ilh_handle_home() {
    if (this.isActive()) {
      return false;
    }

    return true;
  },

  _handle_holdhome: function ilh_handle_holdhome() {
    if (this.isActive()) {
      return false;
    }

    return true;
  },

  handleEvent: function ilh_handleEvent() {
    this.animate();
  },

  _removeCarrierPowerOn: function ilh_removeCarrierPowerOn() {
    var self = this;
    if (this.carrierLogo && this.carrierLogo.parentNode) {
      this.carrierLogo.parentNode.removeChild(self.carrierLogo);
      this._setReady();
    } else {
      document.addEventListener('DOMContentLoaded', function() {
        if (self.carrierLogo) {
          self.carrierLogo.parentNode.removeChild(self.carrierLogo);
        }
        self._setReady();
      });
    }
  },

  _appendCarrierPowerOn: function ilh_appendCarrierPowerOn() {
    this.carrierLogo.appendChild(this.logoLoader.element);
    this._setReady();
    var elem = this.logoLoader.element;
    if (elem && elem.tagName.toLowerCase() !== 'video') {
      this._playDefaultPowerOnSound();
    }
  },

  _appendOsLogo: function ilh_appendCarrierPowerOn() {
    var carrierLogo = document.getElementById('carrier-logo');
    if (carrierLogo) {
      this.osLogo.insertBefore(this.oslogoLoader.element, carrierLogo);
    } else {
      this.osLogo.appendChild(this.oslogoLoader.element);
    }
  },

  _setReady: function ilh_setReady() {
    this.ready = true;
    var elem = this.logoLoader.element;
    if (elem && elem.tagName.toLowerCase() == 'video') {
      // Play video just after the element is first painted.
      window.addEventListener('mozChromeEvent', function startVideo(e) {
        if (e.detail.type == 'system-first-paint') {
          window.removeEventListener('mozChromeEvent', startVideo);
          if (elem && elem.ended === false) {
            elem.play();
          }
        }
      });
    }
    if (this.readyCallBack) {
      this.readyCallBack();
      this.readyCallBack = null;
    }
    this.publish('-activated');
  },

  _waitReady: function ilh_waitReady(callback) {
    this.readyCallBack = callback;
  },

  isActive: function() {
    return this.ready && !this.animated;
  },

  animate: function ilh_animate(callback) {
    var self = this;

    if (!this.ready) {
      this._waitReady(this.animate.bind(this, callback));
      return;
    }

    if (this.animated)
    {return;}

    this.animated = true;

    // No carrier logo - Just animate OS logo.
    if (!self.logoLoader.found) {
      self.osLogo.classList.add('hide');

    // Has carrier logo - Animate carrier logo, then OS logo.
    } else {
      // CarrierLogo is not transparent until now
      // to prevent flashing.
      self.carrierLogo.className = 'transparent';

      var elem = self.logoLoader.element;
      if (elem.tagName.toLowerCase() == 'video' && !elem.ended) {
        // compability: ensure movie being played here in case
        // system-first-paint is not supported by Gecko.
        elem.play();
        elem.onended = function() {
          elem.classList.add('hide');
        };
      } else {
        elem.classList.add('hide');
      }

      self.carrierLogo.addEventListener('transitionend',
        function transCarrierLogo(evt) {
          evt.stopPropagation();
          self.carrierLogo.removeEventListener('transitionend', transCarrierLogo);
          // Clear the `src` attribute to release the resource.
          elem.removeAttribute('src');
          if (elem.tagName.toLowerCase() == 'video') {
          // XXX workaround of bug 831747
          // Unload the video. This releases the video decoding hardware
          // so other apps can use it.
            elem.load();
          }
          self.carrierLogo.parentNode.removeChild(self.carrierLogo);
          delete self.carrierLogo; // Don't entrain the DOM nodes.

          self.osLogo.classList.add('hide');
          self.carrierPowerOnElement = null;
        });
    }

    function transOsLogo() {
      self.osLogo.removeEventListener('transitionend', transOsLogo);
      self.osLogo.parentNode.removeChild(self.osLogo);
      self.oslogoLoader.element.removeAttribute('src');
      delete self.oslogoLoader;
      delete self.osLogo; // Don't entrain the DOM nodes.
      self.publish('-deactivated');
      Service.request('unregisterHierarchy', self);
      window.performance.mark('osLogoEnd');
      var evt = new CustomEvent('logohidden');
      window.dispatchEvent(evt);
      if (callback) {
        callback();
      }
    }

    self.osLogo.addEventListener('transitionend', transOsLogo);
  }
};

CustomLogoPath.init(function() {
  InitLogoHandler.init(new LogoLoader(CustomLogoPath.poweron));
});

export default CustomLogoPath;
