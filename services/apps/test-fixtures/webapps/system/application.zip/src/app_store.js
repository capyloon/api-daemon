import BaseModule from 'base-module';
import SettingsManager from 'settings-manager';

class AppStore extends BaseModule {
  name = 'AppStore';
  autoUpdate = true;

  mapDownloadErrorsToMessage = {
    'NETWORK_ERROR': 'network-issue',
    'DOWNLOAD_ERROR': 'network-issue',
    'MISSING_MANIFEST': 'device-issue',
    'INVALID_MANIFEST': 'device-issue',
    'INSTALL_FROM_DENIED': 'device-issue',
    'INVALID_SECURITY_LEVEL': 'device-issue',
    'INVALID_PACKAGE': 'device-issue',
    'CHECK_DEPENDENCIES_ERROR': 'device-issue',
    'APP_CACHE_DOWNLOAD_ERROR': 'network-issue',
    'DOWNLOAD_CANCELED': 'cancel-install',
    'INSUFFICIENT_STORAGE': 'storage-issue'
  };

  // Set data-enable as default in baseline.
  autoDownloadMode = 'data-enable';
  autoDownload = (navigator.mozWifiManager &&
    navigator.mozWifiManager.connection.status === 'connected');

  constructor() {
    super();

    this.init = () => {
      this.installedApps = new Map();
      this.apps = [];
      this.ready = false;
    };

    this.init();
  }

  get autoDownloadFlag() {
    switch (this.autoDownloadMode) {
      case 'wifi-only':
        // only through wifi
        this.autoDownload = (navigator.mozWifiManager &&
            navigator.mozWifiManager.connection.status === 'connected');
        break;
      case 'auto-update-off':
        // disable auto update
        this.autoDownload = false;
        break;
      case 'data-enable':
        // update through wifi and cellular
        this.autoDownload = true;
        break;
    }
    return this.autoDownload;
  }

  addApp(app, mozApp) {
    let allowAuto = false;

    app.launch = () => {
      mozApp.launch(app.entry);
    };

    app.mozApp = mozApp;
    app.uid = this.getAppUid(app);
    mozApp.ondownloadavailable = (e) => {
      // XXX: get `allowedAutoDownload` in event.application to decide
      // whether auto download or not.
      allowAuto = e.application &&
                        e.application.allowedAutoDownload;

      if (this.autoDownloadFlag && allowAuto) {
        mozApp.download();
      }
    };

    mozApp.ondownloadsuccess = () => {
      if (this.autoUpdate) {
        navigator.mozApps.mgmt.applyDownload(mozApp);
      }
    };

    mozApp.ondownloaderror = (e) => {
      // If allowAuto is true, it means this update belongs to silent update.
      // So don't fire notice.
      let app = e.application;
      allowAuto = app && app.allowedAutoDownload;

      if (!allowAuto && this.isPackaged(app)) {
        this.downloadError(e, true);
      }
    };

    // For fast search
    this.installedApps.set(this.getAppUid(app), app);

    this.apps.push(app);
  }

  isPackaged(mozApp) {
    let appType = mozApp.manifest.type;
    return appType === 'privileged' || appType === 'certified';
  }

  parse(mozApp) {
    let app;
    // the manifest info of webapp with downloaded manifest is in mozApp.updateManifest
    let manifest = mozApp.manifest || mozApp.updateManifest;
    // Entry point app
    let entryPoints = manifest.entry_points;

    if (entryPoints) {
      let name = '';
      // Do deep copy to avoid reference to be overwritten
      // only when we're entry points.
      manifest = JSON.parse(JSON.stringify(manifest));

      for (let ep in entryPoints) {
        app = {};
        let currentEp = entryPoints[ep];

        name = new ManifestHelper(currentEp).name;
        for (let key in currentEp) {
          if (key !== 'locale' && key !== 'name') {
            manifest[key] = currentEp[key];
          }
        }
        for (let key in mozApp) {
          app[key] = mozApp[key];
        }
        app.manifest = manifest;
        app.name = name;
        app.entry = ep;
        this.addApp(app, mozApp);
      }
    } else {
      app = {};
      for (let key in mozApp) {
        app[key] = mozApp[key];
      }
      // updateManifest for installPackaged type app
      if (!app.manifest) {
        app.manifest = app.updateManifest;
      }
      app.name = new ManifestHelper(app.manifest).name;
      this.addApp(app, mozApp);
    }
  }

  getAppUid(app) {
    let _uid = app.manifestURL;
    if (app.entry) {
      _uid += `+${app.entry}`;
    }
    return _uid;
  }

  start() {
    if (!navigator.mozApps.mgmt) {
      return;
    }
    this.fotaMigration();

    this.updateMgmt();
    SettingsManager.addObserver('app.update.auto-download', this);
    window.addEventListener('mozChromeEvent', this);

    // regesiter event for re-run this.start() when app-installed & app-uninstalled
    navigator.mozApps.mgmt.addEventListener('install', this);
    navigator.mozApps.mgmt.addEventListener('uninstall', this);
    navigator.mozApps.mgmt.addEventListener('update', this);
  }

  _handle_mozChromeEvent(evt) {
    const type = evt.detail.type;
    const id = evt.detail.id;

    switch (type) {
      case 'webapps-ask-install':
        this.publish('mozContentEvent', {
          id: id,
          type: 'webapps-install-granted'
        });
        break;
      case 'webapps-ask-uninstall':
        this.publish('mozContentEvent', {
          id: id,
          type: 'webapps-uninstall-granted'
        });
        break;
      default:
        return;
    }
  }

  //should read `autoDownloadMode` from settings.
  '_observe_app.update.auto-download'(value) {
    if (typeof value !== 'undefined') {
      this.autoDownloadMode = value;
    }
  }

  fotaMigration() {
    // Since new setting won't be bring to new version after fota,
    // So system should help set it.
    SettingsManager.get('apps.serviceCenter.settingsEnabled').then((value)=>{
      if (typeof value === 'undefined') {
        SettingsManager.set({'apps.serviceCenter.settingsEnabled': true});
      }
    });
  }

  updateMgmt() {
    navigator.mozApps.mgmt.getAll().onsuccess = (evt) => {
      const apps = evt.target.result;

      apps.forEach((app) => {
        this.parse(app);
      });

      this.ready = true;
      this.emit('ready');
    };
  }

  removeApp(app) {
    let targetAppUid = this.getAppUid(app);
    this.apps.some((_app, index) => {
      if (_app.uid === targetAppUid) {
        this.apps.splice(index, 1);
        this.installedApps.delete(targetAppUid);
        this.emit('change');
        return true;
      } else {
        return false;
      }
    });
  }

  _handle_install(evt) {
    let app = evt.application;
    if ('installed' === app.installState) {
      this.parse(app);
      this.emit('change');
      this.downloadSuccess(app);
      return;
    }
    app.ondownloadapplied = () => {
      // To avoid multiple download success notification/Vibriation
      app.ondownloadapplied = null;
      app.ondownloaderror = null;
      this.parse(app);
      this.emit('change');
      this._evl_log('evl-downloadapplied', app);
      this.downloadSuccess(app);
    };
    app.ondownloaderror = (e) => {
      // To avoid multiple download success notification/Vibriation
      app.ondownloadapplied = null;
      app.ondownloaderror = null;
      this._evl_log('evl-downloaderror', e.application);

      this.downloadError(e);
    };
  }

  _handle_uninstall(evt) {
    this.removeApp(evt.application);
  }

  _handle_update(evt) {
    // If allowAuto is true, it means this update belongs to silent update.
    // So don't fire notice.

    let app = evt.application;
    let allowAuto = app && app.allowedAutoDownload;

    // Skip INSTALL event
    if (app.updateTime === 0) {
      return;
    }

    if (!allowAuto && this.isPackaged(app)) {
      this.downloadSuccess(app, true);
    }
  }

  _evl_log(type, data) {
    var evt = new CustomEvent(type, {
      detail: data,
      bubbles: true,
      cancelable: false
    });
    window.dispatchEvent(evt);
  }

  downloadSuccess(app, update = false) {
    // Block auto update.
    if (app.allowedAutoDownload) {
      return;
    }
    const iconSize = this.getAppIconSize(app.manifest.icons);
    const appName = new ManifestHelper(app.manifest).name;
    let msgBody;

    if (update) {
      msgBody = navigator.mozL10n.get('update_succeeded');
    } else {
      msgBody = navigator.mozL10n.get('download_succeeded');
    }

    let options = {
      body: msgBody
    };
    let noticeCallback = function _launchAPP() {
      app.launch();
    };
    navigator.mozApps.mgmt.getIcon(app, iconSize)
      .then((blob) => {
        options['icon'] = URL.createObjectURL(blob);
        this._showNotification(appName, options, noticeCallback);
      })
      .catch((error) => {
        this._showNotification(appName, options, noticeCallback);
      });
  }

  downloadError(e, update = false) {
    const app = e.application;
    const errorName = e.application.downloadError.name;
    const appName = new ManifestHelper(app.manifest).name;
    const errorNameToHuman = this.mapDownloadErrorsToMessage[errorName];
    let title = 'device-issue-title';
    let msg = 'device-issue-detail';

    switch (errorNameToHuman) {
      case 'storage-issue':
        title = 'storage-full-level-2-title';
        msg = 'delete-to-get-space-level-2';
        this._showStorageFullDialog(title, msg);
        return;
      case 'network-issue':
        title = 'device-issue-title';
        msg = 'device-issue-detail';
        if (update) {
          title = 'device-issue-update-title';
        }
        break;
      case 'cancel-install':
        title = 'cancel-install';
        msg = 'install-generic-error';
        break;
      default:
        // 'device-issue' as default.
        break;
    }

    const msgBody =
      navigator.mozL10n.get(msg);
    const options = {
      icon: 'download-32px',
      body: msgBody
    };
    title = navigator.mozL10n.get(title);
    this._showNotification(title, options);
  }

  _showStorageFullDialog(title, msg) {
    const id = 'storage-full-dialog';
    const _ = navigator.mozL10n.get;
    const config = {
      id,
      title: _(title),
      message: _(msg),
      primarybtntext: _('settings'),
      secondarybtntext: _('cancel'),
      onDialogPrimaryBtnClick: () => {
        new window.MozActivity({
          name: 'configure',
          data: {
            section: 'mediaStorage'
          }
        });
        Service.request('DialogService:hide', id);
      },
      onDialogSecondaryBtnClick: () => {
        Service.request('DialogService:hide', id);
      },
    };
    Service.request('DialogService:show', config);
  }

  _showNotification(title, options, clickHandler) {
    if (!options['mozbehavior']) {
      // set showOnlyOnce to true as default.
      options['mozbehavior'] = {showOnlyOnce: true};
    }
    let notice = new Notification(title, options);
    notice.onclick = function() {
      notice.close();
      if (clickHandler) {
        clickHandler();
      }
    };

    notice.onclose = function() {
      if (options['icon']) {
        URL.revokeObjectURL(options['icon']);
      }
    };
  }

  getAppIconSize(icons, size = 56) {
    // we will try to get the smallest size icon which is bigger than 56px
    return Object.keys(icons).sort((a, b) => (a - b) * (a >= size ? 1 : -1))[0];
  }
}

const appStore = new AppStore();
appStore.start();

window.as = appStore;

export default appStore;
