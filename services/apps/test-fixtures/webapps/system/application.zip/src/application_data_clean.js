/* (c) 2017 KAI OS TECHNOLOGIES (HONG KONG) LIMITED All rights reserved. This
 * file or any portion thereof may not be reproduced or used in any manner
 * whatsoever without the express written permission of KAI OS TECHNOLOGIES
 * (HONG KONG) LIMITED. KaiOS is the trademark of KAI OS TECHNOLOGIES (HONG KONG)
 * LIMITED or its affiliate company and may be registered in some jurisdictions.
 * All other trademarks are the property of their respective owners.
 */

import BaseModule from 'base-module';

class ApplicationData extends BaseModule {
  name = 'ApplicationData';
  start() {
    window.addEventListener('iac-application-data-comms', this);
  }

  postResultMessage(result) {
    let port = IACHandler.getPort('application-data-comms');
    let info = {
      result: result
    };
    port && port.postMessage(info);
  }

  clearStorages(origin) {
    let req = navigator.mozApps.mgmt.getAll();
    req.onsuccess = (evt) => {
      let apps = evt.target.result;
      if (!Array.prototype.find.call(apps, (app) => {
        if (app.origin === origin) {
          let runApp = window.appWindowManager.getApp(origin);
          runApp && runApp.kill();
          app.clearStorage().then(() => {
            this.postResultMessage('success');
            // Manually clear places store since it is owned by system app.
            if (app.origin.includes('app://search')) {
              window.places.clear();
            }
          }, () => {
            this.postResultMessage('clearStorage failed');
          });
          return true;
        }
      })) {
        this.postResultMessage('origin mismatch');
      }
    };
    req.onerror = () => {
      this.postResultMessage('getAll error.');
    };
  }

  '_handle_iac-application-data-comms'(evt) {
    if (evt.detail) {
      this.clearStorages(evt.detail.origin);
    } else {
      this.postResultMessage('detail is null.');
    }
  }
}

var instance = new ApplicationData();
instance.start();

export default instance;

