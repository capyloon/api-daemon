/* (c) 2017 KAI OS TECHNOLOGIES (HONG KONG) LIMITED All rights reserved. This
 * file or any portion thereof may not be reproduced or used in any manner
 * whatsoever without the express written permission of KAI OS TECHNOLOGIES
 * (HONG KONG) LIMITED. KaiOS is the trademark of KAI OS TECHNOLOGIES (HONG KONG)
 * LIMITED or its affiliate company and may be registered in some jurisdictions.
 * All other trademarks are the property of their respective owners.
 */

import BaseModule from 'base-module';

class GoogleVoiceAssistant extends BaseModule {
  name = 'GoogleVoiceAssistant';
  checkAfterkeydown = false;
  launchGVA() {
    let topMostWindow = Service.query('getTopMostWindow');
    let appName = topMostWindow.manifest ?
      topMostWindow.manifest.name : topMostWindow.config.url;
    if (this.inBlockGVAModule() ||
      topMostWindow.isHomescreen ||
      Service.query('InputWindowManager.isActivated')) {
      return;
    }
    new MozActivity({
      name: 'voice-assistant',
      data: { from: appName || 'System' }
    });
  }

  canResponseGVA(evt) {
    if (evt && evt.key === 'MicrophoneToggle') {
      if (evt.type === 'mozbrowserbeforekeydown') {
        this.checkAfterkeydown = true;
      } else if (evt.type === 'mozbrowserafterkeydown') {
        this.checkAfterkeydown = false;
      }
    }
    if (evt && evt.key === 'MicrophoneToggle' && !evt.embeddedCancelled) {
      let topMostWindow = Service.query('getTopMostWindow');
      if (evt.type === 'mozbrowserafterkeydown' ||
        (evt.type === 'keydown' && !this.checkAfterkeydown)) {
        return !this.inBlockGVAModule();
      }
    }
    return false;
  }

  inBlockGVAModule() {
    // kaios-pay/dialer/calllog/instantsettings/lockscreen/FTU
    const blackAppList = [
      'app://communications.gaiamobile.org/manifest.webapp',
      'https://api.stage.kaiostech.com/apps/manifest/UgW01f5JflryQMM4H7SF',
      'app://callscreen.gaiamobile.org/manifest.webapp',
      'https://api.kaiostech.com/apps/manifest/OSlAbgrhLArfT7grf4_N',
      'app://ftu.gaiamobile.org/manifest.webapp'];
    const topMostWindow = Service.query('getTopMostWindow');
    const currentAppURL = topMostWindow && topMostWindow.manifestURL;
    let isBlackApp = blackAppList.find(appURL => {
      return appURL === currentAppURL;
    });
    let isPermisssionDialogActive = false;
    if (topMostWindow && topMostWindow._permissionDialog) {
      isPermisssionDialogActive = topMostWindow._permissionDialog.isActive();
    }

    if (!isBlackApp && !Service.query('locked') &&
      !isPermisssionDialogActive &&
      !Service.query('isFtuRunning') &&
      // clock & callscreen
      Service.query('getTopMostUI').name !== 'AttentionWindowManager' &&
      Service.query('getTopMostUI').name !== 'InstantSettings') {
      return false;
    }
    return true;
  }

  start() {
    Service.registerState('canResponseGVA', this);
    Service.register('launchGVA', this);
  }
}

var instance = new GoogleVoiceAssistant();
instance.start();

export default instance;
