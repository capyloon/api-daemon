import store from './store.js';
import connect from './connect.js';
import Service from '../app_umd/defer/service.js';
import Clock from '../app_umd/defer/clock.js';
import BatteryManager from '../webapi/battery_manager.js';

// Experimentally use Redux for state management.
// We glue some legacy implementations to redux store by dispatching action manually.
const clock = new Clock();
clock.start(() => {
  store.dispatch({
    type: 'UPDATE_DATE'
  });
});

window.addEventListener('activeappchanged', (evt) => {
  store.dispatch({
    type: 'UPDATE_ACTIVE_APP',
    app: evt.detail._activeApp
  });
});

Service.registerState('isActivated', {
  name: 'InputWindowManager',
  isActivated: store.getState().isKeyboardActivated,
});

// sync data between gecko and redux store
const batteryManager = new BatteryManager(store);

export {
  store,
  connect,
  batteryManager,
};
