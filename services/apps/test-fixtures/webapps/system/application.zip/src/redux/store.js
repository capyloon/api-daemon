import { createStore, combineReducers, applyMiddleware } from 'redux';
import thunk from 'redux-thunk';
import logger from '../util/logger.js';

const log = logger('redux/store.js');

const preloadedState = {
  activeApp: {},
  airDeckDisplay: {
    isShown: false,
    at: 'left'
  },
  battery: {
    charging: false,
    level: 0,
    plugged: false
  },
  isInstantPanelShown: false,
  isKeyboardActivated: false,
  isSIMSecurityActivated: false,
  settings: {
    airplaneMode: false,
    mobileData: false,
    bluetooth: false,
    flashlight: false,
    brightness: 70,
    volumn: 7,
    rotationLock: false
  },
  date: new Date()
};

const rootReducer = combineReducers({
  activeApp: (state = preloadedState.activeApp, action) => {
    switch (action.type) {
      case 'UPDATE_ACTIVE_APP':
        return action.app;
      default:
        return state;
    }
  },
  airDeckDisplay: (state = preloadedState.airDeckDisplay, action) => {
    switch (action.type) {
      case 'UPDATE_AIR_DECK':
        return {
          isShown: action.isShown,
          at: action.at || state.at
        };
      case 'SWITCH_AIR_DECK':
        return Object.assign({}, state, {
          at: state.at === 'left' ? 'right' : 'left'
        });
      default:
        return state;
    }
  },
  battery: (state = preloadedState.battery, action) => {
    switch (action.type) {
      case 'UPDATE_BATTERY':
        return {
          ...state,
          ...action.newState
        };
      default:
        return state;
    }
  },
  isInstantPanelShown: (state = preloadedState.isInstantPanelShown, action) => {
    switch (action.type) {
      case 'TOGGLE_INSTANT_PANEL':
        return !state;
      default:
        return state;
    }
  },
  isKeyboardActivated: (state = preloadedState.isKeyboardActivated, action) => {
    switch (action.type) {
      case 'ACTIVATE_KEYBOARD':
        return true;
      case 'DEACTIVATE_KEYBOARD':
        return false;
      default:
        return state;
    }
  },
  isSIMSecurityActivated: (state = preloadedState.isSIMSecurityActivated, action) => {
    switch (action.type) {
      case 'ACTIVATE_SIM_SECURITY':
        return true;
      case 'DEACTIVATE_SIM_SECURITY':
        return false;
      default:
        return state;
    }
  },
  settings: (state = preloadedState.settings, action) => {
    switch (action.type) {
      case 'TOGGLE_SETTING':
        return {
          ...state,
          [action.item]: !state[action.item]
        };
      case 'UPDATE_SETTING':
        return {
          ...state,
          [action.item]: action.value
        };
      default:
        return state;
    }
  },
  date: (state = preloadedState.date, action) => {
    switch (action.type) {
      case 'UPDATE_DATE':
        return new Date();
      default:
        return state;
    }
  }
});

const store = createStore(rootReducer, preloadedState, applyMiddleware(thunk));
log('created with preloadedState:', preloadedState);

export default store;
export { preloadedState };
