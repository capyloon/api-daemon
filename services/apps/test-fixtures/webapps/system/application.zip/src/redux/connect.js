import store from './store.js';

// Borrow the `connect` concept from [react-redux](https://react-redux.js.org/api/connect)
// For Element's part, not all props will be mapped from redux state.
// Those unmapped props are used inside the Element only and no need to be connected with global state.
// Note: `mapStateToProps` is potentially causing performance issues for it's executing everytime the root state changed.
// Consider to apply [Selectors](https://redux.js.org/introduction/learning-resources#selectors) for such issues.
const connect = (mapStateToProps, mapDispatchToProps) => (ElementClass) =>
  class ElementContainer extends ElementClass {
    // actually set new props to this element
    // this will invoke element update
    _update = () => {
      if (typeof mapStateToProps !== 'function') {
        return;
      }
      const state = store.getState();
      const newProps = mapStateToProps(state);
      const propNames = Object.keys(ElementClass.properties || {});
      Object.keys(newProps).forEach((key) => {
        if (!propNames.includes(key)) {
          console.warn('trying to map state to undeclared prop:', key);
          return;
        }
        this[key] = newProps[key];
      });
    }

    constructor() {
      super();
      this._update();

      if (typeof mapDispatchToProps === 'object') {
        Object.entries(mapDispatchToProps).forEach(([key, callback]) => {
          // the mapped callback is not expected to be changed during element's life cycle
          // hence no need to declare in `properties` getter.
          this[key] = (...args) => store.dispatch(callback(...args));
        });
      }
    }

    firstUpdated() {
      super.firstUpdated();
      store.subscribe(this._update);
    }
  };

export default connect;
