/* global navigator */

import BaseModule from 'base-module';
import SettingsManager from 'settings-manager';

class IpSettingsStore__Orientationlock extends BaseModule {
  name = 'IpSettingsStore__Orientationlock';

  config = {
    name: 'orientationLock',
    icon: () => this.config.value ? 'screen-rotation-lock' : 'screen-rotation',
    title: 'orientationLock',
    observerSetting: 'screen.orientation.lock',
    order: {
      portrait: 8,
      landscape: 8
    },
    click: this.toggle.bind(this),
    clickType: 'toggle',
    value: false
  };

  constructor() {
    super();
    this.checkCapability();
  }

  observeCallback = (value) => {
    if (value) {
      this.config.value = true;
      this.config.subtitle = 'on';
      this.blocker(false);
    } else {
      this.config.value = false;
      this.config.subtitle = 'off';
      this.blocker(false);
    }
  };

  checkCapability() {
    this.capability = true;
  }

  toggleObserver(active = true) {
    if (!this.capability) {
      return;
    }
    this.hasObserver = active;
    this.blocker(true);
    let method = active ? 'addObserver' : 'removeObserver';
    SettingsManager[method](this.config.observerSetting, this.observeCallback);
  }

  toggle() {
    if (this.isUpdating) {
      return;
    }
    this.blocker(true);
    let notifier = {};
    notifier[this.config.observerSetting] = !this.config.value;
    SettingsManager.set(notifier);
  }

  blocker(blocking = true) {
    this.isUpdating = blocking;
    this.config.isDisabled = blocking;
    this.emit('change');
  }
}

const ipSettingsStore__Orientationlock = new IpSettingsStore__Orientationlock();

export default ipSettingsStore__Orientationlock;
