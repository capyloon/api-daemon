/* global navigator */

import BaseModule from 'base-module';
import SettingsManager from 'settings-manager';

class IpSettingsStore__Brightness extends BaseModule {
  name = 'IpSettingsStore__Brightness';

  config = {
    name: 'brightness',
    icon: () => {
      if (this.config.value <= 33) {
        return 'brightness-low';
      } else if (this.config.value <=67) {
        return 'brightness';
      } else {
        return 'brightness-high';
      }
    },
    isShortcut: true,
    title: 'brightness',
    observerSetting: 'screen.brightness',
    order: {
      portrait: 6,
      landscape: 6
    },
    clickType: 'toggle',
    click: this.toggle.bind(this),
    maxValue: 100,
    value: 0,
    valueByPercent: () => this.config.value / this.config.maxValue
  };

  constructor() {
    super();
    this.checkCapability();
  }

  observeCallback = (value) => {
    this.config.value = value * 100;
    this.blocker(false);
  };

  checkCapability() {
    this.capability = true;
  }

  toggleObserver(active = true) {
    if (!this.capability || (this.hasObserver === active)) {
      return;
    }
    this.hasObserver = active;
    this.blocker(true);
    let method = active ? 'addObserver' : 'removeObserver';
    SettingsManager[method](this.config.observerSetting, this.observeCallback);
  }

  toggle(val) {
    if (this.isUpdating) {
      return;
    }
    this.blocker(true);
    let notifier = {};
    let _brightnessValue = val / 100;
    if (_brightnessValue < 0.1) {_brightnessValue = 0.1;}
    notifier[this.config.observerSetting] = _brightnessValue;
    SettingsManager.set(notifier);
  }

  blocker(blocking = true) {
    this.isUpdating = blocking;
    this.emit('change');
  }
}

const ipSettingsStore__Brightness = new IpSettingsStore__Brightness();

export default ipSettingsStore__Brightness;
