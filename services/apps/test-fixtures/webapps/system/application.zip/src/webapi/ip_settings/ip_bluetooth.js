/* global navigator */

import BaseModule from 'base-module';
import SettingsManager from 'settings-manager';
import * as utils from '../../util/utils';

class IpSettingsStore__Bluetooth extends BaseModule {
  name = 'IpSettingsStore__Bluetooth';

  config = {
    name: 'bluetooth',
    icon: () => this.config.value ? 'bluetooth-32px' : 'bluetooth-off-32px',
    title: 'bluetooth',
    removed: true,
    observerSetting: 'bluetooth.enabled',
    order: {
      portrait: 4,
      landscape: 4
    },
    click: this.toggle.bind(this),
    clickType: 'toggle',
    value: false
  };

  constructor() {
    super();
    this.checkCapability();
  }

  observeCallback = (value) => {
    this.config.value = value;
    this.config.subtitle = value ? 'on' : 'off';
    this.blocker(false);
  };

  checkCapability() {
    // feature detection: bluetooth
    navigator.hasFeature && navigator.hasFeature('device.capability.bt').then((hasBluetooth) => {
      if (!hasBluetooth) {
        return;
      }
      this.capability = true;

      // If phone is reboot and bluetooth adapter is null.
      // It need prepare to init bluetooth adapter for user experience.
      if (!navigator.mozBluetooth.defaultAdapter) {
        navigator.mozBluetooth.onattributechanged = (evt) => {
          if (evt.attrs.includes('defaultAdapter')) {
            navigator.mozBluetooth.onattributechanged = null;
          }
        };
      }
    });
  }

  toggleObserver(active = true) {
    if (!this.capability || (this.hasObserver === active)) {
      return;
    }
    this.hasObserver = active;
    this.blocker(true);
    let method = active ? 'addObserver' : 'removeObserver';
    SettingsManager[method](this.config.observerSetting, this.observeCallback);
  }

  toggle() {
    if (this.isUpdating) {
      return;
    }
    this.blocker(true);
    utils.toggleBletooth(!this.config.value ? 'enable' : 'disable').then(
      (e) => {
        this.debug(e);
      },
      (reason) => {
        console.warn(reason);
      }
    );
  }

  blocker(blocking = true) {
    this.isUpdating = blocking;
    this.config.isDisabled = blocking;
    this.emit('change');
  }
}

const ipSettingsStore__Bluetooth = new IpSettingsStore__Bluetooth();

export default ipSettingsStore__Bluetooth;
