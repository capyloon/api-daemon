/* global navigator */

import BaseModule from 'base-module';
import SettingsManager from 'settings-manager';

class IpSettingsStore__Airplanemode extends BaseModule {
  name = 'IpSettingsStore__Airplanemode';

  config = {
    name: 'airplaneMode',
    icon: () => this.config.value ? 'airplane-mode' : 'airplane-mode-off',
    title: 'airplaneMode',
    // The key to enable/disable the airplane mode.
    activateSetting: 'airplaneMode.enabled',
    // The key to observe whether the airplane mode is enabled/disabled.
    observerSetting: 'airplaneMode.status',
    order: {
      portrait: 1,
      landscape: 1
    },
    click: this.toggle.bind(this),
    clickType: 'toggle',
    value: false
  };

  constructor() {
    super();
    this.checkCapability();
  }

  observeCallback = (value) => {
    switch (value){
      case 'enabled':
        this.config.value = true;
        this.config.subtitle = 'on';
        this.blocker(false);
        break;
      case 'disabled':
        this.config.value = false;
        this.config.subtitle = 'off';
        this.blocker(false);
        break;
    }
  };

  checkCapability() {
    this.capability = true;
  }

  toggleObserver(active = true) {
    if (!this.capability) {
      return;
    }
    this.hasObserver = active;
    this.blocker(true);
    let method = active ? 'addObserver' : 'removeObserver';
    SettingsManager[method](this.config.observerSetting, this.observeCallback);
  }

  toggle() {
    if (this.isUpdating) {
      return;
    }
    this.blocker(true);

    // Enable/Disable the airplane mode.
    let notifier = {};
    notifier[this.config.activateSetting] = !this.config.value;
    SettingsManager.set(notifier);
  }

  blocker(blocking = true) {
    this.isUpdating = blocking;
    this.config.isDisabled = blocking;
    this.emit('change');
  }
}

const ipSettingsStore__Airplanemode = new IpSettingsStore__Airplanemode();

export default ipSettingsStore__Airplanemode;
