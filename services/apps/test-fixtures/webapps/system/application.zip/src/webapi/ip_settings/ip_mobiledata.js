/* global navigator, SIMSlotManager*/

import BaseModule from 'base-module';
import SettingsManager from 'settings-manager';
import IP_airplanemode from './ip_airplanemode';

class IpSettingsStore__MobileData extends BaseModule {
  name = 'IpSettingsStore__MobileData';

  config = {
    name: 'mobileData',
    icon: () => this.config.value ? 'network-activity' : 'network-activity-off',
    title: 'mobile-data',
    observerSetting: 'ril.data.enabled',
    order: {
      portrait: 3,
      landscape: 3
    },
    click: this.toggle.bind(this),
    clickType: 'toggle',
    value: false
  };

  constructor() {
    super();
    this.checkCapability();
  }

  hasReadySIMCard() {
    let slot = SIMSlotManager.getSlots().find(slot => {
      if (!slot.simCard) {
        return false;
      }
      return slot.getCardState() === 'ready';
    });
    return !!slot;
  }

  observeCallback = (value) => {
    this.config.value = value && this.hasReadySIMCard();
    this.config.subtitle = value ? 'on' : 'off';
    this.blocker(false);
  };

  checkCapability() {
    this.capability = true;
  }

  toggleObserver(active = true) {
    if (!this.capability || (this.hasObserver === active)) {
      return;
    }
    this.hasObserver = active;
    this.blocker(true);
    let method = active ? 'addObserver' : 'removeObserver';
    SettingsManager[method](this.config.observerSetting, this.observeCallback);

    if (active) {
      this.addSimCardObserver();
      IP_airplanemode.on('change', this.checkSimCardState);
    } else {
      this.removeSimCardObserver();
      IP_airplanemode.off('change', this.checkSimCardState);
    }
  }

  /**
   * Observer sim card state by voicechange event to update mobileData button state.
   * But voicechange event will be fired every 3 ~ 5 seconds,
   * so we will add observer when UI is focused, and remove observer when exit.
   */
  addSimCardObserver() {
    if (this.isSimCardObserverAdded) {
      return;
    }
    this.isSimCardObserverAdded = true;
    this.checkSimCardState();
    let conns = window.navigator.mozMobileConnections;
    if (conns) {
      [...conns].forEach((conn) => {
        conn.addEventListener('voicechange', this);
      }, this);
    }
  }

  removeSimCardObserver() {
    this.isSimCardObserverAdded = false;
    let conns = window.navigator.mozMobileConnections;
    if (conns) {
      [...conns].forEach((conn) => {
        conn.removeEventListener('voicechange', this);
      }, this);
    }
  }

  checkSimCardState = () => {
    let hasReadySIMCard = this.hasReadySIMCard();
    this.config.isDisabled = IP_airplanemode.config.value || !hasReadySIMCard;
    if (!hasReadySIMCard && this.config.value) {
      this.toggle();
    }
    this.emit('change');
  }

  _handle_voicechange() {
    this.checkSimCardState();
  }

  toggle() {
    if (this.isUpdating) {
      return;
    }
    this.blocker(true);

    let notifier = {};
    notifier[this.config.observerSetting] = !this.config.value;
    SettingsManager.set(notifier);
  }

  blocker(blocking = true) {
    this.isUpdating = blocking;
    this.config.isDisabled = blocking;
    this.checkSimCardState(false);
    this.emit('change');
  }
}

const ipSettingsStore__MobileData = new IpSettingsStore__MobileData();

export default ipSettingsStore__MobileData;
