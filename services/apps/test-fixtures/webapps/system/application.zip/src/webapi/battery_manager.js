import logger from '../util/logger.js';

const log = logger('battery_manager');

// Used to sync data between `navigator.battery` (backend data) and redux store.
class BatteryManager {
  constructor(store) {
    navigator.getBattery().then(battery => {
      if (!navigator.powersupply) {
        console.log('navigator.powersupply falsy, early return.');
        return;
      }
  
      this._store = store;
      this._battery = battery;
      this._powersupply = navigator.powersupply;
  
      this._battery.addEventListener('levelchange', this._onlevelchange);
      this._battery.addEventListener('chargingchange', this._onchargingchange);
      this._powersupply.addEventListener('powersupplystatuschanged', this._onpowersupplystatuschanged);
  
      this._dispatchState({
        level: this._battery.level,
        charging: this._battery.charging,
        plugged: this._powersupply.powerSupplyOnline,
      });
    });
  }

  _dispatchState = (newState) => {
    this._store.dispatch({
      type: 'UPDATE_BATTERY',
      newState,
    });
  }

  _onlevelchange = () => {
    log('_onlevelchange:', this._battery.level);
    this._dispatchState({
      level: this._battery.level,
    });
  }

  _onchargingchange = () => {
    log('_onchargingchange:', this._battery.charging);
    this._dispatchState({
      charging: this._battery.charging,
    });
  }

  _onpowersupplystatuschanged = () => {
    this._dispatchState({
      plugged: this._powersupply.powerSupplyOnline,
    });
  }
}

export default BatteryManager;
