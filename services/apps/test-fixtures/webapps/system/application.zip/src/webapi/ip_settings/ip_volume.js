/* global navigator, soundManager, SoundManager */

import BaseModule from 'base-module';
import SettingsManager from 'settings-manager';
import * as utils from '../../util/utils';

class IpSettingsStore__Volume extends BaseModule {
  name = 'IpSettingsStore__Volume';
  VOLUME_TITLE_L10N_MAPPING = {
    'content': 'is-volume-type-content',
    'telephony': 'is-volume-type-telephony',
    'alarm': 'is-volume-type-alarm',
    'notification': 'is-volume-type-notification'
  };
  VOLUME_SUBTITLE_L10N_MAPPING = {
    'vibrate': 'vibrate-only',
    'silent': 'silent'
  };
  config = {
    name: 'volume',
    icon: () => {
      if (this.config.value === 0) {
        return 'mute-32px';
      } else if (this.config.value <=5) {
        return 'sound-min';
      } else if (this.config.value <=10) {
        return 'sound-mid';
      } else {
        return 'sound-max';
      }
    },
    icons: {
      init: 'sound-max',
      mute: 'mute-32px',
      vibrate: 'vibrate-32px',
    },
    isShortcut: true,
    maxValue: 15,
    value: 0,
    valueByPercent: () => this.config.value / this.config.maxValue,
    vibrationEnabled: false,
    order: {
      portrait: 7,
      landscape: 7
    },
    click: this.click.bind(this),
    toggleVibration: this.toggleVibration.bind(this)
  };

  constructor() {
    super();
    this.checkCapability();
  }

  observerSettings = [
    ...['alarm', 'notification', 'telephony', 'content', 'bt_sco']
      .map(channel => `audio.volume.${channel}`),
    'vibration.enabled',
  ];

  checkCapability() {
    this.capability = true;
  }

  // for init
  toggleObserver(active) {
    if (!this.capability || (this.hasObserver === active)) {
      return;
    }
    this.hasObserver = active;
    let method = active ? 'addObserver' : 'removeObserver';

    this.observerSettings.forEach((setting) => {
      SettingsManager[method](setting, this.updateValue);
    }, this);

    window[active ? 'addEventListener' : 'removeEventListener'](
      'audiochannelchanged',
      this.updateValue
    );
  }

  click(newPercent) {
    if (this.isUpdating) {
      return;
    }
    this.blocker(true);
    const newVolumeVal = Math.floor(newPercent/100*this.config.maxValue);
    const cChannel = 'audio.volume.' + soundManager.getChannel();
    let notifier = {};
    notifier[cChannel] = newVolumeVal;
    SettingsManager.set(notifier);
  }

  updateValue = () => {
    let channel = soundManager.getChannel();
    let maxValue = SoundManager.MAX_VOLUME[channel];
    let value = soundManager.currentVolume[channel];
    let vibrationEnabled = soundManager.vibrationEnabled;
    this.config = { ...this.config, maxValue, value, vibrationEnabled };
    this.blocker(false);
  }

  toggleVibration () {
    this.blocker(true);
    let notifier = {};
    notifier['vibration.enabled'] = !this.config.vibrationEnabled;
    SettingsManager.set(notifier);
  }

  getChannelL10n(channel = soundManager.getChannel()) {
    return this.VOLUME_TITLE_L10N_MAPPING[channel];
  }

  getModeL10n(mode) {
    return this.VOLUME_SUBTITLE_L10N_MAPPING[mode];
  }

  blocker(blocking = true) {
    this.isUpdating = blocking;
    this.emit('change');
  }
}

const ipSettingsStore__Volume = new IpSettingsStore__Volume();

export default ipSettingsStore__Volume;
