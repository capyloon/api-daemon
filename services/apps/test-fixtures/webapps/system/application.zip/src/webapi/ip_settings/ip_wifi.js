/* global navigator */

import BaseModule from 'base-module';
import SettingsManager from 'settings-manager';

class IpSettingsStore__Wifi extends BaseModule {
  name = 'IpSettingsStore__Wifi';

  config = {
    name: 'wifi',
    icon: () => this.config.value ? 'wifi-32px' : 'wifi-off-32px',
    title: 'wifi',
    observerSetting: 'wifi.enabled',
    removed: true,
    order: {
      portrait: 2,
      landscape: 2
    },
    click: this.toggle.bind(this),
    clickType: 'toggle',
    value: false
  };

  constructor() {
    super();
    this.checkCapability();
  }

  observeCallback = (value) => {
    this.config.value = value;
    this.config.subtitle = value ? 'on' : 'off';
    this.blocker(false);
  };

  checkCapability() {
    // feature detection: wifi
    navigator.hasFeature && navigator.hasFeature('device.capability.wifi').then((hasWifi) => {
      if (!hasWifi) {
        return;
      }
      this.config.removed = false;
      this.capability = true;
    });
  }

  toggleObserver(active = true) {
    if (!this.capability || (this.hasObserver === active)) {
      return;
    }
    this.hasObserver = active;
    this.blocker(true);
    let method = active ? 'addObserver' : 'removeObserver';
    SettingsManager[method](this.config.observerSetting, this.observeCallback);
  }

  toggle() {
    if (this.isUpdating) {
      return;
    }
    this.blocker(true);

    let notifier = {};
    notifier[this.config.observerSetting] = !this.config.value;
    SettingsManager.set(notifier);
  }

  blocker(blocking = true) {
    this.isUpdating = blocking;
    this.config.isDisabled = blocking;
    this.emit('change');
  }
}

const ipSettingsStore__Wifi = new IpSettingsStore__Wifi();

export default ipSettingsStore__Wifi;
