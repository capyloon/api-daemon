/* global navigator */

import BaseModule from 'base-module';
import FlashlightHelper from '../../util/flashlight_helper';

class IpSettingsStore__Flashlight extends BaseModule {
  name = 'IpSettingsStore__Flashlight';

  config = {
    name: 'flashlight',
    icon: () => this.config.value ? 'flashlight-on' : 'flashlight-off',
    title: 'flashlight',
    removed: true,
    order: {
      portrait: 5,
      landscape: 5
    },
    click: this.toggle.bind(this),
    clickType: 'toggle',
    value: false
  };

  constructor() {
    super();
    this.checkCapability();
  }

  observeCallback = () => {
    this.updateValue();
  };

  checkCapability() {
    this.capability = FlashlightHelper.capability;
  }

  toggleObserver(active = true) {
    if (!FlashlightHelper.capability) {
      return;
    }
    this.checkCapability();
    this.observeCallback();

    let method = active ? 'on' : 'off';
    FlashlightHelper[method]('change', this.observeCallback);
  }

  updateValue() {
    let _flashlightEnabled = FlashlightHelper.flashlightManager.flashlightEnabled;
    this.config.value = _flashlightEnabled;
    this.config.subtitle = _flashlightEnabled ? 'on' : 'off';
    this.emit('change');
  }

  toggle() {
    FlashlightHelper.toggle();
    this.updateValue();
  }
}

const ipSettingsStore__Flashlight = new IpSettingsStore__Flashlight();

export default ipSettingsStore__Flashlight;
