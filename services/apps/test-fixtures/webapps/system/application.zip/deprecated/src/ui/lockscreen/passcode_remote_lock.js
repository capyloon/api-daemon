'use strict';

import React from 'react';
import ReactDOM from 'react-dom';
import BaseComponent from 'base-component';
import SettingsManager from 'settings-manager';
import '../../../scss/lockscreen/passcode.scss';

export default class PasscodeRemoteLock extends BaseComponent {
  name = 'PasscodeRemoteLock';
  DEBUG = false;

  PASSCODE_SIZE = 6;

  static defaultProps = {
    softRightHandler: () => {},
    softLeftHandler: () => {},
    unlock: () => { }
  };

  constructor(props) {
    super(props);
    this.state = {
      remoteMessage: '',
      passcode: '000000',
      currentPasscode: '',
      error: ''
    };
  }

  componentDidMount() {
    this.debug('did mount');
    SettingsManager.addObserver('lockscreen.lock-message', this);
    SettingsManager.addObserver('lockscreen.remote-lock', this);
    window.document.getElementById('screen').classList.add('locked');
  }

  '_observe_lockscreen.remote-lock'(value) {
    this.debug('_observe_lockscreen.remote-lock:', value);
    this.setState({
      remoteMessage: value[0],
      passcode: value[1]
    });
  }

  '_observe_lockscreen.lock-message'(value) {
    this.debug('_observe_lockscreen.lock-message:', value);
    if (!value) {
      return;
    }
    this.setState({
      remoteMessage: value
    });
  }

  componentWillUnmount() {
    SettingsManager.removeObserver('lockscreen.remote-lock', this);
    SettingsManager.removeObserver('lockscreen.lock-message', this);
    window.document.getElementById('screen').classList.remove('locked');
  }

  componentDidUpdate() {
    if (this.state.currentPasscode === this.state.passcode) {
      SettingsManager.set({
        'lockscreen.remote-lock': ['', '']
      });
      this.props.unlock();
    } else if (this.state.currentPasscode.length === this.state.passcode.length) {
      this.setState({
        currentPasscode: '',
        error: 'incorrect'
      });
    } else if (this.state.error && this.state.currentPasscode !== '') {
      this.setState({
        error: ''
      });
    }
  }

  onKeyDown(evt) {
    if (document.hidden) {
      return;
    }
    switch (evt.key) {
      case 'SoftRight':
        this.props.softRightHandler();
        break;
      case 'SoftLeft':
        this.props.softLeftHandler();
        break;
      case '1':
      case '2':
      case '3':
      case '4':
      case '5':
      case '6':
      case '7':
      case '8':
      case '9':
      case '0':
        this.setState({
          currentPasscode: this.state.currentPasscode + evt.key
        });
        break;
      case 'Backspace':
        if (this.state.currentPasscode.length) {
          this.setState({
            currentPasscode: this.state.currentPasscode.substr(0, this.state.currentPasscode.length - 1)
          });
        }
        break;
    }
  }

  render() {
    this.debug('render');
    const passcode = this.state.currentPasscode.split('');
    let dom = [];

    for (let i = 0; i < this.PASSCODE_SIZE; i++) {
      const className = (passcode[i] !== undefined) ? 'code dotted' : 'code';
      dom.push(<div className={className} key={i}><div className="dot" /></div>);
    }
    return <div id="remote-passcode-view" className={this.state.error ? 'error' : ''}
      onKeyDown={(e) => this.onKeyDown(e)} tabIndex="-1">
      <p className="remote-message">{this.state.remoteMessage}</p>
      <div className="secondary info-text"
        data-l10n-id={this.state.error ? 'lockscreenCheckLockCode' : 'enterPIN'} />
      <div className="codes">
        {dom}
      </div>
    </div>;
  }
}
