import React from 'react';
import ReactDOM from 'react-dom';
import BaseComponent from 'base-component';
import SettingsManager from 'settings-manager';
import NotificationStore from '../notification_store';
import '../../scss/notification_toaster.scss';
import EnhanceAnimation from '../enhance_animation';

class NotificationToaster extends BaseComponent {
  name = 'NotificationToaster';

  EVENT_PREFIX = 'notification-toaster-';

  _sound = 'shared/resources/media/notifications/notifier_shake.ogg';

  TIMEOUT = 5000;

  constructor(props) {
    super(props);
    this.state = {
      notification: null
    };
  }

  componentDidMount() {
    this.element = ReactDOM.findDOMNode(this.refs.element);
    Service.register('show', this);
    SettingsManager.addObserver('audio.volume.notification', this);
    SettingsManager.addObserver('vibration.enabled', this);
    SettingsManager.addObserver('notification.ringtone', this);
    this.ringtoneURL = new SettingsURL();
    window.nt = this;
  }

  show(notification) {
    if (Service.query('remoteLockEnabled')) {
      return;
    }
    Service.request('turnScreenOn', 'toast');
    this.setState({
      notification: notification
    });
    if (this.timer) {
      clearTimeout(this.timer);
      this.timer = null;
    }
    this.open();
    this.timer = setTimeout(() => {
      this.timer = null;
      this.close();
    }, this.TIMEOUT);
  }

  blur() {

  }

  '_observe_notification.ringtone'(value) {
    this._sound = this.ringtoneURL.set(value);
  }

  '_observe_audio.volume.notification'(value) {
    this.silent = (value === 0);
  }

  '_observe_vibration.enabled'(value) {
    this.vibrationEnabled = value;
  }

  componentDidUpdate() {
    if (!this.state.notification) {
      return;
    }
    var behavior = this.state.notification.mozbehavior;
    var type = this.state.notification.type || 'desktop-notification';
    var manifestURL = this.state.notification.manifestURL;
    if (!this.silent) {
      var ringtonePlayer = new Audio();

      if (behavior) {
        ringtonePlayer.src = behavior.soundFile || this._sound;
      } else {
        ringtonePlayer.src = this._sound;
      }
      ringtonePlayer.mozAudioChannelType = 'notification';
      ringtonePlayer.play();
      window.setTimeout(function smsRingtoneEnder() {
        ringtonePlayer.pause();
        ringtonePlayer.removeAttribute('src');
        ringtonePlayer.load();
      }, 2000);
    }

    if (this.vibrationEnabled) {
      var pattern = [200, 200, 200];
      if (behavior) {
        // don't vibrate if mozbehavior has silent: true
        if (behavior.silent) {
          return;
        }
        if (behavior.vibrationPattern && behavior.vibrationPattern.length &&
            behavior.vibrationPattern[0] > 0) {
          pattern = behavior.vibrationPattern;
        }
      }
      navigator.vibrate(pattern);
    }
  }

  render() {
    var notification = '';
    if (this.state.notification) {
      var detail = this.state.notification;
      var noticeTag = '';
      var noticeIcon = detail.icon.split('?')[0].split('/').reverse()[0];
      if (detail.id.indexOf('#') !== -1) {
        var tagLabel = detail.id.split('#').reverse()[0];
        if (tagLabel.indexOf(':') !== -1) {
          noticeTag = tagLabel.split(':').reverse()[0];
        }
      }
      var sizeDOM = '';
      if (detail.data && detail.data.bluetoothSize) {
        sizeDOM = <span className="secondary-float">{detail.data.bluetoothSize}</span>;
      }
      var iconDOM = '';
      var custIconBg = '';
      if (detail.id.indexOf('batteryFull') !== -1) {
        iconDOM = <i data-icon="full-battery" className="icon-font" role="presentation" />;
      } else if (detail.id.indexOf('simCard') !== -1) {
        iconDOM = <i data-icon="sim-card"
          className="icon-font"
          role="presentation" />;
      } else if (detail.id.indexOf(Wifi.NO_INTERNET_TAG) !== -1) {
        iconDOM = <i data-icon="wifi-32px"
          className="icon-font"
          role="presentation" />;
      } else if (detail.appName === 'Call Log' && !detail.icon.endsWith('.png')) {
        // XXX: workaround for bug-24616
        // or we may need to send custom notification(instead of NotificationHelper) outside of system app
        const icon = detail.icon.split('/').reverse()[0];
        iconDOM = <i data-icon={icon} className="icon-font" role="presentation" />;
      } else if (detail.appName === 'Messages' && !detail.icon.endsWith('.png')) {
        const icon = detail.icon.split('?')[0].split('/').reverse()[0];
        iconDOM = <i data-icon={icon} className="icon-font" role="presentation" />;
      } else if (detail.appName === 'WAP Push manager' && !detail.icon.endsWith('.png')) {
        const icon = detail.icon.split('/').reverse()[0];
        iconDOM = <i data-icon={icon} className="icon-font" role="presentation" />;
      } else if (detail.appName === 'System' && !detail.icon.endsWith('.png') &&
        noticeTag.startsWith('cell-broadcast')) {
        const icon = detail.icon.split('/').reverse()[0];
        iconDOM = <i data-icon={icon} className="icon-font" role="presentation" />;
      } else if (detail.appName === 'System' && detail.icon.endsWith('download-32px')) {
        const icon = detail.icon.split('/').reverse()[0];
        iconDOM = <i data-icon={icon} className="icon-font" role="presentation" />;
      } else if (detail.appName === 'System' && detail.icon.endsWith('Gallery.png')) {
        // Modify the icon background-color in accordance with VsD Spec.
        // The icon background-color is changed by detail.appName, but the appName of screenshot
        // notification is always "System". Therefore, we change the background-color here.
        custIconBg = 'Gallery';
        iconDOM = <img src={detail.icon || detail.appIcon} />;
      } else if (detail.appName === 'Network Alerts' && !detail.icon.endsWith('.png')) {
        const icon = detail.icon.split('/').reverse()[0];
        iconDOM = <i data-icon={icon} className="icon-font" role="presentation" />;
      } else if (detail.id.indexOf('phone-almost-full') !== -1) {
        iconDOM = <i data-icon="settings" className="icon-font" role="presentation" />;
      } else if (detail.type === 'account-authenticator-notification') {
        const icon = detail.icon.split('/').reverse()[0];
        iconDOM = <i data-icon={icon} className="icon-font" role="presentation" />;
      // Not blob:xxxx or 'data:image/png;base64,xxxxx or xxxx.xxx or
      // xxxxxxxx?xxxx, use gaia-icon
      } else if (!detail.icon.includes('blob:') &&
        !detail.icon.includes('data:') && !noticeIcon.includes('.')) {
        iconDOM = <i data-icon={noticeIcon} className="icon-font" role="presentation" />;
      } else {
        iconDOM = <img src={detail.icon || detail.appIcon} />;
      }
      notification = <div className="container"
        data-predefined-dir={detail.dir}
        data-no-clear="false"
        data-notification-id={detail.id}
        data-manifest-url={detail.manifestURL}
        data-app-name={custIconBg || detail.appName}
        key={detail.id}>
        <div className="icon">
          <div className="background" />
          {iconDOM}
        </div>
        <div className="content">
          <div className={detail.appName === 'Call Log' ? 'primary number' : 'primary'}>{detail.title}</div>
          <div className="secondary"><span>{detail.text}</span>{sizeDOM}</div>
        </div>
      </div>;
    }
    return <div id="notification-toaster" ref="element">
      {notification}
    </div>;
  }
}


export default EnhanceAnimation(NotificationToaster, 'slide-from-top', 'fade-out');
