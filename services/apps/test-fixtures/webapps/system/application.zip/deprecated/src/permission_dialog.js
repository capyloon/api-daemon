import React from 'react';
import ReactDOM from 'react-dom';

import BaseComponent from 'base-component';
import ReactDialog from 'react-dialog';
import SoftKeyStore from 'soft-key-store';

import '../scss/permission_dialog.scss';

export default class PermissionDialog extends BaseComponent {
  constructor(props) {
    super(props);
    this.state = {
      id: '',
      isApp: false,
      isGranted: false,
      manifestURL: '',
      name: '',
      origin: '',
      permissions: {},
      remember: false,
      type: '',
      allow: function() {},
      deny: function() {},
      moreInfoShown: false
    };
  }
  softkeys = {
    left: 'deny',
    right: 'allow'
  };
  componentDidMount() {
    this.element = ReactDOM.findDOMNode(this);
    this.moreInfoBox = ReactDOM.findDOMNode(this.refs.moreInfo);
    this.container = ReactDOM.findDOMNode(this.refs.container);
    this.toggleMoreInfo = ReactDOM.findDOMNode(this.refs.toggleMoreInfo);
    this.remember = ReactDOM.findDOMNode(this.refs.remember);

    this.refs.dialog.on('closed', () => {
      this.clear();
      Service.request('focus');
    });
    this.refs.dialog.on('opened', () => {
      Service.request('focus');
    });
  }
  componentDidUpdate() {
    this.updateSoftKeys();
  }
  updateSoftKeys() {
    let _softkeys = {...this.softkeys};
    if (document.activeElement === this.toggleMoreInfo) {
      _softkeys.center = 'select';
    } else if (document.activeElement === this.remember) {
      _softkeys.center = this.state.remember ? 'deselect' : 'select';
    }
    if (!this.state.isApp) {
      _softkeys.center = '';
    }
    SoftKeyStore.register(_softkeys, this.element);
  }
  clear() {
    this.setState({
      id: '',
      isApp: false,
      isGranted: false,
      manifestURL: '',
      name: '',
      origin: '',
      permissions: {},
      remember: false,
      type: '',
      allow: function() {},
      deny: function() {},
      moreInfoShown: false
    });
  }
  show(config) {
    this.setState(config);
    this.refs.dialog.show();
    this.props.app._setVisibleForScreenReader(false);
  }
  hide() {
    this.props.app._setVisibleForScreenReader(true);
  }

  focus() {
    this.container.focus();
  }

  scrollMoreInfoBox(direction) {
    var maxOffset = this.moreInfoBox.scrollHeight - this.moreInfoBox.clientHeight;
    if ((this.moreInfoBox.scrollTop == 0 && direction < 0)
      ||(this.moreInfoBox.scrollTop == maxOffset && direction > 0)){
      this.moreInfoBox.classList.remove('checked');
      this.moreInfoBox.classList.remove('permission-focus');
      return false;
    } else {
      var scorlloffset ;
      var distance = this.moreInfoBox.clientHeight - 41;
      if (direction > 0) {
        scorlloffset= this.moreInfoBox.scrollTop +  distance;
      } else if (direction < 0){
        scorlloffset= this.moreInfoBox.scrollTop -  distance;
      }

      if (scorlloffset < 0) {
        scorlloffset = 0;
      } else if (scorlloffset > maxOffset){
        scorlloffset = maxOffset;
      }
      this.moreInfoBox.scrollTo(0, scorlloffset);
      return true;
    }
  }

  onFocus() {
    this.updateSoftKeys();
    if (document.activeElement === this.container) {
      var candidates = Array.from(this.element.querySelectorAll('.focusable:not(.hidden)'));
      if (!candidates.length) {
        return;
      }
      candidates[0].focus();
    }
  }

  findNext() {
    var candidates = Array.from(this.element.querySelectorAll('.focusable:not(.hidden)'));
    if (!candidates.length) {
      return this.element;
    }

    var current = document.activeElement;
    var next = current;
    candidates.some(function(candidate, index) {
      if (candidate === current) {
        next = candidates[(index + 1) % candidates.length];
        return true;
      } else {
        return false;
      }
    });
    return next;
  }

  findPrev() {
    var candidates = Array.from(this.element.querySelectorAll('.focusable:not(.hidden)'));
    if (!candidates.length) {
      return this.element;
    }

    var current = document.activeElement;
    var next = current;
    candidates.some(function(candidate, index) {
      if (candidate === current) {
        next = candidates[(index - 1 + candidates.length) % candidates.length];
        return true;
      } else {
        return false;
      }
    });
    return next;
  }

  onKeyDown(evt) {
    var handled = false;
    var nextFocus = null;
    switch (evt.key) {
      case 'ArrowDown':
        evt.preventDefault();
        evt.stopPropagation();
        if (document.activeElement === this.moreInfoBox) {
          handled = this.scrollMoreInfoBox(1);
        }
        if (!handled) {
          nextFocus = this.findNext();
        }
        break;
      case 'ArrowUp':
        evt.preventDefault();
        evt.stopPropagation();
        if (document.activeElement === this.moreInfoBox) {
          handled = this.scrollMoreInfoBox(-1);
        }
        if (!handled) {
          nextFocus = this.findPrev();
        }
        break;
      case 'Enter':
        evt.preventDefault();
        evt.stopPropagation();
        if (document.activeElement === this.toggleMoreInfo &&
            !this.state.permissions.fullscreen) {
          this.setState({
            moreInfoShown: !this.state.moreInfoShown
          });
          this.moreInfoBox.scrollTop = 0;
        } else if (document.activeElement === this.remember) {
          this.setState({
            remember: !this.state.remember
          });
        }
        break;
    }
    if (nextFocus) {
      nextFocus.scrollIntoView(false);
      nextFocus.focus();
      if (nextFocus === this.moreInfoBox) {
        if (evt.key === 'ArrowDown') {
          this.moreInfoBox.scrollTo(0, 0);
        } else {
          this.moreInfoBox.scrollTo(0,
            this.moreInfoBox.scrollHeight - this.moreInfoBox.clientHeight);
        }
      }
    }
  }

  render() {
    var permissionType = Object.keys(this.state.permissions)[0];
    var permissionID = '';
    if (permissionType) {
      if (permissionType === 'audio-capture' || permissionType === 'video-capture') {
        permissionType = 'media-capture';
      }
      permissionID = permissionType.replace(':', '-');
    }

    var isCamSelector = false;
    if (this.state.permissions['video-capture'] &&
        this.state.permissions['video-capture'].length > 1) {
      isCamSelector = true;
    }
    let isSimpleStyle = !this.state.isApp;
    var moreInfoClass = 'hidden';
    if (this.state.moreInfoShown && !isSimpleStyle) {
      moreInfoClass = '';
    }
    return (
      <ReactDialog ref="dialog"
        header={this.state.isApp ? (isCamSelector ? 'title-cam' : 'title-app') : 'title-web'}
        ok={this.softkeys.right}
        cancel={this.softkeys.left}
        noFocus={true}
        onOk={()=>this.state.allow(this.state.remember)}
        onCancel={()=>{this.state.deny(this.state.remember);}}
      >
        <div tabIndex="-1"
          className={'container content ' + this.state.name.toLowerCase()}
          onKeyDown={(e)=>this.onKeyDown(e)}
          onFocus={(e)=>this.onFocus(e)}
          ref="container"
        >

          <div className={'permission-more-info ' + (permissionType === 'fullscreen' ? 'hidden' : '')}>
            <a
              className={'secondary info-link ' + (isSimpleStyle ? '' : 'focusable')}
              href="#"
              ref="toggleMoreInfo"
            >
              <div className={(this.state.moreInfoShown && !isSimpleStyle) ? 'hidden' : 'message primary'}
                data-l10n-id={'perm-' + permissionID + (this.state.isApp ? '-appRequest' : '-webRequest')}
                data-l10n-args={this.state.isApp ? ('{"app":"'+this.state.name+'"}') : ('{"site":"'+this.state.origin+'"}')}
              />
              <span data-l10n-id="more-info" className={(this.state.moreInfoShown || isSimpleStyle) ? 'hidden' : ''} data-icon="forward" />
              <span data-l10n-id="hide-info" className={(!this.state.moreInfoShown || isSimpleStyle) ? 'hidden' : ''} data-icon="back" />
            </a>
          </div>

          <div
            className={'permission-more-info-box focusable secondary ' +  moreInfoClass}
            ref="moreInfo"
            data-l10n-id={'perm-' + permissionID + '-more-info'}
          />

          <div
            className={'primary permission-remember-section focusable ' + ((permissionType === 'fullscreen' || isSimpleStyle) ? 'hidden' : '')}
            tabIndex="-1"
            ref="remember"
          >
            <label className="permission-remember-checkbox" />
            <i
              className="checkbox"
              data-icon={this.state.remember ? 'check-on' : 'check-off'}
              ref="checkbox"
            />
            <div data-l10n-id="remember-my-choice" />
          </div>

          <div className="permission-device-selector" />
          <ul className="permission-devices" />

        </div>
      </ReactDialog>
    );
  }
}
