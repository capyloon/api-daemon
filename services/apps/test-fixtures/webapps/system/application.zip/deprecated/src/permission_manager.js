import React from 'react';
import ReactDOM from 'react-dom';
import BaseComponent from 'base-component';
import BaseModule from 'base-module';
import PermissionDialog from './permission_dialog';
import ChromeEventManager from './chrome_event_manager';

class PermissionManager extends BaseModule {
  requests = [];

  start() {
    window.addEventListener('mozChrome-permission-prompt', this);
    window.addEventListener('lockscreen-appopened', this);
    window.addEventListener('fullscreenchange', this);
  }

  '_handle_mozChrome-permission-prompt'(evt) {
    // Format of evt.detail:
    // {
    //    id: '',
    //    isApp: true|false,
    //    isGranted: true|false,
    //    manifestURL: '',
    //    origin: '',
    //    permissions: {
    //      'audio': [],
    //      'video': [],
    //      'geolocation': []
    //    },
    //    remember: true|false,
    //    type: 'permission-prompt'
    // }
    var detail = evt.detail;
    detail.allow = (remember) => {
      var result = {
        id: detail.id,
        type: 'permission-allow',
        remember: remember || false
      };
      this.dispatchResponse(this.configMediaPermissions(detail, result, true));
    };
    detail.deny = (remember) => {
      var result = {
        id: detail.id,
        type: 'permission-deny',
        remember: remember || false
      };
      this.dispatchResponse(this.configMediaPermissions(detail, result));
    };
    detail.name = Service.query('getTopMostWindow').name || '';
    this.requests.push(detail);
    this.handleRequests();
  }

  configMediaPermissions(detail, result, isAllowConfig) {
    if (detail.permissions) {
      var currentChoices = {};
      for (var permission2 in detail.permissions) {
        if (detail.permissions.hasOwnProperty(permission2)) {
          if (detail.permissions[permission2].length > 0) {
            // Check video-capture with front/back options.
            // Then, we can show option menu for camera configuration.
            if (isAllowConfig && (permission2 === 'video-capture')) {
              // Saving current choices.
              this._pendingResponse = {
                detail: detail,
                result: result,
                currentChoices: currentChoices,
                permission: permission2
              };
              // Show option menu for select front/back camera.
              Service.request('showOptionMenu', {
                header: 'select',
                options: this._listItems(detail.permissions[permission2]),
                onCancel: this.choose.bind(this),
                hasCancel: true
              }, Service.query('getTopMostWindow'));
              // Early return here,
              // Pending to dispatch response until get result from select.
              return;
            } else {
              currentChoices[permission2] = detail.permissions[permission2][0];
            }
          }
        }
      }
      if ('audio-capture' in detail.permissions ||
        'video-capture' in detail.permissions) {
        result.choices = currentChoices;
      }
    }
    return result;
  }

  _listItems(choices) {
    let _ = navigator.mozL10n.get;
    var items = [];
    choices.forEach((choice, index) => {
      items.push({
        label: _(`${choice}-camera`),
        callback: () => {
          this.choose(index);
        },
        value: index
      });
    });
    return items;
  }

  choose(index = 0) { // default is front camera
    let currentChoices = this._pendingResponse.currentChoices;
    let permission = this._pendingResponse.permission;
    let result = this._pendingResponse.result;
    currentChoices[permission] =
      this._pendingResponse.detail.permissions[permission][index];
    result.choices = currentChoices;
    this.dispatchResponse(result);
  }

  dispatchResponse(result) {
    var evt = new CustomEvent('mozContentEvent', { detail: result });
    window.dispatchEvent(evt);
  }

  _handle_fullscreenchange() {
    // XXX: Maybe not a good place to do it.
    if (!document.mozFullScreen) {
      Service.request('focus');
    }
  }

  '_handle_lockscreen-appopened'() {
    // XXX: Maybe not a good place to do it.
    if (document.mozFullScreen) {
      document.mozCancelFullScreen();
    }
  }

  handleRequests() {
    var current = this.requests.shift();
    if (!current) {
      return;
    }
    var topMost = Service.query('getTopMostWindow').getTopMostWindow();
    if (topMost._permissionDialog) {
      topMost._permissionDialog.show(current);
    } else {
      var overlay = document.createElement('div');
      overlay.classList.add('permission-root');
      topMost.element.appendChild(overlay);
      topMost._permissionDialog = ReactDOM.render(<PermissionDialog app={topMost}/>, overlay);
      topMost._permissionDialog.show(current);
    }
  }
}

var instance = new PermissionManager();
instance.start();

export default instance;
