'use strict';

import React from 'react';
import ReactDOM from 'react-dom';
import BaseComponent from 'base-component';
import SettingsManager from 'settings-manager';

import '../../../scss/lockscreen/passcode.scss';

export default class Passcode extends BaseComponent {
  name = 'Passcode';
  DEBUG = false;

  PASSCODE_SIZE = 4;

  VALIDING_TIMEOUT = 300;
  ERROR_STATE_TIMEOUT = 1500;

  qwertyKeyMapping = {
    'w': '1', 'e': '2', 'r': '3', 's': '4', 'd': '5',
    'f': '6', 'z': '7', 'x': '8', 'c': '9', ',': '0'
  };


  static defaultProps = {
    softRightHandler: () => {},
    softLeftHandler: () => {},
    unlock: () => {}
  }

  constructor(props) {
    super(props);
    this.state = {
      passcode: '0000',
      currentPasscode: '',
      error: '',
      validing: false
    };
  }

  /**
   * Set closed/opened listeners once mounted
   */
  componentDidMount() {
    this.debug('did mount, should be locked by passcode');
    this.element = ReactDOM.findDOMNode(this);
    SettingsManager.addObserver('lockscreen.passcode-lock.code', this);

    window.document.getElementById('screen').classList.add('locked');
  }

  /**
   * Store user set passcode in state
   */
  '_observe_lockscreen.passcode-lock.code'(value) {
    this.debug('passcode change observed:');
    this.setState({
      passcode: value
    });
  }

  componentWillUnmount() {
    this.debug('will unmount: remove observer:');
    SettingsManager.removeObserver('lockscreen.passcode-lock.code', this);
    window.document.getElementById('screen').classList.remove('locked');
  }

  /**
   * Try to validate current passcode
   */
  componentDidUpdate() {
    this.debug('did update');
    if (this.state.validing) {
      return;
    }
    if (this.state.currentPasscode === this.state.passcode) {
      this.setState({
        validing: true
      });

      if (!OrientationManager.isDefaultPortrait()) {
        this.element.classList.add('hide');
      }

      setTimeout(() => {
        this.props.unlock();
      }, this.VALIDING_TIMEOUT);
    } else if (this.state.currentPasscode.length === this.state.passcode.length) {
      this.setState({
        validing: true,
        error: 'incorrect'
      });
      setTimeout(() => {
        this.setState({
          validing: false,
          currentPasscode: '',
          error: ''
        });
      }, this.ERROR_STATE_TIMEOUT);
    }
  }

  onKeyDown(evt) {
    if (document.hidden) {
      return;
    }
    let keycode = this.qwertyKeyMapping[evt.key] || evt.key;
    switch (keycode) {
      case 'SoftRight':
        this.props.softRightHandler();
        break;
      case 'SoftLeft':
        this.props.softLeftHandler();
        break;
      case '1':
      case '2':
      case '3':
      case '4':
      case '5':
      case '6':
      case '7':
      case '8':
      case '9':
      case '0':
        evt.preventDefault();
        evt.stopPropagation();
        if (this.state.validing) {
          break;
        }
        this.setState({
          currentPasscode: this.state.currentPasscode + keycode
        });
        break;
      case 'Backspace':
        evt.preventDefault();
        evt.stopPropagation();
        if (this.state.validing) {
          break;
        }
        if (this.state.currentPasscode.length) {
          this.setState({
            currentPasscode: this.state.currentPasscode.substr(0, this.state.currentPasscode.length - 1)
          });
        }
        break;
    }
  }

  render() {
    this.debug('ready to render');
    const passcode = this.state.currentPasscode.split('');
    let dom = [];

    for (let i = 0; i < this.PASSCODE_SIZE; i++) {
      const className = (passcode[i] !== undefined) ? 'code dotted' : 'code';
      dom.push(<div className={className} key={i}><div className="dot" /></div>);
    }
    return <div id="passcode-view" className={this.state.error ? 'error' : ''}
      onKeyDown={(e)=>this.onKeyDown(e)} tabIndex="-1">
      <div className="secondary info-text"
        data-l10n-id={this.state.error ? 'lockscreenCheckLockCode' : 'lockscreenEnterLockCode'} />
      <div className="codes">
        {dom}
      </div>
    </div>;
  }
}
