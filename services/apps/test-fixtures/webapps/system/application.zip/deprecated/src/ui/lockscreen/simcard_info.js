/*global SIMSlotManager */
'use strict';

import React from 'react';
import ReactDOM from 'react-dom';
import BaseComponent from 'base-component';
import SettingsManager from 'settings-manager';
import '../../../scss/lockscreen/simcard_info.scss';

export default class SimcardInfo extends BaseComponent {
  name = 'SimcardInfo';

  DEBUG = false;
  simCardsName = {};
  constructor(props) {
    super(props);
    this.state = {
      isAirplaneMode: false,
      cardInfos: []
    };
  }

  componentDidMount() {
    this._initCardInfos();

    SettingsManager.addObserver('airplaneMode.enabled', this);
    SettingsManager.addObserver('custom.simcards.name', this);
  }

  '_observe_custom.simcards.name'(value) {
    this.simCardsName = value || {};
    this._updateCardInfos();
  }

  '_observe_airplaneMode.enabled'(value) {
    this.setState({
      isAirplaneMode: value
    });
  }

  /**
   * Assign event handlers and update cardInfos once
   */
  _initCardInfos(){
    const conns = navigator.mozMobileConnections;
    if (!conns) {
      return;
    }

    if (SIMSlotManager.ready) {
      Array.from(conns).forEach( (conn, index) => {
        if (!SIMSlotManager.isSIMCardAbsent(index)) {
          conn.addEventListener('datachange', this);
          conn.addEventListener('voicechange', this);
          conn.addEventListener('signalstrengthchange', this);
        }
      });
    } else {
      window.addEventListener('simslotready', this);
    }
    this._updateCardInfos();
  }

  componentWillUnmount() {
    SettingsManager.removeObserver('airplaneMode.enabled', this);
    SettingsManager.removeObserver('custom.simcards.name', this);
    const conns = navigator.mozMobileConnections;
    if (conns) {
      Array.from(conns).forEach( (conn, index) => {
        if (!SIMSlotManager.isSIMCardAbsent(index)) {
          conn.removeEventListener('datachange', this);
          conn.removeEventListener('voicechange', this);
          conn.removeEventListener('signalstrengthchange', this);
        }
      });
    }
  }

  /**
   * Update cardInfos by looping all mozMobileConnections
   * Object structure in cardInfos:
   * {
   *  signalLevel: 1, // 1~5
   *  carrierName: 'Far EasTone'  // long name
   * }
   */
  _updateCardInfos(){
    const conns = navigator.mozMobileConnections;
    if (!conns) {
      return;
    }

    let cardInfos = [];
    const simSlots = SIMSlotManager.getSlots();

    Array.from(conns).forEach( (conn, index) => {
      const isAbsent = !conn.iccId;

      // Raw signal level from MozMobileConnections is -1~4
      // we normalize it to 0~5 for data-icon convenient
      let signalLevel = 0;
      if (!isAbsent && conn.voice.connected) {
        if (conn.signalStrength) {
          signalLevel = conn.signalStrength.level + 1;
        } else {
          signalLevel = Math.ceil(conn.voice.relSignalStrength / 20);
        }
      }

      let stateL10nId, carrierName;
      let data = conn.data;
      let network;
      let voice_data = conn.voice ? conn.voice : conn.data;
      if (conn.voice && conn.voice.connected) {
        network = conn.voice.network;
      } else if (data && data.state === 'registered') {
        network = conn.data.network;
      }
      if (isAbsent) {
        stateL10nId = 'noSimCard';
      } else if (simSlots[index].getCardState() !== 'ready') {
        stateL10nId = 'lockedSim';
      } else if (voice_data.state === 'searching') {
        stateL10nId = 'searching';
      } else if (voice_data.emergencyCallsOnly) {
        stateL10nId = 'noService';
      } else if (network) {
        let iccid = conn.iccId;
        let iccObj = navigator.mozIccManager.getIccById(iccid);
        let iccInfo = iccObj ? iccObj.iccInfo : null;
        let operator = network ? network.longName : null;
        if (operator && iccInfo && iccInfo.isDisplaySpnRequired && iccInfo.spn) {
          if (iccInfo.isDisplayNetworkNameRequired && operator !== iccInfo.spn) {
            operator = operator + ' ' + iccInfo.spn;
          } else {
            operator = iccInfo.spn;
          }
        }
        carrierName = this.simCardsName[conn.iccId] || operator;
      } else {
        stateL10nId = 'noService';
      }

      cardInfos.push({
        signalLevel,
        carrierName,
        stateL10nId
      });
    });

    this.setState({ cardInfos });
  }

  /**
   * Handle mobile connection data change.
   * Just update all card infos.
   */
  '_handle_datachange'(evt) {
    this._updateCardInfos();
  }

  '_handle_voicechange'(evt) {
    this._updateCardInfos();
  }


  '_handle_signalstrengthchange'(evt) {
    this._updateCardInfos();
  }

  '_handle_simslotready'(evt) {
    window.removeEventListener('simslotready', this);
    this._initCardInfos();
  }

  /**
   * Currently only render information for multi sim card devices
   */
  render() {
    this.debug('Ready to render SimcardInfo');

    const isMultiSIM = SIMSlotManager.isMultiSIM();
    const infoDOMs = !isMultiSIM ? [] : this.state.cardInfos.map(function(info, index){
      const cardDOM = (
        <div className='icon-wrapper'>
          <div className='icon inactive' data-icon={`sim-${index+1}`}>
            <div className='icon' data-icon='signal-0' />
          </div>
        </div>
      );

      const signalDOM = (
        <div className='icon-wrapper' data-is-searching={info.stateL10nId === 'searching'}>
          <div className='icon level' data-index={`${index+1}`} data-icon={`signal-${info.signalLevel}`} />
          <div className='icon bg' data-icon={'signal-5'} />
        </div>
      );

      const textClass = SIMSlotManager.isSIMCardAbsent(index) ? 'text inactive' : 'text';
      return (
        <div className='info-row' key={index}>
          { ['noSimCard', 'noService', 'lockedSim'].includes(info.stateL10nId) ? cardDOM : signalDOM }
          <div className='carrier-name secondary'>
            <span className={textClass} data-l10n-id={info.stateL10nId}>{info.carrierName}</span>
          </div>
        </div>
      );
    });

    const apmDOM = !isMultiSIM ? null : (
      <div className='airplane-mode-info' data-l10n-id='airplane-mode' />
    );

    return <div id="simcard-info" data-is-airplane-mode={this.state.isAirplaneMode}>
      {infoDOMs}
      {apmDOM}
    </div>;
  }
}
