import React from 'react';
import ReactDOM from 'react-dom';

import NotificationView from './ui/notification_view';
import NotificationToaster from './ui/notification_toaster';
import NotificationDialogView from './ui/notification_dialog_view';
import SoftKeyManager from './ui/soft_key_manager';
import SystemToaster from './ui/system_toaster';
import LockscreenView from './ui/new_lock_screen_view';
import StkDialog from './ui/stk_dialog';
import SystemOptionMenu from './ui/system_option_menu';
import InstantSettings from './ui/instant_settings/instant_settings';

ReactDOM.render(<NotificationView />, document.getElementById('notification-root'));
ReactDOM.render(<NotificationToaster />, document.getElementById('notification-toaster-root'));
ReactDOM.render(<NotificationDialogView />, document.getElementById('notification-dialog-root'));
ReactDOM.render(<SoftKeyManager />, document.getElementById('soft-key-root'));
ReactDOM.render(<SystemToaster />, document.getElementById('system-toaster-root'));
ReactDOM.render(<LockscreenView />, document.getElementById('lockscreen-root'));
ReactDOM.render(<StkDialog />, document.getElementById('stk-root'));
ReactDOM.render(<SystemOptionMenu />, document.getElementById('system-option-menu-root'));
ReactDOM.render(<InstantSettings />, document.getElementById('instant-settings-root'));
