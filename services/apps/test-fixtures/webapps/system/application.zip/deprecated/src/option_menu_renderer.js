import React from 'react';
import ReactDOM from 'react-dom';
import BaseModule from 'base-module';
import OptionMenu from 'react-option-menu';

class OptionMenuRenderer extends BaseModule {
  name = 'OptionMenuRenderer';
  optionMenu = null;
  start() {
    Service.register('showOptionMenu', this);
    Service.register('hideOptionMenu', this);
  }

  hideOptionMenu() {
    this.optionMenu && this.optionMenu.hide();
    this.optionMenu = null;
  }
  showOptionMenu(config, module) {
    if (!module.element) {
      var menu = ReactDOM.render(<OptionMenu />, document.getElementById('menu-root'));
      menu.show(config);
      menu.on('closed', () => {
        Service.request('focus');
      });
      this.optionMenu = menu;
      return;
    }
    if (module._optionMenu) {
      module._optionMenu.show(config);
    } else {
      var overlay = document.createElement('div');
      overlay.classList.add('option-menu-root');
      module.element.appendChild(overlay);
      module._optionMenu = ReactDOM.render(<OptionMenu />, overlay);
      module._optionMenu.on('opened', () => {
        Service.request('focus');
      });
      module._optionMenu.show(config);
      module._optionMenu.on('closed', () => {
        Service.request('focus');
      });
    }
    this.optionMenu = module._optionMenu;
  }
}

var instance = new OptionMenuRenderer();
instance.start();

export default instance;
