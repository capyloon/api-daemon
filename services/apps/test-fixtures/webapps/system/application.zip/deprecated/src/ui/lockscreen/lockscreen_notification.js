'use strict';

import React from 'react';
import ReactDOM from 'react-dom';
import BaseComponent from 'base-component';
import NotificationStore from '../../notification_store';

import '../../../scss/lockscreen/lockscreen_notification.scss';

export default class LockscreenNotification extends BaseComponent {
  name = 'LockscreenNotification';

  DEBUG = false;

  static defaultProps = {
    enabled: false
  };

  static propTypes = {
    enabled: React.PropTypes.bool
  };

  constructor(props) {
    super(props);
    this.state = {
      badgeCountMap: new Map()
    };
  }

  componentDidUpdate() {
    if (this.props.enabled) {
      this.show();
    } else {
      this.hide();
    }
  }

  componentDidMount() {
    this.element = ReactDOM.findDOMNode(this);

    window.addEventListener('notification-add-to-lockscreen', (detail) => {
      this.setState({
        badgeCountMap: NotificationStore.newComingCountMap
      });
    });
  }

  /**
   * Generate icon DOM by app name and badge count
   * @param {string} appName Ex. 'E-Mail', 'Messages'
   * @private
   */
  _iconDOMFactory(appName){
    const iconName = NotificationStore.ICON_MAP[appName];
    const badgeCount = this.state.badgeCountMap.get(appName);

    return <div className='icon-panel' key={appName}>
      <div className='icon' data-icon={iconName}></div>
      <div className='badge'>
        <span className='count thirdary'>{badgeCount}</span>
      </div>
    </div>;
  }

  /**
   * Produce icon DOMs and arrange with different classes
   */
  render() {
    let iconDOMs = [];

    // loop predefined app names
    this.state.badgeCountMap.forEach((count, appName) => {
      if (count <= 0) {
        return;
      }
      const dom = this._iconDOMFactory(appName);
      iconDOMs.push(dom);
    });

    const className = `icon${iconDOMs.length}`;

    return <div id="lockscreen-notification" className={className}>
      {iconDOMs}
    </div>;
  }
}
