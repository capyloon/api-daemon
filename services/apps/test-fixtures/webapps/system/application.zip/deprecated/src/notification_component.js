import React from 'react';

import BaseComponent from 'base-component';
import SettingsManager from 'settings-manager';

const SettingsURL = window.SettingsURL;

const withRingtone = (WrappedComponent) => {
  const FALLBACK_RINGTONE = 'shared/resources/media/notifications/notifier_chime.opus';
  return class extends WrappedComponent {
    audio = new Audio();
    ringtoneURL = new SettingsURL();

    constructor(props) {
      super(props);
      SettingsManager.addObserver('audio.volume.notification', this);
      SettingsManager.addObserver('notification.ringtone', this);
    }

    '_observe_audio.volume.notification'(value) {
      this.silent = (0 === value);
    }

    '_observe_notification.ringtone'(value) {
      this.ringtoneURL.set(value);
    }

    stopRingtone() {
      if (this.audio.paused) {
        return;
      }
      this.audio.pause();
      this.debug('stop ringtone');
    }

    setRingtone(soundFile) {
      this.stopRingtone();
      this.audio.src = soundFile;
      this.audio.mozAudioChannelType = 'notification';
      this.audio.load();
      this.debug(`set ringtone: ${soundFile}`);
    }

    playRingtone(behavior={}) {
      if (this.silent) {
        this.debug('ringtone volume: 0');
        return;
      }
      if (behavior.silent) {
        this.debug('mozbehavior.silent: true');
        return;
      }
      const soundFile = behavior.soundFile
        || this.ringtoneURL.get()
        || FALLBACK_RINGTONE;
      this.setRingtone(soundFile);
      this.audio.play();
      this.debug(`playing ringtone: ${this.audio.src}`);
    }

    render() {
      return <WrappedComponent {...this.props} />;
    }
  };
};

const withVibration = (WrappedComponent) => {
  return class extends WrappedComponent {
    constructor(props) {
      super(props);
      SettingsManager.addObserver('vibration.enabled', this);
    }

    '_observe_vibration.enabled'(value) {
      this.vibrationEnabled = value;
    }

    getVibrationPattern(behavior={}) {
      const customPattern = behavior.vibrationPattern;
      const defaultPattern = [200, 200, 200];
      return (customPattern && customPattern.length && customPattern[0] > 0)
        ? customPattern
        : defaultPattern;
    }

    vibrate(behavior={}) {
      this.debug(`this.vibrationEnabled: ${this.vibrationEnabled}`);
      if (!this.vibrationEnabled || behavior.silent) {
        return;
      }
      const pattern = this.getVibrationPattern(behavior);
      this.debug(`vibration pattern: [${pattern}]`);
      navigator.vibrate(pattern);
    }

    render() {
      return <WrappedComponent {...this.props} />;
    }
  };
};

const NotificationComponent = withVibration(withRingtone(BaseComponent));
export default NotificationComponent;
