import React from 'react';
import ReactDOM from 'react-dom';
import ReactDialog from 'react-dialog';
import '../scss/google_dialog.scss';

export default class GoogleDialog extends ReactDialog {
  name = 'GoogleDialog';

  flat(targetArray) {
    return [].concat(...targetArray);
  }

  insertBetween(targetArray, insertElem) {
    return this.flat(targetArray.map((elem) => [insertElem, elem])).slice(1);
  }

  replaceTextWithComponent(sourceText, placeholder, component) {
    if (!sourceText) { return ''; }
    if (!sourceText.includes(placeholder)) { return sourceText; }
    return (
      <div>
        {this.insertBetween(sourceText.split(placeholder), component)}
      </div>
    );
  }

  render() {
    return (
      <div
        className="dialog-container"
        tabIndex="-1"
        onKeyDown={(e) => this.onKeyDown(e)}
        ref={(dom)=>{this.element=dom;}}
        onBlur={()=>{this.onBlur();}}
      >
        <div role="heading" className="dialog" aria-labelledby={'dialog-header-' + this.getInstanceID()}>
          <div className="google-assistant-header h1" id={'dialog-header-' + this.getInstanceID()}></div>
          <div className="content p-ul google-text" tabIndex="-1">
            {this.replaceTextWithComponent(
              navigator.mozL10n.get(this.props.content),
              '{{ microphone }}',
              <i className="google-microphone" data-icon="google-voice" />
            )}
          </div>
          <div className="google-voice-input-image"></div>
        </div>
      </div>
    );
  }
}
