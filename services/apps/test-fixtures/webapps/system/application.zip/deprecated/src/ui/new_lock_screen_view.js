/* global Service */

import React from 'react';
import BaseComponent from 'base-component';
import SettingsManager from 'settings-manager';
import SoftKeyStore from 'soft-key-store';
import EnhanceAnimation from '../enhance_animation';
import Clock from '../clock';
import NotificationStore from '../notification_store';

import LockscreenNotification from './lockscreen/lockscreen_notification';
import SimcardInfo from './lockscreen/simcard_info';
import LockmodePocket from './lockscreen/lockmode_pocket';
import Passcode from './lockscreen/passcode';
import PasscodeRemoteLock from './lockscreen/passcode_remote_lock';

import './lockscreen/lockscreen_migrator';

import '../../scss/lockscreen/lockscreen.scss';

class LockscreenView extends BaseComponent {
  name = 'LockscreenView';

  DEBUG = false;

  EVENT_PREFIX = 'lockscreen-';

  firstLaunch = true;
  autoLockEnabled = false;

  remoteLockEnabled = false;

  /**
   * To keep the origin screen orientation
   * even the other app changed the orientation(e.g. Video app)
   * before going to lock state.
   */
  _originOrientationType = screen.orientation.type;

  /**
   * To retore the last orientation type set by other app.
   */
  _lastOrientationType = screen.orientation.type;

  constructor(props) {
    super(props);
    this.state = {
      mode: 'none', // none, pocket, passcode, remotePasscode
      lockEnabled: false,
      remoteLockEnabled: false,
      notificationEnabled: false
    };

    this.unlock = this.pocketUnlocked.bind(this);
    this.pocketUnlocked = this.pocketUnlocked.bind(this);
    this.passcodeUnlocked = this.passcodeUnlocked.bind(this);
    this.remotePasscodeUnlocked = this.remotePasscodeUnlocked.bind(this);
    this.initRemoteLockStatus();
  }

  initRemoteLockStatus() {
    let lock = navigator.mozSettings.createLock();
    lock.get('lockscreen.remote-lock').then(value => {
      let lockInfo = value['lockscreen.remote-lock'];
      this.remoteLockEnabled = !!(lockInfo && lockInfo[1]);
    });
    if (lock.forceClose) {
      lock.forceClose();
    }
  }

  setHierarchy(value) {
    if (value) {
      this.focus();
    } else {
      // clean up
    }
  }

  '_observe_lockscreen.unlocked'(unlocked) {
    if (unlocked) {
      this.setState({
        mode: 'none'
      });
    }
  }

  '_observe_lockscreen.enabled'(lockEnabled) {
    this.debug('observed lockEnabled:', lockEnabled);
    this.setState({
      lockEnabled
    });
    if (this.firstLaunch) {
      this.firstLaunch = false;
      this.lockIfEnabled();
    }
  }

  '_observe_lockscreen.notifications-preview.enabled'(value) {
    this.setState({
      notificationEnabled: value
    });
  }

  '_observe_lockscreen.lock-immediately'(value) {
    if (value === true) {
      this.lockIfEnabled();
    }
  }

  '_observe_pocketmode.autolock.enabled'(value) {
    if (value === undefined) {
      value = true;
    }
    this.autoLockEnabled = !!value;
  }

  // detect whether should enable remote lock or not
  // let PasscodeRemoteLock manage the passcode value
  '_observe_lockscreen.remote-lock'(value) {
    this.debug('_observe_lockscreen.remote-lock:', value);
    const remoteLockEnabled = !!value[1];
    this.remoteLockEnabled = remoteLockEnabled;
    this.setState({
      remoteLockEnabled
    });

    if (remoteLockEnabled) {
      this.setMode('remotePasscode');
    }
  }

  lockIfEnabled() {
    // Prioritize anti-theft lock
    if (this.state.remoteLockEnabled) {
      this.setMode('remotePasscode');
    } else if (this.state.lockEnabled) {
      this.setMode('passcode');
    }
  }

  componentDidUpdate(prevProps, prevState) {
    this.debug('did update: mode, lockEnabled:', this.state.mode, this.state.lockEnabled);
    this.publish('lockmode-change', {
      mode: this.state.mode
    }, true);

    if (prevState.mode === 'none') {
      this._lastOrientationType = screen.orientation.type;
    }

    if (this.state.mode === 'none') {
      screen.orientation.lock(this._lastOrientationType);
      this.publish('lockscreen-request-unlock', null, true);
      this.close();
      this._toggleLockedSetting(false);
    } else if (this.state.mode === 'pocket' ||
      (this.state.lockEnabled && this.state.mode === 'passcode') ||
      this.state.remoteLockEnabled) {
      screen.orientation.lock(this._originOrientationType);
      this.open();
      Service.request('focus');
      this._toggleLockedSetting(true);
    }
    this.updateSoftKeys();
  }

  componentDidMount() {
    this.debug('did mount');
    // init some handlers
    this._init();

    this.updateSoftKeys();
  }

  updateSoftKeys() {
    let config = {};

    switch (this.state.mode) {
      case 'passcode':
      case 'remotePasscode':
        config = {
          left: 'emergency-call',
          center: '',
          right: 'camera'
        };
        break;
      default:
        break;
    }

    SoftKeyStore.register(config, this.element);
  }

  _init() {
    window.Service.request('registerHierarchy', this);
    window.addEventListener('beforescreenoff', this);

    window.Service.registerState('locked', this);
    window.Service.registerState('isPocketMode', this);
    window.Service.registerState('remoteLockEnabled', this);
    window.Service.register('lock', this);
    window.Service.register('unlock', this);

    SettingsManager.addObserver('lockscreen.unlocked', this);
    SettingsManager.addObserver('lockscreen.enabled', this);
    SettingsManager.addObserver('lockscreen.lock-immediately', this);
    SettingsManager.addObserver('lockscreen.notifications-preview.enabled', this);
    SettingsManager.addObserver('lockscreen.remote-lock', this);
    SettingsManager.addObserver('pocketmode.autolock.enabled', this);
  }

  /**
   * For bartype, when screen on again, open in 'pocket' mode
   */
  _handle_beforescreenoff(evt) {
    // Don't lock if screen is turned off by promixity sensor.
    if (evt.detail.screenOffBy == 'proximity') {
      return;
    }
    this.debug('beforescreenoff: mode:', this.state.mode);

    let mode;
    if (this.state.remoteLockEnabled) {
      mode = 'remotePasscode';
    } else if (this.autoLockEnabled || this.isPocketMode()) {
      mode = 'pocket';
    } else if (this.state.lockEnabled) {
      mode = 'passcode';
    } else {
      mode = 'none';
    }
    this.setMode(mode);
  }

  _toggleLockedSetting(value) {
    if (!navigator.mozSettings || (value && !this.state.lockEnabled)) {
      return;
    }
    navigator.mozSettings.createLock().set({ 'lockscreen.locked': value });
  }

  onKeyDown(evt) {
    switch (evt.key) {
      case 'EndCall':
        // back to pocketmode if available
        if (this.state.mode != 'pocket' &&
            this.autoLockEnabled && !this.state.remoteLockEnabled) {
          this.setMode('pocket');
        }
        break;
    }
  }

  focus() {
    if (this.refs.activeLock) {
      this.refs.activeLock.focus();
    }
  }

  lock = () => {
    if (!this._ensureLockable()) {
      return;
    }
    if (this.state.mode == 'none') {
      this.debug('to pocket mode');
      this.setMode('pocket');
    }
  };

  pocketUnlocked() {
    if (!this._ensureLockable()) {
      return;
    }
    this.debug('pocketUnlocked:');
    NotificationStore.resetNewComingCount();
    if (this.state.lockEnabled) {
      this.setMode('passcode');
    } else {
      this.setMode('none');
    }
  }

  _ensureLockable() {
    let _topName = Service.query('getTopMostUI').name;
    let _topWindow = Service.query('getTopMostWindow');
    let _topWindowIsHome = _topWindow && _topWindow.isHomescreen;

    // permit to lock/unlock only in this view, option menu & homescreen
    return (
      _topName === 'LockscreenView' ||
      _topName === 'SystemOptionMenu' ||
      (
        _topWindowIsHome &&
        _topName === 'AppWindowManager'
      )
    );
  }

  passcodeUnlocked() {
    this.debug('passcodeUnlocked:');
    this.setMode('none');
  }

  remotePasscodeUnlocked() {
    this.debug('passcodeRemoteUnLock:');
    if (this.state.lockEnabled) {
      this.setMode('passcode');
    } else {
      this.setMode('none');
    }
  }

  locked() {
    return this.isActive();
  }

  isPocketMode() {
    return this.state.mode === 'pocket';
  }

  /**
   * Set lock mode and do lock
   */
  setMode(mode) {
    this.debug('set to mode:', mode);
    this.setState({ mode });
  }

  invokeSecureApp(name) {
    let url = window.parent.location.href.replace('system', name);
    const manifestUrl = url.replace(/(\/)*(index.html#?)*$/, '/manifest.webapp');

    url += '#secure';
    window.dispatchEvent(new window.CustomEvent('secure-launchapp',
      {
        'detail': {
          'appURL': url,
          'appManifestURL': manifestUrl
        }
      }
    ));
  }

  render() {
    this.debug('ready to render: mode:', this.state.mode);

    const activeLockIndex = {
      'none': null,
      'pocket': <LockmodePocket ref='activeLock'
        unlock={this.pocketUnlocked} />,
      'passcode': <Passcode ref="activeLock"
        unlock={this.passcodeUnlocked}
        softRightHandler={this.invokeSecureApp.bind(this, 'camera')}
        softLeftHandler={this.invokeSecureApp.bind(this, 'emergency-call')}
      />,
      'remotePasscode': <PasscodeRemoteLock ref="activeLock"
        unlock={this.remotePasscodeUnlocked}
        softRightHandler={this.invokeSecureApp.bind(this, 'camera')}
        softLeftHandler={this.invokeSecureApp.bind(this, 'emergency-call')}
      />
    };

    const notificationEnabled = this.state.notificationEnabled &&
      this.state.mode === 'pocket';

    const clockClassName = 'passcode' === this.state.mode ? 'in-passcode-mode' : '';

    return <div
      id='lockscreen-view'
      role='presentation'
      ref={ c => this.element = c }
      tabIndex={-1}
      onKeyDown={(e) => this.onKeyDown(e)}
      onFocus={this.focus.bind(this)}>
      { !this.state.remoteLockEnabled ? <SimcardInfo /> : null}
      { !this.state.remoteLockEnabled ? <Clock ref='clock' className={clockClassName} /> : null}
      <LockscreenNotification ref='notification' enabled={notificationEnabled} />
      <div id='lockscreen-bottom' className={this.state.remoteLockEnabled ? 'has-remote-lock' : ''}>
        {activeLockIndex[this.state.mode]}
      </div>
    </div>;
  }
}

export default EnhanceAnimation(LockscreenView, 'immediate', 'fade-out');
