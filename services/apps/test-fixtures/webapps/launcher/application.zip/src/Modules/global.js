import produce from 'immer';
import { GlobalStates } from '../Constants';

// Redux Action Strings
/* eslint-disable max-len */
export const SHIFT_STATE = 'launcher/fsm/SHIFT_STATE';

export const TOGGLE_EDIT_MODE = 'launcher/edit/TOGGLE_EDIT_MODE';
export const TOGGLE_ITEM_SELECTION = 'launcher/edit/TOGGLE_ITEM_SELECTION';
export const DESELECT_ALL = 'launcher/edit/DESELECT_ALL';

export const TOGGLE_DND_MODE = 'launcher/edit/TOGGLE_DND_MODE';

export const TOGGLE_GROUP_VIEW = 'launcher/user/TOGGLE_GROUP_VIEW';

export const REQUEST_CONFIRMATION = 'launcher/user/REQUEST_CONFIRMATION';
export const CONFIRM_DIALOG = 'launcher/ui/CONFIRM_DIALOG';
export const CANCEL_DIALOG = 'launcher/ui/CANCEL_DIALOG';

export const NAVIGATE_TO = 'launcher/nav/NAVIGATE_TO';
export const NAVIGATE_BACK = 'launcher/nav/NAVIGATE_BACK';
export const UPDATE_ROUTE = 'launcher/nav/UPDATE_ROUTE';
export const HANDLE_HOME_BUTTON = 'launcher/nav/HANDLE_HOME_BUTTON';

export const LAUNCH_ITEM = 'launcher/user/LAUNCH_ITEM';
export const DELETE_ITEMS = 'launcher/user/DELETE_ITEMS';
/* eslint-enable max-len */

const initialState = {
  route: 'home',
  status: GlobalStates.idle,
  editMode: {
    enabled: false,
    selectedItems: []
  },
  dndMode: {
    enabled: false,
    selectedItem: null,
    initialCoordinate: null,
    touchId: null,
    sourceSpace: null
  },
  dialog: {
    enabled: false,
    // The deferred action which will be invoked after the confirmation.
    deferredAction: null
  },
  groupView: {
    enabled: false,
    current: null
  }
};

// Redux Reducer
export default function reducer(state = initialState, action) {
  return produce(state, (draft) => {
    switch (action.type) {
      case UPDATE_ROUTE: {
        const { route } = action.payload;
        draft.route = route;
        console.log('Update route to -->', route);
        break;
      }
      case TOGGLE_EDIT_MODE: {
        const { enabled } = action.payload;
        if (typeof enabled === 'boolean') {
          // Reset the edit mode.
          draft.editMode.enabled = enabled;
          draft.editMode.selectedItems = [];
          // Reset the DND mode as well.
          draft.dndMode.enabled = false;
          draft.dndMode.selectedItem = null;
          draft.dndMode.initialCoordinate = null;
          draft.dndMode.touchId = null;
          draft.dndMode.sourceSpace = null;
        }
        break;
      }
      case TOGGLE_ITEM_SELECTION: {
        const { manifestURL, enabled } = action.payload;
        const matchedIndex =
          draft.editMode.selectedItems.indexOf(manifestURL);

        // Explictly enable/disable the seletion while `enabled` is given;
        // Otherwise, just toggle the selection.
        if (typeof enabled === 'boolean') {
          if (enabled === true && matchedIndex < 0) {
            draft.editMode.selectedItems.push(manifestURL);
          } else if (enabled === false && matchedIndex >= 0) {
            draft.editMode.selectedItems.splice(matchedIndex, 1);
          }
          return;
        }

        // Toggle the selection.
        if (matchedIndex >= 0) {
          draft.editMode.selectedItems.splice(matchedIndex, 1);
        } else {
          draft.editMode.selectedItems.push(manifestURL);
        }
        break;
      }
      case DESELECT_ALL: {
        draft.editMode.selectedItems = [];
        break;
      }
      case TOGGLE_DND_MODE: {
        const {
          enabled,
          selectedItem,
          touchId,
          initialCoordinate,
          sourceSpace
        } = action.payload;

        if (enabled === true) {
          draft.dndMode.enabled = enabled;
          draft.dndMode.selectedItem = selectedItem;
          draft.dndMode.touchId = touchId;
          draft.dndMode.initialCoordinate = initialCoordinate;
          draft.dndMode.sourceSpace = sourceSpace;
          // Deselect all
          draft.editMode.selectedItems = [];
        } else if (enabled === false) {
          draft.dndMode.enabled = enabled;
          draft.dndMode.selectedItem = null;
          draft.dndMode.touchId = null;
          draft.dndMode.initialCoordinate = null;
          draft.dndMode.sourceSpace = null;
        }
        break;
      }
      case TOGGLE_GROUP_VIEW: {
        const { enabled, manifestURL } = action.payload;
        if (enabled === true) {
          draft.groupView.enabled = enabled;
          draft.groupView.current = manifestURL;
        } else if (enabled === false) {
          draft.groupView.enabled = enabled;
          draft.groupView.current = null;
        }
        if (typeof enabled === 'boolean') {
          // Deselect item selection after toggling the group view.
          draft.editMode.selectedItems = [];
        }
        break;
      }
      case REQUEST_CONFIRMATION: {
        const { deferredAction } = action.payload;
        draft.dialog.deferredAction = deferredAction;
        draft.dialog.enabled = true;
        break;
      }
      case CONFIRM_DIALOG: {
        draft.dialog.deferredAction = null;
        draft.dialog.enabled = false;
        break;
      }
      case CANCEL_DIALOG: {
        draft.dialog.deferredAction = null;
        draft.dialog.enabled = false;
        break;
      }
      case LAUNCH_ITEM: {
        const { item } = action.payload;
        if (item.type === 'mozApp' && item.launch) {
          draft.launchState = 'launching';
          console.log(`Launching ${item.manifestURL}`);
          item.launch();
        }
        break;
      }
      default:
        break;
    }
  });
}

// Redux Action Creators

/**
 * Shift the global state from one to another.
 * @param {String} state - The next state.
 */
export const shiftState = (state) => ({
  type: SHIFT_STATE,
  payload: { state }
});

/**
 * Toggle the edit mode.
 * @param {Boolean} enabled - To explicitly enable/disable.
 */
export const toggleEditMode = (enabled) => ({
  type: TOGGLE_EDIT_MODE,
  payload: { enabled }
});

/**
 * Toggle the item selection.
 * @param {String} manifestURL - The manifestURL of the target item.
 * @param {Boolean} enabled - To explicitly enable/disable.
 */
export const toggleItemSelection = (manifestURL, enabled) => ({
  type: TOGGLE_ITEM_SELECTION,
  payload: { manifestURL, enabled }
});

/**
 * De-select all of the item selection.
 */
export const deselectAll = () => ({
  type: DESELECT_ALL
});

/**
 * Toggle the drag-n-drop mode.
 * @param {Boolean} enabled - To explicitly enable/disable.
 * @param {Object} params - Required parameters to enable the DND mode.
 */
export const toggleDndMode = (enabled, params) => ({
  type: TOGGLE_DND_MODE,
  payload: {
    enabled,
    ...params
  }
});

export const toggleGroupView = (enabled, manifestURL) => ({
  type: TOGGLE_GROUP_VIEW,
  payload: {
    enabled,
    manifestURL
  }
});

/**
 * Confirm the confirmation dialog.
 */
export const confirmDialog = () => ({
  type: CONFIRM_DIALOG
});

/**
 * Cancel the confirmation dialog.
 */
export const cancelDialog = () => ({
  type: CANCEL_DIALOG
});

/**
 * Handle the home button presses.
 */
export const handleHomeButton = () => ({
  type: HANDLE_HOME_BUTTON
});

/**
 * Navigate the route to given path;
 * This will also pushes route path to the history state.
 * @param {String} route - The next route.
 */
export const navigateTo = (route) => ({
  type: NAVIGATE_TO,
  payload: { route }
});

/**
 * Navigate the route backward for one step.
 */
export const navigateBack = () => ({
  type: NAVIGATE_BACK
});

/**
 * Update the route path (in redux state).
 * @param {String} route - The next route.
 */
export const updateRoute = (route) => ({
  type: UPDATE_ROUTE,
  payload: { route }
});

/**
 * Launch the item.
 * @param {Object} item - The target item.
 */
export const launchItem = (item) => ({
  type: LAUNCH_ITEM,
  payload: { item }
});

/**
 * Request for a confirmation dialog;
 * Can be used when the user triggers an action that
 * needs to be confirmed to proceed.
 * @param {Object} deferredAction - The deferred action to be triggered
 * after the confirmation.
 */
export const requestConfirmation = (deferredAction) => ({
  type: REQUEST_CONFIRMATION,
  payload: { deferredAction }
});

/**
 * Delete/Uninstall the item selection.
 * @param {Array} selectedItems - A list of item to be deleted.
 */
export const deleteItems = (selectedItems) => ({
  type: DELETE_ITEMS,
  payload: { selectedItems }
});
