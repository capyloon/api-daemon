import produce from 'immer';
import { TOGGLE_EDIT_MODE } from './global';
import {
  SPACE,
  allAppsSheetSize,
  favAppsListSize
} from '../Constants';
import {
  defaultFavApps,
  defaultAllApps
} from '../Constants/defaultPlacements';
import {
  isTwoDArray,
  isVisibleItem,
  isGroupSpace,
  getSpaceSheetSize,
  flatten,
  exclude,
  excludeTwoD,
  redistributeSheets,
  reorganizeSheets,
  findIndexInTwoDArray,
  findFirstAvailablePosition,
  findSourceSpaceByURL,
} from '../Shared/ItemUtils';

// Redux Action Strings
/* eslint-disable max-len */
export const MOZAPP_GET_ALL = 'launcher/mozApps/GET_ALL';
export const MOZAPP_UNINSTALL = 'launcher/mozApps/UNINSTALL';
export const MOZAPP_THROW_ERROR = 'launcher/mozApps/THROW_ERROR';

export const ADD_ITEM = 'launcher/items/ADD_ITEM';
export const REMOVE_ITEM = 'launcher/items/REMOVE_ITEM';
export const UPDATE_ITEM = 'launcher/items/UPDATE_ITEM';

export const CREATE_GROUP = 'launcher/groups/CREATE_GROUP';
export const REMOVE_GROUP = 'launcher/groups/REMOVE_GROUP';
export const MOVE_OUT_FROM_GROUP = 'launcher/groups/MOVE_OUT_FROM_GROUP';

export const CREATE_SPACE = 'launcher/spaces/CREATE_SPACE';
export const REMOVE_SPACE = 'launcher/spaces/REMOVE_SPACE';

export const MOVE_TO_SPACE = 'launcher/spaces/MOVE_TO_SPACE';
export const REMOVE_FROM_SPACE = 'launcher/spaces/REMOVE_FROM_SPACE';
/* eslint-enable max-len */

const initialState = {
  items: [],
  spaces: {
    parkingApps: null,
    favApps: null,
    allApps: null,
  },
  flags: {
    additionalBlankSheet: false
  }
};

let itemCount = 0;

export function resetCounter() {
  itemCount = 0;
}

export const itemReducers = {
  [ADD_ITEM]: (state, action) => produce(state, (draft) => {
    const { item } = action.payload;
    const matchedIndex =
      draft.items.findIndex((elem) => elem.manifestURL === item.manifestURL);
    item.id = itemCount++;

    // Deduplication
    if (matchedIndex >= 0) {
      console.warn(ADD_ITEM, 'Trying to add duplicated item:', item);
      draft.items[matchedIndex] = item;
      return;
    }

    draft.items.push(item);
  }),
  [REMOVE_ITEM]: (state, action) => produce(state, (draft) => {
    const { manifestURL } = action.payload;
    const matchedIndex =
      draft.items.findIndex((elem) => elem.manifestURL === manifestURL);
    if (matchedIndex < 0) {
      console.warn(REMOVE_ITEM, 'Item not found:', manifestURL);
      return;
    }
    draft.items.splice(matchedIndex, 1);
  }),
  [UPDATE_ITEM]: (state, action) => produce(state, (draft) => {
    const { manifestURL, nextItem } = action.payload;
    const matchedIndex =
      draft.items.findIndex((elem) => elem.manifestURL === manifestURL);
    if (matchedIndex < 0) {
      console.warn(UPDATE_ITEM, 'Item not found:', manifestURL);
      return;
    }
    // XXX: Come back later and see if this is a problematic manipulation.
    Object.keys(nextItem).forEach((key) => {
      draft.items[matchedIndex][key] = nextItem[key];
    });
  }),
};

export const spaceReducers = {
  [CREATE_SPACE]: (state, action) => produce(state, (draft) => {
    const { spaceName, initialValue } = action.payload;
    draft.spaces[spaceName] = initialValue;
  }),
  [REMOVE_SPACE]: (state, action) => produce(state, (draft) => {
    const { spaceName } = action.payload;
    delete draft.spaces[spaceName];
  }),
  [REMOVE_FROM_SPACE]: (state, action) => produce(state, (draft) => {
    const { manifestURL } = action.payload;
    const sourceSpace = findSourceSpaceByURL(draft.spaces, manifestURL);
    if (sourceSpace) {
      const { name, position } = sourceSpace;
      if (Array.isArray(position)) {
        draft.spaces[name][position[0]].splice(position[1], 1);
      } else {
        draft.spaces[name].splice(position, 1);
      }
    }
  }),
  [MOVE_TO_SPACE]: (state, action) => produce(state, (draft) => {
    const { manifestURL, toSpace, toPosition } = action.payload;
    let { fromSpace } = action.payload;

    // Action can bypass the source query removal by assigning
    // a null object to `fromSpace`.
    if (!fromSpace && fromSpace !== null) {
      console.warn(MOVE_TO_SPACE, 'The source space is not provided, trying to search from spaces.');
      const sourceSpace = findSourceSpaceByURL(draft.spaces, manifestURL);
      if (!sourceSpace) {
        console.error(MOVE_TO_SPACE, 'The manifestURL cannot be found in any space.');
        return;
      }
      console.log(MOVE_TO_SPACE, 'Found', manifestURL, 'in space', sourceSpace);
      // Re-assign the matched space name to `fromSpace`.
      fromSpace = sourceSpace.name;
    }
    if (!toSpace) {
      console.error(MOVE_TO_SPACE, 'The destination space is required:', toSpace);
      return;
    }
    if (!draft.spaces[toSpace]) {
      console.error(MOVE_TO_SPACE, 'Destination space not found:', toSpace);
      return;
    }
    if (!draft.spaces[fromSpace]) {
      console.warn(MOVE_TO_SPACE, 'Source space not found:', fromSpace);
    }

    // Bailout cases when the destination space remains the same.
    if (toSpace === fromSpace && fromSpace !== null) {
      if (isTwoDArray(draft.spaces[toSpace])) {
        // If the destination position is not provided:
        if (!toPosition) {
          console.warn(
            MOVE_TO_SPACE,
            'Trying to add duplicated manifestURL:', manifestURL,
            'to space', toSpace
          );
          return;
        }
        const fromPosition =
          findIndexInTwoDArray(draft.spaces[fromSpace], manifestURL);
        if (!fromPosition) {
          console.warn(
            MOVE_TO_SPACE,
            'Cannot find the manifestURL', manifestURL,
            'from source space', fromSpace
          );
          return;
        }
        if (JSON.stringify(fromPosition) === JSON.stringify(toPosition)) {
          console.warn(
            MOVE_TO_SPACE,
            'The manifestURL', manifestURL,
            'is already at the position', toPosition,
            'in space', toSpace
          );
          return;
        }
      } else if (Array.isArray(draft.spaces[toSpace])) {
        if (!Number.isInteger(toPosition)) {
          console.warn(
            MOVE_TO_SPACE,
            'Trying to add duplicated manifestURL:', manifestURL,
            'to space', toSpace
          );
          return;
        }
        const sourceIndex = draft.spaces[toSpace].indexOf(manifestURL);
        if (sourceIndex === toPosition) {
          console.warn(
            MOVE_TO_SPACE,
            'The manifestURL', manifestURL,
            'is already at the position', toPosition,
            'in space', toSpace
          );
          return;
        }
      }
    }

    // TODO: Check if any of destination space is full.
    // Check if the FavApps space is full.
    if (
      fromSpace !== SPACE.FAV_APPS &&
      toSpace === SPACE.FAV_APPS &&
      draft.spaces[SPACE.FAV_APPS].length >= favAppsListSize
    ) {
      console.warn(
        MOVE_TO_SPACE, 'FavApps has reached to the uplimit of',
        favAppsListSize, 'items.'
      );
      return;
    }

    let sourcePosition = null;

    // Remove the target from source space.
    const sourceSpace = draft.spaces[fromSpace];
    if (isTwoDArray(sourceSpace)) {
      sourcePosition = findIndexInTwoDArray(sourceSpace, manifestURL);
      sourceSpace[sourcePosition[0]].splice(sourcePosition[1], 1);
    } else if (Array.isArray(sourceSpace)) {
      sourcePosition = sourceSpace.indexOf(manifestURL);
      sourceSpace.splice(sourcePosition, 1);
    }

    // Push the target into destination space.
    const destSpace = draft.spaces[toSpace];
    if (isTwoDArray(destSpace)) {
      if (toPosition) {
        const [toX, toY] = toPosition;
        if (parseInt(toY, 10) >= 0) {
          const shiftOffset = (
            (toSpace === fromSpace) &&
            (sourcePosition[1] < toPosition[1])
          ) ? 1 : 0;
          destSpace[toX].splice(toY - shiftOffset, 0, manifestURL);
        } else {
          destSpace[toX].push(manifestURL);
        }
      } else {
        const sheetSize = getSpaceSheetSize(toSpace);
        const targetIndex = findFirstAvailablePosition(destSpace, sheetSize);
        if (targetIndex) {
          const [toX, toY] = targetIndex;
          destSpace[toX].splice(toY, 0, manifestURL);
        } else {
          // If FAP is not found;
          // Create a new sheet and put the target into it.
          destSpace.push([manifestURL]);
        }
      }
    } else if (Array.isArray(destSpace)) {
      // eslint-disable-next-line no-lonely-if
      if (parseInt(toPosition, 10) >= 0) {
        const shiftOffset = (
          (toSpace === fromSpace) &&
          (sourcePosition < toPosition)
        ) ? 1 : 0;
        destSpace.splice(toPosition - shiftOffset, 0, manifestURL);
      } else {
        // While destination position is not provided,
        // append to the last position.
        destSpace.push(manifestURL);
      }
    }
  }),
};

// XXX: Some of calculation need to be memorized.
//
// The centralized pipeline function for space distribution;
// The pipeline will be executed whenever item/space has changed.
// Any of space-related manipulation(e.g., sorting, moving, filtering)
// should be placed in here.
export function redistributeSpaces(state) {
  return produce(state, (draft) => {
    // Retrieve spaces.
    const { parkingApps, favApps, allApps } = draft.spaces;

    // Retrieve items, and we only process available items,
    // where [availability] = [enabled] + [visible] + [not in group]
    const visibleItems = draft.items.filter(isVisibleItem);

    // Exclude items in group spaces:
    // XXX: This could be expensive.
    const groupSpaces = Object.keys(draft.spaces)
      .filter(isGroupSpace)
      .map((spaceName) => draft.spaces[spaceName]);
    const itemsInGroup = flatten(groupSpaces);
    const availableItems = visibleItems.filter((item) =>
      !itemsInGroup.includes(item.manifestURL));

    // Fallback to the default value for each space, if needed.
    const nextParkingApps = parkingApps || [];
    const nextFavApps = (
      favApps ||
      defaultFavApps.map((app) => app.manifestURL)
    );
    const previousAllApps = (
      allApps ||
      defaultAllApps.map((sheet) => sheet.map((item) => item.manifestURL))
    );

    // Exclude `allApps` from `parkingApps` and `favApps`.
    const allAppsLevelOne = excludeTwoD(
      previousAllApps,
      [...nextParkingApps, ...nextFavApps]
    );

    const allAppsLevelTwo =
      redistributeSheets(allAppsLevelOne, allAppsSheetSize);

    // Filter out `unallocated` items,
    // where unallocated items are those items were installed,
    // but not listed in any of spaces yet (e.g. newly installed items).
    const unallocatedItems = exclude(
      availableItems.map((item) => item.manifestURL),
      [
        ...nextParkingApps,
        ...nextFavApps,
        ...flatten(allAppsLevelTwo)
      ]
    );

    // Append unallocated items to the 1st sheet of `allApps`,
    // and we will redistribute them into other sheets if needed.
    const firstSheetOfAllApps = allAppsLevelTwo[0];
    firstSheetOfAllApps.push(...unallocatedItems);

    // Redistribute sheets in `allApps`.
    const allAppsLevelThree =
      reorganizeSheets(allAppsLevelTwo, allAppsSheetSize);

    // Eliminate empty sheets in `allApps`
    const allAppsLevelFour =
      allAppsLevelThree.filter((sheet) => sheet.length > 0);

    // If allApps became an empty array after the elimination,
    // then giving it an empty first sheet.
    if (allAppsLevelFour.length === 0) {
      allAppsLevelFour.push([]);
    }

    // Give `allApps` an additional sheet while it's in edit-mode.
    if (draft.flags.additionalBlankSheet) {
      allAppsLevelFour.push([]);
    }

    // Apply changes on redux state.
    draft.spaces.parkingApps = nextParkingApps;
    draft.spaces.favApps = nextFavApps;
    draft.spaces.allApps = allAppsLevelFour;

    // Process group spaces.
    Object.keys(draft.spaces)
      .filter((spaceName) => spaceName.indexOf('group_') === 0)
      .forEach((groupName) => {
        // Eliminate empty sheets in groups.
        draft.spaces[groupName] =
          draft.spaces[groupName].filter((sheet) => sheet.length > 0);
        // If allApps became an empty array after the elimination,
        // then giving it an empty first sheet.
        if (draft.spaces[groupName].length === 0) {
          draft.spaces[groupName].push([]);
        }
        // Give groups an additional sheet while it's in edit-mode.
        if (draft.flags.additionalBlankSheet) {
          draft.spaces[groupName].push([]);
        }
      });
  });
}

// Redux Reducer
export default function reducer(state = initialState, action) {
  if (action.type.indexOf('launcher/items/') === 0) {
    if (itemReducers[action.type]) {
      const nextState = itemReducers[action.type](state, action);
      return redistributeSpaces(nextState);
    }
  }
  if (action.type.indexOf('launcher/spaces/') === 0) {
    if (spaceReducers[action.type]) {
      const nextState = spaceReducers[action.type](state, action);
      return redistributeSpaces(nextState);
    }
  }
  if (action.type === TOGGLE_EDIT_MODE) {
    const { enabled } = action.payload;
    if (typeof enabled === 'boolean') {
      const nextState = produce(state, (draft) => {
        draft.flags.additionalBlankSheet = enabled;
      });
      return redistributeSpaces(nextState);
    }
  }
  return state;
}

// Redux Action Creators

/**
 * Add the given item into render list.
 * @param {Object} item - The item to be added.
 */
export const addItem = (item) => ({
  type: ADD_ITEM,
  payload: { item }
});

/**
 * Find and remove the target item from render list, by the given manifestURL.
 * @param {String} manifestURL - The manifestURL to find the target item.
 */
export const removeItem = (manifestURL) => ({
  type: REMOVE_ITEM,
  payload: { manifestURL }
});

/**
 * Find and update the target item from render list, by the given manifestURL.
 * @param {String} manifestURL - The manifestURL to find the target item.
 * @param {Object} nextItem - The new item.
 */
export const updateItem = (manifestURL, nextItem) => ({
  type: UPDATE_ITEM,
  payload: {
    manifestURL,
    nextItem
  }
});

/**
 * Create a new group with selected items.
 * @param {Array} selectedItems - A list of item to be grouped.
 */
export const createGroup = (selectedItems) => ({
  type: CREATE_GROUP,
  payload: { selectedItems }
});

/**
 * Remove the group.
 * @param {Array} groupName - The name of the target group.
 */
export const removeGroup = (groupName) => ({
  type: REMOVE_GROUP,
  payload: { groupName }
});

/**
 * Move out selected items from the group.
 * @param {Array} selectedItems - A list of item to be moved out.
 */
export const moveOutFromGroup = (selectedItems) => ({
  type: MOVE_OUT_FROM_GROUP,
  payload: { selectedItems }
});

/**
 * Create a new space.
 */
export const createSpace = (spaceName, initialValue) => ({
  type: CREATE_SPACE,
  payload: { spaceName, initialValue }
});

/**
 * Remove the space.
 * @param {Array} spaceName - The name of the target space.
 */
export const removeSpace = (spaceName) => ({
  type: REMOVE_SPACE,
  payload: { spaceName }
});

/**
 * Remove the item query from its space.
 * @param {String} manifestURL
 */
export const removeFromSpace = (manifestURL) => ({
  type: REMOVE_FROM_SPACE,
  payload: { manifestURL }
});

/**
 * Move the item query to the target space at target position.
 * Note that `toPosition` is expected to be positive integers;
 * Otherwise it will be appended to the end of the target space.
 */
export const moveToSpace = ({
  manifestURL,
  fromSpace,
  toSpace,
  toPosition
}) => ({
  type: MOVE_TO_SPACE,
  payload: {
    manifestURL,
    fromSpace,
    toSpace,
    toPosition
  }
});

/**
 * Request for the list of mozApplication from API.
 */
export const mozAppGetAll = () => ({
  type: MOZAPP_GET_ALL
});

/**
 * Uninstall the mozApplication.
 * @param {Object} item - The target item that contains a mozApp reference.
 */
export const mozAppUninstall = (item) => ({
  type: MOZAPP_UNINSTALL,
  payload: { item }
});

/**
 * Throw a mozApp error from the API.
 * @param {Object} message - The error message.
 */
export const mozAppThrowError = (message) => ({
  type: MOZAPP_THROW_ERROR,
  payload: { message }
});
