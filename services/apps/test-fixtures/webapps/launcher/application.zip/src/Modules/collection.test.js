import { SPACE } from '../Constants';
import reducer, {
  addItem,
  removeItem,
  updateItem,
  removeFromSpace,
  moveToSpace,
  resetCounter,
  redistributeSpaces
} from './collection';

describe('item reducers and action creators', () => {
  test('ADD_ITEM', () => {
    expect(
      reducer(
        {
          flags: { additionalBlankSheet: false },
          items: [],
          spaces: {
            parkingApps: [],
            favApps: [],
            allApps: [['fake://initial-item.webapp']]
          }
        },
        addItem({
          manifestURL: 'fake://added-item.webapp'
        })
      )
    ).toEqual({
      flags: { additionalBlankSheet: false },
      items: [
        {
          id: 0,
          manifestURL: 'fake://added-item.webapp'
        }
      ],
      spaces: {
        allApps: [['fake://initial-item.webapp', 'fake://added-item.webapp']],
        favApps: [],
        parkingApps: []
      }
    });
    // Reset reducer's internal state.
    resetCounter();
  });
  test('ADD_ITEM - Deduplicate', () => {
    const initialState = reducer(
      {
        flags: { additionalBlankSheet: false },
        items: [],
        spaces: {
          parkingApps: [],
          favApps: [],
          allApps: [['fake://initial-item.webapp']]
        }
      },
      addItem({
        manifestURL: 'fake://added-item.webapp'
      })
    );
    expect(
      reducer(
        initialState,
        addItem({
          manifestURL: 'fake://added-item.webapp',
          something: 'new'
        })
      )
    ).toEqual({
      flags: { additionalBlankSheet: false },
      items: [
        {
          id: 1,
          manifestURL: 'fake://added-item.webapp',
          something: 'new'
        }
      ],
      spaces: {
        allApps: [['fake://initial-item.webapp', 'fake://added-item.webapp']],
        favApps: [],
        parkingApps: []
      }
    });
    // Reset reducer's internal state.
    resetCounter();
  });
  test('REMOVE_ITEM', () => {
    const initialState = reducer(
      {
        flags: { additionalBlankSheet: false },
        items: [],
        spaces: {
          allApps: [['fake://initial-item.webapp']],
          favApps: [],
          parkingApps: []
        }
      },
      addItem({
        manifestURL: 'fake://added-item.webapp'
      })
    );
    expect(
      reducer(initialState, removeItem('fake://added-item.webapp'))
    ).toEqual({
      flags: { additionalBlankSheet: false },
      items: [],
      spaces: {
        allApps: [['fake://initial-item.webapp', 'fake://added-item.webapp']],
        favApps: [],
        parkingApps: []
      }
    });
    // Reset reducer's internal state.
    resetCounter();
  });
  test('REMOVE_ITEM - Item does not exist', () => {
    expect(
      reducer(
        {
          flags: { additionalBlankSheet: false },
          items: [],
          spaces: {
            allApps: [['fake://initial-item.webapp']],
            favApps: [],
            parkingApps: []
          }
        },
        removeItem('fake://target-item.webapp')
      )
    ).toEqual({
      flags: { additionalBlankSheet: false },
      items: [],
      spaces: {
        allApps: [['fake://initial-item.webapp']],
        favApps: [],
        parkingApps: []
      }
    });
    // Reset reducer's internal state.
    resetCounter();
  });
  test('UPDATE_ITEM', () => {
    const initialState = reducer(
      {
        flags: { additionalBlankSheet: false },
        items: [],
        spaces: {
          allApps: [['fake://initial-item.webapp']],
          favApps: [],
          parkingApps: []
        }
      },
      addItem({
        manifestURL: 'fake://added-item.webapp'
      })
    );
    expect(
      reducer(
        initialState,
        updateItem('fake://added-item.webapp', {
          manifestURL: 'fake://added-item.webapp',
          something: 'new'
        })
      )
    ).toEqual({
      flags: { additionalBlankSheet: false },
      items: [
        {
          id: 0,
          manifestURL: 'fake://added-item.webapp',
          something: 'new'
        }
      ],
      spaces: {
        allApps: [['fake://initial-item.webapp', 'fake://added-item.webapp']],
        favApps: [],
        parkingApps: []
      }
    });
    // Reset reducer's internal state.
    resetCounter();
  });
});

describe('space reducers and action creators', () => {
  test('REMOVE_FROM_SPACE - Remove from allApps', () => {
    expect(
      reducer(
        {
          flags: { additionalBlankSheet: false },
          items: [],
          spaces: {
            allApps: [
              [
                'fake://item1.webapp',
                'fake://item2.webapp',
                'fake://item3.webapp'
              ]
            ],
            favApps: [
              'fake://item4.webapp',
              'fake://item5.webapp',
              'fake://item6.webapp'
            ],
            parkingApps: ['fake://item7.webapp']
          }
        },
        removeFromSpace('fake://item2.webapp')
      )
    ).toEqual({
      flags: { additionalBlankSheet: false },
      items: [],
      spaces: {
        allApps: [['fake://item1.webapp', 'fake://item3.webapp']],
        favApps: [
          'fake://item4.webapp',
          'fake://item5.webapp',
          'fake://item6.webapp'
        ],
        parkingApps: ['fake://item7.webapp']
      }
    });
  });
  test('REMOVE_FROM_SPACE - Remove from favApps', () => {
    expect(
      reducer(
        {
          flags: { additionalBlankSheet: false },
          items: [],
          spaces: {
            allApps: [
              [
                'fake://item1.webapp',
                'fake://item2.webapp',
                'fake://item3.webapp'
              ]
            ],
            favApps: [
              'fake://item4.webapp',
              'fake://item5.webapp',
              'fake://item6.webapp'
            ],
            parkingApps: ['fake://item7.webapp']
          }
        },
        removeFromSpace('fake://item5.webapp')
      )
    ).toEqual({
      flags: { additionalBlankSheet: false },
      items: [],
      spaces: {
        allApps: [
          ['fake://item1.webapp', 'fake://item2.webapp', 'fake://item3.webapp']
        ],
        favApps: ['fake://item4.webapp', 'fake://item6.webapp'],
        parkingApps: ['fake://item7.webapp']
      }
    });
  });
  test('REMOVE_FROM_SPACE - Remove from parkingApps', () => {
    expect(
      reducer(
        {
          flags: { additionalBlankSheet: false },
          items: [],
          spaces: {
            allApps: [
              [
                'fake://item1.webapp',
                'fake://item2.webapp',
                'fake://item3.webapp'
              ]
            ],
            favApps: [
              'fake://item4.webapp',
              'fake://item5.webapp',
              'fake://item6.webapp'
            ],
            parkingApps: ['fake://item7.webapp']
          }
        },
        removeFromSpace('fake://item7.webapp')
      )
    ).toEqual({
      flags: { additionalBlankSheet: false },
      items: [],
      spaces: {
        allApps: [
          ['fake://item1.webapp', 'fake://item2.webapp', 'fake://item3.webapp']
        ],
        favApps: [
          'fake://item4.webapp',
          'fake://item5.webapp',
          'fake://item6.webapp'
        ],
        parkingApps: []
      }
    });
  });
  test('MOVE_TO_SPACE - from FavApps to AllApps', () => {
    expect(
      reducer(
        {
          flags: { additionalBlankSheet: false },
          items: [],
          spaces: {
            allApps: [
              [
                'fake://item1.webapp',
                'fake://item2.webapp',
                'fake://item3.webapp'
              ]
            ],
            favApps: [
              'fake://item4.webapp',
              'fake://item5.webapp',
              'fake://item6.webapp'
            ],
            parkingApps: []
          }
        },
        moveToSpace({
          manifestURL: 'fake://item5.webapp',
          fromSpace: SPACE.FAV_APPS,
          toSpace: SPACE.ALL_APPS
        })
      )
    ).toEqual({
      flags: { additionalBlankSheet: false },
      items: [],
      spaces: {
        allApps: [
          [
            'fake://item1.webapp',
            'fake://item2.webapp',
            'fake://item3.webapp',
            'fake://item5.webapp'
          ]
        ],
        favApps: ['fake://item4.webapp', 'fake://item6.webapp'],
        parkingApps: []
      }
    });
  });
  test('MOVE_TO_SPACE - from FavApps to ParkingApps', () => {
    expect(
      reducer(
        {
          flags: { additionalBlankSheet: false },
          items: [],
          spaces: {
            allApps: [
              [
                'fake://item1.webapp',
                'fake://item2.webapp',
                'fake://item3.webapp'
              ]
            ],
            favApps: [
              'fake://item4.webapp',
              'fake://item5.webapp',
              'fake://item6.webapp'
            ],
            parkingApps: []
          }
        },
        moveToSpace({
          manifestURL: 'fake://item5.webapp',
          fromSpace: SPACE.FAV_APPS,
          toSpace: SPACE.PARKING_APPS
        })
      )
    ).toEqual({
      flags: { additionalBlankSheet: false },
      items: [],
      spaces: {
        allApps: [
          ['fake://item1.webapp', 'fake://item2.webapp', 'fake://item3.webapp']
        ],
        favApps: ['fake://item4.webapp', 'fake://item6.webapp'],
        parkingApps: ['fake://item5.webapp']
      }
    });
  });
  test('MOVE_TO_SPACE - from FavApps to FavApps (with given position)', () => {
    expect(
      reducer(
        {
          flags: { additionalBlankSheet: false },
          items: [],
          spaces: {
            allApps: [
              [
                'fake://item1.webapp',
                'fake://item2.webapp',
                'fake://item3.webapp'
              ]
            ],
            favApps: [
              'fake://item4.webapp',
              'fake://item5.webapp',
              'fake://item6.webapp'
            ],
            parkingApps: []
          }
        },
        moveToSpace({
          manifestURL: 'fake://item6.webapp',
          fromSpace: SPACE.FAV_APPS,
          toSpace: SPACE.FAV_APPS,
          toPosition: 0
        })
      )
    ).toEqual({
      flags: { additionalBlankSheet: false },
      items: [],
      spaces: {
        allApps: [
          ['fake://item1.webapp', 'fake://item2.webapp', 'fake://item3.webapp']
        ],
        favApps: [
          'fake://item6.webapp',
          'fake://item4.webapp',
          'fake://item5.webapp'
        ],
        parkingApps: []
      }
    });
  });
  test('MOVE_TO_SPACE - from AllApps to FavApps (reached to uplimit)', () => {
    expect(
      reducer(
        {
          flags: { additionalBlankSheet: false },
          items: [],
          spaces: {
            allApps: [
              [
                'fake://item1.webapp',
                'fake://item2.webapp',
                'fake://item3.webapp'
              ]
            ],
            favApps: [
              'fake://item4.webapp',
              'fake://item5.webapp',
              'fake://item6.webapp',
              'fake://item7.webapp',
              'fake://item8.webapp',
              'fake://item9.webapp'
            ],
            parkingApps: []
          }
        },
        moveToSpace({
          manifestURL: 'fake://item1.webapp',
          fromSpace: SPACE.ALL_APPS,
          toSpace: SPACE.FAV_APPS
        })
      )
    ).toEqual({
      flags: { additionalBlankSheet: false },
      items: [],
      spaces: {
        allApps: [
          ['fake://item1.webapp', 'fake://item2.webapp', 'fake://item3.webapp']
        ],
        favApps: [
          'fake://item4.webapp',
          'fake://item5.webapp',
          'fake://item6.webapp',
          'fake://item7.webapp',
          'fake://item8.webapp',
          'fake://item9.webapp'
        ],
        parkingApps: []
      }
    });
  });
  test('MOVE_TO_SPACE - from AllApps to ParkingApps', () => {
    expect(
      reducer(
        {
          flags: { additionalBlankSheet: false },
          items: [],
          spaces: {
            allApps: [
              [
                'fake://item1.webapp',
                'fake://item2.webapp',
                'fake://item3.webapp'
              ]
            ],
            favApps: [
              'fake://item4.webapp',
              'fake://item5.webapp',
              'fake://item6.webapp'
            ],
            parkingApps: []
          }
        },
        moveToSpace({
          manifestURL: 'fake://item1.webapp',
          fromSpace: SPACE.ALL_APPS,
          toSpace: SPACE.PARKING_APPS
        })
      )
    ).toEqual({
      flags: { additionalBlankSheet: false },
      items: [],
      spaces: {
        allApps: [['fake://item2.webapp', 'fake://item3.webapp']],
        favApps: [
          'fake://item4.webapp',
          'fake://item5.webapp',
          'fake://item6.webapp'
        ],
        parkingApps: ['fake://item1.webapp']
      }
    });
  });
  test('MOVE_TO_SPACE - from AllApps to AllApps (with given position)', () => {
    expect(
      reducer(
        {
          flags: { additionalBlankSheet: false },
          items: [],
          spaces: {
            allApps: [
              [
                'fake://item1.webapp',
                'fake://item2.webapp',
                'fake://item3.webapp'
              ]
            ],
            favApps: [
              'fake://item4.webapp',
              'fake://item5.webapp',
              'fake://item6.webapp'
            ],
            parkingApps: []
          }
        },
        moveToSpace({
          manifestURL: 'fake://item3.webapp',
          fromSpace: SPACE.ALL_APPS,
          toSpace: SPACE.ALL_APPS,
          toPosition: [0, 0]
        })
      )
    ).toEqual({
      flags: { additionalBlankSheet: false },
      items: [],
      spaces: {
        allApps: [
          ['fake://item3.webapp', 'fake://item1.webapp', 'fake://item2.webapp']
        ],
        favApps: [
          'fake://item4.webapp',
          'fake://item5.webapp',
          'fake://item6.webapp'
        ],
        parkingApps: []
      }
    });
  });
  test('MOVE_TO_SPACE - from ParkingApps to FavApps', () => {
    expect(
      reducer(
        {
          flags: { additionalBlankSheet: false },
          items: [],
          spaces: {
            allApps: [
              [
                'fake://item1.webapp',
                'fake://item2.webapp',
                'fake://item3.webapp'
              ]
            ],
            favApps: [
              'fake://item4.webapp',
              'fake://item5.webapp',
              'fake://item6.webapp'
            ],
            parkingApps: ['fake://item7.webapp']
          }
        },
        moveToSpace({
          manifestURL: 'fake://item7.webapp',
          fromSpace: SPACE.PARKING_APPS,
          toSpace: SPACE.FAV_APPS
        })
      )
    ).toEqual({
      flags: { additionalBlankSheet: false },
      items: [],
      spaces: {
        allApps: [
          ['fake://item1.webapp', 'fake://item2.webapp', 'fake://item3.webapp']
        ],
        favApps: [
          'fake://item4.webapp',
          'fake://item5.webapp',
          'fake://item6.webapp',
          'fake://item7.webapp'
        ],
        parkingApps: []
      }
    });
  });
  test('MOVE_TO_SPACE - from ParkingApps to AllApps', () => {
    expect(
      reducer(
        {
          flags: { additionalBlankSheet: false },
          items: [],
          spaces: {
            allApps: [
              [
                'fake://item1.webapp',
                'fake://item2.webapp',
                'fake://item3.webapp'
              ]
            ],
            favApps: [
              'fake://item4.webapp',
              'fake://item5.webapp',
              'fake://item6.webapp'
            ],
            parkingApps: ['fake://item7.webapp']
          }
        },
        moveToSpace({
          manifestURL: 'fake://item7.webapp',
          fromSpace: SPACE.PARKING_APPS,
          toSpace: SPACE.ALL_APPS
        })
      )
    ).toEqual({
      flags: { additionalBlankSheet: false },
      items: [],
      spaces: {
        allApps: [
          [
            'fake://item1.webapp',
            'fake://item2.webapp',
            'fake://item3.webapp',
            'fake://item7.webapp'
          ]
        ],
        favApps: [
          'fake://item4.webapp',
          'fake://item5.webapp',
          'fake://item6.webapp'
        ],
        parkingApps: []
      }
    });
  });
  test('MOVE_TO_SPACE - from FavApps to AllApps (with given position)', () => {
    expect(
      reducer(
        {
          flags: { additionalBlankSheet: false },
          items: [],
          spaces: {
            allApps: [
              [
                'fake://item1.webapp',
                'fake://item2.webapp',
                'fake://item3.webapp'
              ]
            ],
            favApps: [
              'fake://item4.webapp',
              'fake://item5.webapp',
              'fake://item6.webapp'
            ],
            parkingApps: []
          }
        },
        moveToSpace({
          manifestURL: 'fake://item5.webapp',
          fromSpace: SPACE.FAV_APPS,
          toSpace: SPACE.ALL_APPS,
          toPosition: [0, 1]
        })
      )
    ).toEqual({
      flags: { additionalBlankSheet: false },
      items: [],
      spaces: {
        allApps: [
          [
            'fake://item1.webapp',
            'fake://item5.webapp',
            'fake://item2.webapp',
            'fake://item3.webapp'
          ]
        ],
        favApps: ['fake://item4.webapp', 'fake://item6.webapp'],
        parkingApps: []
      }
    });
  });
  test('MOVE_TO_SPACE - from AllApps to FavApps (with given position)', () => {
    expect(
      reducer(
        {
          flags: { additionalBlankSheet: false },
          items: [],
          spaces: {
            allApps: [
              [
                'fake://item1.webapp',
                'fake://item2.webapp',
                'fake://item3.webapp'
              ]
            ],
            favApps: [
              'fake://item4.webapp',
              'fake://item5.webapp',
              'fake://item6.webapp'
            ],
            parkingApps: []
          }
        },
        moveToSpace({
          manifestURL: 'fake://item2.webapp',
          fromSpace: SPACE.ALL_APPS,
          toSpace: SPACE.FAV_APPS,
          toPosition: 1
        })
      )
    ).toEqual({
      flags: { additionalBlankSheet: false },
      items: [],
      spaces: {
        allApps: [['fake://item1.webapp', 'fake://item3.webapp']],
        favApps: [
          'fake://item4.webapp',
          'fake://item2.webapp',
          'fake://item5.webapp',
          'fake://item6.webapp'
        ],
        parkingApps: []
      }
    });
  });
});

describe('redistributeSpaces function', () => {
  test('should use default placements while space is null.', () => {
    expect(
      redistributeSpaces({
        flags: { additionalBlankSheet: false },
        items: [],
        spaces: {
          parkingApps: null,
          favApps: null,
          allApps: null
        }
      })
    ).toEqual({
      flags: { additionalBlankSheet: false },
      items: [],
      spaces: {
        parkingApps: [],
        favApps: [
          'app://communications.gaiamobile.org/manifest.webapp',
          'app://message.gaiamobile.org/manifest.webapp',
          'app://calendar.gaiamobile.org/manifest.webapp',
          'app://calculator.gaiamobile.org/manifest.webapp',
          'app://gallery.gaiamobile.org/manifest.webapp',
          'app://camera.gaiamobile.org/manifest.webapp'
        ],
        allApps: [
          [
            'app://filemanager.gaiamobile.org/manifest.webapp',
            'app://contacts.gaiamobile.org/manifest.webapp',
            'app://email.gaiamobile.org/manifest.webapp',
            'app://music.gaiamobile.org/manifest.webapp',
            'app://video.gaiamobile.org/manifest.webapp',
            'app://fm.gaiamobile.org/manifest.webapp',
            'app://search.gaiamobile.org/manifest.webapp',
            'app://notes.gaiamobile.org/manifest.webapp',
            'app://settings.gaiamobile.org/manifest.webapp'
          ],
          [
            'app://soundrecorder.gaiamobile.org/manifest.webapp',
            'app://timer.gaiamobile.org/manifest.webapp',
            'app://unitconverter.gaiamobile.org/manifest.webapp'
          ]
        ]
      }
    });
  });
  test('should remain the same while space is not null.', () => {
    expect(
      redistributeSpaces({
        flags: { additionalBlankSheet: false },
        items: [],
        spaces: {
          parkingApps: [],
          favApps: [],
          allApps: [[]]
        }
      })
    ).toEqual({
      flags: { additionalBlankSheet: false },
      items: [],
      spaces: {
        parkingApps: [],
        favApps: [],
        allApps: [[]]
      }
    });
  });
  test('should eliminate empty sheets.', () => {
    expect(
      redistributeSpaces({
        flags: { additionalBlankSheet: false },
        items: [],
        spaces: {
          parkingApps: [],
          favApps: [],
          allApps: [[1], [], [], [4]]
        }
      })
    ).toEqual({
      flags: { additionalBlankSheet: false },
      items: [],
      spaces: {
        parkingApps: [],
        favApps: [],
        allApps: [[1], [4]]
      }
    });

    expect(
      redistributeSpaces({
        flags: { additionalBlankSheet: false },
        items: [],
        spaces: {
          parkingApps: [],
          favApps: [],
          allApps: [[], [], [3]]
        }
      })
    ).toEqual({
      flags: { additionalBlankSheet: false },
      items: [],
      spaces: {
        parkingApps: [],
        favApps: [],
        allApps: [[3]]
      }
    });

    expect(
      redistributeSpaces({
        flags: { additionalBlankSheet: false },
        items: [],
        spaces: {
          parkingApps: [],
          favApps: [],
          allApps: [[], [], []]
        }
      })
    ).toEqual({
      flags: { additionalBlankSheet: false },
      items: [],
      spaces: {
        parkingApps: [],
        favApps: [],
        // Should remain at least one empty sheet.
        allApps: [[]]
      }
    });
  });
  test('should exclude parkingApps and favApps from allApps.', () => {
    expect(
      redistributeSpaces({
        flags: { additionalBlankSheet: false },
        items: [],
        spaces: {
          parkingApps: [1],
          favApps: [2, 4],
          allApps: [[1, 2, 3], [4, 5]]
        }
      })
    ).toEqual({
      flags: { additionalBlankSheet: false },
      items: [],
      spaces: {
        parkingApps: [1],
        favApps: [2, 4],
        allApps: [[3], [5]]
      }
    });

    expect(
      redistributeSpaces({
        flags: { additionalBlankSheet: false },
        items: [],
        spaces: {
          parkingApps: [1],
          favApps: [2, 3],
          allApps: [[1, 2, 3]]
        }
      })
    ).toEqual({
      flags: { additionalBlankSheet: false },
      items: [],
      spaces: {
        parkingApps: [1],
        favApps: [2, 3],
        allApps: [[]]
      }
    });

    expect(
      redistributeSpaces({
        flags: { additionalBlankSheet: false },
        items: [],
        spaces: {
          parkingApps: [1],
          favApps: [2, 3],
          allApps: [[1], [2, 3, 4]]
        }
      })
    ).toEqual({
      flags: { additionalBlankSheet: false },
      items: [],
      spaces: {
        parkingApps: [1],
        favApps: [2, 3],
        allApps: [[4]]
      }
    });
  });
  test('should distribute unallocated items.', () => {
    expect(
      redistributeSpaces({
        flags: { additionalBlankSheet: false },
        items: [
          { manifestURL: 'unallocated_item_1' },
          { manifestURL: 'unallocated_item_2' },
          { manifestURL: 'unallocated_item_3' }
        ],
        spaces: {
          parkingApps: [],
          favApps: [],
          allApps: [[1, 2, 3]]
        }
      })
    ).toEqual({
      flags: { additionalBlankSheet: false },
      items: [
        { manifestURL: 'unallocated_item_1' },
        { manifestURL: 'unallocated_item_2' },
        { manifestURL: 'unallocated_item_3' }
      ],
      spaces: {
        parkingApps: [],
        favApps: [],
        allApps: [
          [
            1,
            2,
            3,
            'unallocated_item_1',
            'unallocated_item_2',
            'unallocated_item_3'
          ]
        ]
      }
    });

    expect(
      redistributeSpaces({
        flags: { additionalBlankSheet: false },
        items: [
          { manifestURL: 1 },
          { manifestURL: 2 },
          { manifestURL: 3 },
          { manifestURL: 'unallocated_item_1' },
          { manifestURL: 'unallocated_item_2' },
          { manifestURL: 'unallocated_item_3' }
        ],
        spaces: {
          parkingApps: [1],
          favApps: [2],
          allApps: [[3]]
        }
      })
    ).toEqual({
      flags: { additionalBlankSheet: false },
      items: [
        { manifestURL: 1 },
        { manifestURL: 2 },
        { manifestURL: 3 },
        { manifestURL: 'unallocated_item_1' },
        { manifestURL: 'unallocated_item_2' },
        { manifestURL: 'unallocated_item_3' }
      ],
      spaces: {
        parkingApps: [1],
        favApps: [2],
        allApps: [
          [
            3,
            'unallocated_item_1',
            'unallocated_item_2',
            'unallocated_item_3'
          ]
        ]
      }
    });

    expect(
      redistributeSpaces({
        flags: { additionalBlankSheet: false },
        items: [
          { manifestURL: 'unallocated_item_1' },
          { manifestURL: 'unallocated_item_2' },
          { manifestURL: 'unallocated_item_3' }
        ],
        spaces: {
          parkingApps: [],
          favApps: [],
          allApps: [
            ['a1', 'a2', 'a3', 'a4', 'a5', 'a6', 'a7', 'a8', 'a9', 'a10', 'a11', 'a12', 'a13', 'a14'],
            ['b1']
          ]
        }
      })
    ).toEqual({
      flags: { additionalBlankSheet: false },
      items: [
        { manifestURL: 'unallocated_item_1' },
        { manifestURL: 'unallocated_item_2' },
        { manifestURL: 'unallocated_item_3' }
      ],
      spaces: {
        parkingApps: [],
        favApps: [],
        allApps: [
          ['a1', 'a2', 'a3', 'a4', 'a5', 'a6', 'a7', 'a8', 'a9', 'a10', 'a11', 'a12', 'a13', 'a14', 'unallocated_item_1'],
          ['b1', 'unallocated_item_2', 'unallocated_item_3']
        ]
      }
    });
  });
  test('should reorganize exceeding sheets.', () => {
    expect(
      redistributeSpaces({
        flags: { additionalBlankSheet: false },
        items: [],
        spaces: {
          parkingApps: [],
          favApps: [],
          allApps: [
            [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 'target'],
            [16, 17]
          ]
        }
      })
    ).toEqual({
      flags: { additionalBlankSheet: false },
      items: [],
      spaces: {
        parkingApps: [],
        favApps: [],
        allApps: [
          [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15],
          ['target', 16, 17]
        ]
      }
    });
  });
  test('should handle exceeding sheets and newly installed items.', () => {
    expect(
      redistributeSpaces({
        flags: { additionalBlankSheet: false },
        items: [
          { manifestURL: 'unallocated_item_1' }
        ],
        spaces: {
          parkingApps: [],
          favApps: [],
          allApps: [
            [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 'target'],
            [16, 17]
          ]
        }
      })
    ).toEqual({
      flags: { additionalBlankSheet: false },
      items: [
        { manifestURL: 'unallocated_item_1' }
      ],
      spaces: {
        parkingApps: [],
        favApps: [],
        allApps: [
          [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15],
          ['target', 16, 17, 'unallocated_item_1']
        ]
      }
    });
  });
});
