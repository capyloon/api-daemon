## Difference between `redistributeSheets` and `reorganizeSheets`

### `redistributeSheets`
Moving exceeding items to the beginning of next sheet.

```js
// Assume that the uplimit of sheets is 2:
// Input
[[1,2,3], [4]]
// Moving the exceeding value "3" to the beginning of the next sheet.
//
// Output
[[1,2], [3,4]]
```

### `reorganizeSheets`

Moving exceeding items to the first available position.

```js
// Assume that the uplimit of sheets is 2:
// Input
[[1,2,3], [4]]
// Moving the exceeding value "3" to the first available position,
// which is the position after the value "4" in this case.
//
// Output
[[1,2], [4,3]]
```