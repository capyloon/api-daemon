import { combineReducers } from 'redux';

import global from './global';
import collection from './collection';

export default combineReducers({
  global,
  collection
});
