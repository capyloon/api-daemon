import reducer, {
  toggleEditMode,
  toggleItemSelection,
  deselectAll,
  toggleDndMode,
  confirmDialog,
  cancelDialog,
  updateRoute,
  requestConfirmation
} from './global';

describe('reducers and action creators', () => {
  test('UPDATE_ROUTE', () => {
    expect(
      reducer({ route: 'foo' }, updateRoute('bar'))
    ).toEqual({ route: 'bar' });
  });
  test('TOGGLE_EDIT_MODE - Enabling', () => {
    expect(
      reducer({
        editMode: {
          enabled: false,
          selectedItems: []
        },
        dndMode: {
          enabled: false,
          selectedItem: null,
          initialCoordinate: null,
          touchId: null,
          sourceSpace: null
        }
      }, toggleEditMode(true))
    ).toEqual({
      editMode: {
        enabled: true,
        selectedItems: []
      },
      dndMode: {
        enabled: false,
        selectedItem: null,
        initialCoordinate: null,
        touchId: null,
        sourceSpace: null
      }
    });
  });
  test('TOGGLE_EDIT_MODE - Disabling', () => {
    expect(
      reducer({
        editMode: {
          enabled: true,
          selectedItems: ['fake://selected-item.webapp']
        },
        dndMode: {
          enabled: true,
          selectedItem: ['fake://dragging-item.webapp'],
          initialCoordinate: [123, 456],
          touchId: 1,
          sourceSpace: {
            name: 'FAKE_SPACE',
            index: 4
          }
        }
      }, toggleEditMode(false))
    ).toEqual({
      editMode: {
        enabled: false,
        selectedItems: []
      },
      dndMode: {
        enabled: false,
        selectedItem: null,
        initialCoordinate: null,
        touchId: null,
        sourceSpace: null
      }
    });
  });
  test('TOGGLE_ITEM_SELECTION - Enabling', () => {
    expect(
      reducer({
        editMode: {
          enabled: false,
          selectedItems: ['something', 'else']
        }
      }, toggleItemSelection('fake://selected-item.webapp'))
    ).toEqual({
      editMode: {
        enabled: false,
        selectedItems: ['something', 'else', 'fake://selected-item.webapp']
      }
    });
  });
  test('TOGGLE_ITEM_SELECTION - Disabling', () => {
    expect(
      reducer({
        editMode: {
          enabled: false,
          selectedItems: ['something', 'else', 'fake://selected-item.webapp']
        }
      }, toggleItemSelection('fake://selected-item.webapp'))
    ).toEqual({
      editMode: {
        enabled: false,
        selectedItems: ['something', 'else']
      }
    });
  });
  test('DESELECT_ALL', () => {
    expect(
      reducer({
        editMode: {
          enabled: false,
          selectedItems: ['something', 'else']
        }
      }, deselectAll())
    ).toEqual({
      editMode: {
        enabled: false,
        selectedItems: []
      }
    });
  });
  test('TOGGLE_DND_MODE - Enabling', () => {
    expect(
      reducer({
        editMode: {
          enabled: true,
          selectedItems: []
        },
        dndMode: {
          enabled: false,
          selectedItem: null,
          initialCoordinate: null,
          touchId: null
        }
      }, toggleDndMode(true, {
        selectedItem: 'fake://selected-item.webapp',
        initialCoordinate: { x: 123, y: 456 },
        touchId: 3,
        sourceSpace: {
          name: 'FAKE_SPACE',
          index: 4
        }
      }))
    ).toEqual({
      editMode: {
        enabled: true,
        selectedItems: []
      },
      dndMode: {
        enabled: true,
        selectedItem: 'fake://selected-item.webapp',
        initialCoordinate: { x: 123, y: 456 },
        touchId: 3,
        sourceSpace: {
          name: 'FAKE_SPACE',
          index: 4
        }
      }
    });
  });
  test('TOGGLE_DND_MODE - Disabling', () => {
    expect(
      reducer({
        editMode: {
          enabled: true,
          selectedItems: []
        },
        dndMode: {
          enabled: true,
          selectedItem: 'fake://selected-item.webapp',
          initialCoordinate: { x: 123, y: 456 },
          touchId: 3,
          sourceSpace: {
            name: 'FAKE_SPACE',
            index: 4
          }
        }
      }, toggleDndMode(false))
    ).toEqual({
      editMode: {
        enabled: true,
        selectedItems: []
      },
      dndMode: {
        enabled: false,
        selectedItem: null,
        initialCoordinate: null,
        touchId: null,
        sourceSpace: null
      }
    });
  });
  test('REQUEST_CONFIRMATION', () => {
    expect(
      reducer({
        dialog: {
          enabled: false,
          deferredAction: null
        }
      }, requestConfirmation({
        type: 'FAKE_DEFFERRED_ACTION'
      }))
    ).toEqual({
      dialog: {
        enabled: true,
        deferredAction: {
          type: 'FAKE_DEFFERRED_ACTION'
        }
      }
    });
  });
  test('CONFIRM_DIALOG', () => {
    expect(
      reducer({
        dialog: {
          enabled: true,
          deferredAction: {
            type: 'FAKE_DEFFERRED_ACTION'
          }
        }
      }, confirmDialog())
    ).toEqual({
      dialog: {
        enabled: false,
        deferredAction: null
      }
    });
  });
  test('CANCEL_DIALOG', () => {
    expect(
      reducer({
        dialog: {
          enabled: true,
          deferredAction: {
            type: 'FAKE_DEFFERRED_ACTION'
          }
        }
      }, cancelDialog())
    ).toEqual({
      dialog: {
        enabled: false,
        deferredAction: null
      }
    });
  });
  test('LAUNCH_ITEM', () => {
    expect(1).toEqual(1);
  });
});
