/* eslint-disable max-len */
export const defaultFavApps = [
  { name: 'Call Log', manifestURL: 'https://communications.local/manifest.webapp' },
  { name: 'Messages', manifestURL: 'https://message.local/manifest.webapp' },
  { name: 'Calendar', manifestURL: 'https://calendar.local/manifest.webapp' },
  { name: 'Calculator', manifestURL: 'https://calculator.local/manifest.webapp' },
  { name: 'Gallery', manifestURL: 'https://gallery.local/manifest.webapp' },
  { name: 'Camera', manifestURL: 'https://camera.local/manifest.webapp' },
];

export const defaultAllApps = [
  [
    { name: 'File Manager', manifestURL: 'https://filemanager.local/manifest.webapp' },
    { name: 'Contacts', manifestURL: 'https://contacts.local/manifest.webapp' },
    { name: 'Email', manifestURL: 'https://email.local/manifest.webapp' },
    { name: 'Music', manifestURL: 'https://music.local/manifest.webapp' },
    { name: 'Video', manifestURL: 'https://video.local/manifest.webapp' },
    { name: 'FM Radio', manifestURL: 'https://fm.local/manifest.webapp' },
    { name: 'Browser', manifestURL: 'https://search.local/manifest.webapp' },
    { name: 'Notes', manifestURL: 'https://notes.local/manifest.webapp' },
    { name: 'Settings', manifestURL: 'https://settings.local/manifest.webapp' },
  ],
  [
    { name: 'Recorder', manifestURL: 'https://soundrecorder.local/manifest.webapp' },
    { name: 'Timer', manifestURL: 'https://timer.local/manifest.webapp' },
    { name: 'Unit Converter', manifestURL: 'https://unitconverter.local/manifest.webapp' },
  ]
];
/* eslint-enable max-len */
