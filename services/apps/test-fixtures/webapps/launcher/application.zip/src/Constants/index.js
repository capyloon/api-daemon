export const favAppsListSize = 6;
export const groupSheetSize = 9;
export const groupMaxSheetCount = 3;

export const allAppsSheetSize = 15;
export const allAppsMaxSheetCount = 3;

export const internalAppRoles = [
  'system',
  'input',
  'theme',
  'homescreen',
  'invisible',
  'carrier'
];

export const SPACE = {
  PARKING_APPS: 'parkingApps',
  FAV_APPS: 'favApps',
  ALL_APPS: 'allApps'
};

export const GlobalStates = {
  idle: 'idle',
  launching: 'launching',
  uninstalling: 'uninstalling',
  moving: 'moving',
  grouping: 'grouping',
  ungrouping: 'ungrouping',
};
