import { handleHomeButton, navigateBack } from '../Modules/global';

function registerKeyboardHandlers(dispatch) {
  window.addEventListener('keydown', function handleKeyDown(event) {
    console.log('keydown', event.key);
    switch (event.key) {
      case 'Backspace':
        dispatch(navigateBack());
        break;
      case 'ContextMenu':
        dispatch(handleHomeButton());
        break;
      default:
        break;
    }
  });
}

const middleware = ({ getState, dispatch }) => {
  registerKeyboardHandlers(dispatch);
  return (next) => (action) => next(action);
};

export default middleware;
