import {
  SPACE,
  GlobalStates,
  groupSheetSize,
  groupMaxSheetCount,
} from '../Constants';
import GenericItem, { ItemTypes } from '../Shared/GenericItem';
import {
  findLargestGroupNumber,
  findSourceSpaceByURL,
  isGroupSpace
} from '../Shared/ItemUtils';
import {
  CONFIRM_DIALOG,
  DELETE_ITEMS,
  TOGGLE_EDIT_MODE,
  shiftState,
  deselectAll,
  toggleGroupView
} from '../Modules/global';
import {
  REMOVE_ITEM,
  MOVE_TO_SPACE,
  MOVE_OUT_FROM_GROUP,
  CREATE_GROUP,
  REMOVE_GROUP,
  addItem,
  removeItem,
  createSpace,
  removeSpace,
  moveToSpace,
  removeFromSpace,
  removeGroup,
  moveOutFromGroup,
  mozAppUninstall,
} from '../Modules/collection';

const middleware = ({ getState, dispatch }) => {
  return (next) => (action) => {
    switch (action.type) {
      case CONFIRM_DIALOG: {
        const { deferredAction } = getState().global.dialog;
        console.log('Dispatch the deferred action', deferredAction);
        dispatch(deferredAction);
        break;
      }
      case DELETE_ITEMS: {
        const state = getState();
        const { selectedItems } = action.payload;
        if (!selectedItems || selectedItems.length === 0) {
          console.warn(
            'The action', DELETE_ITEMS, 'is cancelled due to',
            'invalid selected items', selectedItems
          );
          return state;
        }

        // An asynchronous callback which will be executed after reducer.
        Promise.resolve()
          .then(() => {
            // Shift the global state to `uninstalling` state.
            dispatch(shiftState(GlobalStates.uninstalling));

            // For-loop the uninstallation on each of selected items.
            const { items } = state.collection;
            items
              .filter((item) => selectedItems.indexOf(item.manifestURL) >= 0)
              // Uninstall removable items only.
              .filter((item) => item.mozApp.removable === true)
              // XXX: Should be able to remove any kinds of item.
              // Uninstall the mozApp.
              .forEach((item) => dispatch(mozAppUninstall(item)));

            // Shift the global state back to `idle` state.
            dispatch(shiftState(GlobalStates.idle));
          });

        break;
      }
      case CREATE_GROUP: {
        const state = getState();
        const { selectedItems } = action.payload;
        if (!selectedItems || selectedItems.length === 0) {
          console.warn(
            'The action', CREATE_GROUP, 'is cancelled due to',
            'invalid selected items', selectedItems
          );
          return state;
        }

        // Pop-up the toast when number of selection exceeded the uplimit.
        const uplimitOfGroup = groupSheetSize * groupMaxSheetCount;
        if (selectedItems.length > uplimitOfGroup) {
          window.Toaster.showToast({
            message: `You've selected ${
              selectedItems.length
            } apps. The maximum number for grouping is ${
              uplimitOfGroup
            }.`
          });
          return state;
        }

        // Find the largest group number.
        const { items } = state.collection;
        const groups = items.filter((item) => item.type === ItemTypes.Group);
        const largestGroupNumber = findLargestGroupNumber(groups);
        const nextGroupNumber = largestGroupNumber + 1;

        // Shift the global state to `grouping` state.
        dispatch(shiftState(GlobalStates.grouping));

        // Create the new group space.
        const newSpaceName = `group_${nextGroupNumber}`;
        dispatch(createSpace(
          newSpaceName,
          [[]]
        ));

        // Move selected items into the group space.
        selectedItems.forEach((manifestURL) => {
          dispatch(moveToSpace({
            manifestURL,
            toSpace: newSpaceName
          }));
        });

        // De-select all selections.
        dispatch(deselectAll());

        // Create the new group item.
        // Note that we delayed the creation of group item on purpose,
        // so that the new group item won't be excluded before selection movement.
        const newURL = `app://launcher.gaiamobile.org/groups/${nextGroupNumber}`;
        const newGroupItem = GenericItem.create({
          type: ItemTypes.Group,
          name: `Group ${nextGroupNumber}`,
          manifestURL: newURL,
          // Link to the group space.
          space: newSpaceName
        });

        const allComesFromFavApps = selectedItems.every((manifestURL) => {
          const source =
            findSourceSpaceByURL(state.collection.spaces, manifestURL);
          return source.name === SPACE.FAV_APPS;
        });
        dispatch(moveToSpace({
          manifestURL: newURL,
          // Omit removal by assigning null object.
          fromSpace: null,
          toSpace: allComesFromFavApps
            ? SPACE.FAV_APPS
            : SPACE.ALL_APPS
        }));

        // Push newGroupItem into the item list.
        dispatch(addItem(newGroupItem));

        // Shift the global state back to `idle` state.
        dispatch(shiftState(GlobalStates.idle));
        break;
      }
      case REMOVE_GROUP: {
        const state = getState();
        const { items, spaces } = state.collection;
        const { groupName } = action.payload;
        if (!spaces[groupName]) {
          console.warn(REMOVE_GROUP, 'The space of the group', groupName, 'is not found.');
          return state;
        }
        const targetGroupItem = items.find((item) => (
          item.type === ItemTypes.Group &&
          item.space === groupName
        ));
        if (!targetGroupItem) {
          console.warn(REMOVE_GROUP, 'The instance of the group', groupName, 'is not found.');
          return state;
        }

        // Shift the global state to `ungrouping` state.
        dispatch(shiftState(GlobalStates.ungrouping));
        // Move out queries inside of the group.
        spaces[groupName].forEach((sheet) => {
          if (sheet.length > 0) {
            dispatch(moveOutFromGroup(sheet));
          }
        });
        // Close the group view.
        dispatch(toggleGroupView(false));
        // Remove the group item, its query and corresponding group space;
        // Beware that the order of removal is matter.
        dispatch(removeItem(targetGroupItem.manifestURL));
        dispatch(removeFromSpace(targetGroupItem.manifestURL));
        dispatch(removeSpace(groupName));
        // Shift the global state back to `idle` state.
        dispatch(shiftState(GlobalStates.idle));
        break;
      }
      case MOVE_OUT_FROM_GROUP: {
        const state = getState();
        const { items, spaces } = state.collection;

        const { selectedItems } = action.payload;
        if (!selectedItems || selectedItems.length === 0) {
          console.warn(
            'The action', MOVE_OUT_FROM_GROUP, 'is cancelled due to',
            'invalid selected items', selectedItems
          );
          return state;
        }

        // Search for the source space of the group item which
        // contains the current selection.
        const sourceGroupSpace = findSourceSpaceByURL(spaces, selectedItems[0]);
        const sourceGroupItem = items
          .filter((item) => item.type === ItemTypes.Group)
          .find((groupItem) => groupItem.space === sourceGroupSpace.name);
        const spaceOfGroupItem =
          findSourceSpaceByURL(spaces, sourceGroupItem.manifestURL);

        // Shift the global state to `moving` state.
        dispatch(shiftState(GlobalStates.moving));

        selectedItems.forEach((query) => {
          dispatch(
            moveToSpace({
              manifestURL: query,
              toSpace: spaceOfGroupItem.name
            })
          );
        });

        // De-select all selections.
        dispatch(deselectAll());

        // Shift the global state back to `idle` state.
        dispatch(shiftState(GlobalStates.idle));
        break;
      }
      // Search for empty groups and remove them after
      // every item movements/removals.
      case REMOVE_ITEM:
      case MOVE_TO_SPACE:
        // An asynchronous callback which will be executed after reducer.
        Promise.resolve()
          .then(() => {
            const { spaces } = getState().collection;
            Object.keys(spaces)
              .filter(isGroupSpace)
              .forEach((spaceName) => {
                const targetSpace = spaces[spaceName];
                if (targetSpace.every((sheet) => sheet.length === 0)) {
                  console.warn('Launcher is going to remove the empty group', spaceName);
                  dispatch(removeGroup(spaceName));
                }
              });
          });
        break;
      case TOGGLE_EDIT_MODE: {
        const { enabled } = action.payload;
        const { parkingApps } = getState().collection.spaces;
        // If there's an item stays in the `parkingApps` space when
        // the edit mode is disabling, move it to the first-available-position.
        if (enabled === false && parkingApps.length > 0) {
          dispatch(
            moveToSpace({
              manifestURL: parkingApps[0],
              fromSpace: SPACE.PARKING_APPS,
              toSpace: SPACE.ALL_APPS
            })
          );
        }
        break;
      }
      // no default
    }
    return next(action);
  };
};

export default middleware;
