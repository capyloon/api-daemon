import { toggleItemSelection } from '../Modules/global';
import {
  MOZAPP_GET_ALL,
  MOZAPP_UNINSTALL,
  mozAppThrowError,
  addItem,
  updateItem,
  removeItem,
  removeFromSpace
} from '../Modules/collection';
import GenericItem, {
  ItemTypes,
  ItemInstallStates
} from '../Shared/GenericItem';

// XXX:
// Try to de-couple mozApps middleware from mozApps API
// The middleware should not aware of mozApps API, use a DataProvider instead.
// So that the middleware can be tested under env without mozApps API.

// TODO: How to revoke the event listeners?
const middleware = ({ getState, dispatch }) => {
  registerMgmtHandlers(dispatch);
  return (next) => (action) => {
    if (!isMozAppAction(action)) {
      return next(action);
    }

    switch (action.type) {
      case MOZAPP_GET_ALL: {
        const { mgmt } = navigator.mozApps;
        const request = mgmt.getAll();
        request.onsuccess = (event) => {
          const mozApps = event.target.result;
          mozApps.forEach((mozApp) => {
            const item = GenericItem.create({
              type: ItemTypes.MozApp,
              manifestURL: mozApp.manifestURL,
              installState: ItemInstallStates.installed,
              name: mozApp.manifest.name,
              mozApp
            });
            dispatch(addItem(item));
          });
        };
        request.onerror = (err) => dispatch(mozAppThrowError(err));
        break;
      }
      case MOZAPP_UNINSTALL: {
        const { item } = action.payload;

        if (item.type !== ItemTypes.MozApp) {
          console.warn('The item', item.manifestURL,
            'is not a mozApp item!');
          return getState();
        }
        if (item.installState !== ItemInstallStates.installed) {
          console.warn('The item', item.manifestURL,
            'is not available for uninstalling!');
          return getState();
        }

        // An asynchronous callback which will be executed after reducer.
        Promise.resolve()
          // Shift the item state to `uninstalling`.
          .then(() => dispatch(
            updateItem(
              item.manifestURL,
              { installState: ItemInstallStates.uninstalling }
            )
          ))
          // Uninstall the mozApplication.
          .then(() => navigator.mozApps.mgmt.uninstall(item.mozApp))
          // Things after sucessfully uninstalled.
          .then(() => {
            // De-select the uninstalled item.
            dispatch(toggleItemSelection(item.manifestURL, false));
            // Shift the item state to `uninstalled` state.
            dispatch(
              updateItem(
                item.manifestURL,
                { installState: ItemInstallStates.uninstalled }
              )
            );
            // Remove from the list of instances.
            dispatch(removeItem(item.manifestURL));
            // Remove from the space of where it locates.
            dispatch(removeFromSpace(item.manifestURL));
          });
        break;
      }
      default:
        break;
    }
    return next(action);
  };
};

function isMozAppAction(action) {
  return action.type.indexOf('launcher/mozApps/') >= 0;
}

function registerMgmtHandlers(dispatch) {
  if (navigator.mozApps && navigator.mozApps.mgmt) {
    // Dispatch corresponding action as soon as mozApps mgmt event is triggered.
    const { mgmt } = navigator.mozApps;
    mgmt.addEventListener('install', (event) => {
      console.log('install', event);
      const mozApp = event.application;
      if (mozApp.installState === ItemInstallStates.installed) {
        const item = GenericItem.create({
          type: ItemTypes.MozApp,
          manifestURL: mozApp.manifestURL,
          installState: mozApp.installState,
          name: mozApp.manifest.name,
          mozApp
        });
        dispatch(addItem(item));
      } else {
        // Create a installing instance for the downloading app
        // console.log('pending mozapp:');
        // for (let key in mozApp) {
        //   console.log(key, mozApp[key]);
        // }
        const item = GenericItem.create({
          type: ItemTypes.MozApp,
          manifestURL: mozApp.manifestURL,
          installState: mozApp.installState,
          mozApp
        });
        dispatch(addItem(item));
        // Then we update it when it's ready.
        mozApp.ondownloadapplied = (downloadAppliedEvent) => {
          console.log('ondownloadapplied', downloadAppliedEvent);
          mozApp.ondownloadapplied = null;
          mozApp.ondownloaderror = null;
          const downloadedMozApp = downloadAppliedEvent.application;
          dispatch(
            updateItem(
              downloadedMozApp.manifestURL,
              {
                mozApp: downloadedMozApp,
                installState: downloadedMozApp.installState,
                name: downloadedMozApp.manifest.name
              }
            )
          );
        };
        mozApp.ondownloaderror = (err) => {
          console.log('ondownloaderror', err);
          mozApp.ondownloadapplied = null;
          mozApp.ondownloaderror = null;
          // Remove the installing item when installation failed.
          // dispatch(removeItem({ manifestURL: mozApp.manifestURL }));
        };
        mozApp.onprogress = (event) => console.log('onprogress', event);
        mozApp.ondownloadsuccess = (event) => console.log('ondownloadsuccess', event);
        mozApp.ondownloadavailable = (event) => console.log('ondownloadavailable', event);
      }
    });
    mgmt.addEventListener('uninstall', (event) => {
      console.log('uninstall', event);
    });
    mgmt.addEventListener('update', (event) => {
      console.log('update', event);
      const mozApp = event.application;

      Promise.resolve()
        // Shift the item state to `updating` state.
        .then(dispatch(
          updateItem(
            mozApp.manifestURL,
            { installState: ItemInstallStates.updating }
          )
        ))
        // Update the entire mozApp reference.
        .then(() => dispatch(
          updateItem(
            mozApp.manifestURL,
            {
              mozApp,
              installState: mozApp.installState
            }
          )
        ));
    });
  }
}

export default middleware;
