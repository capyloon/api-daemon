import {
  NAVIGATE_TO,
  NAVIGATE_BACK,
  HANDLE_HOME_BUTTON,
  navigateTo,
  updateRoute,
  toggleEditMode,
  toggleGroupView,
  cancelDialog
} from '../Modules/global';

function registerEventHandlers(dispatch) {
  window.addEventListener('popstate', function handlePopState(event) {
    const { hash } = window.location;
    const { state } = event;
    console.log('window.onpopstate:');
    console.log('hash ->', hash);
    console.log('state ->', state);

    if (hash) {
      const nextRoute = hash.replace('#', '');
      dispatch(updateRoute(nextRoute));
    }
  });
}

const middleware = ({ getState, dispatch }) => {
  registerEventHandlers(dispatch);
  return (next) => (action) => {
    switch (action.type) {
      case HANDLE_HOME_BUTTON: {
        const { route, editMode, dialog, groupView } = getState().global;
        // XXX: Should escape from any kind of hierarchical state
        // (e.g. edit mode, dialog page, group view)
        const needEscape = (
          dialog.enabled ||
          editMode.enabled ||
          groupView.enabled
        );
        if (needEscape) {
          if (dialog.enabled) {
            dispatch(cancelDialog());
          }
          if (editMode.enabled) {
            dispatch(toggleEditMode(false));
          }
          if (groupView.enabled) {
            dispatch(toggleGroupView(false));
          }
        } else if (route === 'home') {
          dispatch(navigateTo('all-apps'));
        } else {
          dispatch(navigateTo('home'));
        }
        break;
      }
      case NAVIGATE_TO: {
        const nextRoute = action.payload.route;
        // When the route forwarded, push to the state.
        // And only whitelisted route would take effect.
        console.log('NavigationMiddleware caught a `NAVIGATE_TO` ->', nextRoute);
        if (['home', 'all-apps', 'search'].includes(nextRoute)) {
          console.log('NavigationMiddleware pushState ->', nextRoute);
          window.history.pushState(null, null, `#${nextRoute}`);
          dispatch(updateRoute(nextRoute));
        }
        break;
      }
      case NAVIGATE_BACK: {
        const { editMode, dialog, groupView } = getState().global;
        console.log('NavigationMiddleware caught a `NAVIGATE_BACK`');
        // XXX: Should step backward from any kind of hierarchical state
        // (e.g. edit mode, dialog page, group view)
        if (dialog.enabled) {
          dispatch(cancelDialog());
        } else if (groupView.enabled) {
          dispatch(toggleGroupView(false));
        } else if (editMode.enabled) {
          dispatch(toggleEditMode(false));
        } else {
          window.history.back();
        }
        break;
      }
      default:
        break;
    }
    return next(action);
  };
};

export default middleware;
