const keyName = 'state';

export function loadState() {
  try {
    const serializedState = localStorage.getItem(keyName);
    if (serializedState === null) {
      return undefined;
    }
    return JSON.parse(serializedState);
  } catch (err) {
    return undefined;
  }
}

export function saveState(state) {
  try {
    const serializedState = JSON.stringify(state);
    localStorage.setItem(keyName, serializedState);
    console.log('Flushed into localStorage', serializedState);
  } catch (err) {
    console.error(err);
  }
}
