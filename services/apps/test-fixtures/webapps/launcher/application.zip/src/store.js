import { createStore, applyMiddleware } from 'redux';
import throttle from 'lodash.throttle';
import rootReducer from './Modules';
import { loadState, saveState } from './persistedState';

import navigation from './Middlewares/navigation';
import mozApps from './Middlewares/mozApps';
import keyboard from './Middlewares/keyboard';
import ui from './Middlewares/ui';

export default function configureStore() {
  const middlewares = [navigation, mozApps, keyboard, ui];
  const persistedState = loadState();

  const store = createStore(
    rootReducer,
    persistedState,
    applyMiddleware(...middlewares)
  );

  // XXX: This is only for debugging.
  window.store = store;

  store.subscribe(
    throttle(() => {
      const state = store.getState();
      saveState({
        global: state.global,
        collection: {
          ...state.collection,
          // We only allow whitelisted items to be flushed into
          // the persisted storage; Other than that, items should
          // be only generated during the runtime.
          items: state.collection.items.filter((item) => item.type === 'group')
        }
      });
    }, 3000)
  );

  return store;
}
