import { ItemTypes } from './GenericItem';
import {
  SPACE,
  internalAppRoles,
  allAppsSheetSize,
  groupSheetSize,
} from '../Constants';

export function isVisibleItem(item) {
  const isInternalApp = () => (
    item.role && internalAppRoles.includes(item.role)) ||
    (item.type === ItemTypes.MozApp &&
      item.mozApp && item.mozApp.manifest &&
      internalAppRoles.includes(item.mozApp.manifest.role));

  // The item is visible only if it fulfills following requirements
  return !isInternalApp();
}

export function isGroupSpace(spaceName) {
  return spaceName.indexOf('group_') === 0;
}

export function getSpaceSheetSize(spaceName) {
  if (spaceName === SPACE.ALL_APPS) {
    return allAppsSheetSize;
  }
  if (isGroupSpace(spaceName)) {
    return groupSheetSize;
  }
  return null;
}

export function getItemName(item) {
  if (!item) {
    return 'Unknown';
  }
  if (typeof item.name === 'string') {
    return item.name;
  }
  if (item.mozApp) {
    if (item.mozApp.manifest) {
      return item.mozApp.manifest.name;
    }
    if (item.mozApp.updateManifest) {
      return item.mozApp.updateManifest.name;
    }
  }
  return 'Unknown';
}

/**
 * Find the existing largest group number from either
 * Group's name or Group's manifestURL.
 * @param {Array} groups List of current groups.
 */
export function findLargestGroupNumber(groups) {
  const queryForName = new RegExp('group\\s*(\\d+)$', 'i');
  const queryForURL =
    new RegExp('app://launcher.gaiamobile.org/groups/(\\d+)$', 'i');

  const listOfGroupNumbers = [];
  groups.forEach((group) => {
    if (group.name) {
      const matches = group.name.match(queryForName);
      if (matches) {
        const n = matches.pop();
        listOfGroupNumbers.push(n);
      }
    }
    if (group.manifestURL) {
      const matches = group.manifestURL.match(queryForURL);
      if (matches) {
        const n = matches.pop();
        listOfGroupNumbers.push(n);
      }
    }
  });

  // Find the largest number, otherwise return zero.
  return Math.max(0, ...listOfGroupNumbers);
}

export function findSourceSpaceByURL(spaces, url) {
  let source = null;

  Object.keys(spaces).some((spaceName) => {
    const space = spaces[spaceName];
    if (isTwoDArray(space)) {
      return space.some((sheet, sheetIndex) =>
        sheet.some((query, listIndex) => {
          if (query === url) {
            source = {
              name: spaceName,
              position: [sheetIndex, listIndex]
            };
            return true;
          }
          return false;
        }));
    }
    return space.some((query, listIndex) => {
      if (query === url) {
        source = {
          name: spaceName,
          position: listIndex
        };
        return true;
      }
      return false;
    });
  });

  return source;
}

export function findTouchById(touches, touchId) {
  for (let i = 0; i < touches.length; i++) {
    if (touches[i].identifier === touchId) {
      return touches[i];
    }
  }
  return null;
}

export function distance(x1, y1, x2, y2) {
  return Math.hypot(x2 - x1, y2 - y1);
}

export function flatten([firstElement, ...restOfElements]) {
  return firstElement !== undefined
    ? [
      ...(Array.isArray(firstElement)
        ? flatten(firstElement)
        : [firstElement]),
      ...flatten(restOfElements)
    ]
    : [];
}

export function exclude(originSet, excludeSet) {
  if (!originSet || !Array.isArray(originSet)) {
    throw new Error('origin set is required.');
  }
  if (!excludeSet || !Array.isArray(excludeSet)) {
    throw new Error('excluding set is required.');
  }
  return originSet.filter((item) => excludeSet.indexOf(item) === -1);
}

export function excludeTwoD(originTwoDArray, excludeSet) {
  if (!originTwoDArray || !Array.isArray(originTwoDArray)) {
    throw new Error('origin 2d array is required.');
  }
  if (!excludeSet || !Array.isArray(excludeSet)) {
    throw new Error('excluding set is required.');
  }
  return originTwoDArray
    .map((innerArray) => {
      return innerArray.filter((item) => excludeSet.indexOf(item) === -1);
    });
}

export function merge(...sets) {
  if (sets.length < 2) {
    throw new Error('Two or more sets are required');
  }
  return sets.reduce((prev, curr) => {
    return [...prev, ...exclude(curr, prev)];
  }, []);
}

export function chunk(source, size) {
  if (!source || !Array.isArray(source)) {
    throw new Error('chunk source is required.');
  }
  if (!Number.isInteger(size)) {
    throw new Error('chunk size is required.');
  }
  const clone = source.slice();
  const newArray = [];
  while (clone.length > 0) {
    newArray.push(clone.splice(0, size));
  }
  return newArray;
}

export function isTwoDArray(arr) {
  if (
    arr &&
    Array.isArray(arr) &&
    arr.length > 0 &&
    arr.map((elem) => Array.isArray(elem)).filter(Boolean).length === arr.length
  ) {
    return true;
  }
  return false;
}

export function cloneTwoDArray(twoDArray) {
  return twoDArray.map((innerArray) => innerArray.slice());
}

export function findIndexInTwoDArray(arr, elem) {
  if (!arr || !Array.isArray(arr)) {
    throw new Error('The given array is NOT a valid array.');
  }
  if (typeof elem === 'undefined') {
    throw new Error('The given target is invalid.');
  }
  for (let x = 0; x < arr.length; x++) {
    if (!Array.isArray(arr[x])) {
      throw new Error('The given array is NOT a 2-d array.');
    }
    for (let y = 0; y < arr[x].length; y++) {
      if (elem === arr[x][y]) {
        return [x, y];
      }
    }
  }
  return null;
}

export function findFirstAvailablePosition(space, sheetUplimitSize) {
  if (!space || !Array.isArray(space)) {
    throw new Error('space is required.');
  }
  if (!Number.isInteger(sheetUplimitSize)) {
    throw new Error('sheetUplimitSize is required.');
  }
  for (let sheetIterator = 0; sheetIterator < space.length; sheetIterator++) {
    const currentSheetSize = space[sheetIterator].length;
    if (currentSheetSize < sheetUplimitSize) {
      const x = sheetIterator;
      const y = currentSheetSize;
      return [x, y];
    }
  }
  return null;
}

export function isReorganizationNeeded(space, sheetUplimitSize) {
  return space.some((sheet) => {
    return sheet.length > sheetUplimitSize;
  });
}

export function redistributeSheets(sheets, sheetUplimitSize) {
  const nextSheets = cloneTwoDArray(sheets);

  // Because of number of sheets may increase over time,
  // we only process one sheet at a time;
  // Then we recursively go through all of sheets
  // until no sheet has exceeded items.
  nextSheets.some((sheet, index) => {
    if (sheet.length > sheetUplimitSize) {
      const exceedItemCount = sheet.length - sheetUplimitSize;
      const exceedItems = sheet.splice(sheet.length - 1, exceedItemCount);
      const nextSheet = nextSheets[index + 1];
      // Move to next sheet if there's one;
      // Otherwise create a new sheet.
      if (nextSheet) {
        nextSheet.unshift(...exceedItems);
      } else {
        const newSheet = exceedItems;
        nextSheets.push(newSheet);
      }
      return true;
    }
    return false;
  });

  const needRedistribute =
    sheets.filter((sheet) => sheet.length > sheetUplimitSize).length > 0;

  if (needRedistribute) {
    return redistributeSheets(nextSheets, sheetUplimitSize);
  }
  return nextSheets;
}

export function reorganizeSheets(space, sheetUplimitSize) {
  const newSpace = cloneTwoDArray(space);

  // FAP = First available position.
  const moveToFap = (item) => {
    const fap = findFirstAvailablePosition(newSpace, sheetUplimitSize);
    // Create a new sheet with the item if FAP is not found.
    // Otherwise put it at the FAP.
    if (!fap) {
      const newSheet = [item];
      newSpace.push(newSheet);
    } else {
      const [x] = fap;
      newSpace[x].push(item);
    }
  };

  // Iterate and move exceeding items to the FAP.
  newSpace.forEach((sheet) => {
    while (sheet.length > sheetUplimitSize) {
      const item = sheet.splice(sheetUplimitSize, 1)[0];
      moveToFap(item);
    }
  });

  return newSpace;
}
