import {
  flatten,
  exclude,
  excludeTwoD,
  merge,
  chunk,
  findFirstAvailablePosition,
  isReorganizationNeeded,
  reorganizeSheets,
  redistributeSheets,
  findIndexInTwoDArray
} from './ItemUtils';

describe('flatten', () => {
  test('regular case', () => {
    expect(
      flatten([[1], [2], [3]])
    ).toEqual(
      [1, 2, 3]
    );
    expect(
      flatten([1, [2, [3]]])
    ).toEqual(
      [1, 2, 3]
    );
    expect(
      flatten([[[1]]])
    ).toEqual(
      [1]
    );
  });
});

describe('exclude', () => {
  test('regular case', () => {
    expect(
      exclude([1, 2, 3], [2, 3])
    ).toEqual(
      [1]
    );
  });
  test('error case', () => {
    expect(() => exclude()).toThrow();
    expect(() => exclude([1, 2, 3])).toThrow();
  });
});

describe('excludeTwoD', () => {
  test('regular case', () => {
    expect(
      excludeTwoD([[1, 2], [3, 4, 5]], [4, 5])
    ).toEqual(
      [[1, 2], [3]]
    );

    expect(
      excludeTwoD([[1, 2], [3, 4]], [3, 4])
    ).toEqual(
      [[1, 2], []]
    );
  });
});

describe('merge', () => {
  test('regular case', () => {
    expect(
      merge([1, 2], [3, 4])
    ).toEqual(
      [1, 2, 3, 4]
    );
  });
  test('error case', () => {
    expect(() => merge()).toThrow();
    expect(() => merge([1, 2, 3])).toThrow();
  });
});

describe('chunk', () => {
  test('regular case', () => {
    expect(
      chunk([1, 2, 3, 4, 5], 2)
    ).toEqual(
      [[1, 2], [3, 4], [5]]
    );
  });
  test('error case', () => {
    expect(() => chunk()).toThrow();
    expect(() => chunk([])).toThrow();
  });
});

describe('findFirstAvailablePosition', () => {
  test('regular case', () => {
    expect(
      findFirstAvailablePosition([[1], [3, 4]], 2)
    ).toEqual(
      [0, 1]
    );

    expect(
      findFirstAvailablePosition([[1, 2], [3]], 2)
    ).toEqual(
      [1, 1]
    );

    expect(
      findFirstAvailablePosition([[1, 2], [3, 4]], 2)
    ).toEqual(
      null
    );
  });
  test('error case', () => {
    expect(() => findFirstAvailablePosition()).toThrow();
    expect(() => findFirstAvailablePosition([[1], [3, 4]])).toThrow();
  });
});

describe('redistributeSheets', () => {
  test('regular case', () => {
    expect(
      redistributeSheets([[1, 2, 3], [4]], 2)
    ).toEqual([[1, 2], [3, 4]]);

    expect(
      redistributeSheets([[1, 2, 3], [4, 5]], 2)
    ).toEqual([[1, 2], [3, 4], [5]]);

    expect(
      redistributeSheets([[1, 2, 3]], 2)
    ).toEqual([[1, 2], [3]]);

    expect(
      redistributeSheets([[1, 2, 3, 4]], 2)
    ).toEqual([[1, 2], [3, 4]]);

    expect(
      redistributeSheets([[1, 2, 3, 4, 5]], 2)
    ).toEqual([[1, 2], [3, 4], [5]]);

    expect(
      redistributeSheets([[1, 2], [3]], 2)
    ).toEqual([[1, 2], [3]]);

    expect(
      redistributeSheets([[1], [2, 3]], 2)
    ).toEqual([[1], [2, 3]]);

    expect(
      redistributeSheets([[1], [2, 3, 4]], 2)
    ).toEqual([[1], [2, 3], [4]]);

    expect(
      redistributeSheets([[1], [2], [3, 4, 5]], 2)
    ).toEqual([[1], [2], [3, 4], [5]]);

    expect(
      redistributeSheets([[1], [2], [3, 4, 5, 6]], 2)
    ).toEqual([[1], [2], [3, 4], [5, 6]]);

    expect(
      redistributeSheets([[1, 2, 3, 4, 5, 6]], 2)
    ).toEqual([[1, 2], [3, 4], [5, 6]]);
  });
});

describe('isReorganizationNeeded', () => {
  test('regular case', () => {
    expect(
      isReorganizationNeeded([], 2)
    ).toEqual(false);
    expect(
      isReorganizationNeeded([[1, 2]], 2)
    ).toEqual(false);
    expect(
      isReorganizationNeeded([[1], [2]], 2)
    ).toEqual(false);
    expect(
      isReorganizationNeeded([[1, 2], [3, 4]], 2)
    ).toEqual(false);
    expect(
      isReorganizationNeeded([[1, 2, 3]], 2)
    ).toEqual(true);
    expect(
      isReorganizationNeeded([[1, 2], [3, 4, 5]], 2)
    ).toEqual(true);
    expect(
      isReorganizationNeeded([[1, 2, 3], [4, 5, 6]], 2)
    ).toEqual(true);
  });
});

describe('reorganizeSheets', () => {
  test('regular case', () => {
    expect(
      reorganizeSheets([[1, 2, 3]], 2)
    ).toEqual([[1, 2], [3]]);

    expect(
      reorganizeSheets([[1, 2, 3, 4]], 2)
    ).toEqual([[1, 2], [3, 4]]);

    expect(
      reorganizeSheets([[1, 2, 3, 4, 5]], 2)
    ).toEqual([[1, 2], [3, 4], [5]]);

    expect(
      reorganizeSheets([[1, 2], [3]], 2)
    ).toEqual([[1, 2], [3]]);

    expect(
      reorganizeSheets([[1], [2, 3]], 2)
    ).toEqual([[1], [2, 3]]);

    expect(
      reorganizeSheets([[1], [2, 3, 4]], 2)
    ).toEqual([[1, 4], [2, 3]]);

    expect(
      reorganizeSheets([[1], [2], [3, 4, 5]], 2)
    ).toEqual([[1, 5], [2], [3, 4]]);

    expect(
      reorganizeSheets([[1], [2], [3, 4, 5, 6]], 2)
    ).toEqual([[1, 5], [2, 6], [3, 4]]);

    expect(
      reorganizeSheets([[1], [2, 3, 4, 5]], 2)
    ).toEqual([[1, 4], [2, 3], [5]]);

    expect(
      reorganizeSheets([[1, 2, 3, 4, 5, 6]], 2)
    ).toEqual([[1, 2], [3, 4], [5, 6]]);
  });
});

describe('findIndexInTwoDArray', () => {
  expect(
    findIndexInTwoDArray([[1, 2], [3, 4]], 2)
  ).toEqual([0, 1]);

  expect(
    findIndexInTwoDArray([[1, 2], [3, 4]], 3)
  ).toEqual([1, 0]);

  expect(
    findIndexInTwoDArray([[1, 2], [3, 4]], 5)
  ).toEqual(null);


  expect(
    () => findIndexInTwoDArray()
  ).toThrow();

  expect(
    () => findIndexInTwoDArray([])
  ).toThrow();

  expect(
    () => findIndexInTwoDArray(['1-d'])
  ).toThrow();

  expect(
    () => findIndexInTwoDArray([[1]])
  ).toThrow();
});
