export const ItemTypes = {
  MozApp: 'mozApp',
  Bookmark: 'bookmark',
  Group: 'group'
};

export const ItemInstallStates = {
  installed: 'installed',
  uninstalling: 'uninstalling',
  uninstalled: 'uninstalled',
  updating: 'updating',
};

const initialItem = {
  id: null,
  type: null,
  source: null,
  manifestURL: '',
};

const GenericItem = {
  create: (params) => {
    return Object.assign({}, initialItem, params);
  }
};

export default GenericItem;
