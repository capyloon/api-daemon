import React from 'react';
import ReactDOM from 'react-dom';
import { Provider } from 'react-redux';
import configureStore from './store';
import ErrorBoundary from './Components/ErrorBoundary';
import App from './Components/App';

import './index.scss';
import './z-orders.scss';

ReactDOM.render(
  <Provider store={configureStore()}>
    <ErrorBoundary>
      <App />
    </ErrorBoundary>
  </Provider>,
  document.getElementById('root')
);
