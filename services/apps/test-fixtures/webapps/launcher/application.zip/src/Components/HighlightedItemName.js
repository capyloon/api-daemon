import React, { Fragment } from 'react';

const HighlightedItemName = (itemName, highlightedTerm) => {
  if (highlightedTerm && highlightedTerm !== '') {
    const matchedTerm = itemName.match(new RegExp(highlightedTerm, 'i'))[0];
    return (
      <Fragment>
        <span className="highlighted">{matchedTerm}</span>
        <span>{itemName.replace(matchedTerm, '')}</span>
      </Fragment>
    );
  }
  return (
    <span>{itemName}</span>
  );
};

export default HighlightedItemName;
