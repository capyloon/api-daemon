test('Empty test suite', () => {
  expect(1).toBe(1);
});
