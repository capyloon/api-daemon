import React, { useEffect, useRef } from 'react';
import { SPACE, allAppsSheetSize } from '../Constants';
import Item, { ItemPlaceholder } from './Item';

import './AllApps.scss';

const Sheet = (props) => {
  const { items, sheetIndex } = props;
  return (
    <div className="sheet">
      <div className="items-container">
        {items.map((item, itemIndex) => (
          <Item
            key={item.manifestURL}
            item={item}
            flow="horizontal"
            spaceName={SPACE.ALL_APPS}
            spaceIndex={[sheetIndex, itemIndex]}
          />
        ))}
        {items.length < allAppsSheetSize &&
          [...Array(allAppsSheetSize - items.length)].map((elem, index) => (
            <ItemPlaceholder
              // eslint-disable-next-line react/no-array-index-key
              key={index}
              spaceName={SPACE.ALL_APPS}
              // The value -1 indicates that it's vacant.
              spaceIndex={[sheetIndex, -1]}
            />
          ))}
      </div>
    </div>
  );
};

const AllApps = (props) => {
  const { sheets } = props;
  const { visible, scrollingDisabled } = props;

  const allAppsRef = useRef(null);
  useEffect(() => {
    // XXX: This is only a workaround to reset the scrollTop;
    // It'll better to reset the scrollTop when the fade-out transition ended.
    if (visible) {
      const allApps = allAppsRef.current;
      allApps.scrollTop = 0;
    }
  }, [visible]);

  return (
    <section
      style={{
        opacity: visible ? 1 : 0,
        transform: visible ? 'translateY(0%)' : 'translateY(10%)'
      }}
      id="all-apps"
      className={`righthand-side ${
        // Disable scrolling during drag-n-drop phase.
        scrollingDisabled ? 'scrolling-disabled' : ''
      }`}
      ref={allAppsRef}
    >
      <div className="scrollable">
        {sheets.map((sheet, index) => (
          <Sheet
            // eslint-disable-next-line react/no-array-index-key
            key={index}
            items={sheet}
            sheetIndex={index}
          />
        ))}
      </div>
    </section>
  );
};

export default AllApps;
