## The diagram of a long-press:

```
Touch Start => Set the long-press timer.

Touch Move  => Cancel the long-press timer if the touch went out of the tolerable range.

Touch End   => Has long-press triggered? => No  => Cancel the non-activated long-press timer.
                                            Yes => 1. Prevent from further events.
                                                   2. Trigger the `onLongPressEnd` at window's touchend.

Timer is up => Trigger the long-press.
```