import React, { useEffect, useCallback } from 'react';
import ItemIcon from './ItemIcon';
import { findTouchById } from '../Shared/ItemUtils';

import './DraggingItem.scss';

const DraggingItem = (props) => {
  const { visible, dndParams, item } = props;
  const { onDragging, onDrop } = props;
  const { touchId, initialCoordinate } = dndParams;

  const handleDragging = useCallback((touchEvent) => {
    const targetTouch = findTouchById(touchEvent.changedTouches, touchId);
    if (!targetTouch) {
      return;
    }
    // XXX: The query can be cached, but deal with it carefully.
    const draggingItemElem = document.getElementById('dnd-dragging-item');
    const { screenX, screenY } = targetTouch;
    const offsetX = draggingItemElem.clientWidth / 2;
    const offsetY = draggingItemElem.clientHeight / 2;
    // Update the position of the dragging item.
    requestAnimationFrame(() => {
      draggingItemElem.style.transform =
        `translate(${screenX - offsetX}px,${screenY - offsetY}px)`;
    });
    if (onDragging) {
      onDragging({ screenX, screenY, item, dndParams });
    }
  }, [touchId, onDragging, item, dndParams]);

  const handleDragEnd = useCallback((touchEvent) => {
    const targetTouch = findTouchById(touchEvent.changedTouches, touchId);
    if (!targetTouch) {
      return;
    }
    console.log('End dragging with touchId:', touchId, touchEvent);
    const draggingItemElem = document.getElementById('dnd-dragging-item');
    const { screenX, screenY } = targetTouch;
    const offsetX = draggingItemElem.clientWidth / 2;
    const offsetY = draggingItemElem.clientHeight / 2;
    // Update the position of the dragging item.
    requestAnimationFrame(() => {
      draggingItemElem.style.transform =
        `translate(${screenX - offsetX}px,${screenY - offsetY}px)`;
    });
    if (onDrop) {
      onDrop({ screenX, screenY, item, dndParams });
    }
  }, [touchId, onDrop, item, dndParams]);

  useEffect(() => {
    if (visible) {
      document.addEventListener('touchmove', handleDragging);
      document.addEventListener('touchend', handleDragEnd);
      // Manually update the icon position with initial coordinate.
      const draggingItemElem = document.getElementById('dnd-dragging-item');
      requestAnimationFrame(() => {
        draggingItemElem.style.transform =
          `translate(${initialCoordinate.x}px,${initialCoordinate.y}px)`;
      });
    }
    return () => {
      document.removeEventListener('touchmove', handleDragging);
      document.removeEventListener('touchend', handleDragEnd);
    };
  }, [visible, touchId, initialCoordinate, handleDragging, handleDragEnd]);

  return (
    <div
      id="dnd-dragging-item"
      className={!visible ? 'invisible' : ''}
    >
      <div className="item">
        <div className="icon-container">
          <ItemIcon item={item} />
        </div>
      </div>
    </div>
  );
};

export default DraggingItem;
