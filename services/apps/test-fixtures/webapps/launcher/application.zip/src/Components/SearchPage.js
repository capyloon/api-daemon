import React, { useState, useRef, useMemo, useCallback, useEffect } from 'react';
import { connect } from 'react-redux';
import Item from './Item';

import * as globalAction from '../Modules/global';

import './SearchPage.scss';
import { isVisibleItem } from '../Shared/ItemUtils';
import { ItemTypes } from '../Shared/GenericItem';

const Search = (props) => {
  const { visible, items, navigateBack } = props;

  const [term, setTerm] = useState(null);
  const updateSearchTerm = useCallback((term) => {
    if (!term || term === '') {
      setTerm(null);
    } else {
      setTerm(term);
    }
  }, [setTerm]);

  const searchBarRef = useRef(null);
  const handleChange = useCallback((e) => {
    updateSearchTerm(e.detail.value);
  }, [updateSearchTerm]);
  const handleInput = useCallback((e) => {
    updateSearchTerm(e.detail.value);
  }, [updateSearchTerm]);
  const handleCancel = useCallback((e) => {
    navigateBack();
  }, [navigateBack]);

  useEffect(() => {
    const searchBar = searchBarRef.current;
    searchBar.addEventListener('change', handleChange);
    searchBar.addEventListener('input', handleInput);
    searchBar.addEventListener('cancel', handleCancel);
    return () => {
      searchBar.removeEventListener('change', handleChange);
      searchBar.removeEventListener('input', handleInput);
      searchBar.removeEventListener('cancel', handleCancel);
    };
  }, [searchBarRef, handleCancel, handleInput, handleChange]);

  useEffect(() => {
    const searchBar = searchBarRef.current;
    // Reset the page state while the page is hidden.
    if (!visible) {
      // Return the focus back to the document
      // so that the keyboard app can be closed.
      searchBar.blur();
      searchBar.value = '';
      updateSearchTerm(null);
      console.log('Search page has self-cleaned the state.');
    } else {
      // Auto-focus on the search field as soon as the page is opened.
      searchBar.focus();
    }
  }, [visible, updateSearchTerm]);

  const mozApps = useMemo(() => {
    return items
      .filter(isVisibleItem)
      .filter((item) => item.type === ItemTypes.MozApp);
  }, [items]);

  const matchedItems = useMemo(() => {
    if (!term) {
      return null;
    }
    return mozApps.filter((item) =>
      item.mozApp.manifest.name.toLowerCase()
        .indexOf(term.toLowerCase()) === 0);
  }, [term, mozApps]);

  const searchResult = useMemo(() => {
    if (!matchedItems) {
      return <h4>Type something to search.</h4>;
    }
    if (matchedItems.length === 0) {
      return <h4>&quot;{term}&quot; not found.</h4>;
    }

    return (
      <div className="scrollable">
        <kai-separator label="APPS MENU" />
        <div className="items-container">
          {matchedItems.map((item) => (
            <Item
              key={item.id}
              item={item}
              highlightedTerm={term}
            />
          ))}
        </div>
      </div>
    );
  }, [term, matchedItems]);

  return (
    <section
      id="search-page"
      className={`page-fullsize ${!visible ? 'hidden' : ''}`}
    >
      <kai-searchbar
        ref={searchBarRef}
        placeholder="Search"
        withcancel
        isheader
      />
      {searchResult}
    </section>
  );
};

const mapState = (state) => state.collection;
const mapDispatch = {
  navigateBack: globalAction.navigateBack
};

export default connect(
  mapState,
  mapDispatch
)(Search);
