import React, { useRef, useCallback, useEffect } from 'react';
import { connect } from 'react-redux';
import * as globalAction from '../Modules/global';

import './DialogPage.scss';

const Dialog = (props) => {
  const { visible, dialog, confirmDialog, cancelDialog } = props;
  const dialogRef = useRef(null);

  const handlePrimaryButtonClick =
    useCallback(() => {
      confirmDialog();
    }, [confirmDialog]);

  const handleSecondaryButtonClick =
    useCallback(() => {
      cancelDialog();
    }, [cancelDialog]);

  useEffect(() => {
    const currentDialogRef = dialogRef.current;
    currentDialogRef.addEventListener('dialogPrimaryBtnClick', handlePrimaryButtonClick);
    currentDialogRef.addEventListener('dialogSecondaryBtnClick', handleSecondaryButtonClick);
    return () => {
      currentDialogRef.removeEventListener('dialogPrimaryBtnClick', handlePrimaryButtonClick);
      currentDialogRef.removeEventListener('dialogSecondaryBtnClick', handleSecondaryButtonClick);
    };
  }, [dialogRef, handlePrimaryButtonClick, handleSecondaryButtonClick]);

  useEffect(() => {
    if (dialogRef.current) {
      dialogRef.current.open = dialog.enabled;
    }
  }, [dialog]);

  return (
    <kai-dialog
      ref={dialogRef}
      class={!visible ? 'hidden' : ''}
      title="Delete"
      message="Delete selected item(s)?"
      primarybtntext="Delete"
      secondarybtntext="Cancel"
    />
  );
};

const mapState = (state) => state.global;
const mapDispatch = {
  confirmDialog: globalAction.confirmDialog,
  cancelDialog: globalAction.cancelDialog
};

export default connect(
  mapState,
  mapDispatch
)(Dialog);
