import React from 'react';
import { connect } from 'react-redux';
import * as globalAction from '../Modules/global';
import { SPACE, favAppsListSize } from '../Constants';
import Item, { ItemPlaceholder } from './Item';

import './FavApps.scss';

const FavApps = (props) => {
  const { editMode, toggleItemSelection } = props;
  const items = props.items || [];
  return (
    <section
      id="fav-apps"
      className="lefthand-side"
    >
      <div className="background-container">
        {editMode && !editMode.enabled && (
          <div className="divider" />
        )}
      </div>
      <div className="items-container">
        {items && items.map((item, index) => (
          <Item
            key={item.id}
            item={item}
            editMode={editMode}
            flow="vertical"
            spaceName={SPACE.FAV_APPS}
            spaceIndex={index}
            toggleItemSelection={toggleItemSelection}
          />
        ))}
        {items.length < favAppsListSize &&
          [...Array(favAppsListSize - items.length)].map((elem, index) => (
            <ItemPlaceholder
              // eslint-disable-next-line react/no-array-index-key
              key={index}
              spaceName={SPACE.FAV_APPS}
              // The value -1 indicates that it's vacant.
              spaceIndex={-1}
            />
          ))}
      </div>
    </section>
  );
};

const mapState = (state) => state.global;
const mapDispatch = {
  toggleItemSelection: globalAction.toggleItemSelection
};

export default connect(
  mapState,
  mapDispatch
)(FavApps);
