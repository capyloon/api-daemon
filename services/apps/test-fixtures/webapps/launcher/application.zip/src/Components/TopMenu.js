import React, { Fragment, useCallback } from 'react';
import { connect } from 'react-redux';
import * as globalAction from '../Modules/global';

import './TopMenu.scss';

const TopMenu = (props) => {
  const { visible, editMode } = props;
  const { navigateTo, toggleEditMode } = props;

  const handleSearchButtonClick =
    useCallback(() => navigateTo('search'), [navigateTo]);
  const handleEditButtonClick =
    useCallback(() => toggleEditMode(true), [toggleEditMode]);
  const handleDoneButtonClick =
    useCallback(() => toggleEditMode(false), [toggleEditMode]);

  return (
    <section
      id="top-menu"
      className={!visible ? 'invisible' : ''}
    >
      {editMode && editMode.enabled
        ? (
          <span
            className="button done"
            role="button"
            tabIndex={-1}
            onClick={handleDoneButtonClick}
          >
            Done
          </span>
        )
        : (
          <Fragment>
            <span
              className="button search"
              role="button"
              tabIndex={-1}
              data-icon="search"
              onClick={handleSearchButtonClick}
            />
            <span
              className="button edit"
              role="button"
              tabIndex={-1}
              onClick={handleEditButtonClick}
            >
              Edit
            </span>
          </Fragment>
        )}
    </section>
  );
};

const mapState = (state) => state.global;
const mapDispatch = {
  navigateTo: globalAction.navigateTo,
  toggleEditMode: globalAction.toggleEditMode
};

export default connect(
  mapState,
  mapDispatch
)(TopMenu);
