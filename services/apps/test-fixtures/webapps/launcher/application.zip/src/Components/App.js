import React, { Fragment, useEffect } from 'react';
import { connect } from 'react-redux';
import * as itemActions from '../Modules/collection';
import HomePage from './HomePage';
import SearchPage from './SearchPage';
import DialogPage from './DialogPage';

import './App.scss';

const App = (props) => {
  const { mozAppGetAll } = props;
  const { route, groupView, dialog } = props.global;

  useEffect(() => {
    // Initialize the mozApps from here.
    mozAppGetAll();

    // Set the initial URL fragment.
    window.history.pushState(null, null, `#${route || 'home'}`);

  // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  const visibility = {
    home: route === 'home' || route === 'all-apps',
    search: route === 'search'
  };
  return (
    <div id="app" className={groupView.enabled ? 'group-view' : ''}>
      <HomePage
        visible={visibility.home}
        route={route}
      />
      <SearchPage
        visible={visibility.search}
        route={route}
      />
      <DialogPage visible={dialog.enabled} />
    </div>
  );
};

const mapState = (state) => state;
const mapDispatch = {
  mozAppGetAll: itemActions.mozAppGetAll
};

export default connect(
  mapState,
  mapDispatch
)(App);
