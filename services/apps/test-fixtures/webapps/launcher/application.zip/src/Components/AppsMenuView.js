import produce from 'immer';
import React, { Fragment, useMemo, useEffect } from 'react';
import { connect } from 'react-redux';
import * as itemActions from '../Modules/collection';
import { ItemTypes } from '../Shared/GenericItem';
import FavApps from './FavApps';
import AllApps from './AllApps';
import GroupView from './GroupView';
import TopMenu from './TopMenu';
import BottomMenu from './BottomMenu';
import DraggingItem from './DraggingItem';
import ParkingApps from './ParkingApps';

export function findDroppableArea(screenX, screenY, onFoundCallback) {
  const topMostDroppableArea = document
    .elementsFromPoint(screenX, screenY)
    // XXX: In fact, I'm not sure if the list is ordered by the z-index.
    // So far I cannot ensure it's top-most or not.
    .find((elem) => elem.classList.contains('droppable'));
  if (topMostDroppableArea) {
    if (onFoundCallback) {
      onFoundCallback(topMostDroppableArea.dataset);
    }
  }
}

// Turn item queries into item instances.
const executeItemQueries = (items, queries) => {
  return queries
    .map((query) => {
      // Recursively querying when there's a nested array.
      if (Array.isArray(query)) {
        return executeItemQueries(items, query);
      }
      return items.find((item) => item.manifestURL === query);
    })
    .filter(Boolean);
};

const AppsMenuView = (props) => {
  const { allAppsEnabled, moveToSpace } = props;
  const { editMode, dndMode, groupView } = props.global;
  const { items, spaces } = props.collection;

  const clonedItems = produce(items, (draft) => {
    draft.forEach((item) => {
      // Execute queries from group space.
      if (item.type === ItemTypes.Group) {
        const groupSpace = spaces[item.space];
        item.spaceItems = executeItemQueries(items, groupSpace);
      }
    });
  });

  // Space distribution pass
  const parkingApps = useMemo(() => {
    return spaces.parkingApps
      ? executeItemQueries(clonedItems, spaces.parkingApps)
      : [];
  }, [clonedItems, spaces.parkingApps]);

  const favApps = useMemo(() => {
    return spaces.favApps
      ? executeItemQueries(clonedItems, spaces.favApps)
      : [];
  }, [clonedItems, spaces.favApps]);

  const allApps = useMemo(() => {
    return spaces.allApps
      ? executeItemQueries(clonedItems, spaces.allApps)
      : [];
  }, [clonedItems, spaces.allApps]);

  const draggingItem = useMemo(() => {
    if (!dndMode.enabled) {
      return null;
    }
    return executeItemQueries(clonedItems, [dndMode.selectedItem]).shift();
  }, [dndMode.enabled, dndMode.selectedItem, clonedItems]);

  const handleDragging = ({ screenX, screenY, item, dndParams }) => {
    // TODO: Micro-interactions during the dragging.
  };
  const handleDrop = ({ screenX, screenY, item, dndParams }) => {
    findDroppableArea(screenX, screenY, (droppableAreaDataset) => {
      if (droppableAreaDataset.dropPlacement === 'group') {
        if (item.type === ItemTypes.Group) {
          console.warn('Trying to drag-n-drop a group into another group, this is a no-op.');
          return;
        }
        moveToSpace({
          manifestURL: item.manifestURL,
          fromSpace: dndParams.sourceSpace.name,
          toSpace: droppableAreaDataset.spaceName
        });
        return;
      }

      let toPosition = null;

      // Calculate the detination position if `spaceIndex` is provided.
      // Otherwise, keep it `null` so that reducer will place it at FAP.
      if (droppableAreaDataset.spaceIndex !== undefined) {
        const insertionOffset =
          droppableAreaDataset.dropPlacement === 'after' ? 1 : 0;
        const isTuple =
          droppableAreaDataset.spaceIndex.indexOf(',') >= 0;

        if (isTuple) {
          const targetDroppableIndex =
            droppableAreaDataset.spaceIndex.split(',').map(Number);
          toPosition = targetDroppableIndex;
          toPosition[1] += insertionOffset;
        } else {
          const targetDroppableIndex =
            parseInt(droppableAreaDataset.spaceIndex, 10);
          toPosition = targetDroppableIndex + insertionOffset;
        }
      }

      moveToSpace({
        manifestURL: item.manifestURL,
        fromSpace: dndParams.sourceSpace.name,
        toSpace: droppableAreaDataset.spaceName,
        toPosition
      });
    });
  };

  // Give a haptic feedback while enabling the DND mode.
  useEffect(() => {
    if (dndMode.enabled) {
      navigator.vibrate(50);
    }
  }, [dndMode.enabled]);

  return (
    <Fragment>
      <div
        className="background-overlay"
        style={{ opacity: allAppsEnabled ? 1 : 0 }}
      />
      <ParkingApps
        visible={editMode.enabled}
        items={parkingApps}
      />
      <FavApps items={favApps} />
      <AllApps
        visible={allAppsEnabled}
        sheets={allApps}
        scrollingDisabled={dndMode.enabled}
      />
      <GroupView
        visible={groupView.enabled}
        scrollingDisabled={dndMode.enabled}
      />
      <TopMenu visible={allAppsEnabled} />
      {editMode.enabled && (
        <BottomMenu />
      )}
      <DraggingItem
        visible={dndMode.enabled}
        dndParams={dndMode}
        item={draggingItem}
        onDragging={handleDragging}
        onDrop={handleDrop}
      />
    </Fragment>
  );
};

const mapState = (state) => state;
const mapDispatch = {
  moveToSpace: itemActions.moveToSpace
};

export default connect(
  mapState,
  mapDispatch
)(AppsMenuView);
