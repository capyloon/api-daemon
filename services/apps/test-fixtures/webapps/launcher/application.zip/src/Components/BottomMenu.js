import React, { useRef, useEffect, useMemo, useCallback } from 'react';
import { connect } from 'react-redux';
import { GlobalStates } from '../Constants';
import * as globalAction from '../Modules/global';
import * as itemAction from '../Modules/collection';

import './BottomMenu.scss';

const BottomMenu = (props) => {
  const { status, editMode, groupView } = props.global;
  const { items } = props.collection;
  const { requestConfirmation, createGroup, moveOutFromGroup } = props;

  const isMenuDisabled = (
    status !== GlobalStates.idle ||
    editMode.selectedItems.length === 0
  );
  const selectedMoreThanTwoItems = editMode.selectedItems.length >= 2;
  const selectionContainsRemovableItem = useMemo(() => {
    if (editMode.selectedItems.length > 0) {
      const matchedIndex =
        editMode.selectedItems.findIndex((selectedItem) => {
          const matchedItem =
            items.find((item) => item.manifestURL === selectedItem);
          // XXX: We should also verify for non-mozApp types as well.
          return (
            matchedItem && matchedItem.mozApp &&
            matchedItem.mozApp.removable === true
          );
        });
      return matchedIndex >= 0;
    }
    return false;
  }, [editMode.selectedItems, items]);

  const actionBarRef = useRef();
  const leftButton = groupView.enabled
    ? {
      title: 'Move Out',
      value: 'move-out',
      icon: 'export',
      disabled: isMenuDisabled
    }
    : {
      title: 'Group',
      value: 'group',
      icon: 'app-folder',
      disabled: isMenuDisabled || !selectedMoreThanTwoItems
    };
  const rightButton = {
    title: 'Delete',
    value: 'delete',
    icon: 'delete',
    disabled: isMenuDisabled || !selectionContainsRemovableItem
  };
  const actions = [leftButton, rightButton];

  const isInactive =
    actions.reduce((curr, next) => curr && next.disabled, true);
  useEffect(() => {
    actionBarRef.current.inactive = isInactive;
  }, [isInactive, actionBarRef]);

  const handleActionbarSelect = useCallback((e) => {
    const action = e.detail.selected;
    console.log('actionbarSelect', action);
    switch (action) {
      case 'group':
        createGroup(editMode.selectedItems);
        break;
      case 'move-out':
        moveOutFromGroup(editMode.selectedItems);
        break;
      case 'delete':
        // Defer the action with a confirmation dialog.
        requestConfirmation(
          globalAction.deleteItems(editMode.selectedItems)
        );
        break;
      // no default
    }
  }, [
    editMode.selectedItems,
    requestConfirmation,
    createGroup,
    moveOutFromGroup,
  ]);

  useEffect(() => {
    const actionBar = actionBarRef.current;
    actionBar.addEventListener('actionbarSelect', handleActionbarSelect);
    return () => {
      actionBar.removeEventListener('actionbarSelect', handleActionbarSelect);
    };
  }, [actionBarRef, handleActionbarSelect]);

  return (
    <section id="bottom-menu">
      <kai-actionbar
        ref={actionBarRef}
        actions={JSON.stringify(actions)}
        inactive={isInactive || null}
      />
    </section>
  );
};

const mapState = (state) => state;
const mapDispatch = {
  requestConfirmation: globalAction.requestConfirmation,
  createGroup: itemAction.createGroup,
  moveOutFromGroup: itemAction.moveOutFromGroup,
};

export default connect(
  mapState,
  mapDispatch
)(BottomMenu);
