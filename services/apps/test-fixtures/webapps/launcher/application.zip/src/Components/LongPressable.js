import React, { useState } from 'react';
import { findTouchById, distance } from '../Shared/ItemUtils';

const LONG_PRESS_DURATION = 500; // ms
const LONG_PRESS_OFFSET_TOLERANCE = 25; // px

const LongPressable = (props) => {
  const {
    className,
    children,
    onLongPressStart,
    onLongPressEnd,
    ...restProps
  } = props;

  const [longPressTimer, setLongPressTimer] = useState(null);
  const [targetTouch, setTargetTouch] = useState(null);

  const handleTouchStart = (touchEvent) => {
    const currentTouch = touchEvent.targetTouches[0];
    setTargetTouch(currentTouch);

    // Preserve properties from React SyntheticEvent for asynchronous usage.
    const longPressParams = {
      currentTarget: touchEvent.currentTarget,
      targetTouch: currentTouch
    };
    // Set the long-press timer.
    const timer = setTimeout(() => {
      // Set the timer to null to inform the touchend handler
      // that long-press has already been triggered.
      setLongPressTimer(null);
      // Trigger the long-press handler.
      if (onLongPressStart) {
        onLongPressStart(longPressParams);
      }
    }, LONG_PRESS_DURATION);
    setLongPressTimer(timer);
  };

  // Long-press requires user to press and hold the touch in place.
  // So we will cancel a long-press if the touch went out of the
  // tolerable range.
  const handleTouchMove = (touchEvent) => {
    if (!targetTouch || !longPressTimer) {
      return;
    }

    const matchedTouch = findTouchById(
      touchEvent.changedTouches,
      targetTouch.identifier
    );
    if (matchedTouch) {
      const d = distance(
        targetTouch.clientX, targetTouch.clientY,
        matchedTouch.clientX, matchedTouch.clientY
      );
      if (d >= LONG_PRESS_OFFSET_TOLERANCE) {
        clearTimeout(longPressTimer);
        setLongPressTimer(null);
      }
    }
  };

  const handleTouchEnd = (touchEvent) => {
    const isLongPressed = (longPressTimer === null);
    if (isLongPressed) {
      // Stop from triggering further mouse events.
      touchEvent.preventDefault();
      // Invoke the onLongPressEnd handler from window's touchend event
      // because it's the end of the touchend event's bubbling phase.
      window.addEventListener('touchend', (touchEndEvent) => {
        if (onLongPressEnd) {
          onLongPressEnd(touchEndEvent);
        }
      }, { once: true });

      return;
    }
    // Cancel the non-activated long-press timer.
    if (Number.isInteger(longPressTimer)) {
      clearTimeout(longPressTimer);
      setLongPressTimer(null);
    }
  };

  return (
    <div
      {...restProps}
      className={`long-pressable ${className}`}
      onTouchStart={handleTouchStart}
      onTouchMove={handleTouchMove}
      onTouchEnd={handleTouchEnd}
    >
      {children}
    </div>
  );
};

export default LongPressable;
