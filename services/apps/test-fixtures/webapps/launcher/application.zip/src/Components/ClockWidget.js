import React, { useState, useEffect } from 'react';

import './ClockWidget.scss';

const getWeekdayString = (weekday) => {
  if (!Number.isInteger(weekday) || weekday < 0 || weekday > 6) {
    return '';
  }
  // eslint-disable-next-line max-len
  return ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'][weekday];
};

const getMonthString = (month) => {
  if (!Number.isInteger(month) || month < 0 || month > 11) {
    return '';
  }
  // eslint-disable-next-line max-len
  return ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'][month];
};

const ClockWidget = (props) => {
  const [time, setTime] = useState(new Date());
  useEffect(() => {
    const ticker = setInterval(() => setTime(new Date()), 1000);
    return () => clearInterval(ticker);
  }, []);

  const period = time.getHours() >= 12 ? 'PM' : 'AM';

  const hh = `0${time.getHours() % 12 || 12}`.slice(-2);
  const hoursFirstDigit = hh[0] === '0' ? null : hh[0];
  const hoursSecondDigit = hh[1];

  const mm = `0${time.getMinutes()}`.slice(-2);
  const minutesFirstDigit = mm[0];
  const minutesSecondDigit = mm[1];

  const weekday = getWeekdayString(time.getDay()).toUpperCase();
  const month = getMonthString(time.getMonth()).toUpperCase();
  // Looks like .toLocaleString() will cause memory bloating.
  // const weekday = time.toLocaleString('en-us', { weekday: 'long' }).toUpperCase();
  // const month = time.toLocaleString('en-us', { month: 'long' }).toUpperCase();
  const day = time.getDate();
  return (
    <div className="clock-widget">
      <span className="time">
        {hoursFirstDigit && (
          <span
            className="digit"
            data-icon={`numeric_${hoursFirstDigit}_light`}
          />
        )}
        <span
          className="digit"
          data-icon={`numeric_${hoursSecondDigit}_light`}
        />
        <span className="colon" />
        <span
          className="digit"
          data-icon={`numeric_${minutesFirstDigit}_light`}
        />
        <span
          className="digit"
          data-icon={`numeric_${minutesSecondDigit}_light`}
        >
          <span className="period">{period}</span>
        </span>
      </span>
      <span className="date-container">
        <span className="weekday">{weekday}</span>
        <span className="date">
          {month} {day}
        </span>
      </span>
    </div>
  );
};

export default ClockWidget;
