import React, { Fragment, useMemo } from 'react';
import { connect } from 'react-redux';
import * as globalAction from '../Modules/global';
import { ItemInstallStates, ItemTypes } from '../Shared/GenericItem';
import { getItemName } from '../Shared/ItemUtils';
import HighlightedItemName from './HighlightedItemName';
import LongPressable from './LongPressable';
import ItemIcon from './ItemIcon';

import './Item.scss';

const Item = (props) => {
  const {
    item,
    highlightedTerm,
    editMode,
    dndMode,
    flow,
    spaceName,
    spaceIndex
  } = props;
  const { toggleDndMode, toggleItemSelection, toggleGroupView } = props;

  const isInEditMode = editMode && editMode.enabled;
  const isDndTarget = dndMode.selectedItem === item.manifestURL;
  const itemName = useMemo(() => {
    const name = getItemName(item);
    return HighlightedItemName(name, highlightedTerm);
  }, [item, highlightedTerm]);

  const launchItem = () => {
    // Item launching:
    // FIXME: Temporarily assume that we're handling a mozApp instance.
    // Should extend to various of data types.
    if (item && item.mozApp && item.mozApp.origin && item.mozApp.manifest && item.mozApp.manifest.launch_path) {
      //console.log(`About to launch app from ${item.mozApp.origin + item.mozApp.manifest.launch_path}`);
      window.open(item.mozApp.manifestURL, "_blank", "kind=app");
    } else {
      console.error(`Failed to launched ${JSON.stringify(item)}`);
    }
  };

  const handleItemClick = () => {
    switch (item.type) {
      case ItemTypes.MozApp: {
        if (item.installState !== ItemInstallStates.installed) {
          throw new Error('The item is currently not available.');
        }
        if (isInEditMode) {
          toggleItemSelection(item.manifestURL);
        } else {
          launchItem();
        }
        break;
      }
      case ItemTypes.Group:
        toggleGroupView(true, item.manifestURL);
        break;
      // no default
    }
  };

  const isSelected = useMemo(() => (
    isInEditMode &&
    editMode.selectedItems.indexOf(item.manifestURL) >= 0
  ), [isInEditMode, editMode, item]);

  const isRemovable = (
    item &&
    item.mozApp &&
    item.mozApp.removable === true
  );

  // Enable the DND mode as soon as long-pressed.
  const handleLongPressStart = (longPressParams) => {
    const { x, y } = longPressParams.currentTarget
      .querySelector('.icon-container')
      .getBoundingClientRect();
    if (isInEditMode && !dndMode.enabled) {
      toggleDndMode(true, {
        selectedItem: item.manifestURL,
        initialCoordinate: { x, y },
        touchId: longPressParams.targetTouch.identifier,
        sourceSpace: {
          name: spaceName,
          index: spaceIndex
        }
      });
    }
  };

  // Disable the DND mode as soon as dragging ended.
  const handleLongPressEnd = (touchEvent) => {
    if (dndMode.enabled &&
      touchEvent.changedTouches[0].identifier === dndMode.touchId) {
      toggleDndMode(false);
    }
  };

  return (
    <LongPressable
      className="item-space"
      role="button"
      tabIndex={-1}
      onClick={handleItemClick}
      onLongPressStart={handleLongPressStart}
      onLongPressEnd={handleLongPressEnd}
    >
      <div className={`item ${
        isInEditMode && !isRemovable ? 'unremovable' : ''
      } ${
        isDndTarget ? 'dnd-target' : ''
      }`}
      >
        <div className="icon-container">
          {isInEditMode && (
            <div className="icon-editable-bg" />
          )}
          <ItemIcon item={item} />
          {isSelected && (
            <Fragment>
              <div className="icon-selected-overlay" />
              <span className="icon-selected-overlay__tick" data-icon="tick" />
            </Fragment>
          )}
          {/* <div className="icon-notification" /> */}
        </div>
        <span className="name">{itemName}</span>
      </div>
      {item.type === ItemTypes.Group ? (
        <div
          className="hitarea group droppable"
          data-drop-placement="group"
          data-space-name={item.space}
          data-space-index={-1}
        />
      ) : (
        <Fragment>
          <div
            className={`hitarea before droppable ${flow}`}
            data-space-name={spaceName}
            data-space-index={spaceIndex}
            data-drop-placement="before"
          />
          <div
            className={`hitarea after droppable ${flow}`}
            data-space-name={spaceName}
            data-space-index={spaceIndex}
            data-drop-placement="after"
          />
        </Fragment>
      )}
    </LongPressable>
  );
};

const mapState = (state) => state.global;
const mapDispatch = {
  toggleDndMode: globalAction.toggleDndMode,
  toggleItemSelection: globalAction.toggleItemSelection,
  toggleGroupView: globalAction.toggleGroupView
};

export default connect(
  mapState,
  mapDispatch
)(Item);

export const ItemPlaceholder = (props) => {
  const {
    spaceName,
    spaceIndex,
    showEditableBackground
  } = props;

  return (
    <div className="item-space">
      <div className="item placeholder">
        <div className="icon-container">
          {showEditableBackground && (
            <div className="icon-editable-bg" />
          )}
        </div>
        <span className="name" />
      </div>
      <div
        className="hitarea vacant droppable"
        data-drop-placement="vacant"
        data-space-name={spaceName}
        data-space-index={spaceIndex}
      />
    </div>
  );
};
