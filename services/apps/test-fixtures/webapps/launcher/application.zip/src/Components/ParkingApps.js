import React from 'react';
import { connect } from 'react-redux';
import { SPACE } from '../Constants';

import './ParkingApps.scss';

import Item, { ItemPlaceholder } from './Item';

const ParkingApps = (props) => {
  const { visible, items, editMode } = props;
  return (
    <section id="parking-apps" className={!visible ? 'hidden' : ''}>
      <div className="items-container">
        {items.length > 0
          ? (
            <Item
              item={items[0]}
              editMode={editMode}
              spaceName={SPACE.PARKING_APPS}
              spaceIndex={0}
            />
          )
          : (
            <ItemPlaceholder
              spaceName={SPACE.PARKING_APPS}
              // The value -1 indicates that it's vacant.
              spaceIndex={-1}
              showEditableBackground
            />
          )
        }
      </div>
    </section>
  );
};

const mapState = (state) => state.global;
const mapDispatch = null;

export default connect(
  mapState,
  mapDispatch
)(ParkingApps);
