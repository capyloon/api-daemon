import React from 'react';
import ClockWidget from './ClockWidget';

import './ClockView.scss';

const ClockView = (props) => {
  const { visible } = props;

  return (
    <section
      id="clock-view"
      className={`righthand-side ${!visible ? 'invisible' : ''}`}
    >
      <ClockWidget />
    </section>
  );
};

export default ClockView;
