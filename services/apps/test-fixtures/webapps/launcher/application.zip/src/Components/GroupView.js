import React, { useRef, useEffect, useMemo, useCallback } from 'react';
import { connect } from 'react-redux';
import { SPACE, groupSheetSize } from '../Constants';
import * as globalAction from '../Modules/global';
import * as itemAction from '../Modules/collection';
import Item, { ItemPlaceholder } from './Item';

import './GroupView.scss';


const Sheet = (props) => {
  const { items, sheetIndex, isSingleSheet, spaceName } = props;

  const itemsPerRow = 3;
  const numOfPlaceholder = isSingleSheet
    ? ((itemsPerRow - (items.length % itemsPerRow)) % itemsPerRow)
    : (groupSheetSize - items.length);

  return (
    <div className="sheet">
      <div className="items-container">
        {items.map((item, itemIndex) => (
          <Item
            key={item.id}
            item={item}
            flow="horizontal"
            spaceName={spaceName}
            spaceIndex={[sheetIndex, itemIndex]}
          />
        ))}
        {numOfPlaceholder > 0 &&
          [...Array(numOfPlaceholder)].map((elem, index) => (
            <ItemPlaceholder
              // eslint-disable-next-line react/no-array-index-key
              key={index}
              spaceName={spaceName}
              // The value -1 indicates that it's vacant.
              spaceIndex={[sheetIndex, -1]}
            />
          ))}
      </div>
    </div>
  );
};

const GroupView = (props) => {
  const { visible, scrollingDisabled } = props;
  const { updateItem, toggleGroupView } = props;
  const { items, spaces } = props.collection;
  const { groupView, editMode, allAppsSheetIndex } = props.global;

  const groupItem = items.find((item) =>
    item.manifestURL === groupView.current);
  const spaceName = groupItem ? groupItem.space : null;

  const sheetsInstance = useMemo(() => {
    // Retrieve the corresponding space of the group.
    const groupSpace = spaces[spaceName];
    if (!groupSpace) return [];
    return groupSpace
      .map((sheet) => {
        return sheet
          .map((manifestURL) => items.find((item) =>
            item.manifestURL === manifestURL))
          .filter(Boolean);
      });
  }, [spaces, items, spaceName]);

  const handleOverlayClick = () => toggleGroupView(false);

  // Reset the scrollTop.
  const contentRef = useRef(null);
  useEffect(() => {
    // XXX: This is only a workaround to reset the scrollTop;
    // It'll better to reset the scrollTop when the fade-out transition ended.
    if (visible) {
      contentRef.current.scrollTop = 0;
    }
  }, [visible]);

  const handleInputBlur = useCallback((event) => {
    const newName = event.currentTarget.value;
    updateItem(groupView.current, { name: newName });
  }, [groupView, updateItem]);

  return (
    <section
      id="group-view"
      className={`page-fullsize ${!visible ? 'hidden' : ''}`}
    >
      <div className="container">
        <div
          className="background-overlay droppable"
          role="button"
          tabIndex={-1}
          onClick={handleOverlayClick}
          data-drop-placement="vacant"
          data-space-name={SPACE.ALL_APPS}
          // The value -1 indicates that it's vacant.
          data-space-index={[allAppsSheetIndex, -1]}
        />
        <div className="dialog">
          {editMode.enabled ? (
            <kai-textfield
              value={groupItem && groupItem.name}
              onBlur={handleInputBlur}
            />
          ) : (
            <h3>{groupItem && groupItem.name}</h3>
          )}
          <div
            className={`content ${
              // Disable scrolling during drag-n-drop phase.
              scrollingDisabled ? 'scrolling-disabled' : ''
            }`}
            ref={contentRef}
          >
            <div className="scrollable">
              {sheetsInstance.map((sheet, index) => (
                <Sheet
                  // eslint-disable-next-line react/no-array-index-key
                  key={index}
                  items={sheet}
                  sheetIndex={index}
                  isSingleSheet={sheetsInstance.length === 1}
                  spaceName={groupItem.space}
                />
              ))}
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

const mapState = (state) => state;
const mapDispatch = {
  toggleGroupView: globalAction.toggleGroupView,
  updateItem: itemAction.updateItem
};

export default connect(
  mapState,
  mapDispatch
)(GroupView);
