import React from 'react';
import { ItemTypes } from '../Shared/GenericItem';
import useMozAppIcon from '../Hooks/useMozAppIcon';

const capacityOfGroupIcon = 4;

export function Icon(props) {
  const { url } = props;
  const iconStyle = url
    ? { backgroundImage: `url(${url})` }
    : {};
  return (
    <div
      className="icon"
      style={iconStyle}
    />
  );
}

export function MozAppIcon(props) {
  const { mozApp } = props;
  const iconUrl = useMozAppIcon(mozApp);
  return <Icon url={iconUrl} />;
}

export function GroupIcon(props) {
  const { items = [] } = props;
  return (
    <div className="icon group">
      <div className="background" />
      <div className="grouped-icons">
        {items.map((item) => (
          <ItemIcon
            key={item.manifestURL}
            item={item}
          />
        ))}
        {[...Array(capacityOfGroupIcon - items.length)].map((_, index) => {
          // eslint-disable-next-line react/no-array-index-key
          return <Icon key={index} />;
        })}
      </div>
    </div>
  );
}

function ItemIcon(props) {
  const { item } = props;
  // If item is not available -> return the empty icon element
  if (!item || !item.type) {
    return <Icon />;
  }

  switch (item.type) {
    default:
    case ItemTypes.Bookmark:
      return <Icon />;
    case ItemTypes.MozApp: {
      return <MozAppIcon mozApp={item.mozApp} />;
    }
    case ItemTypes.Group: {
      const firstSheet = item.spaceItems[0];
      const firstFourItems = firstSheet.slice(0, capacityOfGroupIcon);
      return <GroupIcon items={firstFourItems} />;
    }
  }
}

export default ItemIcon;
