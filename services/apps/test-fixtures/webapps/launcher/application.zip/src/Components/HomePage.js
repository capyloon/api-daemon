import React from 'react';
import ClockView from './ClockView';
import AppsMenuView from './AppsMenuView';

import './HomePage.scss';

const Home = (props) => {
  const { visible, route } = props;
  const allAppsEnabled = (route === 'all-apps');

  return (
    <section
      id="home-page"
      className={`page-fullsize ${!visible ? 'hidden' : ''}`}
    >
      <ClockView visible={!allAppsEnabled} />
      <AppsMenuView allAppsEnabled={allAppsEnabled} />
    </section>
  );
};

export default Home;
