import { useState, useEffect } from 'react';

const defaultAppIconUrl = './assets/default_app_112.png';
const cache = new Map();

// TODO: We need to revoke/refresh the icon url when mozApp uninstall/update.
function useMozAppIcon(mozApp) {
  const [iconUrl, setIconUrl] = useState(null);

  // Try to get icon when component is mounted.
  useEffect(() => {
    if (!mozApp) {
      setIconUrl(null);
      return;
    }
    // See if there's a cache available.
    const cacheKey = mozApp.manifestURL;
    if (cache.has(cacheKey)) {
      const cachedIconUrl = cache.get(cacheKey);
      setIconUrl(cachedIconUrl);
      return;
    }
    // Try to fetch the icon from `getIcon` API;
    // Then cache it when success,
    // otherwise fallback to the default icon.
    navigator.mozApps.mgmt
      // TODO: We need to try to find the closest icon size instead of hard-coded.
      .getIcon(mozApp, 112)
      .then((res) => {
        const newIconUrl = (typeof res  === "string") ? res : URL.createObjectURL(res);
        cache.set(cacheKey, newIconUrl);
        setIconUrl(newIconUrl);
      })
      .catch((err) => {
        console.error('getIcon()', mozApp.manifestURL, err);
        setIconUrl(defaultAppIconUrl);
      });
  }, [mozApp]);

  return iconUrl;
}

export default useMozAppIcon;
