# Launcher

## Development

Below you will find some information on how to perform common tasks.

- [Build Options](#build-options)
  - [`make lint`](#make-lint)
  - [`make test`](#make-test)
  - [`make watch`](#make-watch)
  - [`make build`](#make-build)
  - [`make analyze`](#make-analyze)
  - [`make flash`](#make-flash)
  - [`make clean`](#make-clean)
  - [`make distclean`](#make-distclean)

## Build Options

In the project directory, you can run:

### `make lint`

Runs ESLint and Stylelint to detect and highlight potential issues.

### `make test`

Runs Jest for JavaScript unit testing and snapshot testing.

### `make watch`

Runs the app in the development mode.

You can flash the app to check if it works by running `make flash`.

### `make build`

Builds the app for production.

The build is minified and your app is ready to be deployed.

You can flash the app to check if it works by running `make flash`.

### `make analyze`

Analyzes the app bundles and opens a report to see what modules take space.

### `make flash`

Deploys the app and pushes it into the device you attached.

It is identical to `DEVICE_DEBUG=1 NO_BUNDLE=1 APP=launcher make install-gaia`.

### `make clean`

Removes all outputs and build caches throughly.

### `make distclean`

Runs `make clean` and removes `mode_modules` folder.
