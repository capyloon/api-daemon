/* eslint-disable import/no-extraneous-dependencies */
const merge = require('webpack-merge');
const { BundleAnalyzerPlugin } = require('webpack-bundle-analyzer');

const prodConfig = require('./webpack.config.prod.js');

module.exports = merge(prodConfig, {
  optimization: {
    concatenateModules: false
  },
  plugins: [
    new BundleAnalyzerPlugin()
  ]
});
