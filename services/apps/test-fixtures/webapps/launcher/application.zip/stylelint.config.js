module.exports = {
  'extends': 'stylelint-config-standard',
  'rules': {
    'rule-empty-line-before': [
      'always',
      {
        'except': ['first-nested'],
        'ignore': ['after-comment', 'inside-block']
      }
    ],
    'indentation': [
      2,
      {
        'severity': 'warning'
      }
    ],
    'max-empty-lines': 1,
    'max-line-length': 80,
    'selector-type-no-unknown': [
      true,
      {
        ignoreTypes: [
          'kai-textfield',
          'kai-searchbar',
          'kai-separator',
          'kai-actionbar',
          'kai-dialog',
          'kai-pillbutton'
        ]
      }
    ]
  },
  'ignoreFiles': ['**/*.js'],
};
