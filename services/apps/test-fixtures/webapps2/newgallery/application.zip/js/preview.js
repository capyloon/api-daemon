'use strict';
(function (exports) {
  const Preview = {
    header: null,
    actionBar: null,
    previewFile: null,
    initFrames: false,
    previewContainer: null,
    intoFocusView: false,
    actions: {
      share: {
        title: 'Share',
        value: 'share',
        icon: 'share',
        disabled: false
      },
      delete: {
        title: 'Delete',
        value: 'delete',
        icon: 'delete',
        disabled: false
      },
      edit: {
        title: 'Edit',
        value: 'edit',
        icon: 'edit',
        disabled: false
      },
      favoriteOff: {
        title: 'Favorite',
        value: 'favoriteOff',
        icon: 'favorite-off',
        disabled: false
      },
      favoriteOn: {
        title: 'Unfavorite',
        value: 'favoriteOn',
        icon: 'favorite-on',
        disabled: false
      }
    },

    enterPreview(thumbnail) {
      this.previewFile = thumbnail;
      this.getPreviewContainer();
      window.performance.mark('gallery-preview-start');
      if (ScreenLayout.getCurrentLayout('portrait')) {
        this.initPreviewView(View.views.previewView);
        this.updateFrame();
      }
      if (window.performance.getEntriesByName('gallery-preview-start',
        'mark').length > 0) {
        window.performance.mark('gallery-preview-end');
        window.performance.measure('performance-gallery-preview',
          'gallery-preview-start',
          'gallery-preview-end');
        window.performance.clearMeasures('performance-gallery-preview');
        window.performance.clearMarks('gallery-preview-start');
        window.performance.clearMarks('gallery-preview-end');
      }
    },

    exitPreview() {
      this.previewFile = null;
      this.header.removeAttribute('menuoptions');
      if (Frames.showFocusView) {
        Frames.exitFocusView();
      }
      if (View.lastView === View.views.favoriteView) {
        const unfavoriteCount = Favorite.unfavoriteFileNames.length;
        if (unfavoriteCount !== 0) {
          for (let i = 0; i < unfavoriteCount; i++) {
            const name = Favorite.unfavoriteFileNames[i];
            const item = Favorite.thumbnailList.getThumbnail(name);
            Favorite.deletePhoto(item);
          }
        }
        Favorite.unfavoriteFileNames = [];
        const conut = Frames.getThumbnailCount();
        if (!conut) {
          Overlay.showEmptyPage(View.views.favoriteView);
        }
      }
      Frames.clearFrames();
      View.switchView(View.lastView);
    },

    getPreviewContainer() {
      if (!this.previewContainer) {
        this.previewContainer = document.querySelector('#preview');
      }
    },

    updateFrame() {
      if (!this.initFrames) {
        Frames.initFrames();
        this.initFrames = true;
      }
      Frames.clearFrames();
      Frames.updateFrames(this.previewFile);
    },

    initPreviewView(view) {
      this.initView(view);
      this.updateHeaderTitle();
      this.updateOptionmenu();
      this.updateActionbar();
    },

    updatePreview(file) {
      this.previewFile = file;
      this.updateHeaderTitle();
      this.updateOptionmenu();
      this.updateActionbar();
    },

    initView(view) {
      View.lastView = View.currentView;
      View.currentView = view;
      document.body.classList.remove(View.lastView);
      document.body.classList.add(view);
    },

    updateOptionmenu() {
      let optionmenu = [
        Options.items.addAlbum,
        Options.items.fileInfo
      ];
      if (View.lastView === View.views.inAlbumView) {
        optionmenu = [
          Options.items.addAlbum,
          Options.items.removeAlbum,
          Options.items.fileInfo
        ];
      }
      if (this.previewFile.data.metadata.largeSize) {
        optionmenu = [Options.items.fileInfo];
      }
      this.header.setAttribute('menuoptions',
        JSON.stringify(optionmenu));
      Options.items.addAlbum.callback = this.addToAlbum.bind(this);
      Options.items.removeAlbum.callback = this.removeFromAlbum.bind(this);
      Options.items.fileInfo.callback = this.showPreviewFileInfo.bind(this);
    },

    updateHeaderTitle() {
      if (!this.header) {
        this.header = document.querySelector('#preview-header');
      }
      const { date } = this.previewFile.data;
      const text = this.formatDate(date);
      this.header.setAttribute('text',
        text);
    },

    formatDate(time) {
      const formattedTime = new Date(time).toLocaleString(navigator.language,
        {
          year: 'numeric',
          month: '2-digit',
          day: '2-digit'
        });
      return formattedTime;
    },

    updateActionbar() {
      if (!this.actionBar) {
        this.actionBar = document.querySelector('#preview-actionbar');
        this.actionBar.addEventListener('actionbarSelect',
          (e) => {
            this.actionbarSelectCallback(e);
          });
      }
      let actions = [];
      if (this.previewFile.data.metadata.largeSize) {
        actions = [this.actions.delete];
        this.actionBar.setAttribute('actions',
          JSON.stringify(actions));
        return;
      }
      if (this.previewFile.data.metadata.favorite) {
        actions = [
          this.actions.share,
          this.actions.edit,
          this.actions.favoriteOn,
          this.actions.delete
        ];
      } else {
        actions = [
          this.actions.share,
          this.actions.edit,
          this.actions.favoriteOff,
          this.actions.delete
        ];
      }
      this.actionBar.setAttribute('actions',
        JSON.stringify(actions));
    },

    actionbarSelectCallback(e) {
      switch (e.detail.selected) {
        case 'share':
          this.sharePhoto();
          break;
        case 'edit':
          ImageEditView.enterEditView();
          break;
        case 'delete':
          this.deletePhoto();
          break;
        case 'favoriteOff':
          this.favoriteOrUnfavoritePhoto(true);
          break;
        case 'favoriteOn':
          this.favoriteOrUnfavoritePhoto(false);
          break;
      }
    },

    sharePhoto() {
      const { name } = this.previewFile.data;
      PhotoDB.photodb.getFile(name,
        (blob) => {
          LaunchActivity.launchShareApps([blob]);
        });
    },

    favoriteOrUnfavoritePhoto(favorite) {
      const { name } = this.previewFile.data;
      this.previewFile.data.metadata.favorite = favorite;
      PhotoDB.photodb.updateMetadata(name,
        { favorite },
        () => {
          this.updateActionbar();
          if (favorite) {
            this.previewFile.htmlNode.classList.add('favorite');
          } else {
            this.previewFile.htmlNode.classList.remove('favorite');
          }
          const views = [View.views.favoriteView, View.views.inAlbumView];
          if (views.contains(View.lastView)) {
            const item = Photos.thumbnailList.getThumbnail(name);
            item.data.metadata.favorite = favorite;
            if (favorite) {
              item.htmlNode.classList.add('favorite');
            } else {
              item.htmlNode.classList.remove('favorite');
            }
          }
          if (View.lastView === View.views.favoriteView) {
            if (favorite) {
              const index = Favorite.unfavoriteFileNames.indexOf(name);
              Favorite.unfavoriteFileNames.splice(index,
                1);
            } else {
              Favorite.unfavoriteFileNames.push(name);
            }
          }
        });
    },

    deletePhoto() {
      const message = navigator.mozL10n.get('dialog-delete-n-photos',
        { n: 1 });
      Dialog.delete.message = message;
      Dialog.showDialog(Dialog.delete,
        null,
        this.deleteFile.bind(this));
    },

    deleteFile() {
      let item = Frames.getNextItem(Frames.currentFrame.filename);
      if (!item) {
        item = Frames.getPreviousItem(Frames.currentFrame.filename);
      }
      const deleteFile = this.previewFile.data;
      const storage = navigator.getDeviceStorage('pictures');
      const deleteRequest = storage.delete(deleteFile.name);
      deleteRequest.onsuccess = () => {
        Album.someAlbumsRemovePhotos([this.previewFile]);
        Photos.thumbnailList.removeItem(deleteFile,
          View.groupByDate);
        switch (View.lastView) {
          case View.views.inAlbumView:
            Favorite.deletePhoto(deleteFile);
            break;
          case View.views.favoriteView:
            InAlbum.deletePhoto(deleteFile);
            break;
        }
        if (item) {
          this.updatePreview(item);
          this.updateFrame();
        } else {
          View.switchView(View.lastView);
          Overlay.showEmptyPage(View.currentView);
        }
        Message.show('toast-delete-n-photos',
          { n: 1 });
      };
      Dialog.hideDialog();
      deleteRequest.onerror = (e) => {
        console.error('Failed to delete',
          deleteFile.name,
          'from DeviceStorage:',
          e.target.error);
      };
      const { preview } = deleteFile.metadata;
      if (preview && preview.filename) {
        storage.delete(preview.filename);
      }
    },

    addToAlbum() {
      let options = [
        {
          data: {
            id: 'create-new-album',
            name: 'Create new album'
          }
        }
      ];
      if (Album.userCreatedAlbums.length !== 0) {
        options = options.concat(Album.userCreatedAlbums);
      }
      const custom = document.createElement('div');
      custom.setAttribute('slot',
        'custom-view');
      Array.forEach(options,
        (option) => {
          const item = document.createElement('kai-1line-listitem');
          item.setAttribute('text',
            option.data.name);
          item.classList.add('add-to-album');
          item.dataset.id = option.data.id;
          custom.appendChild(item);
          item.addEventListener('click',
            () => {
              Dialog.hideDialog();
              if (option.data.id === 'create-new-album') {
                Album.createNewAlbum();
                return;
              }
              this.addPreviewToAlbum(option.data.id);
            });
        });
      Dialog.showDialog(Dialog.addToAlbum,
        custom);
      Dialog.dialog.classList.add('add-to-dialog');
    },

    addPreviewToAlbum(albumId) {
      const addSuccess = Album.addPhoto(albumId,
        this.previewFile);
      let dataId = null;
      const albumName = Album.albumsFiles[albumId].name;
      if (addSuccess) {
        dataId = 'toast-add-n-photos';
      } else {
        dataId = 'toast-n-photos-already-in-album';
      }
      Message.show(dataId,
        { n: 1, name: albumName });
    },

    removeFromAlbum() {
      const message = navigator.mozL10n.get('dialog-remove-n-photos',
        { n: 1 });
      Dialog.remove.message = message;
      Dialog.showDialog(Dialog.remove,
        null,
        this.removePreviewFromAlbum.bind(this));
    },

    removePreviewFromAlbum() {
      let item = Frames.getNextItem(Frames.currentFrame.filename);
      if (!item) {
        item = Frames.getPreviousItem(Frames.currentFrame.filename);
      }
      InAlbum.deletePhoto(this.previewFile);
      if (item) {
        this.updatePreview(item);
        this.updateFrame();
      } else {
        View.switchView(View.lastView);
        Overlay.showEmptyPage(View.currentView);
      }
      Dialog.hideDialog();
      Album.anAlbumRemovePhotos([this.previewFile],
        InAlbum.albumId);
      Message.show('toast-remove-n-photos',
        { n: 1 });
    },

    showPreviewFileInfo() {
      FileInfo.show();
    }
  };
  exports.Preview = Preview;
}(window));
