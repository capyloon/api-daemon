'use strict';
(function (exports) {
  const Photos = {
    thumbnailList: null,
    container: null,
    firstLoadImages: 6,

    enterPhotos() {
      View.switchView(View.views.photosView);
      const count = Photos.thumbnailList.getCount();
      if (!count) {
        Overlay.showEmptyPage(View.views.photosView);
      } else {
        Overlay.hideEmptyPage();
      }
    },

    initPhotos() {
      this.container = document.querySelector('#thumbnails');
      this.thumbnailList =
        new ThumbnailList(ThumbnailDateGroup,
          this.container);
      this.lazyLoadImage = new LazyLoadImage();
      this.lazyLoadImage.init(this.container);
      Overlay.photosView.emptyBtn.clickCallback =
        LaunchActivity.launchCameraApp.bind(LaunchActivity);
    },

    groupOrUngroupThumbnails(group) {
      View.groupByDate = !!group;
      this.thumbnailList.resetThumbnail(View.groupByDate);
      this.lazyLoadImage.render();
      try {
        const obj = { groupByDate: View.groupByDate };
        localStorage.setItem('groupByDate',
          JSON.stringify(obj));
      } catch (e) {
        console.error('Set groupByDate error:',
          e);
      }
      View.headers.photosView.menuoptions =
        View.groupByDate ? [Options.items.ungroup] : [Options.items.group];
      View.setHeaderMenuoptions(View.views.photosView);
    },

    deletePhotos(deleteFiles, callback, deleteDone) {
      const deleteFileCount = deleteFiles.length;
      let storageSuccess = [];
      let storageError = [];
      const storage = navigator.getDeviceStorage('pictures');
      for (let i = 0; i < deleteFileCount; i++) {
        const item = deleteFiles[i];
        const deleteRequest = storage.delete(item.data.name);
        deleteRequest.onsuccess = () => {
          storageSuccess.push(item);
          const successCount = storageSuccess.length;
          const errorCount = storageError.length;
          if (successCount + errorCount !== deleteFileCount) {
            return;
          }
          for (let j = 0; j < successCount; j++) {
            this.thumbnailList.removeItem(storageSuccess[j].data,
              View.groupByDate);
            if (callback) {
              callback(storageSuccess[j]);
            }
          }
          if (deleteDone) {
            deleteDone(storageSuccess);
            storageSuccess = [];
            storageError = [];
          }
        };
        deleteRequest.onerror = (e) => {
          storageError.push(item);
          console.error('Failed to delete',
            item.data.name,
            'from DeviceStorage:',
            e.target.error);
        };
        const { preview } = item.data.metadata;
        if (preview && preview.filename) {
          storage.delete(preview.filename);
        }
      }
    }
  };
  exports.Photos = Photos;
}(window));
