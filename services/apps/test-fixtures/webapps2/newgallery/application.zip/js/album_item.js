'use strict';
/* global Album, PhotoDB */
function AlbumItem(albumData) {　// eslint-disable-line
  if (!albumData) {
    throw new Error('fileData should not be null or undefined.');
  }
  this.data = albumData;
  this.htmlNode = document.createElement('div');
  this.htmlNode.classList.add('album');
  let { columnCount } = Album;
  if (albumData.isSystem) {
    columnCount = Album.systemColumn;
  }
  this.htmlNode.dataset.columncount = columnCount;
  this.htmlNode.dataset.date = albumData.date;
  this.noCoverPhoto = document.createElement('div');
  this.noCoverPhoto.classList.add('album-no-coverphoto');
  this.icon = document.createElement('i');
  this.icon.setAttribute('data-icon',
    'launcher-gallery');
  this.noCoverPhoto.appendChild(this.icon);
  if (albumData.coverPhoto) {
    PhotoDB.photodb.getFileInfo(albumData.coverPhoto,
      (file) => {
        const { thumbnail } = file.metadata;
        const url = URL.createObjectURL(thumbnail);
        this.htmlNode.style.backgroundImage = `url(${url})`;
      });
  } else {
    this.htmlNode.appendChild(this.noCoverPhoto);
  }
  this.albumName = document.createElement('div');
  this.albumName.classList.add('album-name');
  if (albumData.isSystem) {
    this.albumName.setAttribute('data-l10n-id',
      albumData.name);
  } else {
    this.albumName.innerHTML = albumData.name;
    this.selector = document.createElement('span');
    this.selector.classList.add('album-selector');
    this.htmlNode.appendChild(this.selector);
  }
  this.htmlNode.appendChild(this.albumName);
}
