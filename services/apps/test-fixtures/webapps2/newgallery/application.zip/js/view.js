'use strict';
(function (exports) {
  const View = {
    header: null,
    selectBtn: null,
    selectAllBtn: null,
    selectDoneBtn: null,
    currentView: 'photosView',
    selectedCategorybar: 'photosView',
    lastView: null,
    views: {
      photosView: 'photosView',
      albumsView: 'albumsView',
      inAlbumView: 'inAlbumView',
      favoriteView: 'favoriteView',
      previewView: 'previewView',
      editView: 'editView',
      selectView: 'selectView',
      pickMoreView: 'pickMoreView',
      pickOneView: 'pickOneView',
      emptyView: 'emptyView'
    },
    groupByDate: false,
    SORTTYPE: 0,
    headers: {
      photosView: {
        title: 'PHOTOS',
        type: 'large',
        menuoptions: [Options.items.ungroup]
      },
      albumsView: {
        title: 'ALBUMS',
        type: 'large',
        menuoptions: null
      },
      inAlbumView: {
        title: null,
        type: 'small',
        menuoptions: [
          Options.items.addPhotos,
          Options.items.renameAlbum,
          Options.items.deleteAlbum
        ]
      },
      favoriteView: {
        title: 'FAVORITES',
        type: 'large',
        menuoptions: null
      },
      selectView: {
        title: '0 Selected',
        type: 'small',
        menuoptions: null
      },
      pickMoreView: {
        title: 'Select Photo',
        type: 'small',
        menuoptions: null
      }
    },
    lazyLoadSelectFiles: false,

    getGroupByDataValue() {
      if (localStorage.getItem('groupByDate')) {
        this.groupByDate =
          JSON.parse(localStorage.getItem('groupByDate')).groupByDate;
      } else {
        this.groupByDate = false;
      }
      this.headers.photosView.menuoptions =
        this.groupByDate ? [Options.items.ungroup] : [Options.items.group];
    },

    init() {
      this.eventListener();
      this.getGroupByDataValue();
      this.switchView(this.views.photosView);
      Overlay.showScanning();
    },

    switchView(view) {
      this.lastView = this.currentView;
      this.currentView = view;
      const views = [this.views.selectView];
      if (!views.contains(view)) {
        document.body.classList.remove(this.lastView);
      }
      document.body.classList.add(view);
      this.setHeaderMenuoptions(view);
      this.setHeaderType(view);
      this.setHeaderTitle(view);
    },

    setHeaderMenuoptions(view) {
      const options = this.headers[view].menuoptions;
      if (options) {
        this.header.setAttribute('menuoptions',
          JSON.stringify(options));
      } else {
        this.header.removeAttribute('menuoptions');
      }
    },

    setHeaderType(view) {
      const headType = this.headers[view].type;
      this.header.setAttribute('type',
        headType);
    },

    setHeaderTitle(view) {
      const headTitle = this.headers[view].title;
      this.header.setAttribute('title',
        headTitle);
    },

    categorybarSelectCallback(e) {
      if (this.selectedCategorybar === e.detail.selected) {
        return;
      }
      this.selectedCategorybar = e.detail.selected;
      if (this.selectedCategorybar === this.views.photosView) {
        Photos.enterPhotos();
      } else if (this.selectedCategorybar === this.views.albumsView) {
        Album.enterAlbums();
      } else if (this.selectedCategorybar === this.views.favoriteView) {
        Favorite.enterFavorites();
      }
      if (this.lastView === this.views.favoriteView) {
        Favorite.exitFavorite();
      }
    },

    eventListener() {
      this.header = document.getElementById('header');
      this.selectBtn = document.querySelector('.select-btn');
      this.selectAllBtn = document.querySelector('.select-all');
      this.selectDoneBtn = document.querySelector('.select-done');
      document.addEventListener('categorybarSelect',
        (e) => {
          this.categorybarSelectCallback(e);
        });
      this.selectBtn.addEventListener('click',
        () => {
          if (this.lazyLoadSelectFiles) {
            Selector.enterSelectView();
            return;
          }
          LazyLoader.load(['js/selector.js'],
            () => {
              this.lazyLoadSelectFiles = true;
              Selector.enterSelectView();
            });
        });
      this.selectDoneBtn.addEventListener('click',
        () => {
          Selector.selectDoneCallback();
        });
      this.selectAllBtn.addEventListener('click',
        () => {
          Selector.selectAllCallback();
        });
      document.addEventListener('keydown',
        (e) => {
          if ('Backspace' === e.key) {
            if (Overlay.current === 'scanning') {
              return;
            }
            if (FileInfo.showFileInfo) {
              e.preventDefault();
              FileInfo.hide();
              return;
            }
            if (Dialog.dialog && Dialog.dialog.open) {
              e.preventDefault();
              Dialog.hideDialog();
              return;
            }
            if (this.currentView === this.views.previewView) {
              e.preventDefault();
              Preview.exitPreview();

            } else if (this.currentView === this.views.selectView) {
              e.preventDefault();
              Selector.selectDoneCallback();

            } else if (this.currentView === this.views.inAlbumView) {
              e.preventDefault();
              InAlbum.exitAnAlbum();

            } else if (this.currentView === this.views.pickMoreView) {
              e.preventDefault();
              PickMore.exitPickmoreView();

            } else if (this.currentView === this.views.editView) {
              e.preventDefault();
              ImageEditView.exitEditView();

            }
          }
        });
    }
  };
  exports.View = View;
}(window));
