'use strict';
(function (exports) {
  const FileInfo = {
    labelIds: {
      name: 'fileinfo-name',
      size: 'fileinfo-size',
      type: 'fileinfo-type',
      date: 'fileinfo-date',
      resolution: 'fileinfo-resolution',
      path: 'fileinfo-path',
      url: 'fileinfo-url'
    },
    container: null,
    showFileInfo: false,
    values: null,

    show() {
      this.showFileInfo = true;
      this.init();
      document.body.appendChild(this.container);
    },

    hide() {
      document.body.removeChild(this.container);
      this.container = null,
      this.values = null,
      this.showFileInfo = false;
    },

    init() {
      this.container = document.createElement('div');
      this.container.classList.add('fileinfo-container');
      this.header = document.createElement('kai-header');
      this.header.title = navigator.mozL10n.get('fileinfo-title');
      this.valuesContainer = document.createElement('div');
      this.valuesContainer.classList.add('fileinfo-values');
      this.container.appendChild(this.header);
      this.container.appendChild(this.valuesContainer);
      this.getValues();
      let i = null;
      for (i in this.labelIds) {
        const itemNode = document.createElement('div');
        const label = navigator.mozL10n.get(this.labelIds[i]);
        const labelNode = document.createElement('div');
        labelNode.classList.add('fileinfo-label');
        labelNode.innerHTML = label;
        const valueNode = document.createElement('div');
        valueNode.classList.add('fileinfo-value');
        if (!this.values[i]) {
          itemNode.classList.add('hidden');
        } else {
          valueNode.innerHTML = this.values[i];
        }
        itemNode.appendChild(labelNode);
        itemNode.appendChild(valueNode);
        this.valuesContainer.appendChild(itemNode);
      }
    },

    getValues() {
      const file = Preview.previewFile.data;
      this.values = {
        name: file.name.split('/').pop(),
        size: MediaUtils.formatSize(file.size),
        type: file.type,
        date: Preview.formatDate(file.date),
        resolution: `${file.metadata.width}x${file.metadata.height}`,
        path: this.getDisplayPath(file.name),
        url: file.url ? file.url : null
      };
    },

    getDisplayPath(displayPath) {
      const displayArr = displayPath.split('/');
      if (displayArr[1] === 'sdcard1') {
        displayArr[1] = navigator.mozL10n.get('fileinfo-sd-card');
      } else {
        displayArr[1] = navigator.mozL10n.get('fileinfo-internal');
      }
      displayPath = displayArr.join('/');
      return displayPath;
    }
  };
  exports.FileInfo = FileInfo;
}(window));
