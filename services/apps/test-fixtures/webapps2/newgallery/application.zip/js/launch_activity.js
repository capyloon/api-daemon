'use strict';
(function (exports) {
  const LaunchActivity = {
    triggerCamera: false,
    intoCameraTimeOut: null,
    shareProcess: false,
    intoShareTimeOut: null,

    launchCameraApp() {
      if (this.triggerCamera) {
        return;
      }
      this.triggerCamera = true;
      if (this.intoCameraTimeOut) {
        clearTimeout(this.intoCameraTimeOut);
      }
      this.intoCameraTimeOut = setTimeout(() => {
        this.triggerCamera = false;
      }, 1000);
      const activity = new MozActivity({
        name: 'record',
        data: {
          type: 'photos'
        }
      });
      activity.onsuccess = () => {
        this.triggerCamera = false;
      };
      activity.onerror = () => {
        this.triggerCamera = false;
      };
    },

    launchShareApps(blobs) {
      if (blobs.length === 0) {
        return;
      }
      const names = [],
        types = [],
        fullpaths = [];
      blobs.forEach((blob) => {
        let { name } = blob;
        if (!name && blobs.length === 1) {
          name = blobName;
        }
        fullpaths.push(name);
        name = name.substring(name.lastIndexOf('/') + 1);
        names.push(name);
        let { type } = blob;
        if (type) {
          type = type.substring(0,
            type.indexOf('/'));
        }
        types.push(type);
      });
      let type = 'application/*';
      const allTypesSame = types.every((t) => t === types[0]);
      if (types.length === 1 || allTypesSame) {
        type = `${types[0]}/*`;
      }
      const activity = new MozActivity({
        name: 'share',
        data: {
          type,
          number: blobs.length,
          blobs,
          filenames: names,
          filepaths: fullpaths
        }
      });
      this.shareProcess = true;
      activity.onsuccess = () => {
        if (this.intoShareTimeOut) {
          clearTimeout(this.intoShareTimeOut);
        }
        this.intoShareTimeOut = setTimeout(() => {
          this.shareProcess = false;
        }, 500);
      };
      activity.onerror = (e) => {
        this.shareProcess = false;
        if (activity.error.name === 'NO_PROVIDER') {
          const msg = navigator.mozL10n.get('share-noprovider');
          alert(msg);
        } else {
          console.warn('share activity error:',
            activity.error.name);
        }
      };
    },

    launchSettings() {
      new MozActivity({
        name: 'configure',
        data: {
          target: 'device',
          section: 'mediaStorage'
        }
      });
    }
  };
  exports.LaunchActivity = LaunchActivity;
}(window));
