'use strict';
/* global ImageProcessor, ImageEditView*/
(function (exports) { // eslint-disable-line
  const ImageCorrector = {
    tools: null,

    enterCorrectionView() {
      this.addEventListeners();
    },

    exitEditMode() {
      if (!this.tools) {
        return;
      }
      const tools = this.tools.querySelectorAll('.image-corrector');
      [].forEach.call(tools, (el) => {
        if (el.dataset.tool === 'off') {
          el.classList.add('focus');
        } else {
          el.classList.remove('focus');
        }
      });
      this.removeEventListeners();
    },

    addEventListeners() {
      if (this.tools) {
        return;
      }
      this.tools = document.querySelector('#image-corrector-tools');
      this.correctorToolsClickHandel = this.correctImage.bind(this);
      this.tools.addEventListener('click',
        this.correctorToolsClickHandel);
    },

    removeEventListeners() {
      this.tools.removeEventListener('click',
        this.correctorToolsClickHandel);
      this.tools = null;
      this.correctorToolsClickHandel = null;
    },

    correctImage(e) {
      const { target } = e;
      if (!target.dataset.tool || target.classList.contains('focus')) {
        return;
      }
      const tools = this.tools.querySelectorAll('.image-corrector');
      [].forEach.call(tools, (el) => {
        el.classList.remove('focus');
      });
      target.classList.add('focus');
      ImageEditView.editSettings.enhance.rgbMinMaxValues =
        target.dataset.tool === 'on'
          ? ImageEditView.imageEditor.autoEnhanceValues
          : ImageProcessor.default_enhancement;
      ImageEditView.imageEditor.edit();
      ImageEditView.changeSaveBtnState(ImageEditView.imageEditor.isEdited());
    }

  };
  exports.ImageCorrector = ImageCorrector;
}(window));
