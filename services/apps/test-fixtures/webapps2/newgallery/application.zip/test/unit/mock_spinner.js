'use strict';
/* exported MockSpinner */

var MockSpinner = {
  show: sinon.spy(),
  hide: sinon.spy()
};
