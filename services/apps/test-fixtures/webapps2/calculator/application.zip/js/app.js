{
  let panel = new Panel();
  if (!panel.lang) {
    panel.lang = navigator.language;
    panel.formatNumber('1.1', true);
  }
  let keyBoard = new KeyBoard(panel);
  keyBoard.init();
  panel.getStorage();
}