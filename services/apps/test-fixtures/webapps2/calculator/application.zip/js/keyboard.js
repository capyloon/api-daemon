class KeyBoard {
  constructor(panel) {
    this.panel = panel;
    this.calculate = new Calculator();
    this.backTimeout = null;
    this.backInterval = null;
    this.ACTIVE_LONG_PRESS_TIMEOUT = 300;
    this.SERIES_PRESS_TIMEOUT = 100;
  }

  init() {
    document.addEventListener('keydown', e => {
      if (e.key === 'Backspace') {
        this.panel.addStorage({
          showResult: this.panel.showResult,
          secondOperand: this.panel.secondOperandValue,
          operator: this.panel.operatorValue,
          firstOperand: this.panel.firstOperandValue
        });
      }
    });
    let buttonAry = Array.from(document.getElementsByClassName('button'));
    buttonAry.map(element => element.addEventListener('click', () => {
      let key = element.getAttribute('key');
      this.inputStatus = this.panel.getStatus();
      switch (key) {
        case '0':
        case '1':
        case '2':
        case '3':
        case '4':
        case '5':
        case '6':
        case '7':
        case '8':
        case '9':
        case '.':
          this.appendDigit(key);
          break;
        case '±':
          this.changeSign();
          break;
        case '−':
        case '+':
        case '×':
        case '÷':
          this.handleOperator(key);
          break;
        case '=':
          this.handleEqual();
          break;
        case '%':
          this.handlePercent();
          break;
        case 'AC':
          this.panel.addStorage(null);
          this.panel.showResult = false;
          this.panel.updatePanel({ firstOperand: '', secondOperand: '0', operator: '' });
          break;
        default:
          break;
      }
    }));
    this.panel.backBtn.addEventListener('touchstart', () => {
      this.clear();
      this.backTimeout = setTimeout(() => {
        this.serialClear();
      }, this.ACTIVE_LONG_PRESS_TIMEOUT);
    });
    this.panel.backBtn.addEventListener('touchend', () => {
      clearTimeout(this.backTimeout);
      clearInterval(this.backInterval);
    });
  }

  serialClear() {
    this.backInterval = setInterval(() => {
      this.clear();
    }, this.SERIES_PRESS_TIMEOUT);
  }

  appendDigit(digit) {
    let secondOperand;
    if (this.inputStatus === STATUS.RESULT) {
      secondOperand = '';
    } else {
      secondOperand = this.panel.secondOperandValue;
    }

    if (this.calculate.exceedLimit(secondOperand)) {
      return;
    }
    if ('.' !== digit) {
      if ('0' === secondOperand) {
        secondOperand = '';
      } else if ('-0' === secondOperand) {
        secondOperand = '-';
      }
    } else {
      if (secondOperand.indexOf('.') !== -1) {
        return;
      }
      secondOperand = '-' === secondOperand ? '-0' : (secondOperand || '0');
    }
    secondOperand += digit;
    this.panel.showResult = false;
    this.panel.secondOperandValue = secondOperand;
  }

  changeSign() {
    let operand = this.panel.secondOperandValue;
    let sign = operand.substring(0, 1);
    if (navigator.mozL10n.get('error') !== operand) {
      if (!operand) {
        operand = '-0';
      } else if ('-' === sign) {
        operand = operand.substring(1, operand.length);
      } else {
        operand = '-' + operand;
      }
      this.panel.secondOperandValue = operand;
    }
  }

  handleOperator(operator) {
    this.panel.showResult = false;
    switch (this.inputStatus) {
      case STATUS.FIRST_OPERAND:
      case STATUS.RESULT:
        if (navigator.mozL10n.get('error') !== this.panel.secondOperandValue) {
          let currentValue = this.panel.secondOperandValue;
          this.panel.updatePanel({ firstOperand: currentValue, secondOperand: '', operator });
        } else {
          this.panel.showResult = true;
        }
        break;
      case STATUS.OPERATOR:
        this.panel.operatorValue = operator;
        break;
      case STATUS.SECOND_OPERAND:
        const result = this.panel.liftResult();
        if (navigator.mozL10n.get('error') !== result) {
          this.panel.updatePanel({ firstOperand: result, secondOperand: '', operator });
        } else {
          this.panel.updatePanel({ firstOperand: '', secondOperand: result, operator: '' });
          this.panel.showResult = true;
        }
        break;
    }
  }

  handleEqual() {
    let secondOperand;
    switch (this.inputStatus) {
      case STATUS.FIRST_OPERAND:
        secondOperand = this.panel.secondOperandValue;
        break;
      case STATUS.OPERATOR:
        secondOperand = this.panel.firstOperandValue;
        break;
      case STATUS.SECOND_OPERAND:
        secondOperand = this.panel.liftResult();
        break;
      default:
        return {};
    }
    this.panel.showResult = true;
    this.panel.updatePanel({ firstOperand: '', secondOperand, operator: '' });
  }

  clear() {
    this.inputStatus = this.panel.getStatus();
    let operand = this.panel.secondOperandValue;
    let len = operand.length;
    let sign = operand.substring(0, 1);
    switch (this.inputStatus) {
      case STATUS.FIRST_OPERAND:
      case STATUS.SECOND_OPERAND:
        if (this.inputStatus === STATUS.SECOND_OPERAND) {
          if ('0' === operand) {
            this.panel.secondOperandValue = '';
            return;
          }
        }
        if (len === 1 || '-0' === operand) {
          this.panel.secondOperandValue = '0';
        } else if (len === 2 && '-' === sign) {
          this.panel.secondOperandValue = '-0';
        } else {
          this.panel.secondOperandValue = operand.substring(0, len - 1);
        }
    }
  }

  handlePercent() {
    switch (this.inputStatus) {
      case STATUS.FIRST_OPERAND:
      case STATUS.SECOND_OPERAND:
      case STATUS.RESULT:
        let operand = this.panel.secondOperandValue;
        if ('-0' !== operand && '0' !== operand && navigator.mozL10n.get('error') !== operand) {
          this.panel.secondOperandValue = this.calculate.calculate(operand, '100', '÷');
        }
    }
  }
}