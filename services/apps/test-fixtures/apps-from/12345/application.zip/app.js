window.addEventListener("load", function() {
  console.log("12345!");
});
